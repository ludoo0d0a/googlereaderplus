

var grp_fixwidth = function() {
	GM_addStyle(".entry .entry-body, .entry .entry-title{ max-width: 100% !important; }");
};
