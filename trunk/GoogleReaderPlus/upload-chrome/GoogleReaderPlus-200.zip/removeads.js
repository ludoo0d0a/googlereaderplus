//remove ads
var grp_removeads = function() {
	function removeAds() {
		var i;
		
		// DIV#tads
		var ads = document.getElementById("tads");
		if (ads) {
			ads.parentNode.removeChild(ads);
		}
		// Remove Search-Tracking 
		var links = document.getElementsByTagName("a");
		if (links) {
			for ( i = 0; i < links.length; i++) {
				var link = links[i];
				if (link.className == "l") {
					link.removeAttribute("onmousedown");
				}
				if (/feedsportal\.com|doubleclick\.net|\/ads/.test(link.href)) {
					link.parentNode.removeChild(link);
				}
			}
		}

		// Remove Right-side Ads
		var iframe = document.getElementsByTagName("iframe");
		if (iframe) {
			for (  i = 0; i < iframe.length; i++) {
				var s = iframe[i].src;
				if (/feedsportal\.com|doubleclick\.net|googlesyndication.com\/pagead\/ads/.test(s)) {
					iframe[i].height = 0;
					iframe[i].width = 0;
					iframe[i].src = '';
				}
				
			}
		}
	}

	var e = document.getElementById('entries');
	if (e) {
		e.addEventListener('DOMNodeInserted', function() {
			removeAds();
		}, false);
	}
	removeAds();//remove ads anyway on start

};
