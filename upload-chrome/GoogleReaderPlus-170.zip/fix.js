// ==UserScript==
// @name           Google Reader: Fixer
// @description    Fix all missing images in enclosures.
// @author henrah / LudoO(xeoos.fr) 
// @namespace      http://www.pitaso.com
// @include        htt*://www.google.*/reader/view*
// ==/UserScript==

function get_elements(doc, xpath){
        var r = doc.evaluate(xpath, doc, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        for (var i = 0,l = r.snapshotLength, res = new Array(l);i<l;i++) res[i] = r.snapshotItem(i);
        return res;
}
function oeach(list, callback) {
	Array.prototype.forEach.call(list, callback);
};

(function () {

    function GoogleReaderFixer(){
        this.fixEnclosures();
        //this.fixWidth();
    };
    
    GoogleReaderFixer.prototype.fixWidth = function() {
      GM_addStyle(".entry .entry-body, .entry .entry-title{ max-width: 100% !important; }");
    };
    
    GoogleReaderFixer.prototype.fixEnclosures = function() {
      var nodes = get_elements(document, "//a[span[@class='view-enclosure']]");
      if (!nodes || !nodes.length){
        return;
      }
 
      oeach(nodes, function(o){
        var div = document.createElement('div');
        div.className = "item-pict";
        var img = document.createElement('img');
        div.appendChild(img);
        img.src = o.href;
        var p = o.parentNode.parentNode;
        p.parentNode.replaceChild(div, p);
      });
    };
    
    var e = document.getElementById('entries');
    if (e){
      e.addEventListener('DOMNodeInserted', function(){ new GoogleReaderFixer(); }, false);
    }
})();



