//fix width of entry
var grp_fixwidth = function() {
	GM_addStyle(".entry .entry-body, .entry .entry-title{ display: inline !important; max-width: 100% !important; }");
};
