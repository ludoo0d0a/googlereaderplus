// unreadcount

var grp_unreadcount = function() {
	var css = '.lhn-section-no-unread-counts .unread-count{display:inline !important}';
	GM_addStyle(css);
};