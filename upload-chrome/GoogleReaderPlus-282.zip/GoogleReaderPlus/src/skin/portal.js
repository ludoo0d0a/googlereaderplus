//Portal theme

GRP.portal = function() {
	var css = '.entry{float:left;max-width:400px;padding:2px!important;}.entry .entry-title {font-size:100%!important;}.entry .card-bottom{display:none;}#scroll-filler{float:left;}';
	GM_addStyle(css);
	
	fireResize();
};