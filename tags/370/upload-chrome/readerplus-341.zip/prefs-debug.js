/* ReaderPlus Chrome Extension by LudoO */

/**
 * Crossbrowser implementation for native browser
 *
 * @param {Object} a
 * @param {Object} fn
 */
var mycore = {
    env: {
        background: false,
        chrome: (typeof chrome !== "undefined" && chrome.extension),
        safari: (typeof safari !== "undefined"),
        prefix: '',
        autoparse: true
    },
    application: {
        sendRequest: function(a, fn, b){
            if (mycore.env.chrome) {
            
            } else if (mycore.env.safari) {
                safari.application.addEventListener(a.message, fn, false);
            }
        }
        
    },
    extension: {
        sendRequest: function(){
            //to bg
            var guid = false, a, fn, l = arguments.length;
            if (l > 2) {
                guid = arguments[0];
                a = arguments[1];
                fn = arguments[2];
            } else {
                a = arguments[0];
                fn = arguments[1];
            }
            
            if (mycore.env.chrome) {
                if (guid) {
                    if (fn) {
                        chrome.extension.sendRequest(guid, a, fn);
                    } else {
                        chrome.extension.sendRequest(guid, a);
                    }
                } else {
                    if (fn) {
                        chrome.extension.sendRequest(a, fn);
                    } else {
                        chrome.extension.sendRequest(a);
                    }
                }
                //chrome.extension.sendRequest(arguments);
            } else if (mycore.env.safari) {
                safari.self.addEventListener('crossaction', function(e){
                    var a = e;
                    a.message = a.name;
                    delete a.name;
                    fn(a);
                }, false);
                safari.self.tab.dispatchMessage('crossaction', a);
            }
        },
        onRequest: {
            addListener: function(fn){
                //from bg
                if (mycore.env.chrome) {
                    chrome.extension.onRequest.addListener(fn);
                } else if (mycore.env.safari) {
                    safari.application.addEventListener('crossaction', fn, false);
                }
            }
        },
        onRequestExternal: {
            addListener: function(fn){
                if (mycore.env.chrome) {
                    chrome.extension.onRequestExternal.addListener(fn);
                } else if (mycore.env.safari) {
                    safari.application.addEventListener('crossaction', fn, false);
                }
            }
        }
    },
    page: {
        listen: function(cb){
			if (mycore.env.chrome) {
				chrome.extension.onConnect.addListener(function(port){
					port.onMessage.addListener(cb);
				});
			}
		},
		postMessage: function(msg, cb, options){
            function post(msg, cb, options, tab){
                if (mycore.env.chrome) {
                    var port = chrome.tabs.connect(tab.id);
                    port.postMessage({
                        message: msg,
                        tab: tab.tabId,
                        options: options
                    });
                    port.onMessage.addListener(cb);
                } else if (mycore.env.safari) {
                    //safari
                }
            }
            
            if (options && options.tab) {
                post(msg, cb, options, tab);
            } else {
                mycore.tabs.getSelected(null, function(tab){
                    post(msg, cb, options, tab);
                });
            }
            
        }
    },
    tabs: {
        create: function(options){
            if (mycore.env.chrome) {
                chrome.tabs.create(options);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        get: function(id, fn){
            if (mycore.env.chrome) {
                chrome.tabs.get(id, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        getSelected: function(options, fn){
            if (mycore.env.chrome) {
                chrome.tabs.getSelected(options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        update: function(id, options, fn){
            if (mycore.env.chrome) {
                chrome.tabs.update(id, options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        executeScript: function(id, options){
            if (mycore.env.chrome) {
                chrome.tabs.executeScript(id, options);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        onRemoved: {
            addListener: function(fn){
                if (mycore.env.chrome) {
                    chrome.tabs.onRemoved.addListener(fn);
                } else if (mycore.env.safari) {
                    //safari
                }
            }
        }
    },
    windows: {
        getAll: function(options, fn){
            if (mycore.env.chrome) {
                chrome.windows.getAll(options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        }
    },
    storage: {
        getItem: function(name, def, cb){
            var v = null;
            if (mycore.env.chrome) {
                if (cb && !mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'get',
                        name: name
                    }, function(o){
                        cb(o || def);
                    });
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    v = localStorage.getItem(name);
                }
            } else if (mycore.env.safari) {
                v = localStorage.getItem(name);
                //return safari.extension.settings.getItem(name);
            }
            if (v && typeof v === 'string' && mycore.env.autoparse) {
                try {
                    v = JSON.parse(v);
                } catch (e) {
                    //
                }
            }
            v = v || def;
            if (cb && typeof v === 'function') {
                cb(v);
            }
            return v;
        },
        removeItem: function(name){
            if (mycore.env.chrome) {
                if (!mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'remove',
                        name: name
                    }, cb);
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    localStorage.removeItem(name);
                }
            } else if (mycore.env.safari) {
                localStorage.removeItem(name);
            }
        },
        setItem: function(name, value, cb){
            var s = value;
            if (s && mycore.env.autoparse && typeof s === 'object') {
                s = JSON.stringify(s);
            }
            if (mycore.env.chrome) {
                if (cb !== false && !mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'set',
                        name: name,
                        value: value
                    }, cb);
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    localStorage.setItem(name, s);
                }
            } else if (mycore.env.safari) {
                localStorage.setItem(name, s);
            }
        },
        key: function(i){
            if (mycore.env.chrome) {
                return localStorage.key(i);
            } else if (mycore.env.safari) {
                return localStorage.key(i);
                //return safari.extension.settings.key(i);
            }
        },
        getLength: function(cb){
            var v = -1;
            if (mycore.env.chrome) {
                v = localStorage.length;
            } else if (mycore.env.safari) {
                v = localStorage.length;
                //return safari.extension.settings.length;
            }
            if (cb && typeof v === 'function') {
                cb(v);
            }
            return v;
        },
        clear: function(){
            localStorage.clear();
        }
    },
    getUrl: function(path){
        if (mycore.env.chrome) {
            return 'chrome-extension://' + mycore.getGUID() + path;
        } else if (mycore.env.safari) {
            return safari.extension.baseURI;
            //return 'safari-extension://' + mycore.getGUID() + path;
        }
    },
    getGUID: function(){
        if (mycore.env.chrome) {
            var url = chrome.extension.getURL('bg.html');
            var m = /:\/\/(\w+)/.exec(url);
            return m[1];
        } else if (mycore.env.safari) {
            //TODO
            var namespace = 'com.pitaso.readerplus';
            var guid = '37PA8NKYKP';
            return namespace + '-' + guid;
        }
    },
    getLocalPath: function(){
        return mycore.getProtocol() + mycore.getGUID();
    },
    getProtocol: function(){
        if (mycore.env.chrome) {
            return 'chrome-extension://';
        } else if (mycore.env.safari) {
            return 'safari-extension://';
        }
    }
};

//
// Global util functions
//
function hasClass(el, clazz){
    if (!el || !el.className) {
        return false;
    }
    var reClassname = new RegExp("(^|\\s)" + clazz + "(\\s|$)");
    return (reClassname.test(el.className));
}

function addClass(el, clazz, checked){
    if (checked && hasClass(el, clazz)) {
        return;
    }
    if (el) {
        el.className = (el.className || '') + ' ' + clazz;
    }
}

function addClassChecked(el, clazz){
    addClass(el, clazz, true);
}

function addClassIf(el, cls, status, cls2){
    if (typeof status === 'string') {
        cls2 = status;
        status = null;
    }
    if (typeof status === 'undefined' || status === null) {
        status = !hasClass(el, cls);
    }
    if (status) {
        addClass(el, cls, true);
        if (cls2) {
            removeClass(el, cls2);
        }
    } else {
        removeClass(el, cls);
        if (cls2) {
            addClass(el, cls2);
        }
    }
}

function addAttr(el, name, value){
    var attr = document.createAttribute(name);
    attr.value = value;
    el.attributes.setNamedItem(attr);
}

function findParentNode(eel, etag, clazz){
    var tag = etag.toUpperCase();
    var el = eel.parentNode;
    if (clazz) {
        // Find first element's parent node matching tag and className
        while (el && el.tagName !== 'BODY' && (el.tagName !== tag || !hasClass(el, clazz))) {
            // console.log(el.tagName+'.'+el.className);
            el = el.parentNode;
            /*
             * if (!el){ console.log('el null for clazz '+clazz ); }
             */
        }
    } else {
        while (el && el.tagName !== 'BODY' && el.tagName !== tag) {
            el = el.parentNode;
        }
    }
    return ((el && el.tagName !== 'BODY') ? el : false);
}

function getFirstNode(el){
    var o = el.firstChild;
    //if (typeof o == "HTMLDivElement"){
    if (o && o.nodeType == 1) {
        return o;
    }
    //
    //while(typeof o !== "undefined" && typeof o !== "HTMLDivElement"){
    while (typeof o !== "undefined" && o.nodeType !== 1) {
        o = o.nextSibling;
    }
    return o;
}

function getIndex(el){
    var pos = 0, o = el;
    while ((o = o.previousSibling)) {
        pos++;
    }
    return (pos + 1);
}

function getPos(obj){
    var output = {};
    var mytop = 0, myleft = 0;
    while (obj) {
        mytop += obj.offsetTop;
        myleft += obj.offsetLeft;
        obj = obj.offsetParent;
    }
    output.left = myleft;
    output.top = mytop;
    return output;
}

//native getElementsByClassName
function getFirstElementByClassName(root, clazz){
	return root.getElementsByClassName(clazz)[0];
}

function getElementText(root, cls, html, firstchild){
    var txt = '', el = getFirstElementByClassName(root || document, cls);
    if (el) {
        if (firstchild) {
            el = el.firstChild;
        }
        if (html) {
            txt = el.innerHTML;
        } else {
            txt = el.innerText || el.textContent;
        }
    }
    return txt;
}

function copyAttributes(src, dest){
    var ats;
    if (src && dest && src.attributes && src.attributes.length > 0) {
        for (var i = 0, len = src.attributes.length; i < len; i++) {
            ats = src.attributes[i];
            addAttr(dest, ats.nodeName, ats.nodeValue);
        }
    }
}

/**
 *
 * @param {Object} root
 * @param {Object} tag
 * @param {Object} clazz
 * @deprecated use getFirstElementByClassName
 */
function getFirstElementMatchingClassName(root, tag, clazz){
    var elements = root.getElementsByTagName(tag);
    var i = 0;
    while (elements[i] && !hasClass(elements[i], clazz)) {
        i++;
    }
    return ((!elements[i]) ? null : (elements[i]));
}

function getLastElementMatchingClassName(root, tag, clazz){
    var elements = root.getElementsByTagName(tag);
    var i = elements.length, j = 0;
    while (i >= 0 && elements[i] && !hasClass(elements[i], clazz)) {
        i--;
    }
    return ((i < 0 || !elements[i]) ? null : (elements[i]));
}

function getElementsByClazzName(clazz, itag, ielm){
    var tag = itag || "*";
    var elm = ielm || document;
    var elements = (tag == "*" && elm.all) ? elm.all : elm.getElementsByTagName(tag);
    var returnElements = [];
    var current;
    var length = elements.length;
    for (var i = 0; i < length; i++) {
        current = elements[i];
        if (hasClass(current, clazz)) {
            returnElements.push(current);
        }
    }
    return returnElements;
}

function getElements(xpath, context){
    var res = false, doc = (context) ? context.ownerDocument : document;
    try {
        var r = doc.evaluate(xpath, (context || doc), null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        for (var i = 0, l = r.snapshotLength, res = new Array(l); i < l; i++) {
            res[i] = r.snapshotItem(i);
        }
    } catch (e) {
        console.error('xpath error : ' + xpath);
    }
    return res;
}

function serializeXml(nodes){
    var html = '';
    nodes.forEach(function(node){
        html += node.outerHTML;
    });
    return html;
}

/*
 * From jQuery
 */
function serializePost(a, traditional){
    var e = encodeURIComponent, s = [];
    if (isArray(a) || a.jquery) {
        forEeach(a, function(){
            add(this.name, this.value);
        });
    } else {
        for (var prefix in a) {
            buildParams(prefix, a[prefix]);
        }
    }
    return s.join("&").replace(/%20/g, "+");
    
    function buildParams(prefix, obj){
        if (isArray(obj)) {
            iterate(obj, function(i, v){
                if (traditional || /\[\]$/.test(prefix)) {
                    add(prefix, v);
                } else {
                    buildParams(prefix + "[" + (typeof v === "object" || isArray(v) ? i : "") + "]", v);
                }
            });
            
        } else if (!traditional && obj != null && typeof obj === "object") {
            // Serialize object item.
            iterate(obj, function(k, v){
                buildParams(prefix + "[" + k + "]", v);
            });
            
        } else {
            // Serialize scalar item.
            add(prefix, obj);
        }
    }
    
    function add(key, value){
        // If value is a function, invoke it and return its value
        value = (typeof value === 'function') ? value() : value;
        s[s.length] = e(key) + "=" + e(value);
    }
}

function get_id(id){
    return document.getElementById(id);
}

function getElementValue(query, context){
    var doc = (context) ? context.ownerDocument : document;
    return doc.evaluate(query, (context || doc), null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

function parseXml(xmlText){
    var dom = new DOMParser().parseFromString(xmlText, "application/xml");
    //urlinput.value = dom.getElementsByTagName('shortUrl')[0].textContent;
    return dom;
}

if (typeof Array.forEach === "undefined") {
    Array.forEach = function(arr, fn){
        Array.prototype.forEach.call(arr, fn);
    };
}
function insertAfter(el, ref){
    var next = ref.nextSibling;
    if (next) {
        insertBefore(el, next);
    } else {
        ref.parentNode.appendChild(el);
    }
}

function insertBefore(el, ref){
    ref.parentNode.insertBefore(el, ref);
}

function insertFirst(el, ref){
    if (ref.firstChild) {
        insertBefore(el, ref.firstChild);
    } else {
        ref.parentNode.appendChild(el);
    }
}

function remove(el){
    if (el && el.parentNode) {
        el.parentNode.removeChild(el);
    }
}

/**
 * Strings
 */
function normalizeUrl(url){
    if (!(/^http(s)?:/i.test(url))) {
        return 'http://' + url;
    } else {
        return url;
    }
}

//without parameter
function cleanUrl(url){
    var m = /([^\?]+)\??(.*)/.exec(url);
    if (m) {
        return m[1];
    } else {
        return url;
    }
}

function ellipsis(text, max){
    var match = text || '';
    max = max || 24;
    if (match.length > max) {
        match = match.substr(0, max - 3) + '...';
    }
    return match;
}

String.prototype.toMaj = function(){
    return this.replace(/(^\w)/, function(m){
        return m.toUpperCase();
    });
};

//To Camel Case
String.prototype.toCamel = function(){
    return this.replace(/(\-[a-z])/g, function($1){
        return $1.toUpperCase().replace('-', '');
    });
};
//To Dashed from Camel Case
String.prototype.toDash = function(){
    return this.replace(/([A-Z])/g, function($1){
        return "-" + $1.toLowerCase();
    });
};
//To Underscore from Camel Case
String.prototype.toUnderscore = function(){
    return this.replace(/([A-Z])/g, function($1){
        return "_" + $1.toLowerCase();
    });
};
function isArray(obj){
    return (obj && obj.constructor == Array);
}

/**
 * Shortcuts
 *
 */
/**
 *
 * @param fn
 * @param keys
 *  [{keycode, shift, ctrl, alt}]
 * @return
 */
function initKey(keys){
    document.addEventListener('keydown', function(e){
        var target = e.target;
        var tag = target.tagName;
        //console.log('keydown on '+tag+'.'+(tag.className||''));
        if (tag !== 'INPUT' && tag !== 'SELECT' && tag !== 'TEXTAREA') {
            if (!isArray(keys)) {
                keys = [keys];
            }
            for (var i = 0, len = keys.length; i < len; i++) {
                var k = keys[i];
                if (k.keyCode == e.keyCode &&
                ((k.shiftKey && e.shiftKey) || (!k.shiftKey && !e.shiftKey)) &&
                ((k.ctrlKey && e.ctrlKey) || (!k.ctrlKey && !e.ctrlKey)) &&
                ((k.altKey && e.altKey) || (!k.altKey && !e.altKey))) {
                    e.preventDefault();
                    //e.stopPropagation();
                    //k.fn(e);
                    if (!target.locked) {
                        //console.log('run fn for keyCode='+k.keyCode);
                        k.fn(e);
                        target.locked = true;
                        window.setTimeout(function(){
                            target.locked = false;
                        }, 300);
                    } else {
                        console.log('LOCK run fn for keyCode=' + k.keyCode);
                    }
                    break;
                }
            }
        }
    }, false);
}

function notEmpty(o){
    if (o) {
        if (isArray(o) && o.length > 0) {
            return o;
        } else if (typeof o === "object" && !isObjectEmpty(o)) {
            return o;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function isFunction(fn){
    return (fn && typeof fn === 'function');
}


function isObjectEmpty(o){
    if (!o) {
        return true;
    }
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        return false;
    }
    return true;
}

function findInArray(a, value){
    for (var i = 0, len = a.length; i < len; i++) {
        if (a[i] === value) {
            return i;
        }
    }
    return false;
}

function find(o, key, value){
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (o[p][key] === value) {
            return o[p];
        }
    }
    return false;
}

function findre(o, key, re){
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (re.test(o[p][key])) {
            return o[p];
        }
    }
    return false;
}

function getCount(o){
    var count = 0;
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        count++;
    }
    return count;
}

function returnItemAtPosition(o, i){
    var count = 0;
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (count == i) {
            return o;
        }
    }
    return false;
}

function randomselect(ar){
    if (isArray(ar)) {
        return ar[Math.round(Math.random() * (ar.length - 1))];
    } else if (typeof ar == 'object') {
        var i = Math.round(Math.random() * (getCount(ar) - 1));
        return returnItemAtPosition(ar, i);
    } else {
        return false;
    }
    
}

function removeClass(el, classname){
    //todo: use regex word boundary
    var s = (el.className || '').split(' ');
    for (var i = 0, len = s.length; i < len; i++) {
        if (s[i] == classname) {
            s[i] = '';
        }
    }
    el.className = s.join(' ').trim();
//el.className = el.className.replace(classname, '').trim();
}

function toggleClass(el, classDelete, classAdd){
    removeClass(el, classDelete);
    addClass(el, classAdd);
}

function fireResizeDefer(){
    window.setTimeout(fireResize, 500);
}

function fireResize(){
    fitHeight('sub-tree');
    fitHeight('entries', 'viewer-footer');
}

function fitHeight(id, bottom){
    var el = document.getElementById(id);
    var h = findTop(el);
    if (bottom) {
        var elb = document.getElementById(bottom);
        if (elb) {
            h -= elb.clientHeight;
        }
    }
    el.style.height = (window.innerHeight - h) + 'px';
}

function findTop(obj, relative){
    var curtop = 0;
    if (obj.offsetParent) {
        do {
            curtop += obj.offsetTop;
        } while ((obj = obj.offsetParent) && (!relative || (relative && relative!==obj)) );
        return curtop;
    }
}

function getStyle(el, property){
    if (el && el.style && el.style[property]) {
        return parseInt(el.style[property].replace('px', ''), 10);
    } else {
        return 0;
    }
}

function simulateClick(node){
    var event = node.ownerDocument.createEvent("MouseEvents");
    event.initMouseEvent("click", true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
    /* ReadByMouse
 event.initMouseEvent("click", true, // can bubble
 true, // cancellable
 node.ownerDocument.defaultView, 1, // clicks
 50, 50, // screen coordinates
 50, 50, // client coordinates
 false, false, false, false, // control/alt/shift/meta
 0, // button,
 node);
 */
    node.dispatchEvent(event);
}

function simulateKeypress(node, keycode){
    var event = node.ownerDocument.createEvent("KeyboardEvent");
    if (typeof keycode === "string") {
        keycode = keycode.charCodeAt(0);
    }
    event.initKeyEvent("keypress", true, true, window, 0, 0, 0, 0, 0, keycode);
    //event.initKeyboardEvent('keypress', true, true, window, "U+0041");
    node.dispatchEvent(evt);
}

/**
 * Shortcuts
 * @param {Object} e
 */
function getStringFromCharCode(codePt){
    if (codePt > 0xFFFF) {
        codePt -= 0x10000;
        return String.fromCharCode(0xD800 + (codePt >> 10), 0xDC00 + (codePt & 0x3FF));
    } else if (keycodes && keycodes[codePt]) {
        return keycodes[codePt];
    } else {
        return String.fromCharCode(codePt);
    }
}

//saved under format CTRL[0,1]ALT[0,1]SHIFT[0,1]keyCode
function unmarshallKey(text){
    var m = /(\d)(\d)(\d)(\d+)/.exec(text || '');
    var key = {};
    if (m) {
        key = {
            ctrlKey: (m[1] === '1'),
            altKey: (m[2] === '1'),
            shiftKey: (m[3] === '1'),
            keyCode: m[4]
        };
    }
    return key;
}

function marshallKey(e){
    return ((e.ctrlKey) ? '1' : '0') + ((e.altKey) ? '1' : '0') + ((e.shiftKey) ? '1' : '0') + e.keyCode;
}

function formatKey(e, keyFirst){
    if (e && e.keyCode) {
		var keyLetter = getStringFromCharCode(e.keyCode);
		if (keyFirst) {
			return keyLetter + ((e.ctrlKey) ? '+ctrl' : '') + ((e.altKey) ? '+alt' : '') + ((e.shiftKey) ? '+shift' : '');
		} else {
			return ((e.ctrlKey) ? 'ctrl+' : '') + ((e.altKey) ? 'alt+' : '') + ((e.shiftKey) ? 'shift+' : '') + keyLetter;
		}
	}else{
		return '';
	}
}

/**
 * Cookies
 *
 */
function readCookie(name){
    name = name.replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
    var regex = new RegExp('(?:^|;)\\s?' + name + '=(.*?)(?:;|$)', 'i'), match = document.cookie.match(regex);
    return match && unescape(match[1]);
}

/**
 * Templates
 */
function fillTpl(tpl, o){
    var txt = '' + tpl;
    for (var k in o) {
        if (o.hasOwnProperty(k)) {
            if (typeof o[k] !== "object") {
                var re = new RegExp("\\{" + k + "\\}", "g");
                txt = txt.replace(re, (o[k]) ? ('' + o[k]) : '');
            }
        }
    }
    return txt;
}

//Format text using number {0}
function formatText(tpl){
    if (!arguments) {
        return '';
    }
    var args = Array.prototype.slice.call(arguments, 1);
    var values = {};
    for (var i = 0, len = args.length; i < len; i++) {
        values[i] = args[i];
    }
    return fillTpl(tpl, values);
}

function getGlobal(){
    return (window.GRP = window.GRP || {});
}

var keycodes = {
    8: 'backspace',
    9: 'tab',
    13: 'enter',
    16: 'shift',
    17: 'ctrl',
    18: 'alt',
    19: 'pause',
    20: 'capslock',
    27: 'escape',
    33: 'pageup',
    32: 'space',
    34: 'pagedown',
    35: 'end',
    36: 'home',
    37: 'arrowleft',
    38: 'arrowup',
    39: 'arrowright',
    40: 'arrowdown',
    44: 'printscreen',
    45: 'insert',
    46: 'delete',
    48: '0',
    49: '1',
    50: '2',
    51: '3',
    52: '4',
    53: '5',
    54: '6',
    55: '7',
    56: '8',
    57: '9',
    65: 'a',
    66: 'b',
    67: 'c',
    68: 'd',
    69: 'e',
    70: 'f',
    71: 'g',
    72: 'h',
    73: 'i',
    74: 'j',
    75: 'k',
    76: 'l',
    77: 'm',
    78: 'n',
    79: 'o',
    80: 'p',
    81: 'q',
    82: 'r',
    83: 's',
    84: 't',
    85: 'u',
    86: 'v',
    87: 'w',
    88: 'x',
    89: 'y',
    90: 'z',
    91: 'leftwindowkey',
    92: 'rightwindowkey',
    93: 'selectkey',
    96: '0 pad',
    97: '1 pad',
    98: '2 pad',
    99: '3 pad',
    100: '4 pad',
    101: '5 pad',
    102: '6 pad',
    103: '7 pad',
    104: '8 pad',
    105: '9 pad',
    106: '*',
    107: '+',
    109: '-',
    110: '.',
    111: '/',
    112: 'f1',
    113: 'f2',
    114: 'f3',
    115: 'f4',
    116: 'f5',
    117: 'f6',
    118: 'f7',
    119: 'f8',
    120: 'f9',
    121: 'f10',
    122: 'f11',
    123: 'f12',
    144: 'numlock',
    145: 'scrolllock',
    182: 'MyComputer',
    183: 'MyCalculator',
    186: ';',
    187: '=',
    188: ',',
    189: 'dash',
    190: 'period',
    191: '/',
    219: '(',
    220: '\\',
    221: ')',
    222: '\''
};
//a.href sometimes truncated
function getHref(a){
    var url = a.protocol + '//' + a.host + a.pathname + (a.hash || '');
    return url;
}

function adjustIframeHeight(iframe, heightMaxi){
    var el;
    if (iframe.document.height) {
        el = parent.document.getElementById(iframe.name);
        el.style.height = iframe.document.height + 'px';
    //el.style.width = iframe.document.width + 'px';
    } else if (document.all) {
        el = parent.document.all[iframe.name];
        if (iframe.document.compatMode &&
        iframe.document.compatMode != 'BackCompat') {
            el.style.height = iframe.document.documentElement.scrollHeight + 5 + 'px';
        //el.style.width = iframe.document.documentElement.scrollWidth + 5 + 'px';
        } else {
            el.style.height = iframe.document.body.scrollHeight + 5 + 'px';
        //el.style.width = iframe.document.body.scrollWidth + 5 + 'px';
        }
    }
}

function bind(func, thisArg){
    var args = Array.prototype.slice.call(arguments, 2);
    return function(){
        var bargs = args.concat(Array.prototype.slice.call(arguments));
        func.apply(thisArg, bargs);
    };
}

function foreach(array, fn, scope){
    if (!array) {
        return;
    }
    if (typeof array.length == "undefined") {
        array = [array];
    }
    for (var i = 0, len = array.length; i < len; i++) {
        if (fn.call(scope || array[i], array[i], i, array) === false) {
            return i;
        }
    }
}

function map2array(o, key, value, flat, eu){
    var r = [];
    iterate(o, function(p, o){
        var a = {};
        a[key || 'key'] = p;
        if (flat && typeof o === "object") {
            iterate(o, function(k, obj){
                a[k] = obj;
            });
        } else {
            a[value || 'value'] = o;
        }
        r.push(a);
    });
    return r;
}

function iterate(o, fn, scope, id){
    if (o) {
        for (var p in o) {
            if (!hasOwnProperty.call(o, p)) {
                continue;
            }
            if (typeof id !== 'undefined') {
                o[p][(typeof id === "string") ? id : 'id'] = p;
            }
            fn.call(scope || this, p, o[p]);
        }
    }
    return false;
}

function namespace(){
    var o, d;
    foreach(arguments, function(v){
        d = v.split(".");
        o = window[d[0]] = window[d[0]] || {};
        foreach(d.slice(1), function(v2){
            o = o[v2] = o[v2] || {};
        });
    });
    return o;
}

function apply(o, c, defaults){
    if (defaults) {
        apply(o, defaults);
    }
    if (o && c && typeof c === 'object') {
        for (var p in c) {
            o[p] = c[p];
        }
    }
    return o;
}

//Override text with last item
function merge(o, c, defaults){
    if (defaults) {
        merge(o, defaults);
    }
    if (typeof o !== "undefined" && typeof c !== "undefined") {
        /*if (isArray(c)) {
 for (var i = 0, len = c.length; i < len; i++) {
 //o[i] = c[i];
 //console.log(c[i] + ' Amerge['+i+']> ' + o[i]);
 if (typeof c[i] === 'object' || isArray(c[i])) {
 merge(o[i], c[i]);
 } else {
 o[i] = c[i];
 }
 }
 //console.log('after: ' + c[i] + ' Amerge[' + i + ']> ' + o[i]);
 } else */
        if (typeof c === 'object') {
            for (var p in c) {
                //console.log(c[p] + ' Omerge['+p+']> ' + o[p]);
                if (typeof c[p] === 'object' || isArray(c[p])) {
                    merge(o[p], c[p]);
                } else {
                    o[p] = c[p];
                }
            }
        } else {
            //o[p] = c[p];
            //console.log(c + ' -> ' + o);
            o = c;
        }
    }
    return o;
}

function isundef(o){
    return (typeof o === 'undefined');
}

function group(a, name){
    var r = {};
    iterate(a, function(id, o){
        var val = o[name] || 'other';
        if (!r[val]) {
            r[val] = {};
        }
        r[val][id] = o;
    });
    return r;
}

function applyRemoteLang(lang, base, id, o, fn, scope){
    GM_xmlhttpRequest({
        method: 'GET',
        url: base + '_locales/' + lang + '/' + id + '.json',
        onload: function(res){
            var data = eval(xhr.responseText);
            if (data) {
                //merge data into o
                applyLast(o[id], data);
            }
        },
        onerror: function(res, a){
            if (a && a.url) {
                console.error(a.url);
            }
            console.error(res);
        }
    });
}

//http://snipplr.com/view/9649/escape-regular-expression-characters-in-string/
//http://simonwillison.net/2006/Jan/20/escape/
var re_encodeRE = new RegExp("[.*+?|()\\[\\]{}\\\\]", "g"); // .*+?|()[]{}\
function encodeRE(s){
    return s.replace(re_encodeRE, "\\$&").replace(' ', '\\W');
}

function urlDecode(string){
    var obj = {}, pairs = string.split('&'), d = decodeURIComponent, name, value;
    for (var i = 0, len = pairs.length; i < len; i++) {
        var pair = pairs[i];
        pair = pair.split('=');
        name = d(pair[0]);
        value = d(pair[1]);
        obj[name] = !obj[name] ? value : [].concat(obj[name]).concat(value);
    }
    return obj;
}

function getDomain(url, withProtocol){
    var m = url.split(/\/|\?/);
    if (withProtocol) {
        return m[0] + '/' + m[1] + '/' + m[2];
    } else {
        return m[2];
    }
}

/*
 isChromeVersionMini('5.0.342.1')
 compareVersion('5.1', '5.0.342.1');->=true
 compareVersion('5.0.100', '5.0.342.1');->=false
 */
function getChromeVersion(){
    var version = /Chrome\/([\d\.]+)/.exec(window.navigator.appVersion);
    return version[1];
}

//Chrome mini version required
function isChromeVersionMini(ref){
    return (compareVersion(getChromeVersion(), ref) >= 0);
}

function isOsMac(){
	return window.navigator.platform.toLowerCase().indexOf('mac')>=0;
}
function isOsLinux(){
	return window.navigator.platform.toLowerCase().indexOf('linux')>=0;
}
//compare 2 first segments
function isVersionMajorUpdated(oldVersion, newVersion){
    return (compareVersion(newVersion, oldVersion, 2) > 0);
}

function compareVersion(version, ref, count){
    if (!ref) {
        //new version, no previous version
        return 1;
    }
    var versions = version.split('.');
    var refs = ref.split('.');
    count = count || versions.length;
    for (var i = 0, len = count; i < len; i++) {
        versions[i] = parseInt(versions[i], 10);
        if (i <= refs.length) {
            refs[i] = parseInt(refs[i], 10);
            if (versions[i] < refs[i]) {
                return -1;
            } else if (versions[i] > refs[i]) {
                return 1;
            }
        }
    }
    return 0;
}

function textareaTab(){
    //Let handle tab on textarea
    var areas = document.getElementsByTagName('textarea');
    if (areas) {
        for (var i = 0, len = areas.length; i < len; i++) {
            areas[i].addEventListener('keydown', function(e){
                var t = e.target;
                if (e.keyCode == 9) {
                    e.preventDefault();
                    var tab = '\t';
                    var ss = t.selectionStart;
                    var se = t.selectionEnd;
                    var currentScroll = t.scrollTop;
                    // Indent
                    if (ss != se && t.value.slice(ss, se).indexOf("\n") != -1) {
                        var pre = t.value.slice(0, ss);
                        var selb = t.value.slice(ss, se);
                        if (e.shiftKey) {
                            //un-indent
                            sel = selb.replace(/^\t/mg, "\n");
                        } else {
                            //indent
                            sel = selb.replace(/\n/g, "\n" + tab);
                        }
                        var post = t.value.slice(se, t.value.length);
                        t.value = pre.concat(tab).concat(sel).concat(post);
                        t.selectionStart = ss + tab.length;
                        t.selectionEnd = se + (sel.length - selb.length);
                    } else {
                        t.value = t.value.slice(0, ss).concat(tab).concat(t.value.slice(ss, t.value.length));
                        if (ss == se) {
                            t.selectionStart = t.selectionEnd = ss + tab.length;
                        } else {
                            t.selectionStart = ss + tab.length;
                            t.selectionEnd = se + tab.length;
                        }
                    }
                    t.scrollTop = currentScroll;
                    t.focus();
                    return false;
                } else {
                    return true;
                }
            });
        }
    }
}

function waitlib(check, fn, scope){
    if (check()) {
        if (fn) {
            fn.call(scope || this);
        }
    } else {
        window.setTimeout(function(){
            waitlib(check, fn);
        }, 200);
    }
}

function waitImages(images, cb, scope){
    var count = (images) ? images.length : 0;
    if (count <= 0) {
        cb.call(scope || this, true);
    } else {
        var timeout = window.setTimeout(function(){
            console.log("Images are not all loaded: " + count);
            cb.call(scope || this, false);
        }, 3000);
        function check(){
            if (count === 0) {
                window.clearTimeout(timeout);
                cb.call(scope || this, true);
            }
        }
        for (var i = 0, len = images.length; i < len; i++) {
            var image = images[i];
            if (image.complete) {
                count--;
            } else {
                image.addEventListener('load', function(){
                    count--;
                    check();
                });
            }
        }
        check();
    }
}

function isShown(el){
    return (el && el.style && el.style.display !== 'none' && el.visibility !== 'hidden');
}

function show(el, value){
    if (el) {
        if (!el.style) {
            el.style = {};
        }
        el.style.display = value || '';
    }
}

function hide(el){
    if (el) {
        el.style.display = 'none';
    }
}

function toggle(el){
    if (isShown(el)) {
        hide(el);
    } else {
        show(el);
    }
}

function showas(el, hideme){
    if (hideme) {
        hide(el);
    } else {
        show(el);
    }
}

//http://forums.mozillazine.org/viewtopic.php?f=19&t=1806595
//http://forums.mozillazine.org/viewtopic.php?f=19&t=1594275
//https://developer.mozilla.org/En/Code_snippets:HTML_to_DOM
function loadXml(html, id){
    var el = document.createElement('div');
	el.id = id || ('_grp_xml_'+Math.round(Math.random()*999+1));
    el.style.display = 'none';
    el.innerHTML = (html.split(/<body[^>]*>((?:.|\n)*)<\/body>/i)[1]) || html;
    return el;
}

function loadText(url, cb){
    GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        onload: function(r){
            var txt = r.responseText;
            cb(txt);
        }
    });
}

function loadCss(url, cb, option){
    loadText(url, function(txt){
        var css = txt;
        if (!option || option.compact) {
            css = compact(css);
        }
        if (!option || option.clean) {
            css = css.replace(/\/\*.*?\*\//g, '');
        }
        cb(css);
    });
}

function compact(text){
    return text.replace(/[\n\t]/g, '').replace(/\s+/g, ' ');
}

//Only works with XML well-formed
function getDocumentXml(html, id){
    var h = html.replace(/^(.*\n)*.*<html/i, "<html");
    h = h.replace(/<\/html>(.*\n)*.*$/i, "</html>");
    var parser = new DOMParser();
    var dom = parser.parseFromString(t, "text/xml");
    return dom;
}

function loadXMLDoc(url){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, false);
    xhr.send("");
    return xhr.responseXML;
}

function applyXsl(xml, xsl){
    var oxml = loadXMLDoc(xml);
    var oxsl = loadXMLDoc(xsl);
    var xp = new XSLTProcessor();
    xp.importStylesheet(oxsl);
    var doc = xp.transformToFragment(oxml, document);
    return doc;
}

var tmaps = {
    id: 'id',
    cls: 'className',
    style: 'style',
    href: 'href',
    alt: 'alt',
    title: 'title',
    text: 'innerText',
    html: 'innerHTML'
};
function dh(root, tag, attrs, events){
    var config = attrs;
    if (root) {
        config.root = root;
    }
    if (tag) {
        config.tag = tag;
    }
    if (events) {
        config.events = events;
    }
    return dhc(config);
}

function dhc(config){
    if (!config) {
        return false;
    }
    var root = config.root;
    if (!root) {
        root = document.body;
    } else if (typeof config.root == "string") {
        root = get_id(config.root);
        if (!root) {
            return false;
        }
    }
    var excepts = {
        root: 1,
        tag: 1,
        events: 1,
        el: 1,
        position: 1
    };
    var el = document.createElement(config.tag || 'div');
    iterate(config, function(k, o){
        if (typeof o !== 'undefined') {
            if (excepts[k] !== 1) {
                if (tmaps[k]) {
                    el[tmaps[k]] = o;
                } else {
                    addAttr(el, k, o);
                }
            }
        }
    });
    iterate(config.events, function(event, fn){
        el.addEventListener(event, fn, false);
    });
    if (config.el) {
        //recurse
        var cfg = config.el;
        cfg.root = el;
        dhc(cfg);
    }
    if (config.position) {
        if (config.position === 'before') {
            insertBefore(el, root);
        } else {
            insertAfter(el, root);
        }
    } else {
        root.appendChild(el);
    }
    return el;
}

function newel(id, cls){
    var el = get_id(id);
    if (el) {
        return el;
    } else {
        return dh('', 'div', {
            id: id,
            cls: cls
        });
    }
}

function randomItem(items){
    return items[Math.round(Math.random() * (items.length - 1))];
}

function loadjQuery(cb, version, local){
    version = version || '1';
    var url = (local) ? (LOCALPATH + '/lib/jquery.min.js') : ('http://ajax.googleapis.com/ajax/libs/jquery/' + version + '/jquery.min.js');
    GM_loadScript(url, false, function(){
        return (typeof jQuery !== "undefined");
    }, cb);
}

function runfn(fn, id, priority, delay){
    GRP.fns.push({
        fn: fn,
        id: id,
        delay: delay,
        priority: priority
    });
}

function encodeu(el){
    return escape(encodeURIComponent(el));
}

function decodeu(el){
    return decodeURIComponent(unescape(el));
}

function getBoolean(val){
    return (val && (val === true || val.toLowerCase() === 'true'));
}


function getTypedValue(o){
    var text;
    if (typeof o === 'object') {
        text = o.value || '';
    } else {
        text = o;
    }
    if (text === "true") {
        return true;
    } else if (text === "false") {
        return false;
    } else {
        return text;
    }
}
mycore.env.prefix = "readerplus.";
//GreaseKit
//http://groups.google.com/group/greasekit-users/browse_thread/thread/d0ed6e8919bb6b42
if (typeof GM_getValue === "undefined") {
    GM_getValue = function(name, def, cb){
        //Move old nameing value to new prefixed place
        /*var value = mycore.storage.getItem(name, cb);
         if (value) {
         GM_setValue(PREFIX + name, value);
         mycore.storage.removeItem(name);//remove old
         }*/
        value = mycore.storage.getItem(name, def, cb);
        return value;
    };
}
if (typeof GM_getCookieValue === "undefined") {
    GM_getCookieValue = function(name, def){
        var value;
        var nameEQ = escape(name) + "=", ca = document.cookie.split(';');
        for (var i = 0, c; i < ca.length; i++) {
            c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1, c.length);
            }
            if (c.indexOf(nameEQ) === 0) {
                value = unescape(c.substring(nameEQ.length, c.length));
                break;
            }
        }
        if (value === null && def !== null) {
            value = def;
        }
        return value;
    };
}
if (typeof GM_setValue === "undefined") {
    GM_setValue = function(name, value, cb){
        try {
            mycore.storage.setItem(name, value, cb);
        } catch (e) {
            console.log('error on GM_setValue[' + n + ']=' + value);
        }
    };
}
if (typeof GM_setCookieValue === "undefined") {
    GM_setCookieValue = function(name, value, options){
        options = (options || {});
        if (options.expiresInOneYear) {
            var today = new Date();
            today.setFullYear(today.getFullYear() + 1, today.getMonth, today.getDay());
            options.expires = today;
        }
        var curCookie = escape(name) +
        "=" +
        escape(value) +
        ((options.expires) ? "; expires=" +
        options.expires.toGMTString() : "") +
        ((options.path) ? "; path=" + options.path : "") +
        ((options.domain) ? "; domain=" + options.domain : "") +
        ((options.secure) ? "; secure" : "");
        document.cookie = curCookie;
    };
}
function clearcache(lang){
    var name, v;
    for (var i = 0; i <= mycore.storage.getLength() - 1; i++) {
        name = mycore.storage.key(i);
        if ((/^readerplus\.theme_/.test(name)) || (/^readerplus\.rps_/.test(name)) || (/^readerplus\.cache/.test(name))) {
            mycore.storage.removeItem(name);
        }
    }
    alert(getTextPrefs(lang, 'global', 'cachecleared', 'en', "Cache cleared"));
}

function openWindow(o, cb){
    sendMessage("window", o, cb);
}

function sendMessage(message, o, callback){
    var a = clone(o) || {};
    a.message = message;
    var fns = ['onload', 'onreadystatechange', 'onerror'];
    for (var i = 0, len = fns.length; i < len; i++) {
        if (o[fns[i]]) {
            a[fns[i]] = true;
        }
    }
    mycore.extension.sendRequest(a, callback);
}


if (typeof GM_xmlhttpRequest === "undefined") {
    GM_xmlhttpRequest = function(o){
        o.method = (o.method) ? o.method.toUpperCase() : "GET";
        if (!o.url) {
            throw ("GM_xmlhttpRequest requires an URL.");
        }
        
        var om = o;
        sendMessage("request", om, function(a){
            if (a.message === (om.callback || "requestdone")) {
                if (a.action === "load") {
                    if (typeof om.onload == "function") {
                        om.onload(a, a.request);
                    }
                } else if (a.action === "readystatechange") {
                    if (typeof om.onreadystatechange == "function") {
                        om.onreadystatechange(a, a.request);
                    }
                } else if (a.action === "error") {
                    GM_log('error: ' + a.responseText);
                    if (typeof om.onerror == "function") {
                        om.onerror(a, a.request);
                    }
                }
            }
        });
        
    };
}
if (typeof GM_addStyle === "undefined") {
    function GM_addStyle(/* String */styles, id){
        var el;
        if (id) {
            el = document.getElementById(id);
        }
        if (!el) {
            el = document.createElement("style");
            el.setAttribute("type", "text\/css");
            if (id) {
                el.id = id;
            }
            el.appendChild(document.createTextNode(styles));
            document.getElementsByTagName("head")[0].appendChild(el);
        } else {
            //update
            el.innerText = styles;//textContent??
        }
        return el;
    }
}
if (typeof GM_addCss === "undefined") {
    function GM_addCss(css, id){
        var el = document.createElement("link");
        el.setAttribute("rel", "stylesheet");
        el.setAttribute("type", "text\/css");
        el.setAttribute("href", css);
        if (id) {
            el.id = id;
        }
        document.getElementsByTagName("head")[0].appendChild(el);
    }
}
if (typeof GM_addScript === "undefined") {
    function GM_addScript(script, remote, cb, cbonerror, scope, time){
        //var id = script.replace(/[\.:-_\/\\]/g, '');
        var id = script;
        var s = document.getElementById(id);
        if (s) {
            if (cbonerror && cb) {
                cb.call(this);
            }
        } else {
            if (remote) {
                GM_xmlhttpRequest({
                    method: 'get',
                    url: script,
                    onload: function(r){
                        if (remote === 'inline') {
                            GM_addjs(script, true, id, cb, scope, time);
                        } else {
                            eval(r.responseText);
                            if (cb) {
                                cb.call(scope || this);
                            }
                        }
                    },
                    onerror: function(r){
                        if (cbonerror && cb) {
                            cb.call(scope || this);
                        }
                        console.error('Error on loading Javascript ' + script);
                    }
                });
            } else {
                GM_addjs(script, false, id, cb, scope, time);
            }
        }
    }
    function GM_addjs(script, inline, id, cb, scope, time){
        var el = document.createElement("script");
        el.setAttribute("type", "text\/javascript");
        if (inline) {
            el.innerText = script;
        } else {
            el.setAttribute("src", script);
        }
        if (id) {
            el.setAttribute("id", id);
        }
        document.getElementsByTagName("head")[0].appendChild(el);
        if (cb) {
            window.setTimeout(function(){
                cb.call(scope || this);
            }, time || 500);
        }
    }
    /**
     * Pack for GM_addScript + check + callback
     * @param {Object} script
     * @param {Object} remote
     * @param {Object} check
     * @param {Object} cb
     * @param {Object} scope
     */
    function GM_loadScript(script, remote, check, cb, scope){
        function cbwait(){
            waitlib(check, cb, scope);
        }
        function cbonerror(){
            if (cb) {
                cb.call(scope || this);
            }
        }
        GM_addScript(script, remote, cbwait, cbonerror, scope);
    }
}
if (typeof GM_log === "undefined") {
    function GM_log(log){
        console.log(log);
    }
}
if (typeof GM_registerMenuCommand === "undefined") {
    function GM_registerMenuCommand(a, b){
        //
    }
}
if (typeof GM_openInTab === "undefined") {
    GM_openInTab = function(url, selected, search, index, windowId){
        //send request port to bg
        if (typeof selected == "undefined") {
            selected = true;
        }
        var data = {
            message: 'opentab',
            url: url,
            search: search || url,
            selected: selected,
            index: index,
            windowId: windowId
        };
        mycore.extension.sendRequest(data);
    };
}
if (typeof unsafeWindow === "undefined") {
    unsafeWindow = window;
}
if (typeof(this['clone']) !== 'function') {
    clone = function(o){
        try {
            return eval(uneval(o));
        } catch (e) {
            throw (e);
        }
    };
}
/**
 * uneval for prefetch !!
 */
if (typeof(this['uneval']) !== 'function') {
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var protos = [];
    var char2esc = {
        '\t': 't',
        '\n': 'n',
        '\v': 'v',
        '\f': 'f',
        '\r': '\r',
        '\'': '\'',
        '\"': '\"',
        '\\': '\\'
    };
    var escapeChar = function(c){
        if (c in char2esc) 
            return '\\' + char2esc[c];
        var ord = c.charCodeAt(0);
        return ord < 0x20 ? '\\x0' + ord.toString(16) : ord < 0x7F ? '\\' + c : ord < 0x100 ? '\\x' + ord.toString(16) : ord < 0x1000 ? '\\u0' + ord.toString(16) : '\\u' + ord.toString(16);
    };
    var uneval_asis = function(o){
        return o.toString();
    };
    /* predefine objects where typeof(o) != 'object' */
    var name2uneval = {
        'boolean': uneval_asis,
        'number': uneval_asis,
        'string': function(o){
            return '\'' +
            o.toString().replace(/[\x00-\x1F\'\"\\\u007F-\uFFFF]/g, escapeChar) +
            '\'';
        },
        'undefined': function(o){
            return 'undefined';
        },
        'function': uneval_asis
    };
    var uneval_default = function(o, np){
        var src = []; // a-ha!
        for (var p in o) {
            if (!hasOwnProperty.call(o, p)) 
                continue;
            src[src.length] = uneval(p) + ':' + uneval(o[p], 1);
        }
        // parens needed to make eval() happy
        return np ? '{' + src.toString() + '}' : '({' + src.toString() + '})';
    };
    uneval_set = function(proto, name, func){
        protos[protos.length] = [proto, name];
        name2uneval[name] = func || uneval_default;
    };
    uneval_set(Array, 'array', function(o){
        var src = [];
        for (var i = 0, l = o.length; i < l; i++) 
            src[i] = uneval(o[i]);
        return '[' + src.toString() + ']';
    });
    uneval_set(RegExp, 'regexp', uneval_asis);
    uneval_set(Date, 'date', function(o){
        return '(new Date(' + o.valueOf() + '))';
    });
    var typeName = function(o){
        // if (o === null) return 'null';
        var t = typeof o;
        if (t != 'object') 
            return t;
        // we have to lenear-search. sigh.
        for (var i = 0, l = protos.length; i < l; i++) {
            if (o instanceof protos[i][0]) 
                return protos[i][1];
        }
        return 'object';
    };
    uneval = function(o, np){
        // if (o.toSource) return o.toSource();
        if (o === null) 
            return 'null';
        var func = name2uneval[typeName(o)] || uneval_default;
        return func(o, np);
    };
}
/**
 * @author Valente
 */
window.GRP={
	VERSION: "3.4.0",
	setVersion:function(text){
		var ver = document.getElementById('version');
		ver.innerHTML = (text||'') + GRP.VERSION;
	}
};
/**
 * @author Valente
 */
GRP.scripts = {
    general: {
        name: "General",
        category: 'main',
		status: 'updated',
        options: {
            secure: false,

			text_layout:{
                xtype: 'h'
            },
            topcurrent: false,
            floatactions: false,
			bottomup:false,
			currdir:true,
			icons:false,
            /*antisocial:true,*/

			text_pageicon:{
                xtype: 'h'
            },
			pageicon:true,
			
			text_toolbaricon: {
                xtype: 'h'
            },
			icontoolbar_add: {
                xtype: 'p',
                label: true
            },
			counter: true,
			counterinterval: 2,
			opendirect: false,
            icontoolbar_text: {
                xtype: 'p',
                label: true
            },
			
			text_private:{
                xtype: 'h'
            },
			stats:true,
            noupdatepopup: false,
			
			text_export:{
                xtype: 'h'
            },
            importexport_text: {
                xtype: 'p',
                label: true
            },
            preferences: {
                xtype: 'html',
                label: true,
                value: '<input id="ieprefs" class="ignore" type="text" size="30"/><input type="button" id="bimport" value="import" onclick="importprefs();"/><input type="button" id="bexport" value="export" onclick="exportprefs();"/>'
            }
        }
    },
    theme: {
        name: "Theme",
        category: 'theme',
        status: 'updated',
        options: {
            skin: '',
            noborder: false,
            mytheme: {
                xtype: 'p',
                label: true,
                parent: 'mytheme'
            },
            externaltheme: {
                value: '',
                values: {
                    none: '',
					gmail_chrome: 'Gmail Bold Blue',
					gmail_c: 'Gmail Classic',
					gmail_newblue: 'Gmail New Blue',
					gmail_coldshower: 'Gmail Cold Shower',
					gmail_steel: 'Gmail Steel',
					gmail_lightbright: 'Gmail Minimalist',
					gmail_greensky: 'Gmail Green Sky',
					gmail_lightsoft: 'Gmail Bubblegum',
					gmail_cherry: 'Gmail Cherry Blossom',
					gmail_nightshade: 'Gmail Night Shade',
					gmail_medsoft: 'Gmail marina',
					gmail_medred: 'Gmail dusk',
					gmail_darkwarm: 'Gmail sunset',
					gmail_greyrain: 'Gmail Silver Lining',
					gmail_contrastblack: 'Gmail Contrast Black',
					gmail_shiny: 'Gmail shiny',
					gmail_desk: 'Gmail Desk',
					gmail_tree: 'Gmail Tree',
					gmail_beach: 'Gmail Beach',
					gmail_mountains: 'Gmail Mountains',
					gmail_pebbles: 'Gmail pebbles',
					gmail_ocean: 'Gmail Summer ocean',
                    gmail_phantasea: 'Gmail Phantasea',
					gmail_graffiti: 'Gmail Graffiti',
					gmail_planets: 'Gmail Planets',
					gmail_gizmos: 'Gmail Zoozimps',
					gmail_candy: 'Gmail Candy',
					gmail_busstop: 'Gmail Bus Stop',
					gmail_ninja: 'Gmail Ninja',
					gmail_teahouse: 'Gmail Tea House',
		            gmail_terminal: 'Gmail Terminal',
					gmail_orcasisland: 'Gmail Orcas Island',
					gmail_highscore: 'Gmail Highscore',
					gmail_turf: 'Gmail Turf',
					gmail_lapinscretins: 'Gmail lapinscretins',
					gmail_assasinscreed2: 'Gmail assasinscreed2',				
/* editors_picks */
"editor_5478752472500006610":"Google, artist, Dale Chihuly, 01_chihuly_06.jpg","editor_5478752827007585634":"Google, artist, Dale Chihuly, 08_chihuly_02.jpg","editor_5478752842710333378":"Google, artist, Dale Chihuly, 10_chihuly_05.jpg","editor_5478753114195988130":"Google, artist, Dale Chihuly, 14_chihuly_01.jpg","editor_5478753075316627266":"Google, artist, Dale Chihuly, 12_chihuly_03.jpg","editor_5478753460334726146":"Google, artist, Dale Chihuly, 16_chihuly_07.jpg","editor_5478752501519603442":"Google, \u00a9 Jeff Koons, 04_koons_02.jpg","editor_5478753089633816370":"Google, \u00a9 Jeff Koons, 13_koons_01.jpg","editor_5478752819223180210":"Google, Polly Apfelbaum, 06_apfelbaum_01.jpg","editor_5478753117486370930":"Google, Polly Apfelbaum, 15_apfelbaum_03.jpg","editor_5478752835087677362":"Google, Polly Apfelbaum, 09_apfelbaum_02.jpg","editor_5478752493997894098":"Google, \u00a9 Tom Otterness, 03_otterness_02.jpg","editor_5478752822146891810":"Google, \u00a9 Tom Otterness, 07_otterness_03.jpg","editor_5478753058608504226":"Google, \u00a9 Tom Otterness, 11_otterness_01.jpg","editor_5480987905094465154":"Google, \u00a9 Kengo Kuma (???), kengo_kuma.jpg","editor_5480987906200029490":"Google, \u00a9 Tord Boontje, tord_boontje.jpg","editor_5480998621006856338":"Google, \u00a9 Kwon, Ki-soo (???), ki_soo_kwon.jpg","editor_5480987916726984130":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_01.jpg","editor_5480987917979934498":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_02.jpg","editor_5480987925727076290":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_03.jpg","editor_5480988005113749330":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_04.jpg","editor_5480988012864676114":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_05.jpg","editor_5478753466167683746":"Google, National Geographic Stock, natgeo_01.jpg","editor_5478753483552159554":"Google, National Geographic Stock, natgeo_02.jpg","editor_5478755559461692018":"Google, National Geographic Stock, natgeo_03.jpg","editor_5478755572322259650":"Google, National Geographic Stock, natgeo_04.jpg","editor_5478753799989312658":"Google, National Geographic Stock, natgeo_06.jpg","editor_5478753813630017442":"Google, National Geographic Stock, natgeo_07.jpg","editor_5478753819961634386":"Google, National Geographic Stock, natgeo_08.jpg","editor_5478752511525657170":"Google, National Geographic Stock, 05_natgeo_10.jpg","editor_5478753832267149810":"Google, National Geographic Stock, natgeo_09.jpg","editor_5480997862386069170":"Google, National Geographic Stock, NationalGeographic_1143826.jpg","editor_5480997893054118498":"Google, National Geographic Stock, NationalGeographic_1146940.jpg","editor_5480998186992651026":"Google, National Geographic Stock, NationalGeographic_1223429.jpg","editor_5478769425598313058":"Google, Blue, Color_Google_blue.jpg","editor_5478769428183578882":"Google, Green, Color_Google_green.jpg","editor_5478769428473291154":"Google, Grey, Color_Google_grey.jpg","editor_5478769530404012082":"Google, Red, Color_Google_red.jpg","editor_5478769535168997586":"Google, Yellow-Orange, Color_Google_yelloworange.jpg","editor_5480596593254567266":"Google, White, white-2000x1500.jpg",
/* public_gallery */
"public_5468005866288280370":"Google, EricasJoys/HorizontalMambo","public_5480525382039743330":"Google, 116086157836169916177/Favorites","public_5469661666160577106":"Google, 114728257341600814985/PicasaWebPublicPictures","public_5464847589870262818":"Google, juliantoledo/Best","public_5468620555541748930":"Google, bdowney/ClassicPlus","public_5465726438613138322":"Google, EricasJoys/HorizontalMambo","public_5480525372525642866":"Google, 116086157836169916177/Favorites","public_5468095309182211138":"Google, climent/Travels","public_5467968585789456354":"Google, max.braun/Homepage","public_5467968606322662898":"Google, max.braun/Homepage","public_5394978350593597026":"Google, bluan01/JiuZhaiGouYellowDragonNationalParks","public_5468030760630111442":"Google, 109244757320221408388/Test2006","public_5461268259373019506":"Google, jclilot/Portfolio_Flowers","public_5418083111186176690":"Google, fkarpelevitch/200806","public_5465064542962429986":"Google, snoozy.koala/Images","public_5465267981519769410":"Google, magdalar/Backgrounds","public_5464637264209516562":"Google, brettw/Taiwan","public_5469816275349772930":"Google, max.braun/Homepage","public_5405276903498929458":"Google, jclilot/Portfolio_Nature","public_5464602659331416274":"Google, maeve.mara/FeaturedPhotos","public_5468081125425097026":"Google, michos.conradt/Public","public_5480525380508846738":"Google, 116086157836169916177/Favorites","public_5465064395281172466":"Google, snoozy.koala/Images","public_5427875955486466754":"Google, sandysroom/VerdugoNorthTraverse","public_5480525385832476034":"Google, 116086157836169916177/Favorites","public_5464721817854022450":"Google, mjwiacek/PhotosILike","public_5468499236979512002":"Google, uffishmpk/SelectedFavourites","public_5465811371224046274":"Google, 103752943986656263237/Night","public_5468499251879550482":"Google, uffishmpk/SelectedFavourites","public_5468011240643552594":"Google, sweth.c/ForGoogle","public_5464721917635140242":"Google, mjwiacek/PhotosILike","public_5465963404565598994":"Google, arendsf/ThomasFavoriteShared","public_5464886839716494226":"Google, mariusm/ILikeThese","public_5464644514748019778":"Google, simon.tong/Wallpapers","public_5465825398133839090":"Google, 103752943986656263237/Background","public_5467921205742594898":"Google, TenSafeFrogs/Favorites","public_5436863789388960962":"Google, marius.schilder/Trona","public_5464721845849026242":"Google, mjwiacek/PhotosILike","public_5467928286294729906":"Google, merciniebres/HelloWorld","public_5469782237294118322":"Google, peter.norvig/Pictures","public_5463830940035733394":"Google, mattgundersen/LandmarksOfTahoe","public_5470258900410180098":"Google, kevin.cantrell/PublicAlbum","public_5467976005541355106":"Google, romain.guy/Wallpapers","public_5467975931636282290":"Google, romain.guy/Wallpapers","public_5467936023478442338":"Google, TenSafeFrogs/Favorites","public_5468630655462131890":"Google, RussHaig/SFNightD40","public_5468499216650860930":"Google, uffishmpk/SelectedFavourites","public_5464708695072547106":"Google, pawliger/Homepage","public_5464721937652197202":"Google, mjwiacek/PhotosILike","public_5464593346215231826":"Google, arendsf/ThomasFavoriteShared"
					
},
                xtype: 'select',
                parent: 'mytheme'
            },
			color: {
                value: '#565656',
                xtype: 'picker',
                parent: 'mytheme'
            },
            bg: {
                value: '#FFC',
                xtype: 'picker',
                parent: 'mytheme'
            },
			imgsbg: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgrbg: {
                value: '',
                size: 80,
                parent: 'mytheme'
            },imgrh: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgh: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imghr: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imghl: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgrf: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgf: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgfr: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgfl: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, ncolumns: {
	            value: 2,
	            parent: 'portal'
	       }	
        }
    },
    ig: {
        name: "iGoogle Theme",
        category: 'theme',
        desc: "Use iGoogle Theme in your Google Reader (Beta)",
        options: {
            warning: {
                xtype: 'p',
                label: true,
                cls: 'warning center'
            },
            skin_name: {
                value: '',
                size: 80
            },
            skin_url: {
                value: '',
                size: 80
            },
            skin_id: {
                xtype: 'hidden'
            },
            /*debug: false,*/
            randomtime: true,
            userandomthemes: false,
            randomthemes: {
                value: 30,
                lcls: 'large'
            },
            themes: {
                xtype: 'html',
                label: true,
                value: '<div id="ig_themes"></div>'
            }
        },
        shortcuts: {
            'random': {
                id: 'random',
                title: 'Random theme',
                key: {
                    //82 r
                    keyCode: 82,
                    shiftKey: true
                }
            }
        }
    },
    relook: {
        name: "Relook",
        category: 'theme',
        desc: "Relook yourself GoogleReader using custom stylesheets",
        options: {
            resize: false,
            css: {
                xtype: 'textarea',
                cls: 'code',
                rows: 40,
                value: '/* This CSS sample alternates green entry, red border */\n/* green entry */\n.entry:nth-child(even) .card-common, \n.entry:nth-child(even) .card-actions, \n#entries .entry:nth-child(even) .collapsed {\n border:1px solid #FFACAC;\n}\n/* red border */\n.entry:nth-child(odd) .card-common, \n.entry:nth-child(odd) .card-actions, \n#entries .entry:nth-child(odd) .collapsed {\n background-color:#C4DFC0;\n}\n'
            }
        }
    },
    favicons: {
        name: "Favicons",
        category: 'icons',
        options: {
            providerpageicons: false,
            sidebaronly: false,
			cloud:true,
            custom: {
                xtype: 'p',
                label: true
            },
            domains: {
                xtype: 'crud'
            },
            tip: {
                xtype: 'p',
                label: true
            },
            manual: false,
            parsing: {
                xtype: 'p',
                label: true
            }
        }
    },
    unreadcount: {
        category: 'counter',
        name: "Show all unread count"
    },
    fixlayout: {
        category: 'layout',
        name: "Fix layout"
    },
    count: {
        category: 'counter',
        name: "Fix counter (1000+)"
    },
    counticon: {
        category: 'counter',
        name: "Icon counter"
    },
    removeads: {
        name: "Remove ads",
        category: 'content',
        options: {
            links: {
                xtype: 'textarea',
                value: "da\.feedsportal\.com|res\.feedsportal\.com|doubleclick\.net|/ads"
            },
            images: {
                xtype: 'textarea',
                value: "feedsportal\.com|doubleclick\.net|/ads"
            },
            iframes: {
                xtype: 'textarea',
                value: "feedsportal\.com|doubleclick\.net|googlesyndication\.com/pagead/ads"
            }
        }
    },
    column: {
        name: "Text multi columns",
        category: 'layout',
        options: {
            count: 3,
            /*maxcolumns:6,*/
            pagebreak: true,
			miniparas:5,
            locked: false,
            filter: {
                xtype: 'crud'
            }
        },
        shortcuts: {
            'columns': {
                id: 'columns',
                title: 'Multi columns',
                key: {
                    //67 c
                    keyCode: 67
                }
            }
        }
    },
    preview: {
        name: "Integrated preview",
        category: 'layout',
        options: {
            onicon: false,
            overlay: false,
            locked: false,
            filter: {
                xtype: 'crud'
            }
        },
        //shortcut: "shift+R",
        shortcuts: {
            'prview': {
                id: 'prview',
                title: 'Entry preview',
                key: {
                    //81 q
                    keyCode: 81
                }
            },
			'next': {
                id: 'next',
                title: 'Next preview',
                key: {
                    //81 q
                    keyCode: 81,
					shiftKey:true
                }
            },
			'previous': {
                id: 'previous',
                title: 'Previous preview',
                key: {
                    //81 q
                    keyCode: 81,
					ctrlKey:true
                }
            },
			'close': {
                id: 'close',
                title: 'Close preview',
                key: {
                    //88 x
                    keyCode: 88,
					shiftKey:true
                }
            }
        }
    },
    colorful: {
        name: "Colorful listview",
        category: 'layout',
        options: {
            tree: false,
            usebasecolor: false,
            background: {
                value: '#BCBCBC',
                xtype: 'picker'
            },
            color: {
                value: '#000000',
                xtype: 'picker'
            }
        }
    },
    filter: {
        name: "Filter entries",
        category: 'layout',
        options: {
            searchbody: false,
			excludes: {xtype:'textarea',list:true,cls:'xlist'},
			highlights: {xtype:'textarea',list:true,cls:'xlist'}
        }
    },
    readbymouse: {
        name: "Read by mouse",
        category: 'navigation'
    },
    facebook: {
        name: "Facebook integration",
        category: 'share',
        shortcuts: {
            'gofacebook': {
                id: 'gofacebook',
                title: 'Post on Facebook',
                key: {
                    //70 f
                    keyCode: 70
                }
            }
        }
    },
    twitter: {
        name: "Twitter integration",
        category: 'share',
        options: {
            shortener: {
                xtype: 'select',
                values: {
                    tinyurl: 'TinyUrl',
                    bitly: 'BitLy'
                }
            },
            shortener_bitly: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            shortener_login: {
                value: '',
                size: 20
            },
            shortener_apikey: {
                value: '',
                size: 30
            }
        },
        shortcuts: {
            'tweet': {
                id: 'tweet',
                title: 'Post on Twitter',
                key: {
                    //87 w
                    keyCode: 87
                }
            }
        }
    },
    instapaper: {
        name: "Instapaper integration",
        category: 'share',
        options: {
            auth: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            username: '',
            password: {
                input: 'password',
                value: ''
            }
        },
        shortcuts: {
            'share': {
                id: 'share',
                title: 'Read Later with Instapaper',
                key: {
                    //73 i
                    keyCode: 73
                }
            }
        }
    },
    readitlater: {
        name: "ReadItLater integration",
        category: 'share',
        options: {
            auth: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            username: '',
            password: {
                input: 'password',
                value: ''
            }
        },
        shortcuts: {
            'share': {
                id: 'share',
                title: 'Read Later with ReadItLater',
                key: {
                    //76 l
                    keyCode: 76
                }
            }
        }
    },
    mark: {
        name: "Mark As Read",
        category: 'navigation',
        shortcuts: {
            'markprev': {
                id: 'markprev',
                title: 'Mark items before As Read',
                key: {
                    //87 w
                    keyCode: 87
                }
            },
            'marknext': {
                id: 'marknext',
                title: 'Mark items after As Read',
                key: {
                    //89 y
                    keyCode: 89
                }
            }
        }
    },
    jump: {
        name: "Add top/bottom links",
        category: 'navigation',
        shortcuts: {
            'goup': {
                id: 'goup',
                title: 'Goto top',
                key: {
                    //84 Shift+T
                    keyCode: 84,
                    shiftKey: true
                }
            },
            'godown': {
                id: 'godown',
                title: 'Goto bottom',
                key: {
                    //66 Shift+B
                    keyCode: 66,
                    shiftKey: true
                }
            }
        }
    },
    fitheight: {
        name: "Fit height",
        category: 'layout',
        options: {
            locked: false
        },
        shortcuts: {
            'fit': {
                id: 'fit',
                title: 'Fit height',
                key: {
                    //72 h
                    keyCode: 72
                }
            }
        }
    },
    closeentry: {
        name: "Close entry",
        category: 'action',
        shortcuts: {
            'close': {
                id: 'close',
                title: 'Close entry',
                key: {
                    //88 x
                    keyCode: 88
                }
            }
        }
    },
    openbackground: {
        name: "Open in background",
        category: 'action',
        shortcuts: {
            'openback': {
                id: 'openback',
                title: 'Open in background tab',
                key: {
                    shiftKey: true,
                    keyCode: 86
                }
            }
        }
    },
    translate: {
        name: "Translate",
        category: 'content',
        options: {
            lang: 'en',
            locked: false,
            include: false,
            filter: {
                xtype: 'crud'
            }
        },
        shortcuts: {
            'translate': {
                id: 'translate',
                title: 'Translate entry',
                key: {
                    //84 alt+T
                    keyCode: 84,
                    altKey: true
                }
            }
        }
    },
    limit: {
        name: "Limit",
        category: 'layout',
        options: {
            mini: 30,
            maxi: 200
        }
    },
	prefetch: {
        name: "Prefetch",
        category: 'layout',
        status: 'new',
        options: {
            first: 25,
			next: 15,
			list: 60
        }
    },
	nested: {
        name: "Nested folders",
        category: 'layout',
        status: 'new',
        options: {
            separator: ":"
        }
    },
    replacer: {
        name: "Replacer",
        category: 'content',
        status: 'updated',
        options: {
            intro: {
                xtype: 'p',
                label: true
            },
			cloud: true,
            items: {
                xtype: 'crud'
            }
        }
    },
   /* menu: {
     name: "Smart menu",
	 category: 'navigation',
     desc: "Smart menu to add extra capabilites on each entry"
    },*/
    aero: {
        name: "Google Aero Toolbar",
        category: 'theme'
    },
    /*antisocial: {
        name: "Antisocial",
        category: 'layout',
        status: 'new',
        options: {
            status: false
        }
    },*/
    /*hover: {
     name: "Hover selection"
     },*/
    info: {
        name: "SysInfo",
        link: true,
        options: {
            sysinfo: {
                xtype: 'html',
                label: true,
                value: '<div id="sysinfo"></div>'
            }
        }
    },
    extshortcuts: {
        name: "Shortcuts",
        link: true
    },
    pack: {
        name: "Packages",
        link: true
    },
    thanks: {
        name: "Thanks",
        link: true
    }
};
GRP.packages = {
    'none': {
        general: {
            secure: true,
			stats:true
        }
    },
	'mini': {
        general: {
            secure: true,
			stats:true
        },
		favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true
    },
    'ludoo': {
        general: {
            secure: true,
            counter: false,
			pageicon: true,
			stats:true
        },
        favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true,
        column: true,
        mark: true,
        jump: true,
        fitheight: true,
        closeentry: true,
        openbackground: true,
        replacer: {
			cloud:true
		},
        preview: {
            onicon: true,
            overlay: true
        },
        theme: {
            skin:'mytheme',
			externaltheme: 'gmail_coldshower'
        }
    },
    'full': {
        general: {
            secure: true,
            counter: false,
			pageicon: true,
			stats:true
        },
		theme: {
            skin: 'osxblack',
			stats:true
        },
        favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true,
        column: true,
        mark: true,
        jump: true,
        preview: true,
        colorful: true,
        filter: true,
        readbymouse: true,
        twitter: true,
        facebook: true,
        fitheight: true,
        closeentry: true,
        openbackground: true,
        aero: true,
        instapaper: true,
        readitlater: true,
        translate: true,
        replacer: true,
        limit: true
    }
};
GRP.skins = {
    none: {
        name: "None"
    },
    mytheme: {
        name: "My Theme <span class='updated'>Updated!</span>"
    },
    nativecompact: {
        name: "Native compact"
    },
    player: {
        name: "Player Theme"
    },
    osxblue: {
        name: "Mac OS X Snow Leopard - Blue"
    },
    osxblack: {
        name: "Mac OS X Snow Leopard - Black"
    },
    portal: {
        name: "Portal Theme"
    },
    helvetireader: {
        name: "Helvetireader Skin"
    },
    minimal: {
        name: "Minimalistic Skin"
    },
    optimized: {
        name: "Optimized Skin"
    },
    air: {
        name: "Air Skin"
    },
    aircomic: {
        name: "Air Skin Comic Sans"
    },
    black: {
        name: "Google Enhanced Black"
    },
    dark: {
        name: "Dark Skin"
    },
    darkgray: {
        name: "Dark Gray Skin"
    },
    calibri: {
        name: "Calibri Skin"
    },
	sublimelight: {
        name: "Sublime Reader Light",
		ref:'https://code.google.com/p/sublimereader/'
    },
	sublimedark: {
        name: "Sublime Reader Dark",
		ref:'https://code.google.com/p/sublimereader'
    },
	redesigned: {
        name: "Redesigned",
		ref:'http://www.globexdesigns.com/products/gr/'
    },
	webbizgeek: {
		name: "WebBizGeek Skin <span class='new'>New!</span>",
		pic: 'http://www.webbizgeek.com/wp-content/uploads/2010/07/Google-Reader-custom-skin1.jpg'
	},
    glassblackgold: {
        name: "Glass Black Gold Skin",
        /*
         url: 'http://userstyles.org/styles/userjs/26569/Google%20Reader%20-%20Glass%20BlackGold%20.user.js',
         */
        pic: 'http://userstyles.org/style_screenshots/26569_after.png',
        ref: 'http://userstyles.org/styles/26569',
        fix: '#chrome-view-links,#lhn-selectors .selected,#lhn-selectors .selected:hover{background-color: transparent !important;}',
        desc: 'userstyles.org'
    },
    simpleclean: {
        name: "Simple and Clean",
        url: 'http://userstyles.org/styles/userjs/17120/Google%20Reader%20simple%20and%20clean.user.js',
        pic: 'http://userstyles.org/style_screenshots/17120_after.gif',
        ref: 'http://userstyles.org/styles/17120',
        fix: '.entry-actions{height: auto!important;}',
        desc: 'userstyles.org'
    },
    peacockfeather: {
        name: "Peacock Feather",
        url: 'http://userstyles.org/styles/userjs/3014/Google%20Reader%20-%20peacock%20feather.user.js',
        pic: 'http://userstyles.org/style_screenshots/3014_after.gif',
        ref: 'http://userstyles.org/styles/3014',
        desc: 'userstyles.org',
        resize: true
    },
    myowngooglereader: {
        name: "My Own Google Reader",
        url: 'http://userstyles.org/styles/userjs/13384/My%20Own%20Google%20Reader.user.js',
        pic: 'http://userstyles.org/style_screenshots/13384_after.png',
        ref: 'http://userstyles.org/styles/13384',
        desc: 'userstyles.org',
        resize: true
    },
    compactcleantweaked: {
        name: "Compact, Clean & Tweaked",
        url: 'http://userstyles.org/styles/userjs/16117/Google%20Reader%20-%20Compact%2C%20Clean%20%26%20Tweaked.user.js',
        pic: 'http://userstyles.org/style_screenshots/16117_after.png',
        ref: 'http://userstyles.org/styles/16117',
        desc: 'userstyles.org'
    },
    /*
     '31d1remix':
     {
     name: "31d1 remix",
     url:'http://userstyles.org/styles/userjs/3519/Google%20Reader%20-%2031d1%20remix%20.user.js',
     pic:'http://userstyles.org/style_screenshots/3519_after.png',
     ref:'http://userstyles.org/styles/3519',
     desc: 'userstyles.org'
     },
     */
    absolutelycompact: {
        name: "Absolutely Compact",
        url: 'http://userstyles.org/styles/userjs/12691/Google%20Reader%20Absolutely%20Compact.user.js',
        pic: 'http://userstyles.org/style_screenshots/12691_after.png',
        ref: 'http://userstyles.org/styles/12691',
        desc: 'userstyles.org'
    },
    darkshinyblue: {
        name: "Dark Shiny Blue",
        url: 'http://userstyles.org/styles/userjs/8935/iGoogle%2FGoogle%20Dark%20Shiny%20Blue%2C%20transparency.user.js',
        pic: 'http://userstyles.org/style_screenshots/8935_after.jpeg',
        ref: 'http://userstyles.org/styles/8935',
        desc: 'userstyles.org'
    },
    persian: {
        name: "Optimized Persian",
        url: 'http://userstyles.org//styles/userjs/2375/Optimized%20Persian%20Google%20Reader%20.user.js',
        pic: 'http://userstyles.org/style_screenshots/2375_after.png',
        ref: 'http://userstyles.org/styles/2375',
        desc: 'userstyles.org'
    }
};
GRP.googleshortcuts = {
    'j': {
        text: 'item down : selects the next item in the list',
        key: {
            keyCode: 74
        }
    },
    'k': {
        text: 'item up : selects the previous item in the list',
        key: {
            keyCode: 75
        }
    },
    'space': {
        text: 'page down : moves the page down',
        key: {
            keyCode: 32
        }
    },
    'shift+space': {
        text: 'page up : moves the page up',
        key: {
            keyCode: 32,
            shiftKey: true
        }
    },
    'n': {
        text: 'scan down : in list view, selects the next item without opening it',
        key: {
            keyCode: 78
        }
    },
    'p': {
        text: 'scan up : in list view, selects the next item without opening it',
        key: {
            keyCode: 80
        }
    },
    'shift+n': {
        text: 'navigation down : selects the next subscription or folder in the navigation',
        key: {
            keyCode: 78,
            shiftKey: true
        }
    },
    'shift+p': {
        text: 'navigation up : selects the previous subscription or folder in the navigation',
        key: {
            keyCode: 80,
            shiftKey: true
        }
    },
    'shift+x': {
        text: 'navigation expand/collapse : expands or collapses a folder selected in the navigation',
        key: {
            keyCode: 88,
            shiftKey: true
        }
    },
    'o': {
        text: 'open/close item : in list view, expands or collapses the selected item',
        key: {
            keyCode: 79
        }
    },
    'enter': {
        text: 'open/close item : in list view, expands or collapses the selected item',
        key: {
            keyCode: 13
        }
    },
    'shift+o': {
        text: 'navigation open subscription : opens the subscription or folder currently selected in the navigation',
        key: {
            keyCode: 79,
            shiftKey: true
        }
    },
    '-': {
        text: 'zoom out : decreases the font size of the current item',
        key: {
            keyCode: 109
        }
    },
    '=': {
        text: 'zoom in : increases the font size of the current item',
        key: {
            keyCode: 187
        }
    },
    's': {
        text: 'toggle star : stars or un-stars the selected item',
        key: {
            keyCode: 83
        }
    },
    'shift+s': {
        text: 'toggle share : shares or un-shares the selected item',
        key: {
            keyCode: 83,
            shiftKey: true
        }
    },
    'shift+d': {
        text: 'share with note : shares the selected item with a note',
        key: {
            keyCode: 68,
            shiftKey: true
        }
    },
    'v': {
        text: 'view original : opens the original source for this article in a new window',
        key: {
            keyCode: 86
        }
    },
    't': {
        text: 'tag an item : opens the tagging field for the selected item',
        key: {
            keyCode: 84
        }
    },
    'm': {
        text: 'mark as read/unread : switches the read status of the selected item',
        key: {
            keyCode: 77
        }
    },
    'shift+a': {
        text: 'mark all as read : marks all items in the current view as read',
        key: {
            keyCode: 65,
            shiftKey: true
        }
    },
    'e': {
        text: 'email item : opens the email form to send an item to a friend',
        key: {
            keyCode: 69
        }
    },
    'g then h': {
        text: 'go to home : goes to the Google Reader homepage',
        key: {
            keyCode: 71
        }
    },
    'g then a': {
        text: 'go to all items : goes to the "All items" view',
        key: {
            keyCode: 71
        }
    },
    'g then s': {
        text: 'go to starred items : goes to the "Starred items" view',
        key: {
            keyCode: 71
        }
    },
    'g then shift-s': {
        text: 'go to shared items : goes to the "Your shared items" view',
        key: {
            keyCode: 71
        }
    },
    'g then u': {
        text: 'go to subscription : allows you to navigate to a subscription by entering the subscription name',
        key: {
            keyCode: 71
        }
    },
    'g then t': {
        text: 'go to tag : allows you to navigate to a tag by entering the tag name',
        key: {
            keyCode: 71
        }
    },
    'g then f': {
        text: 'go to friend : allows you to navigate to a friend\'s shared items by entering the friend\'s name',
        key: {
            keyCode: 71
        }
    },
    'g then shift-f': {
        text: 'go to all friends\' shared items : shows all of your friends\' shared items',
        key: {
            keyCode: 71
        }
    },
    'g then shift-t': {
        text: 'go to trends : goes to the "Trends" view',
        key: {
            keyCode: 71
        }
    },
    'g then d': {
        text: 'go to feed discovery : shows the recommendations page, or the browse page if there are no recommendations',
        key: {
            keyCode: 71
        }
    },
    'r': {
        text: 'refresh : refreshes the unread counts in the navigation',
        key: {
            keyCode: 82
        }
    },
    'u': {
        text: 'toggle full screen mode : hides or shows the list of subscriptions',
        key: {
            keyCode: 85
        }
    },
    '1': {
        text: 'expanded view : displays the subscription as expanded items',
        key: {
            keyCode: 49
        }
    },
    '2': {
        text: 'list view : displays the subscription as a list of headlines',
        key: {
            keyCode: 50
        }
    },
    '1 pad': {
        text: 'expanded view : displays the subscription as expanded items',
        key: {
            keyCode: 97
        }
    },
    '2 pad': {
        text: 'list view : displays the subscription as a list of headlines',
        key: {
            keyCode: 98
        }
    },
    '/': {
        text: 'search : moves your cursor to the search box',
        key: {
            keyCode: 111
        }
    },
    'a': {
        text: 'add a subscription : opens the "Add a subscription" box in the sidebar',
        key: {
            keyCode: 65
        }
    },
    '?': {
        text: 'keyboard shortcuts help : displays a quick guide to all of Reader\'s shortcuts',
        key: {
            keyCode: 219
        }
    }
};
/**
 * @author Valente
 */
function getText(lang, script, option, deflang, deftext){
    var text = '';
    if (GRP.langs[lang] && GRP.langs[lang].texts[script] && GRP.langs[lang].texts[script][option]) {
        text = GRP.langs[lang].texts[script][option];
    }
    if (!text && deflang) {
        text = getText(deflang, script, option, false, deftext);
    }
    if (!text && !deflang) {
        text = deftext || '';
    }
    return text;
}

function getCategory(lang, name, deflang){
    var text = '';
    if (GRP.langs[lang] && GRP.langs[lang].categories && GRP.langs[lang].categories[name]) {
        text = GRP.langs[lang].categories[name];
    }
    if (!text && deflang) {
        text = getCategory(deflang, name);
    }
    if (!text && !deflang) {
        text = name.toMaj();
    }
    return text;
}


function getTextPrefs(lang, script, option, deflang, deftext){
    var text = '';
    if (GRP.langs[lang] && GRP.langs[lang].prefs[script] && GRP.langs[lang].prefs[script][option]) {
        text = GRP.langs[lang].prefs[script][option];
    }
    if (!text && deflang) {
        text = getTextPrefs(deflang, script, option, false, deftext);
    }
    if (!text && !deflang) {
        text = deftext || '';
    }
    return text;
}


function autoTranslate(name){
    var params = urlDecode(window.location.search.substring(1));
    var lang = params.lang || 'en';
    loadLangs(lang, function(){
        translatePage(lang, name);
    });
}

/*
 //Dynamical translation (too complex ; not useful)
 function onLang(){
 var lang = get_id('language_lang').value;
 loadLangs(lang, function(){
 translatePage(lang, 'cat', 'categories',0);
 translatePage(lang);
 });
 }
 */
function translatePage(lang, name, section, level){
    section = section || 'prefs';
    var translations = GRP.langs[lang][section];
    if (translations) {
        function replaceTexts(name, texts){
            for (var key in texts) {
                var id = 't_' + ((name === 'global') ? '' : (name + '_')) + key;
                var el = document.getElementById(id);
                if (el) {
                    var text = texts[key];
                    if (/^val-/.test(key)) {
                        el.value = text;
                    } else {
                        el.innerHTML = text;
                    }
                }
            }
        }
        if (name) {
            var texts = (level == 0) ? translations : translations[name];
            replaceTexts(name, texts);
        } else {
            for (var nam in translations) {
                var texts = translations[nam];
                replaceTexts(nam, texts);
            }
        }
    }
}

function getAllTexts(){
    var texts = getElements("//*[starts-with(@id, 't_')]");
    var translations = {};
    for (var i = 0, len = texts.length; i < len; i++) {
        var id = texts[i].id;
        var o = splitId(id);
        
        var text = texts[i].innerHTML;
        text = text.replace(/\n/g, '');
        if (!translations[o.name]) {
            translations[o.name] = {};
        }
        translations[o.name][o.key] = text.trim();
    }
    //document.write("<!--" + JSON.stringify(translations) + "-->");
}

function splitId(id){
    var key, name;
    var m = id.split('_');
    if (m.length == 2) {
        name = 'global';
        key = m[1];
    } else {
        name = m[1];
        m.shift();
        m.shift();
        key = m.join('_');
    }
    return {
        key: key,
        name: name
    };
}

function loadLangs(lang, cb, scope){
    //TODO: load json here instead evald js
    if (GRP.langs && GRP.langs[lang]) {
        merge(GRP, GRP.langs[lang]);
		if (cb) {
            cb.call(scope || this);
        }
    } else {
        GM_addScript('lang/' + lang + '/features.js', true, function(){
            GM_addScript('lang/' + lang + '/langs.js', true, function(){
                //override locale texts
                if (GRP.langs) {
                    merge(GRP, GRP.langs[lang]);
                }
                if (cb) {
                    cb.call(scope || this);
                }
            }, true);
        }, true);
    }
}
var tplCruds = {};
function loadCruds(id){
    lang = lang || 'en';
    var gp = getTextPrefs;
    tplCruds = {
        favicons_domains: {
            tpl: '{{%IMPLICIT-ITERATOR}}<table class="crud rounded" summary="{{summary}}">' +
            '<thead><tr>{{#headers}}<th scope="col" class="crud_header_{{.}}">{{.}}</th>{{/headers}}</tr></thead>' +
            '<tfoot><tr><td colspan="{{colspan}}"><em>{{desc}}</em></td>' +
            '<td><a id="t_{{$name}}_add" class="add" href="javascript:add(\'{{$name}}\');">{{txt_add}}</a></td></tr></tfoot>' +
            '<tbody>{{#rows}} ' +
            '<tr><td><a href="{{url}}" target="_blank"><span>{{#ico}}<img alt="favicon" class="favicon" title="Preview" src="{{icon}}" width="16" height="16"/>{{/ico}}{{etext}}</span></a></td>' +
            '<td><a class="action" id="t_{{$name}}_edit" href="javascript:add(\'{{$name}}\', \'{{url}}\');">{{txt_edit}}</a></td>' +
            '<td><a class="action" id="t_{{$name}}_remove" href="javascript:remove(\'{{$name}}\', \'{{url}}\');">{{txt_remove}}</a></td>' +
            '</tr>{{/rows}}</tbody></table>',
            data: {
                name: 'favicons',
                ico: true,
                colspan: 2,
                headers: ['url', 'edit', 'remove'],
                summary: getText(lang, 'favicons', 'summary'),
                desc: getText(lang, 'favicons', 'desc'),
                txt_add: getText(lang, 'filter', 'add'),
                txt_edit: getText(lang, 'filter', 'edit'),
                txt_remove: getText(lang, 'filter', 'remove'),
                url: function(){
                    return normalizeUrl(this.url);
                },
                rows: function(){
                    return notEmpty(map2array(prefs.favicons_domains, 'url', 'icon'));
                },
                etext: function(){
                    return ellipsis(this.url, 60);
                }
            }
        },
        column_filter: {
            tpl: '{{%IMPLICIT-ITERATOR}}<table class="crud rounded" summary="{{summary}}">' +
            '<thead><tr>{{#headers}}<th scope="col" class="crud_header_{{.}}">{{.}}</th>{{/headers}}</tr></thead>' +
            '<tfoot><tr><td colspan="{{colspan}}"><em>{{desc}}</em></td>' +
            '<td><a id="t_{{$name}}_add" class="add" href="javascript:add(\'{{$name}}\');">{{txt_add}}</a></td></tr></tfoot>' +
            '<tbody>{{#rows}} ' +
            '<tr><td><a href="{{.}}" target="_blank"><span>{{#ico}}<img alt="favicon" class="favicon" title="Preview" src="{{icon}}" width="16" height="16"/>{{/ico}}{{etext}}</span></a></td>' +
            '<td><a class="action" id="t_{{$name}}_edit" href="javascript:add(\'{{$name}}\', \'{{.}}\');">{{txt_edit}}</a></td>' +
            '<td><a class="action" id="t_{{$name}}_remove" href="javascript:remove(\'{{$name}}\', \'{{.}}\');">{{txt_remove}}</a></td>' +
            '</tr>{{/rows}}</tbody></table>',
            data: {
                name: 'column',
                ico: false,
                colspan: 2,
                headers: ['url', 'edit', 'remove'],
                summary: getText(lang, 'column', 'summary'),
                desc: getText(lang, 'column', 'desc'),
                txt_add: getText(lang, 'filter', 'add'),
                txt_edit: getText(lang, 'filter', 'edit'),
                txt_remove: getText(lang, 'filter', 'remove'),
                rows: function(){
                    //return notEmpty(map2array(prefs.column_filter, 'url', 'exclude'));
                    return notEmpty(prefs.column_filter);
                },
                etext: function(){
                    return ellipsis(this['.'], 60);
                }
            }
        },
        preview_filter: {
            tpl: '{{%IMPLICIT-ITERATOR}}<table class="crud rounded" summary="{{summary}}">' +
            '<thead><tr>{{#headers}}<th scope="col" class="crud_header_{{.}}">{{.}}</th>{{/headers}}</tr></thead>' +
            '<tfoot><tr><td colspan="{{colspan}}"><em>{{desc}}</em></td>' +
            '<td><a id="t_{{$name}}_add" class="add" href="javascript:add(\'{{$name}}\');">{{txt_add}}</a></td></tr></tfoot>' +
            '<tbody>{{#rows}} ' +
            '<tr><td><a href="{{.}}" target="_blank"><span>{{#ico}}<img alt="favicon" class="favicon" title="Preview" src="{{icon}}" width="16" height="16"/>{{/ico}}{{etext}}</span></a></td>' +
            '<td><a class="action" id="t_{{$name}}_edit" href="javascript:add(\'{{$name}}\', \'{{.}}\');">{{txt_edit}}</a></td>' +
            '<td><a class="action" id="t_{{$name}}_remove" href="javascript:remove(\'{{$name}}\', \'{{.}}\');">{{txt_remove}}</a></td>' +
            '</tr>{{/rows}}</tbody></table>',
            data: {
                name: 'preview',
                ico: false,
                colspan: 2,
                headers: ['url', 'edit', 'remove'],
                summary: getText(lang, 'preview', 'summary'),
                desc: getText(lang, 'preview', 'desc'),
                txt_add: getText(lang, 'filter', 'add'),
                txt_edit: getText(lang, 'filter', 'edit'),
                txt_remove: getText(lang, 'filter', 'remove'),
                rows: function(){
                    return notEmpty(prefs.preview_filter);
                },
                etext: function(){
                    return ellipsis(this['.'], 60);
                }
            }
        },
        lightbox_filter: {
            tpl: '{{%IMPLICIT-ITERATOR}}<table class="crud rounded" summary="{{summary}}">' +
            '<thead><tr>{{#headers}}<th scope="col" class="crud_header_{{.}}">{{.}}</th>{{/headers}}</tr></thead>' +
            '<tfoot><tr><td colspan="{{colspan}}"><em>{{desc}}</em></td>' +
            '<td><a id="t_{{$name}}_add" class="add" href="javascript:add(\'{{$name}}\');">{{txt_add}}</a></td></tr></tfoot>' +
            '<tbody>{{#rows}} ' +
            '<tr><td><a href="{{.}}" target="_blank"><span>{{#ico}}<img alt="favicon" class="favicon" title="Preview" src="{{icon}}" width="16" height="16"/>{{/ico}}{{etext}}</span></a></td>' +
            '<td><a class="action" id="t_{{$name}}_edit" href="javascript:add(\'{{$name}}\', \'{{.}}\');">{{txt_edit}}</a></td>' +
            '<td><a class="action" id="t_{{$name}}_remove" href="javascript:remove(\'{{$name}}\', \'{{.}}\');">{{txt_remove}}</a></td>' +
            '</tr>{{/rows}}</tbody></table>',
            data: {
                name: 'lightbox',
                ico: false,
                colspan: 2,
                headers: ['url', 'edit', 'remove'],
                summary: getText(lang, 'lightbox', 'summary'),
                desc: getText(lang, 'lightbox', 'desc'),
                txt_add: getText(lang, 'filter', 'add'),
                txt_edit: getText(lang, 'filter', 'edit'),
                txt_remove: getText(lang, 'filter', 'remove'),
                rows: function(){
                    return notEmpty(prefs.lightbox_filter);
                },
                etext: function(){
                    return ellipsis(this['.'], 60);
                }
            }
        },
        replacer_items: {
            tpl: '{{%IMPLICIT-ITERATOR}}<table class="crud rounded" summary="{{summary}}">' +
            '<thead><tr>{{#headers}}<th scope="col" class="crud_header_{{.}}">{{.}}</th>{{/headers}}</tr></thead>' +
            '<tfoot><tr><td colspan="{{colspan}}"><em>{{desc}}</em></td>' +
            '<td><a id="t_{{$name}}_add" class="add" href="javascript:add(\'{{$name}}\');">{{txt_add}}</a></td></tr></tfoot>' +
            '<tbody>{{#rows}} ' +
            '<tr><td>{{.}}</td><td><span class="url_replacer">{{url}}</span><br/>{{search}}<br/>{{replace}}</td>' +
            '<td><a class="action" id="t_{{$name}}_edit" href="javascript:add(\'{{$name}}\', \'{{.}}\');">{{txt_edit}}</a></td>' +
            '<td><a class="action" id="t_{{$name}}_remove" href="javascript:remove(\'{{$name}}\', \'{{.}}\');">{{txt_remove}}</a></td>' +
            '</tr>{{/rows}}</tbody></table>',
            data: {
                name: 'replacer',
                ico: false,
                colspan: 3,
                headers: [gp(lang, 'replacer', 'title'), gp(lang, 'replacer', 'link') + '; ' + gp(lang, 'replacer', 'from') + '; ' + gp(lang, 'replacer', 'to'), 'edit', 'remove'],
                summary: getText(lang, 'replacer', 'summary'),
                desc: getText(lang, 'replacer', 'desc'),
                txt_add: getText(lang, 'filter', 'add'),
                txt_edit: getText(lang, 'filter', 'edit'),
                txt_remove: getText(lang, 'filter', 'remove'),
                rows: function(){
                    //var a = notEmpty(prefs.replacer_items);
                    var a = map2array(prefs.replacer_items, '.', '', true);
                    return a;
                }
            }
        },
        translate_filter: {
            tpl: '{{%IMPLICIT-ITERATOR}}<table class="crud rounded" summary="{{summary}}">' +
            '<thead><tr>{{#headers}}<th scope="col" class="crud_header_{{.}}">{{.}}</th>{{/headers}}</tr></thead>' +
            '<tfoot><tr><td colspan="{{colspan}}"><em>{{desc}}</em></td>' +
            '<td><a id="t_{{$name}}_add" class="add" href="javascript:add(\'{{$name}}\');">{{txt_add}}</a></td></tr></tfoot>' +
            '<tbody>{{#rows}} ' +
            '<tr><td><a href="{{.}}" target="_blank"><span>{{#ico}}<img alt="favicon" class="favicon" title="Preview" src="{{icon}}" width="16" height="16"/>{{/ico}}{{etext}}</span></a></td>' +
            '<td><a class="action" id="t_{{$name}}_edit" href="javascript:add(\'{{$name}}\', \'{{.}}\');">{{txt_edit}}</a></td>' +
            '<td><a class="action" id="t_{{$name}}_remove" href="javascript:remove(\'{{$name}}\', \'{{.}}\');">{{txt_remove}}</a></td>' +
            '</tr>{{/rows}}</tbody></table>',
            data: {
                name: 'translate',
                ico: false,
                colspan: 2,
                headers: ['url', 'edit', 'remove'],
                summary: getText(lang, 'translate', 'summary'),
                desc: getText(lang, 'translate', 'desc'),
                txt_add: getText(lang, 'filter', 'add'),
                txt_edit: getText(lang, 'filter', 'edit'),
                txt_remove: getText(lang, 'filter', 'remove'),
                rows: function(){
                    //return notEmpty(map2array(prefs.column_filter, 'url', 'exclude'));
                    return notEmpty(prefs.translate_filter);
                },
                etext: function(){
                    return ellipsis(this['.'], 60);
                }
            }
        }
    };
    if (id) {
        loadCRUD(id, tplCruds[id]);
    } else {
        iterate(tplCruds, function(id, otpl){
            loadCRUD(id, otpl);
        });
    }
}

/**
 *
 * @param {Object} id  Id of Dom Element
 * @param {Object} name Name of prefs to get data
 */
function loadCRUD(id, o){
    var el = document.getElementById(id);
    if (el) {
        var html = '';
        if (!o) {
            o = tplCruds[id];
        }
        //html = fillTemplate(o);
        html = Mustache.to_html(o.tpl, o.data);
        el.innerHTML = html;
    }
}

function fillTemplate(o){
    var html = '', v = o.data || {};
    if (o.tpls) {
        //here v must be an object
        iterate(o.tpls, function(key, otpl){
            v[key] = fillTemplate(otpl);
        });
    }
    if (isArray(v)) {
        html = iterateFillTpl(v, o.tpl, o.formatData);
    } else if (!isObjectEmpty(v)) {
        if (o.formatData) {
            html = iterateFillTpl(v, o.tpl, o.formatData);
        } else {
            html = fillTpl(o.tpl, v);
        }
    }
    return html;
}

function iterateFillTpl(data, tpl, formatData){
    var html = '';
    iterate(data, function(k, o){
        var v = (formatData) ? formatData.call(this, k, o) : {
            text: o
        };
        html += fillTpl(tpl, v);
    });
    return html;
}

function remove(id, key){
    if (id === 'favicons') {
        return removefavicon(key);
    } else if (id === 'replacer') {
        return removeReplacerItems(key);
    } else {
        //if (id === 'column' || id === 'preview' || id === 'lightbox')
        return removefiltersites(id, key);
    }
}

function add(id, key){
    if (id === 'favicons') {
        return addfavicon(key);
    } else if (id === 'replacer') {
        return addReplacerItems(id, key);
    } else {
        //if (id === 'column' || id === 'preview' || id === 'lightbox')
        return addfiltersites(id, key);
    }
}

/**
 * CRUD for filter sites
 *
 */
function addfiltersites(id, urlin){
    var DEFAULT_SITE = '';
    var DEFAULT_URL = '';
    var url = urlin || DEFAULT_SITE;
    url = prompt(getTextPrefs(lang, id, 'entersite'), url);
    if (!url) {
        return;
    }
    if (!prefs[id + '_filter']) {
        prefs[id + '_filter'] = [];
    }
    if (findInArray(prefs[id + '_filter'], url) === false) {
        prefs[id + '_filter'].push(url);
        //Refresh
        loadCRUD(id + '_filter');
    }
}

function removefiltersites(id, url){
    var i = findInArray(prefs[id + '_filter'], url);
    if (i!==false && i>=0) {
        delete prefs[id + '_filter'][i];
		//prefs[id + '_filter'].splice(i,1);
        //Refresh
        loadCRUD(id + '_filter');
    }
}

/**
 * CRUD for Favicons
 *
 */
function addfavicon(urlin){
    var DEFAULT_SITE = '';
    var DEFAULT_URL = '';
    var url = urlin || DEFAULT_SITE;
    url = prompt(getTextPrefs(lang, 'favicons', 'entersite'), url);
    if (!url) {
        return;
    }
    var icon = cleanUrl(prefs.favicons_domains[url] || getDomain(url)) + '/favicon.ico';
    //Enter the icon url
    var promptUrl = getTextPrefs(lang, 'favicons', 'prompticon');
    icon = prompt(promptUrl, icon);
    if (icon === '') {
        //go to find
        chrome.extension.sendRequest({
            message: "geticon",
            url: url
        }, function(a){
            // ->iconget 
            addfaviconNext(a.url, a.icon, a.title);
        });
    } else {
        addfaviconNext(url, icon, '');
    }
}

function addfaviconNext(url, icon, title){
    if (!icon) {
        return;
    }
    var favicon = {
        url: url,
        icon: icon
    };
    /*if (urlin && url != urlin) {
     //remove old
     removefavicon(urlin);
     }*/
    savefavicon(favicon.url, favicon.icon);
}

//WARN: used too from background
function savefavicon(url, icon, title){
    prefs.favicons_domains[url] = icon;
    loadCRUD('favicons_domains');
}

function removefavicon(url){
    delete prefs.favicons_domains[url];
	//prefs.favicons_domains.splice(url,1);
    loadCRUD('favicons_domains');
}

/**
 * Replacer
 *
 */
function addReplacerItems(id, key){
    var title = key || 'Image site.web';
    title = prompt(getTextPrefs(lang, 'replacer', 'prompttitle'), title);
    if (!title) {
        return;
    }
    if (!key && prefs.replacer_items[title]) {
        //on add, check if key already exists
        alert(getTextPrefs(lang, 'global', 'alreadyexist'));
        return;
    }
    var def = prefs.replacer_items[key] ||
    {
        url: 'http://www.WEBSITE.COM',
        search: 'xpath://div[@class="CLASSNAME"]',
        replace: "$1"
    };
    url = prompt(getTextPrefs(lang, 'replacer', 'link'), def.url);
    if (!url) {
        return;
    }
    search = prompt(getTextPrefs(lang, 'replacer', 'from'), def.search);
    if (!search) {
        return;
    }
    replace = prompt(getTextPrefs(lang, 'replacer', 'to'), def.replace);
    if (replace) {
        saveReplacerNext(title, url, search, replace);
    }
}

function saveReplacerNext(title, url, search, replace){
    if (!prefs.replacer_items) {
        prefs.replacer_items = {};
    }
    prefs.replacer_items[title] = {
        url: url,
        search: search,
        replace: replace
    };
	prefs._replacer_changed=true;
    loadCRUD('replacer_items');
}

function removeReplacerItems(key){
    delete prefs.replacer_items[key];
	//prefs.replacer_items.splice(key,1);
    loadCRUD('replacer_items');
}
function loadSkin(){
    var input = document.getElementById("theme_skin");
    var li = document.getElementById('skin_' + input.value);
    if (!li) {
        li = document.getElementById('skin_none');
    }
    //select theme
    if (li) {
        li.onclick(false, true);
    }
}

var lastPanel, lastLink;
function showPanel(id){
    if (typeof window['run_' + id] == "function") {
        window['run_' + id].call(this, id);
    }
    var link = document.getElementById('l_' + id);
    if (lastLink) {
        lastLink.className = "";
    }
    if (link) {
        link.className = "on";
        showcat(link);
        lastLink = link;
    }
    var panel = document.getElementById('panel_' + id);
    if (lastPanel) {
        lastPanel.style.display = "none";
    }
    if (panel) {
        panel.style.display = "inline";
        lastPanel = panel;
        window.location.hash = '#' + id;
    }
}

function showcat(el, fromoutside){
    var wrap;
	if (fromoutside){
		wrap = getFirstElementByClassName(el, 'wrap');
	}else{
		wrap=findParentNode(el, 'ul', 'wrap');
	}
    if (lastCat) {
        hide(lastCat);
    }
    show(wrap);
    lastCat = wrap;
}

var lastCat;
function renderScripts(){
    var list = document.getElementById('scriptlist');//ul#scriptlist
    var panels = document.getElementById('panels');
    var tplCheckbox = '<li id="l_{id}"><a href="javascript:showPanel(\'{id}\')"><input id="{id}" name="{id}" type="checkbox" /><label for="{id}" id="l{id}" title="{desc}">{name}{status}</label><span class="open">{dlink}</span></a></li>';
    var tplLink = '<li id="l_{id}"><a class="link" href="javascript:showPanel(\'{id}\')"><span class="linkblock">{name}</span><span class="open olink">{dlink}</span></a></li>';
    var tplPanelTitle = '<div class="title"><h2>{name}</h2><div id="paneldesc_{id}" class="desc">{desc}</div></div>';
    var tplPanelIframe = '<div class="title"><h2>{name}</h2><iframe src="{url}" width="700" height="620"></iframe></div>';
    var categories = group(GRP.scripts, 'category');
	var firstcat=true;
    iterate(categories, function(category, scripts){
        var ulcat;
		var incat=true;
        if (incat) {
            var licat = dh(list, 'li', {
                cls: 'category'
            });
            var html = '<span class="bullet">•</span><span id="t_cat_'+category+'">'+getCategory(lang, category)+'</span>';
			if (firstcat){
				firstcat=false;
				html+='<div id="expandall">'+getTextPrefs(lang, 'global', 'expandall', 'en', 'All')+'</div>';
			}
			var acat = dh(licat, 'a', {
                //text: getCategory(lang, category),
				html: html,
                href: '#'
            }, {
                click: function(e){
                    var li=findParentNode(e.target, 'li', 'category');
					showcat(li, true);
                }
            });
            ulcat = dh(licat, 'ul', {
                cls: 'wrap'
            });
            hide(ulcat);
        }else{
			ulcat = list;
		}
        var html = '';
		
        iterate(scripts, function(id, script){
			script.dlink = '>';
			script.desc = script.desc||'';
			if (script.status){
				var stat = getTextPrefs(lang, 'global', 's'+script.status) || script.status;
				script.status='<span class="'+script.status+'">'+stat+'</span>';
			}else{
				script.status='';
			}
			
            var t = (script.link) ? tplLink : tplCheckbox;
            html += fillTpl(t, script);
            var body, panel = document.getElementById('panel_' + id);
            if (!panel) {
                //create panels for descritpion
                panel = document.createElement('div');
                panel.id = "panel_" + id;
                panel.style.display = "none";
                script.shortcut = script.shortcut || '-';
                var tpl = (script.url) ? tplPanelIframe : tplPanelTitle;
                panel.innerHTML = fillTpl(tpl, script);
                //+body
                body = document.createElement('div');
                body.className = "body";
                panel.appendChild(body);
                panels.appendChild(panel);
                script.dlink = '&gt;';
            } else {
                var header = document.createElement('div');
                header.className = 'header';
                header.innerHTML = fillTpl(tplPanelTitle, script);
                insertFirst(header, panel);
                body = getFirstElementByClassName(panel, 'body');
            }
            renderOptions(body, script);
            renderShortcuts(panel, script);
        }, this, true);
        if (incat) {
            ulcat.innerHTML = html;
        } else {
            ulcat.innerHTML += html;
        }
    });
    addClass(list.firstElementChild, 'first');
    addClass(list.lastElementChild, 'last');
    extraFeatures();
    showcat(list, true);
	
	//expand all 
	var eall = get_id('expandall');
	if (eall){
		eall.onclick=function(e){
			if (hasClass(eall, 'expanded')){
				removeClass(eall, 'expanded');
				toggleCategories(true);
			}else{
				addClass(eall, 'expanded');
				toggleCategories(false);
			}
		};
	}
}

function toggleCategories(expand){
	var s = get_id('scriptlist');
	var uls = s.getElementsByClassName('wrap');
	iterate(uls, function(id, ul){
		showas(ul, expand);
	});
}

var tplInput = '<label class="lbl {lcls}" id="t_{id}" for="{id}">{text}</label><input id="{id}" class="{cls}" name="{id}" type="{input}" value="{value}"{extra}"/><br/>';
var tplTextarea = '<label class="lbl lbltxtarea {lcls}" id="t_{id}" for="{id}">{text}</label><textarea style="" class="{cls}" id="{id}" name="{id}" cols="{cols}" rows="{rows}"{extra}">{value}</textarea><br/>';
var tplCheckbox = '<input id="{id}" name="{id}" type="checkbox"/><label class="lbl_checkbox" id="t_{id}" for="{id}">{text}</label><br/>';
var tplSelect = '<label class="lbl {lcls}" id="t_{id}">{text}</label><select name="{id}" id="{id}">{options}</select><br/><br/>';
var tplSelectOption = '<option value="{id}"{checked}>{value}</option>';
var tplButton = '<button value="{value}" name="{name}" id="{id}" onclick="javascript:{action}();return false;">{text}</button>';
var tplPara = '<p class="{cls}" id="t_{id}">{text}</p>';
var tplHeader = '<h{level}>{text}</h{level}>';
var tplDiv = '<div class="{cls}" id="{id}"></div>';
function renderOptions(body, script){
    if (!script.options) {
        return;
    }
    var cfg, xtype, value, html = '';
    iterate(script.options, function(option, cfg){
        if (typeof cfg === "object") {
            cfg.value = cfg.value || '';
            value = cfg.value;
            xtype = cfg.xtype || (typeof value);
        } else {
            value = cfg;
            xtype = typeof value;
        }
        var o = {
            text: getTextPrefs(lang, script.id, option, 'en') || ('-' + option + '-'),
            id: script.id + '_' + option,
            value: value,
            extra: '',
            lcls: cfg.lcls || '',
            input: cfg.input || 'text',
            cls: cfg.cls || ''
        };
        if (!document.getElementById(o.id)) {
            if (cfg.parent) {
                html += "<div class='mto' alt='" + cfg.parent + "'>";
            }
			
            if (xtype === "boolean") {
                html += fillTpl(tplCheckbox, o);
            } else if (xtype === "string") {
                if (cfg.size) {
                    o.extra = ' size="' + cfg.size + '"';
                }
                html += fillTpl(tplInput, o);
            } else if (xtype === "password") {
                if (cfg.size) {
                    o.extra = ' size="' + cfg.size + '"';
                }
                html += fillTpl(tplPwd, o);
            } else if (xtype === "number") {
                o.size = cfg.size || 3;
                o.extra = ' size="' + o.size + '"';
                html += fillTpl(tplInput, o);
            } else if (xtype === "textarea") {
                o.rows = cfg.rows || 5;
                o.cols = cfg.cols || 70;
				if (cfg.list && isArray(o.value)){
					o.value=o.value.join(cfg.sep||'\n');
				}
                html += fillTpl(tplTextarea, o);
            } else if (xtype === "p") {
                html += fillTpl(tplPara, o);
            }else if (xtype === "h") {
                o.level = o.level || 3;
				html += fillTpl(tplHeader, o);
            } else if (xtype === "html") {
                html += value;
            } else if (xtype === "select") {
                o.options = '';
                iterate(cfg.values, function(id, vo){
                    text = ''; //getTextPrefs(lang, script.id, option+'_'+id);
                    o.options += fillTpl(tplSelectOption, {
                        id: id,
                        value: vo.value || vo,
                        checked: (vo.checked ? ' checked="checked"' : '')
                    });
                });
                html += fillTpl(tplSelect, o);
            } else if (xtype === "button") {
                o.value= o.value||'';
				o.name= o.name||o.id;
				o.action= cfg.action||'void';
				html += fillTpl(tplButton, o);
            } else if (xtype === "crud") {
                o.cls = '_crud' + ((o.cls) ? (' ' + o.cls) : '');
                html += fillTpl(tplDiv, o);
            } else if (xtype === "picker") {
                o.cls = 'picker' + ((o.cls) ? (' ' + o.cls) : '');
                if (cfg.size) {
                    o.extra = ' size="' + cfg.size + '"';
                }
                html += fillTpl(tplInput, o);
            }
            if (cfg.parent) {
                html += "</div>";
            }
        }
    });
    body.innerHTML += html;
}

var EDITORS = {};
function extraFeatures(){
    textareaTab();
    renderpicker();
    //var CODEMIRROR_PATH = 'http://marijn.haverbeke.nl/codemirror';
    var CODEMIRROR_PATH = 'lib/codemirror';
    if (CodeMirror && get_id('relook_css')) {
        EDITORS.relook_css = CodeMirror.fromTextArea('relook_css', {
            parserfile: "parsecss.js",
            stylesheet: [CODEMIRROR_PATH + "/css/csscolors.css", "css/editor.css"],
            path: CODEMIRROR_PATH + "/js/",
            tabMode: 'shift',
            height: '500px'
        });
    }
}

function renderpicker(){
    if (typeof jQuery !== "undefined") {
        jQuery('.picker').ColorPicker({
            onSubmit: function(hsb, hex, rgb, el){
                $(el).val('#' + hex);
                $(el).ColorPickerHide();
            },
            onBeforeShow: function(){
                $(this).ColorPickerSetColor(this.value.replace('#', ''));
            }
        }).bind('keyup', function(){
            $(this).ColorPickerSetColor(this.value);
        });
    }
}

function renderSkins(){
    var last;
	var SKINS_PATH = 'http://googlereaderplus.googlecode.com/svn/trunk/GoogleReaderPlus/images/skins/';
    var list = document.getElementById('skinlist');
    list.innerHTML = '';
    iterate(GRP.skins, function(id, o){
        var li = document.createElement('li');
        var a = document.createElement('a');
        li.id = 'skin_' + id;
        a.innerHTML = o.name;
        a.href = '#';
        li.appendChild(a);
        list.appendChild(li);
        li.onclick = function(e, simulate){
            var c = this;
            if (last) {
                last.className = "";
            }
            addClass(c, "on");
            var thumb = document.getElementById("thumb");
            var id = c.id.replace('skin_', '');
            var input = document.getElementById("theme_skin");
            var mtos = document.getElementsByClassName('mto');
            if (mtos && mtos.length > 0) {
                foreach(mtos, function(mto){
                    addClassIf(mto, 'hidden', (id !== mto.getAttribute('alt')));
                });
            }
            if (id === "none") {
                input.value = "";
                addClass(thumb, "hidden", true);
				addClass(get_id('skindesc'), "hidden", true)
            } else {
                input.value = id;
                thumb.className = "";
				thumb.src = "images/loading-bar300.gif";
                thumb.src = o.pic || (SKINS_PATH+ id + ".png");
                var athumb = document.getElementById("athumb");
                if (o.ref) {
                    athumb.href = o.ref;
                    athumb.target = 'blank';
                } else {
                    athumb.href = '#';
                    athumb.target = '';
                    athumb.removeAttribute('target');
                }
                var skindesc = document.getElementById("skindesc");
                if (skindesc) {
                    skindesc.innerHTML = (o.desc) ? (o.name + ' - ' + o.desc) : o.name;
                }
                athumb.title = o.name;
                //check theme feature
                if (!simulate) {
                    var checktheme = document.getElementById("theme");
                    if (checktheme) {
                        checktheme.checked = true;
                    }
                }
            }
            last = c;
        };
    });
    addClass(list.firstChild, 'first');
    addClass(list.lastChild, 'last');
}

function createReport(report){
    var list = document.getElementById('sysinfo');
    if (list) {
        list.innerHTML = '';
        recurseList(list, report, true);
    }
}

function recurseList(root, list, first){
    var ul = document.createElement('ul');
    if (!first) {
        ul.className = "mnu rounded info";
    }
    for (var o in list) {
        var li = document.createElement('li');
        if (typeof list[o] === "object") {
            ul.innerHTML += "<span class='info-title'>" + o + "</span>";
            recurseList(ul, list[o]);
        } else {
            li.innerHTML = '<span>' + o + " : " + list[o] + '</span>';
            ul.appendChild(li);
        }
    }
    root.appendChild(ul);
}

function disableAllScripts(){
    /*for (var i = 0, len = GRP.scripts.length; i < len; i++) {
     var script = GRP.scripts[i];
     prefs[script.id] = false;
     }*/
    iterate(GRP.scripts, function(id, script){
        prefs[id] = false;
    });
}

function setpackage(id){
    disableAllScripts();
    if (id === "reset") {
        //Refresh page to reload all options for each script
        var sure = confirm(getTextPrefs(lang, 'pack', 'confirmdel'));
        if (sure) {
            prefs = {};
            renderPrefs();
            saveprefs(true, true);
        }
        return;
    } else {
        iterate(GRP.packages[id], function(i, data){
            prefs[i] = true;
            if (data && (typeof data === 'object')) {
                iterate(data, function(k, o){
                    prefs[i + '_' + k] = o;
                });
            }
        });
    }
    renderPrefs();//update
}
var externalthemes={};
function renderPreviewTheme(){
	externalthemes = GRP.getExternalThemes();
	var theme = document.getElementById('theme_externaltheme');
	theme.addEventListener('change', previewtheme, false);
	theme.addEventListener('click', previewtheme, false);
	theme.addEventListener('keyup', previewtheme, false);
	previewtheme();
}
var reGmailTheme = /^gmail_/;
var reGooglePublicTheme = /^public_/;
var reGoogleEditorTheme = /^editor_/;
function previewtheme(){
	var theme = document.getElementById('theme_externaltheme');
	var prview = document.getElementById('thprview');
	if (!prview) {
		dh(theme, 'div', {
			id: 'thprview',
			position: 'after',
			html: '<img id="imgprview"/>'
		});
	}
	var imgprview = document.getElementById('imgprview');
	var code = theme.value;
	var otheme = externalthemes[code];
	if (reGmailTheme.test(code)) {
		code=code.replace(reGmailTheme, '');
		imgprview.src = "https://mail.google.com/mail/images/2/5/" + code + "/preview1.png";
		removeClass(imgprview, 'hidden');
	}else if (reGooglePublicTheme.test(code)) {
		imgprview.src = otheme + "s104/";
		removeClass(imgprview, 'hidden');
	}else if (reGoogleEditorTheme.test(code)) {
		imgprview.src = otheme + "s144/";
		removeClass(imgprview, 'hidden');
	}else{
		addClass(imgprview, 'hidden', true);
		imgprview.src = "";
	}
}
function importprefs(){
    var r = confirm(getTextPrefs(lang, 'general', 'confirmimport'));
    if (r) {
        var el = document.getElementById("ieprefs");
        if (el && el.value) {
            try {
                prefs = JSON.parse(el.value);
                saveprefs(true, true);
                info(getTextPrefs(lang, 'global', 'prefsimportedok', 'en', "Preferences imported!"));
            } 
            catch (e) {
                info(getTextPrefs(lang, 'global', 'prefsimportfailed', 'en', "Import failed!") + ' : ' + e, 'error');
            }
        }
    }
}

function exportprefs(){
    var el = document.getElementById("ieprefs");
    var p = {};
    iterate(prefs, function(i, pref){
        if (i && pref && !(/password/.test(i))) {
            p[i] = pref;
        }
    });
    el.value = JSON.stringify(p)
}

function initprefs(){
    lang = prefs.language_lang || 'en';
    console.log('Current lang : ' + lang);
    loadLangs(lang, function(){
        renderScripts();
        translatePage(lang);
        specialTranslate(lang);
        renderSkins();
        renderPrefs();
        var current = window.location.hash.substring(1) || 'general';
        showPanel(current);
        reportNavigator();
        renderPreviewTheme();
        renderThemes();
        renderDummies();
    });
}

function isChecked(form, name){
    return (form && form[name] && form[name].checked);
}

function applyprefs(){
    var form = document.frmprefs;
    //general checked if one option ON 
    if (isChecked(form, 'general_secure') ||
    isChecked(form, 'general_counter') ||
    isChecked(form, 'general_opendirect')) {
        if (form.general) {
            form.general.checked = true;
        }
    }
    for (var i in form) {
        var ctrl = form[i];
        if (ctrl && ctrl.name && !hasClass(ctrl, 'ignore')) {
            var o = ctrl.name;
            if (typeof ctrl.key !== "undefined") {
                //shortcut code
                prefs[o] = ctrl.key;
            } else if (ctrl.type === "checkbox") {
                if (ctrl.checked || prefs[o]) {
                    prefs[o] = ctrl.checked;
                }
            } else if (ctrl.nodeName === "TEXTAREA") {
                if (EDITORS && EDITORS[o]) {
                    prefs[o] = EDITORS[o].getCode();
                    //ctrl.innerHTML=prefs[o];
                } else {
                    var v = ctrl.value;
                    if (v || prefs[o]) {
                        if (hasClass(ctrl, 'xlist')) {
                            v = v.split('\n');
                        }
                        prefs[o] = v;
                    }
                    
                }
            } else {
                if (ctrl.value || prefs[o]) {
                    prefs[o] = ctrl.value;
                }
            }
            //keep prefs light
			/*if (!prefs[o]) {
                delete prefs[o];
            }*/
        }
    }
    var select = document.getElementById("language_lang");
    if (select) {
        prefs.language_lang = select.value;
    }
}

function saveprefs(reload, cleanall){
    if (!cleanall) {
        applyprefs();
    }
    if (prefs && lang !== prefs.language_lang) {
        //reload if lang changed!
        reload = true;
    }
    chrome.extension.sendRequest({
        message: "setprefs",
        prefs: prefs,
        cleanall: cleanall || false
    });
    run_extshortcuts();
    info(getTextPrefs(lang, 'global', 'prefssaved', 'en', "Preferences saved"));
    if (reload) {
        window.location.reload();
    }
}

function renderPrefs(){
    if (prefs) {
        var select = get_id("language_lang");
        if (select) {
            select.value = lang;
        }
        console.log(prefs);
        for (var o in prefs) {
            var ctrl = document.frmprefs[o];
            if (ctrl && (typeof prefs[o] !== 'undefined')) {
                if (!hasClass(ctrl, 'ignore')) {
                    //This could help
                    //var m = /([^_]+)_(.*)/.exec(o);
                    //var script = m[1], name= m[2];
                    //var opts = GRP.scripts[script].options[name];
                    var opts = {};
                    if (ctrl.tagName === "INPUT") {
                        if (ctrl.key) {
                            //shortcut
                            var key = unmarshallKey(prefs[o]);
                            setShortcut(key, ctrl);
                        } else if (ctrl.type === "checkbox") {
                            ctrl.checked = (prefs[o] === true);
                        } else {
                            //text,password,hidden
                            ctrl.value = prefs[o];
                        }
                    } else if (ctrl.nodeName === "SELECT") {
                        ctrl.value = prefs[o];
                    } else if (ctrl.nodeName === "TEXTAREA") {
                        if (EDITORS && EDITORS[o]) {
                            var ed = EDITORS[o];
                            var p = prefs[o];
                            window.setTimeout(function(){
                                ed.setCode(p);
                            }, 500);
                        } else {
                            var v = prefs[o];
                            if (isArray(v)) {
                                v = v.join(opts.sep || '\n');
                            } else if (typeof v === 'object') {
                                try {
                                    v = JSON.stringify(v);
                                } 
                                catch (e) {
                                    //
                                }
                            }
                            ctrl.value = v;
                        }
                    }
                }
            }
        }
        loadSkin();
        loadCruds();
    }
}

function reportNavigator(){
    createReport(getInfo());
}

function initGRP(){
    GRP.setVersion();
    var me = this;
    mycore.extension.sendRequest({
        message: "getprefs"
    }, function(a){
        prefs = a.prefs;
        initprefs();
    });
}

function info(msg, cls){
    var status = document.getElementById('status');
    status.innerHTML = msg;
    status.className = "rounded " + (cls || '');
    window.setTimeout(function(){
        status.innerHTML = "";
        status.className = "rounded hidden";
    }, 3000);
}

function findReader(){
    chrome.extension.sendRequest({
        message: "findreader"
    });
}

function specialTranslate(lang){
    var el = document.getElementById("t_link_about");
    if (el) {
        el.href = "about.html?lang=" + lang;
    }
}

function hashchange(){
    var script = location.hash;
    showPanel(script);
}

function renderDummies(){
    /*var sel = get_id('language_lang');
     if (sel){
     sel.addEventListener('change', onLang);
     sel.addEventListener('keyup', onLang);
     }*/
    var el = get_id('fbbtn');
    el.innerHTML = '<iframe class="ifbook" src="http://www.facebook.com/plugins/like.php?href=https%253A%252F%252Fchrome.google.com%252Fextensions%252Fdetail%252Fhhcknjkmaaeinhdjgimjnophgpbdgfmg&amp;layout=button_count&amp;action=recommend&amp;font=trebuchet%2Bms&amp;colorscheme=dark" scrolling="no" frameborder="0" allowTransparency="true"></iframe>';
}
function run_extshortcuts(){
    //update all Keyboard shortcuts
    var key, html = '';
    var grpshortcuts = document.getElementById('grpshortcuts');
    grpshortcuts.innerHTML = '';
    var shortcuts = [];
    iterate(GRP.scripts, function(id, script){
        iterate(script.shortcuts, function(sid, shortcut){
            if (prefs && prefs[id + '_key_' + sid]) {
                var v = prefs[id + '_key_' + sid];
				if (typeof v === 'string') {
					key = unmarshallKey(v);
				}else{
					key = v.key;
				}
            } else {
                key = shortcut.key;
            }
            shortcut.keytext = formatKey(key);
			shortcut.keysort = formatKey(key, true);
            shortcuts.push({
                script: id,
                sid: sid,
                shortcut: shortcut
            });
        });
    });
    iterate(GRP.googleshortcuts, function(id, o){
        shortcuts.push({
            script: 'google',
            sid: 'google_' + id,
            shortcut: {
                id: 'google_' + id,
                title: 'Google - ' + o.text,
                keytext: id,
				keysort: formatKey(o.key, true)
            }
        });
    });
    shortcuts.sort(function(a, b){
        if (a.shortcut.keysort > b.shortcut.keysort) {
            return 1;
        } else if (a.shortcut.keysort < b.shortcut.keysort) {
            return -1;
        }
        return 0;
    });
	var tplShorcutGoogle = '<li class="shortcut_google"><span>{keytext}</span>{title}</li>';
	var tplShorcut = '<li><a href="javascript:showPanel(\'{script}\');"><span>{keytext}</span>{title}</a></li>';
    foreach(shortcuts, function(o){
        o.shortcut.script=o.script;
		var tpl = (o.script==='google')?tplShorcutGoogle:tplShorcut;
		html += fillTpl(tpl, o.shortcut);
    });
    grpshortcuts.innerHTML = html;
}

function renderShortcuts(el, script){
	iterate(script.shortcuts, function(sid, shortcut){
        createShortcut(el, script, shortcut, sid);
    });
}

function createShortcut(el, script, shortcut){
    var div = document.createElement('div');
    div.className = 'shortcut';
    var label = document.createElement('label');
    var t = getText(lang, script.id, 'shortcut_' + shortcut.id);
    if (t) {
        shortcut.title = t;
    }
    label.innerHTML = shortcut.title + ':';
    div.appendChild(label);
    var input = document.createElement('input');
    input.type = 'text';
    input.size = 15;
    input.className = 'shortcut';
    input.id = script.id + '_key_' + shortcut.id;
    var key = shortcut.key;
	
    //use default value on creation
    setShortcut(key, input, false);
    var scriptId = script.id;
    var shortcutId = shortcut.id;
    input.onkeydown = function(e){
        e.preventDefault();
        e.stopPropagation();
        fixShortcut(e, e.target);
    };
    div.appendChild(input);
    var br = document.createElement('br');
    br.className = 'clearall';
    div.appendChild(br);
    el.appendChild(div);
}

function isShortcutFree(e){
    var text = formatKey(e);
    var key = marshallKey(e);
    //custom in prefs
    if (gshortcuts[key]) {
        var warning1 = getTextPrefs(lang, 'extshortcuts', 'alreadyusedprefs');
        return warning1;
    }
    //google
    if (GRP.googleshortcuts && GRP.googleshortcuts[text]) {
        var warning2 = getTextPrefs(lang, 'extshortcuts', 'alreadyusedgoogle');
        var w = warning2;
		if (GRP.googleshortcuts[text]){
			w += '<br/>(' + GRP.googleshortcuts[text].text + ')';
		}
		return w;
    }
    return true;
}

function setShortcut(key, ctrl, save){
	//remove old
	clearShortcut(key, ctrl);
	
	if (!key.keyCode) {
        //error
        return;
    }
    ctrl.value = formatKey(key);
    ctrl.key = marshallKey(key);
    //add new
	if (save) {
		gshortcuts[ctrl.key] = key;
		prefs[ctrl.id] = ctrl.key;
	}
}
function clearShortcut(key, ctrl){
	delete gshortcuts[ctrl.key];
}
function fixShortcut(e, input){
    var newKey = marshallKey(e);
    var free = isShortcutFree(e);
    var warn = getFirstElementMatchingClassName(input.parentNode, 'div', 'warning');//div.warning
    if (!warn) {
        warn = document.createElement('div');
        warn.className = 'warning';
        insertAfter(warn, input);
    }
    if (free === true) {
		warn.className = 'warning hidden';
		warn.innerHTML = '';
        input.className = '';
        setShortcut(e, input, true);
    } else {
        input.value = formatKey(e);
        input.className = 'warning';
        warn.className = 'warning';
		warn.innerHTML = free;
		clearShortcut(e, input);
    }
}
//
//Utility to render iGoogle themes
// http://www.google.com/ig/directory?type=themes
// 
var tpl_ig_skin_block = '{{%IMPLICIT-ITERATOR}}' +
'<div class="indi_cats">{{#cats}}' +
'<span class="indi_link" onclick="javascript:igcat(\'{{id}}\')">{{name}}</span> ' +
'{{/cats}}</div>' +
'<div class="indi_sort">{{#sorts}}' +
'<span class="indi_link" onclick="javascript:igsort(\'{{id}}\')">{{name}}</span> - ' +
'{{/sorts}}</div>' +
'<form onsubmit="javascript:igsearch();return false;"><input type="text" value="{{q}}" size="20" id="igq"><input type="submit" value="{{txt_search}}">' +
'&nbsp;<span class="indi_link" onclick="javascript:igprevious()">{{txt_previous}}</span> - ' +
'<span class="indi_link" onclick="javascript:ignext()">{{txt_next}}</span> - ' +
'<span class="indi_link" onclick="javascript:igrnd()">{{txt_random}}</span>' +
'</form>' +
'<div class="indi_entries">' +
'{{#entry}}<div class="indi_entry">' +
'<div class="indi_entry_title_wrap"><div class="indi_entry_title">{{title}}</div></div>' +
'<div class="indi_thumbnail"><img class="indi_img" src="http://skins.gmodules.com/ig/skin_fetch?type=4&sfkey={{dthumbnail}}" onclick="javascript:setTheme(\'{{skin_id}}\')"/></div>' +
'</div>{{/entry}}</div>';
var entries = {}, ig_cat, ig_q = '', ig_pos = 0, ig_page = 4 * 12, ig_sort = 'popular';
var ig_cats = [{
    id: '',
    name: 'All'
}, {
    id: 'artist',
    name: 'Artist'
}, {
    id: 'games',
    name: 'Games'
}, {
    id: 'naturecampaign',
    name: 'Nature'
}, {
    id: 'comics',
    name: 'Comics'
}, {
    id: 'food',
    name: 'Food'
}, {
    id: 'travel',
    name: 'Travel'
}, {
    id: 'animals',
    name: 'Animals'
}, {
    id: 'nature',
    name: 'Environment'
}, {
    id: 'sports',
    name: 'Sports'
}, {
    id: 'destinations',
    name: 'Destinations'
}, {
    id: 'abstract',
    name: 'Abstract'
}, {
    id: 'trendy',
    name: 'Trendy'
}, {
    id: 'fun',
    name: 'Fun'
}, {
    id: 'causes',
    name: 'Causes'
}];
var ig_sorts = [{
    id: 'popular',
    name: 'Popular'
}, {
    id: 'users',
    name: 'Most users'
}, {
    id: 'newest',
    name: 'Newest'
}];
function igsearch(){
    var q = get_id('igq');
    if (q) {
        ig_q = q.value;
        renderThemes(ig_cat, ig_pos, ig_sort, ig_q);
    }
}

function ignext(){
    ig_pos = ig_pos + ig_page;
    renderThemes(ig_cat, ig_pos);
}

function igprevious(){
    ig_pos = Math.max(0, ig_pos - ig_page);
    renderThemes(ig_cat, ig_pos);
}

var randomCallback, lastSkin;
function getRandomTheme(current, cb, inBg){
    ig_cat = randomItem(ig_cats).id;
    ig_sort = randomItem(ig_sorts).id;
    ig_pos = 0;
    var o = {
        cat: ig_cat,
        pos: ig_pos,
        sort: ig_sort,
        q: ''
    };
    lastSkin = current;
    randomCallback = cb;//global way
    if (inBg) {
        callApi('randomThemeBg', o, inBg);
    } else {
        callApi('randomTheme', o, inBg);
    }
}

function randomThemeBg(data){
    randomTheme(data, true);
}

function randomTheme(data, inBg){
    if (randomCallback) {
        var entries = data.feed.entry;
        if (entries && entries.length > 0) {
            entry = randomItem(entries);
            if (checkSkin(entry, lastSkin)) {
                randomCallback(entry);
            } else {
                //retry
                getRandomTheme(lastSkin, randomCallback, inBg);
            }
        }
    }
}

function igrnd(){
    ig_cat = randomItem(ig_cats).id;
    ig_sort = randomItem(ig_sorts).id;
    ig_pos = Math.round(Math.random() * 10) - 1;
    renderThemes(ig_cat, ig_pos, ig_sort);
}

function igcat(cat){
    if (cat === 'all') {
        cat = '';
    }
    renderThemes(cat);
}

function igsort(sort){
    renderThemes(ig_cat, ig_pos, sort);
}

function setTheme(id){
    var entry = find(entries.entry, 'skin_id', id);
    if (!entry) {
        return;
    }
    var el = get_id('ig_skin_name');
    if (el) {
        el.value = entry.title;
    }
    el = get_id('ig_skin_url');
    if (el) {
        var link = entry.link;
        if (!(/^http(s)?:/i.test(link))) {
            if (!(/^\//.test(link))) {
                link = '/' + link;
            }
            link = 'http://skins.gmodules.com' + link;
        }
        el.value = link;
    }
}

function callApi(callback, o, inBg){
    lang = o.lang || lang || 'en';
    ig_cat = o.cat || '';
    ig_pos = o.pos || 0;
    ig_sort = o.sort || ig_sort;
    ig_q = (typeof o.q === 'undefined') ? ig_q : o.q;
    var api = 'http://www.google.com/ig/directory?type=themes&output=json&callback=' + callback + '&sort=' + ig_sort + '&cat=' + ig_cat + '&gl=us&hl=en&start=' + ig_pos + '&num=' + ig_page;
    if (ig_q) {
        api += '&q=' + ig_q;
    }
    var a = {
        url: api,
        onload: function(xhr){
            var txt = xhr.responseText;
            var re = new RegExp("^" + callback);
            if (txt && (re.test(txt))) {
                eval(txt);
            }
        }
    };
    if (inBg) {
        request(a, true);
    } else {
        GM_xmlhttpRequest(a);
    }
}

function renderThemes(cat, pos, sort, q){
    var o = {
        cat: cat || '',
        pos: pos || 0,
        sort: sort || '',
        q: q || ''
    };
    callApi('setThemes', o);
}

function checkSkin(entry, lastSkin){
    return (entry && entry.skin_id && parseInt(entry.skin_id, 10) > 1000 && entry.title !== lastSkin);
}

function setThemes(data){
    entries = data.feed || {};
    var e2 = [];
    foreach(entries.entry, function(entry){
        //Ignore special theme such sampler and default, i dont know how to get them
        if (checkSkin(entry)) {
            e2.push(entry);
        }
    });
    entries.entry = e2;
    apply(entries, {
        cats: ig_cats,
        sorts: ig_sorts,
        q: ig_q,
        txt_add: getTextPrefs(lang, 'ig', 'add') || 'Add it now',
        txt_next: getTextPrefs(lang, 'ig', 'next') || 'Next',
        txt_previous: getTextPrefs(lang, 'ig', 'previous') || 'Previous',
        txt_random: getTextPrefs(lang, 'ig', 'random') || 'Randm',
        txt_search: getTextPrefs(lang, 'ig', 'search') || 'Search themes',
        dthumbnail: function(){
            return encodeURIComponent(decodeURIComponent(this.thumbnail));
        }
    });
    var el = get_id('ig_themes');
    if (el) {
        var html = Mustache.to_html(tpl_ig_skin_block, entries);
        //console.log(html);
        el.innerHTML = html;
        checkImages(el);
    }
}

function checkImages(el){
    window.setTimeout(function(){
        var retry = false, imgs = el.getElementsByClassName('indi_img');
        foreach(imgs, function(img){
            if (img.complete) {
                if (img.width < 50) {
                    img.src = img.src.replace('type=4', 'type=2');
                }
                addClass(img, 'indi_image');
            } else {
                retry = true;
            }
        });
        if (retry) {
            checkImages(el);
        }
    }, 500);
}

function dblQuote(txt){
    return txt.replace(/\"/g, "%#22").replace(/'/g, "\"").replace(/%#22/g, "\"");
}

/*
  Shameless port of http://github.com/defunkt/mustache
  by Jan Lehnardt <jan@apache.org>, 
     Alexander Lang <alex@upstream-berlin.com>,
     Sebastian Cohnen <sebastian.cohnen@googlemail.com>

  Thanks @defunkt for the awesome code.

  See http://github.com/defunkt/mustache for more info.
*/
//Modified by ludoo :
//- add $ as global context
//- jslint fixes

var Mustache = function() {
  var Renderer = function() {};

  Renderer.prototype = {
    otag: "{{",
    ctag: "}}",
    pragmas: {},
    buffer: [],
    pragmas_parsed: false,
    pragmas_implemented: {
      "IMPLICIT-ITERATOR": true
    },
    gcontext:false,

    render: function(template, context, partials, in_recursion) {
      // fail fast
      if(template.indexOf(this.otag) == -1) {
        if(in_recursion) {
          return template;
        } else {
          this.send(template);
          return;
        }
      }

      if(!in_recursion) {
        this.buffer = [];
      }

      if(!this.pragmas_parsed) {
        template = this.render_pragmas(template);
      }
      var html = this.render_section(template, context, partials);
      if(in_recursion) {
        return this.render_tags(html, context, partials, in_recursion);
      }

      this.render_tags(html, context, partials, in_recursion);
    },

    /*
      Sends parsed lines
    */
    send: function(line) {
      if(line !== "") {
        this.buffer.push(line);
      }
    },

    /*
      Looks for %PRAGMAS
    */
    render_pragmas: function(template) {
      this.pragmas_parsed = true;
      // no pragmas
      if(template.indexOf(this.otag + "%") == -1) {
        return template;
      }

      var that = this;
      var regex = new RegExp(this.otag + "%([\\w_-]+) ?([\\w]+=[\\w]+)?"
        + this.ctag);
      return template.replace(regex, function(match, pragma, options) {
        if(!that.pragmas_implemented[pragma]) {
          throw({message: "This implementation of mustache doesn't understand the '"
            + pragma + "' pragma"});
        }
        that.pragmas[pragma] = {};
        if(options) {
          var opts = options.split("=");
          that.pragmas[pragma][opts[0]] = opts[1];
        }
        return "";
        // ignore unknown pragmas silently
      });
    },

    /*
      Tries to find a partial in the global scope and render it
    */
    render_partial: function(name, context, partials) {
      if(typeof(context[name]) != "object") {
        throw({message: "subcontext for '" + name + "' is not an object"});
      }
      if(!partials || !partials[name]) {
        throw({message: "unknown_partial '" + name + "'"});
      }
      return this.render(partials[name], context[name], partials, true);
    },

    /*
      Renders boolean and enumerable sections
    */
    render_section: function(template, context, partials) {
      if(template.indexOf(this.otag + "#") == -1) {
        return template;
      }
      var that = this;
      // CSW - Added "+?" so it finds the tighest bound, not the widest
      var regex = new RegExp(this.otag + "\\#(.+)" + this.ctag +
              "\\s*([\\s\\S]+?)" + this.otag + "\\/\\1" + this.ctag + "\\s*", "mg");

      // for each {{#foo}}{{/foo}} section do...
      return template.replace(regex, function(match, name, content) {
        var value = that.find(name, context);
        if(that.is_array(value)) { // Enumerable, Let's loop!
          return that.map(value, function(row) {
            return that.render(content, that.merge(context,
                    that.create_context(row)), partials, true);
          }).join("");
        } else if(value) { // boolean section
          return that.render(content, context, partials, true);
        } else {
          return "";
        }
      });
    },

    /*
      Replace {{foo}} and friends with values from our view
    */
    render_tags: function(template, context, partials, in_recursion) {
      // tit for tat
      var that = this;

      var new_regex = function() {
        return new RegExp(that.otag + "(=|!|>|\\{|%)?([^\/#]+?)\\1?" +
          that.ctag + "+", "g");
      };

      var regex = new_regex();
      var lines = template.split("\n");
       for (var i=0; i < lines.length; i++) {
         lines[i] = lines[i].replace(regex, function(match, operator, name) {
           switch(operator) {
             case "!": // ignore comments
               return match;
             case "=": // set new delimiters, rebuild the replace regexp
               that.set_delimiters(name);
               regex = new_regex();
               return "";
             case ">": // render partial
               return that.render_partial(name, context, partials);
             case "{": // the triple mustache is unescaped
               return that.find(name, context);
             /*case "$": // global context
               return that.escape(that.find(name, gcontext));*/
             default: // escape the value
               return that.escape(that.find(name, context));
           }
         }, this);
         if(!in_recursion) {
           this.send(lines[i]);
         }
       }

       if(in_recursion) {
         return lines.join("\n");
       }
    },

    set_delimiters: function(delimiters) {
      var dels = delimiters.split(" ");
      this.otag = this.escape_regex(dels[0]);
      this.ctag = this.escape_regex(dels[1]);
    },

    escape_regex: function(text) {
      // thank you Simon Willison
      if(!arguments.callee.sRE) {
        var specials = [
          '/', '.', '*', '+', '?', '|',
          '(', ')', '[', ']', '{', '}', '\\'
        ];
        arguments.callee.sRE = new RegExp(
          '(\\' + specials.join('|\\') + ')', 'g'
        );
      }
    return text.replace(arguments.callee.sRE, '\\$1');
    },

    /*
      find `name` in current `context`. That is find me a value
      from the view object
    */
    find: function(name, context, global) {
      name = this.trim(name);
      var c= (global)?this.gcontext:context;
      if(typeof c[name] === "function") {
        return c[name].apply(context);
      }
      if(c[name] !== undefined) {
        return c[name];
      }
      //Ludoo:global context
      if(/^\$/.test(name)) {
        return this.find(name.substring(1), context, true);
      }
      // silently ignore unkown variables
      return "";
    },

    // Utility methods

    /*
      Does away with nasty characters
    */
    escape: function(s) {
      return ((s === null) ? "" : s).toString().replace(/[&"<>\\]/g, function(s) {
        switch(s) {
          case "&": return "&amp;";
          case "\\": return "\\\\";
          case '"': return '\"';
          case "<": return "&lt;";
          case ">": return "&gt;";
          default: return s;
        }
      });
    },

    /*
      Merges all properties of object `b` into object `a`.
      `b.property` overwrites a.property`
    */
    merge: function(a, b) {
      var _new = {};
      for(var name in a) {
        if(a.hasOwnProperty(name)) {
          _new[name] = a[name];
        }
      }
      for(var name in b) {
        if(b.hasOwnProperty(name)) {
          _new[name] = b[name];
        }
      }
      return _new;
    },

    // by @langalex, support for arrays of strings
    create_context: function(_context) {
      if(this.is_object(_context)) {
        return _context;
      } else if(this.pragmas["IMPLICIT-ITERATOR"]) {
        var iterator = this.pragmas["IMPLICIT-ITERATOR"].iterator || ".";
        var ctx = {};
        ctx[iterator] = _context;
        return ctx;
      }
    },

    is_object: function(a) {
      return a && typeof a == "object";
    },

    is_array: function(a) {
      return Object.prototype.toString.call(a) === '[object Array]';
    },

    /*
      Gets rid of leading and trailing whitespace
    */
    trim: function(s) {
      return s.replace(/^\s*|\s*$/g, "");
    },

    /*
      Why, why, why? Because IE. Cry, cry cry.
    */
    map: function(array, fn) {
      if (typeof array.map == "function") {
        return array.map(fn);
      } else {
        var r = [];
        var l = array.length;
        for(i=0;i<l;i++) {
          r.push(fn(array[i]));
        }
        return r;
      }
    }
  };

  return({
    name: "mustache.js",
    version: "0.2.3-dev",

    /*
      Turns a template and view into HTML
    */
    to_html: function(template, view, partials, send_fun) {
      var renderer = new Renderer();
      if(send_fun) {
        renderer.send = send_fun;
      }
      renderer.gcontext=view;
      renderer.render(template, view, partials);
      if(!send_fun) {
        return renderer.buffer.join("\n");
      }
    }
  });
}();
/**
 * SystemInformation
 * @version  0.3
 * @date 2010-01-22
 * @author LudoO
 *
 * Gives information about system (OS, Chrome...)
 *
 */
GRP.info = function(prefs){

    var status, report = {};
    
    function sendreport(){
        if (status == 3) {
            //status ==3 -> report complete
            chrome.extension.sendRequest(
            {
                message: "info",
                report: report
            });
        }
    }
    
    function sysinfo(){
        status = 0;
        infoNavigator();
        infoExtensions();
        infoVersion();
    }
    
    function infoNavigator(){
        report.navigator = getInfo();
        sendreport(++status);
    }
    
    function infoExtensions(){
        GM_xmlhttpRequest(
        {
            method: 'GET',
            url: 'chrome://extensions',
            onload: function(res){
                var extensions = parseExtensions(res.responseXML);
                console.log(extensions);
                report.extensions = extensions;
                sendreport(++status);
            },
            onerror: function(res){
                console.log(res);
                report.extensions = {};
                sendreport(++status);
            }
        });
    }
    
    function infoVersion(){
        GM_xmlhttpRequest(
        {
            method: 'GET',
            url: 'about:version',
            onload: function(res){
                var version = parseVersion(res.responseXML);
                console.log(version);
                report.version = version;
                sendreport(++status);
            },
            onerror: function(res){
                console.log(res);
                report.version = {};
                sendreport(++status);
            }
        });
    }
    
    function parseExtensions(xml){
        var extensions = {};
        Array.forEach(xml.getElementsByClassName('extension'), function(e){
            var data = 
            {
                name: getElementValue("./span[@jscontent='name']", e),
                version: getElementValue("./span[@jscontent='version']", e),
                description: getElementValue("./span[@jscontent='description']", e),
                id: getElementValue("./span[@jscontent='id']", e)
            };
            extensions[data.name] = data;
        });
        return extensions;
    }
    
    function parseVersion(xml){
        var version = {};
        var t = xml.getElementsById('inner');
        Array.forEach(t.getElementsByTagName('tr'), function(row){
            var name, value, i = 0, cell = {};
            Array.forEach(row.getElementsByTagName('td'), function(c){
                if (i === 0) {
                    name = c.innerText;
                } else {
                    value = c.innerText;
                }
                i++;
            });
            if (name) {
                version[name] = value;
            }
        });
        return version;
    }
    
};


function getInfo(){
    var w = {}, navs = ['language','product','appVersion','onLine','platform','vendor','appCodeName','cookieEnabled','appName','productSub','userAgent'];
	foreach(navs, function(nav){
		w[nav] = window.navigator[nav];
	});
	//This will crash on close preferences !!!!!
	/*iterate(window.navigator, function(p, o){
        if (p && o && typeof o === "string" || typeof o === "boolean") {
            w[p] = o;
        }
    });*/
    var chromeVersion = extractInfo('Chrome', w.appVersion);
    var webkitVersion = extractInfo('AppleWebKit', w.appVersion);
    
    var o = 
    {
        version: chromeVersion,
        webkit: webkitVersion,
        os: w.platform,
        lang: w.language,
        resolution: screen.width + 'x' + screen.height
    };
    return {
        info: o,
        navigator: w,
        screen: screen
    };
}

function extractInfo(name, text){
    try {
        var re = new RegExp(name + '/[\\d\\.]+');
        var r = re.exec(text);
        return (r) ? (r[0].replace(name + '/', '')) : '?';
    } 
    catch (e) {
        return '?';
    }
}
/**
 * ReaderPlus
 * Translation for features
 *
 * **************************
 * fr : English
 * **************************
 *
 * For translators : please keep major version or original for your translations !
 * Use minor version for yours translations
 * so that 0.3.11 is the 11th translated version of the original v0.3 english version.
 *
 *
 * Version : 1.4
 * Date : 04-22-2010
 * @author Valente
 */
var locale = 'en';
namespace('GRP.langs.' + locale);
GRP.langs[locale].categories = {
	main: 'Main',
	theme: 'Theme/skins',
	icons:'Icons',
	counter:'Counter',
	layout: 'Layout',
	navigation: 'Navigation',
	share: 'Share',
	action: 'Action',
	content: 'Content'
};
GRP.langs[locale].scripts = {
    general: {
        name: "General",
        desc: "General configuration"
    },
    theme: {
        name: "Theme",
        desc: "Change the look of GoogleReader"
    },
    ig: {
        name: "iGoogle Theme",
        desc: "Use <a href='http://www.google.com/ig/directory?type=themes' target='blank'>iGoogle Theme</a> in your Google Reader (Beta)"
	},
    relook: {
        name: "Relook",
        desc: "Relook your site using custom stylesheets"
    },
    favicons: {
        name: "Favicons",
        desc: "Display favicons for every feed"
    },
    unreadcount: {
        name: "Show all unread count",
        desc: "Show all feeds unread count"
    },
    fixlayout: {
        name: "Fix layout",
        desc: "Fix different layout bugs style like full width for entry, fix missing pictures in enclosures, and make big images fit the screen"
    },
    count: {
        name: "Fix counter (1000+)",
        desc: "Display real unread count"
    },
    counticon: {
        name: "Icon counter",
        desc: "Dislay unread count in the Google Reader favicon"
    },
    removeads: {
        name: "Remove ads",
        desc: "Simple advertising blocker"
    },
    column: {
        name: "Text multi columns",
        desc: "Display news as a newspaper in multi columns"
    },
    preview: {
        name: "Integrated preview",
        desc: "Display original page content instead feed entry"
    },
    colorful: {
        name: "Colorful listview",
        desc: "Use a background color for a same feed"
    },
    filter: {
        name: "Filter entries",
        desc: "Filter entries by removing or highligting items based on user terms"
    },
	limit: {
        name: "Limit entries",
        desc: "Limit entries number in one page. Read items are removed to fit in a range"
    },
	prefetch: {
        name: "Prefetch more",
        desc: "Loading more entries at the same time for a smoother navigation"
    },
	nested: {
        name: "Nested folders",
        desc: "Multiple level on folders"
    },
    readbymouse: {
        name: "Read by mouse",
        desc: "Next/previous item using right/left mouse click"
    },
    facebook: {
        name: "Facebook",
        desc: "Add a button to share news using Facebook"
    },
    twitter: {
        name: "Twitter",
        desc: "Add a button to share news using Twitter"
    },
    instapaper: {
        name: "Instapaper",
        desc: "Add a button to read news later using Instapaper"
    },
	readitlater: {
        name: "ReadItLater",
        desc: "Add a button to read news later using ReadItLater"
    },
    mark: {
        name: "Mark As Read",
        desc: "Mark items before/after current as read"
    },
    jump: {
        name: "Add top/bottom links",
        desc: "Add a 'goto bottom' icon on top entry and a 'goto top' on bottom entry"
    },
    fitheight: {
        name: "Fit height",
        desc: "Fit height of the current news to the screen height (for long articles)"
    },
    closeentry: {
        name: "Close entry",
        desc: "Add a 'close' button on each entry to remove it"
    },
    openbackground: {
        name: "Open in background",
        desc: "Add a 'open in background' button on each entry"
    },
    replacer: {
        name: "Replacer",
        desc: "Replace entry with a part of the original page. Currently used to get comic strips.<br/>Thanks to jolan78 for its original idea and script."
    },
    aero: {
        name: "Google Aero Toolbar",
        desc: "Toolbar using Aero theme"
    },
    info: {
        name: "SysInfo",
        desc: "System information"
    },
    extshortcuts: {
        name: "Shortcuts",
        desc: "Keyboard shortcuts"
    },
    pack: {
        name: "Packages",
        desc: "Predefined configuration packages"
    },
    thanks: {
        name: "Thanks",
        desc: ""
    },
    about: {
        name: "About",
        desc: "About ReaderPlus"
    }
};
GRP.langs[locale].skins = {
    none: {
        name: "None"
    },
    air: {
        name: "Air Skin"
    },
    aircomic: {
        name: "Air Skin Comic Sans"
    },
    black: {
        name: "Google Enhanced Black"
    },
    dark: {
        name: "Dark Skin"
    },
    darkgray: {
        name: "Dark Gray Skin"
    },
    helvetireader: {
        name: "Helvetireader Skin"
    },
    minimal: {
        name: "Minimalistic Skin"
    },
    optimized: {
        name: "Optimized Skin"
    },
    portal: {
        name: "Portal Theme"
    },
    player: {
        name: "Player Theme"
    },
    osxblue: {
        name: "Mac OS X Snow Leopard - Blue"
    },
    osxblack: {
        name: "Mac OS X Snow Leopard - Black"
    },
	calibri: {
        name: "Calibri Skin"
    },
    glassblackgold: {
        name: "Glass Black Gold Skin"
    },
    simpleclean: {
        name: "Simple and Clean"
    },
    peacockfeather: {
        name: "Peacock Feather"
    },
    myowngooglereader: {
        name: "My Own Google Reader"
    },
    compactcleantweaked: {
        name: "Compact, Clean & Tweaked"
    },
    absolutelycompact: {
        name: "Absolutely Compact"
    },
    darkshinyblue: {
        name: "Dark Shiny Blue"
    },
	persian: {
        name: "Optimized Persian"
    }
};
/**
 * ReaderPlus
 * Translation
 *
 * **************************
 * en : English
 * **************************
 *
 * Version : 1.6
 * Date : 07-21-2010
 * @author Valente
 */
var locale = 'en';
namespace('GRP.langs.' + locale);
GRP.langs[locale].texts = {
    version: "version",
    closeentry: {
        text: 'Close this entry',
        keyword: 'Close'
    },
    column: {
        text: 'Display as multi columns layout',
        keyword: 'Column',
        summary: 'Add/edit items',
        desc: 'Manage columns'
    },
    facebook: {
        text: 'Share this news on Facebook',
        keyword: 'Facebook'
    },
    twitter: {
        text: 'Share this news on Twitter',
        keyword: 'Twitter',
        plslogin: 'Please login to Twitter',
        toolong: "the message is too long!",
        notetoolong: "<b>Note to go along with the item:</b> (Optional, remain {0} characters)",
        notemax: "<b>Note to go along with the item:</b> (Optional, no more than 140 characters)",
        text_title: 'Title',
        text_tag: 'Tag',
        text_url: 'URL',
        text_send: 'Send',
        text_count: 'Count',
        text_cancel: 'Cancel',
        text_shortener: 'Short url',
        shortfailed: "Sorry, an error occured on trying to use short url!\n\r{0}"
    },
    readit: {
        password: 'Password, if you have one:',
        wronglogin: 'Wrong username or password, please check it!!',
        nologin: 'This feature requires a username, please set preferences!!',
        error: 'The service encountered an error. Please try again later.',
        badrequest: 'Bad request. Probably missing a required parameter, such as url.',
        saving: 'Saving',
        shortcut_readitlater: 'Read Later with Instapaper'
    },
    instapaper: {
        text: 'Read Later with Instapaper',
        keyword: 'Instapaper',
        plslogin: 'Please login to Instapaper',
        login: 'Email or username:'
    },
    readitlater: {
        text: 'Read Later with ReadItLater',
        keyword: 'ReadItLater',
        plslogin: 'Please login to ReadItLater',
        rateexceeded: 'Rate limit exceeded, please wait a little bit before resubmitting',
        maintenance: 'Read It Later\'s sync server is down for scheduled maintenance'
    },
    favicons: {
        preferences: 'Preferences',
        getfavicon: 'Get favicon',
        notfoundicon: 'Cannot found favicon for "{0}"',
        summary: 'Add/edit items',
        desc: 'Manage favicons'
    },
    filter: {
        settings: 'Filter settings',
        excludes: 'Excludes',
        highlights: 'Highlights',
        highlight: 'Highlight',
        exclude: 'Exclude',
        hideduplicates: 'Hide Duplicates',
        hideexcludes: 'Hide Excludes',
        preferehighlights: 'Prefer Hilights over excludes',
        update: 'Update',
        quickadd: 'Quick Add',
        add: 'Add',
        close: 'Close',
        edit: 'Edit',
        remove: 'Remove'
    },
    fitheight: {
        text: 'Fit height',
        keyword: 'Fit height'
    },
    jump: {
        textbottom: 'Jump to bottom',
        texttop: 'Jump to top',
        keywordtop: 'top'
    },
    openbackground: {
        text: 'Open in background',
        keyword: 'Open'
    },
    preview: {
        text: 'Integrated preview of the news',
        title: 'Open as preview',
        opennewtab: 'Open in a new window',
        keyword: 'Preview',
        overlay_next: 'Next',
        overlay_previous: 'Previous',
        overlay_close: 'Close',
        overlay_category: 'Category'
    },
    readbymouse: {
        middleclick: 'Middle click',
        openintab: 'Opens in Tab',
        openinbacktab: 'Opens in Background Tab',
        shares: 'Shares',
        stars: 'Stars',
        tag: 'Tag',
        addtag: 'Add a Tag',
        on: 'ReadByMouse On',
        off: 'ReadByMouse Off'
    },
    replacer: {
        nomatch: 'No match found.',
        loading: 'Loading ...'
    },
    lightbox: {
        text: 'Light on the media',
        keyword: 'Light'
    },
    ig: {
        menu_prefs: 'Reader+ preferences',
        menu_theme: 'Reader+ theme',
        menu_randomtheme: 'Change theme :'
    },
    menu: {
        label: 'Extra',
        showallfolders: 'Afficher tous les dossiers'
    }
};
GRP.langs[locale].prefs = {
    global: {
        title: "Reader Plus",
        "val-save": "Save",
        alreadyexist: "Item already exists!",
        snew: 'new!',
        supdated: 'Updated!',
        prefssaved: "Preferences saved!",
        cachecleared: "Cache cleared!",
        expandall: 'All'
    },
    theme: {
        noborder: "Remove entries borders to display more items on a single page",
        mytheme: 'Use <a href="http://code.google.com/p/googlereaderplus/wiki/Backgrounds" target="blank">custom background picture</a> and font color with skin "MyTheme" (<a href="http://code.google.com/p/googlereaderplus/wiki/Themes" target="blank">Preview</a>)',
        /*url: 'Picture URL',*/
        color: 'Text color',
        bg: 'Background color',
        /*repeat: 'Tiled Picture ',*/
        externaltheme: 'Google/Gmail theme',
        imgrbg: 'Repeated background',
        imgsbg: 'Background',
        imgrh: 'Repeated header',
        imgh: 'Header',
        imghr: 'Right header',
        imghl: 'Left header',
        imgrf: 'Repeated footer',
        imgf: 'Footer',
        imgfr: 'Right footer',
        imgfl: 'Left footer'
    },
    ig: {
        warning: 'Some themes could be displayed incorrectly ; this is a Beta feature!',
        skin_name: 'iGoogle theme name',
        skin_url: 'iGoogle theme URL',
        debug: 'Debug mode (For debugging only)',
        randomtime: 'Dynamic theme toggles randomly instead time control',
        userandomthemes: 'Theme is automatically switched randomly',
        randomthemes: 'Toggle theme every (min.)',
        add: 'Add it now',
        next: 'Next',
        previous: 'Previous',
        random: 'Random',
        search: 'Search themes'
    },
    about: {
        thanks1: '<td><span class="top_right"><img src="images/48.png"></span><h1>Thank you...</h1>' +
        '<p>... for installing (or updating to) the latest version of <strong>Reader Plus</strong>!</p>' +
        '<p>Make sure you check the <a href="preferences.html" title="Go to the preferences page"><strong>preferences page</strong></a> for configuration of the extension.</p>' +
        '<p><a href="https://chrome.google.com/extensions/detail/hhcknjkmaaeinhdjgimjnophgpbdgfmg" target="_blank" title="Visit extension homepage"><strong>Visit the Google Chrome Extensions gallery page!</strong></a></p>' +
        '<p><a href="http://www.twitter.com/ludoo0d0a"><img src="http://twitter-badges.s3.amazonaws.com/follow_me-a.png" alt="Follow me on Twitter"/></a></p>' +
        '<p></p></td>',
        thanks2: '<td><p>If you like this extension and want more features, feel free to make a donation.</p>' +
        '<p>In this way, I could buy a truck of coffee so that i can stay awake to write all the code :)</p>' +
        '<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=FK9P8MNY9MGZL&lc=US&item_name=GoogleReaderPlus%20project&currency_code=EUR&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted"><img alt="Donate" border="0" src="https://www.paypal.com/en_US/i/btn/btn_donate_SM.gif" width="74" height="21"></a></td>',
        whatsnew: '<td><h2>What\'s new!!</h2><ul><li>Try the new themes</li><li>or use a custom background with the new theme "MyTheme"</li><li>or use a random <a href="http://www.google.com/ig/directory?type=themes" target="blank">iGoogle</a> theme</li><li>Preview as lightbox</li><li>Share items using <a href="http://www.readitlater.com" target="blank">ReadItLater</a></li><li>Entry actions as floating window (general)</li><li>Translate news</li></ul></td>',
        nopopup: '<p>If you don\'t want to be alerted on new version updates, check option "No popup on updates" in <a href="preferences.html#general">General section</a>.</p>'
    },
    link: {
        reader: "<span>Google Reader</span>Your RSS reader",
        issues: "<span>Report issue</span>Found a bug or suggestion ?",
        download: "<span>Google Extension</span>The place to download",
        about: "<span>About</span>About, thanks,...",
        site: "<span>Website</span>My personal website",
        twitter: "<span><img width=\"160\" height=\"27\" src=\"http://twitter-badges.s3.amazonaws.com/follow_me-a.png\" alt=\"Follow ludoo0d0a on Twitter\"></span>Follow news and updates",
        donate: '<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&amp;business=FK9P8MNY9MGZL&amp;lc=US&amp;item_name=googlereaderplus%20project&amp;currency_code=EUR&amp;bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHosted"><span><img alt="Donate" border="0" src="https://www.paypal.com/en_US/i/btn/btn_donate_SM.gif" width="74" height="21"></span>Offer me a coffee!</a>',
        translate: '<span>Translation</span>Help me to translate</a>'
    },
    column: {
        count: "Columns number",
        locked: "Always actived, except following feeds:",
        pagebreak: "Break long articles so long articles can be read page by page like a newspaper.",
		miniparas: "Number of paragraphs minimum before split into columns",
        entersite: "Enter URL of the site"
    },
    translate: {
        lang: "Translate content into ",
        locked: "Always actived, except for:",
        include: "Only include following feeds:",
        entersite: "Enter URL of the site"
    },
    twitter: {
        shortener: "Shortener",
        shortener_bitly: "BitLy configuration (optional):",
        shortener_login: "Login",
        shortener_apikey: "ApiKey",
        shortener_pwd: "Password"
    },
    instapaper: {
        auth: "<a href='http://www.instapaper.com' target='blank'>Instapaper</a> authentication:",
        username: "Username:",
        password: "Password (optional):"
    },
    readitlater: {
        auth: "<a href='http://www.readitlaterlist.com' target='blank'>ReadItLater</a> <a href='http://readitlaterlist.com/signup' target='blank'>authentication</a> (required):",
        username: "Username:",
        password: "Password:"
    },
    colorful: {
        tree: "Show label colors in the left navigation tree",
		usebasecolor: "Use following base colors :",
		background: "Background color",
		color:"Fore color"
    },
    general: {
        counter: "Display unread counter in the toolbar icon",
counterinterval: "Refresh unread counter every (s)",
        pageicon: 'Activate icon in the address bar (click will open a menu)',
        stats: 'Enable anonymous statistics reporting (for a better support)',
        bottomup: 'Footer toolbar on the top',
        opendirect: "Click on toolbar icon will open GoogleReader",
        secure: "Always force use of secure protocol (https)",
        topcurrent: "Current entry always on top",
        floatactions: "Entry actions are displayed as a floating window",
        noupdatepopup: "No popup on updates",
        icontoolbar_add: "To add button with icon in toolbar, please <a href=\"https://chrome.google.com/extensions/detail/ecpcafinfpjgabomoamkhkgnpgpmdmeo\">download and install it</a>.",
        icontoolbar_text: "<span>To make the button optional, we put him in an another extension as standalone,</span>                                    <br>                                    <span>to be installed along with readerplus.</span>                                    <br>                                    <span>To add the button, click <b></b> on the <a href=\"https://chrome.google.com/extensions/detail/ecpcafinfpjgabomoamkhkgnpgpmdmeo\">readerplus Toolbar button</a> page.</span><span>To remove the button, right click him and choose Disable.</span>",
        importexport_text: "You can now save your preferences using 'export' and reload it later using 'import', but be sure data are <a href='http://jsonformatter.curiousconcept.com/' target='blank'>JSON compliant</a>:",
        confirmimport: "Are you sure to import this configuration?\nCurrent configuration will be LOST!",
        text_layout: 'Layout options',
        text_private: 'Private data and updates',
        text_toolbaricon: 'Toolbar icon',
        text_pageicon: 'Address bar icon',
        text_export: 'Export/import',
currdir: 'Highlight folder of current entry <span class="new">new!</span>',
icons: 'Icons only for action buttons (except checkbox) <span class="new">new!</span>'
    },
limit: {
slidewindow: "Slidewindow - limit entries number",
mini: "Minimum items",
maxi: "Maximum items"
},
prefetch: {
first: "Initial loading items number on the expanded view.",
next: "Loading items when scrolling on the expanded view. ",
list: "Initial fetch on the list view."
},
nested: {
separator: "Separator to add extra level (example: Sports:Footbal)."
},
    removeads: {
        links: "Link filter:",
        images: "Image filter:",
        iframes: "Iframe filter:"
    },
    preview: {
        onicon: "Show integrated preview when click on icon right after the title (if not checked, on title)",
        locked: "Always actived, except following feeds:",
        overlay: 'Fullscreen preview (Lightbox)'
    },
    fitheight: {
        locked: "Always actived, except following feeds:"
    },
    filter: {
        searchbody: "Search inside title and body text",
        highlights: 'Highlights list (one item per line)',
        excludes: 'Excludes list (one item per line)'
    },
    favicons: {
        providerpageicons: 'Use <a href="http://pageicons.appspot.com" target="blank">PageIcons</a> provider (Recommended to load succesfully all icons)',
        sidebaronly: "Show favicons in sidebar only",
        cloud: 'Use cloud database <a href="http://wedata.net/databases/Favicons" target="blank">wedata/Favicons</a> so that community completes favicons',
        custom: "Enter your custom favicons :",
        add: "Add",
        tip: "Tip: You could add it easily using the contextual menu \"Get favicon\" of the left side bar",
        manual: "Manual favicons for all sites (not recommended ; slower)",
        parsing: "This will try to detect favicon by parsing each homepage",
        entersite: "Enter URL of the site",
        prompticon: "Enter the icon url (let empty to get it automatically):"
    },
    replacer: {
        intro: '<a href="http://code.google.com/p/googlereaderplus/wiki/ReplacerHowto" target="blank">Help on how to use replacer</a>',
        cloud: 'Use online expressions from <a href="http://wedata.net/databases/LDRFullFeed/items" target="blank">wedata/LDRFullFeed</a> and <a href="http://wedata.net/databases/Replacer/items" target="blank">wedata/Replacer</a> cloud database',
        link: "Link Regex",
        from: "Search regex/xpath/css",
        to: "Replace",
        prompttitle: "Title for this filter"
    },
    lightbox: {
        locked: "Always actived, except following feeds:"
    },
    relook: {
        css: "CSS stylesheet",
        resize: "Fire resize event to adapt fullscreen"
    },
    pack: {
        mini: "<span>Package Mini</span>The minimum for best reading",
        ludoo: "<span>Package LudoO</span>The best features in one click",
        full: "<span>Package Full</span>All features activated",
        reset: "<span>Package Reset</span>Reset your configuration",
        confirmdel: "This will ERASE and reset all your preferences. Are you sure ?"
    },
    extshortcuts: {
        custom: "Your custom Shortcuts",
        official: "Google Reader official shortcuts",
        alreadyusedprefs: "Already used in your preferences!",
        alreadyusedgoogle: "Already used by Google!"
    },
    thanks: {
        donators: "Thanks to donators to contribute to this project",
        translators: "Thanks to brave translators for their wonderful work",
        authors: "Thanks to authors of original scripts and skins (Greasemonkey and Stylish)"
    }
};
//My theme
//Customizable theme with background picture
/*
 to get theme from gmail (desk is a good omplete example):
 - Open gmail
 - selet theme
 - open all css
 - copy paste 2nd line into notepad2 (html,body...)
 - replace } with }\n (transform backslash on)
 - line 5 is the background color .cP{overflow:visible;background-color:#fff}
 - line 9 is the font color : .aB,.e,.cg{color:#0065cc;
 - line 17 : the tiled piture .cP{background:url(...)}
 - line 20-39 5 groups of 4 css classes
 -.wp=hl header left
 -.wq=hr header right
 -.wn=fl footer let
 -.wo=fr footer right
 */
GRP.mytheme = function(prefs){
    var daycodes = ['mon', 'tue', 'thu', 'wed', 'fri', 'sat', 'sun'];
    var fulldaycodes = ['monday', 'tuesday', 'thursday', 'wednesday', 'friday', 'saturday', 'sunday'];
    var daytimes = {
        0: 'midnight',
        2: '2am',
        4: '4am',
        6: '6am',
        8: '8am',
        10: '10am',
        12: 'noon',
        14: '2pm',
        16: '4pm',
        18: '6pm',
        20: '8pm',
        22: '10pm'
    };
    
    var css = ''; //GM_getValue('theme_mytheme');
    if (css) {
        GM_addStyle(css, 'rps_mytheme');
    }
    else {
        loadCss('skin/css/mytheme.css', function(css){
            stylish(css);
        }, {
            compact: true,
            clean: false
        });
    }
    
    function stylish(tplCss){
        //rbg : Repeated image background
        //sbg : Single image background
        //hr : header right
        //h: header
        //rh : repeated header
        //f: footer
        //fr: footer right
        //fl: footer left
        //rf: repeated footer
        var items = ['rbg', 'sbg', 'rh', 'h', 'hr', 'hl', 'rf', 'f', 'fr', 'fl'];
        
        var o = {};
        
		var externalthemes = GRP.getExternalThemes();
		
        if (prefs.theme_externaltheme && externalthemes && externalthemes[prefs.theme_externaltheme]) {
            o = externalthemes[prefs.theme_externaltheme];
			track('theme_externaltheme', prefs.theme_externaltheme);
            o.bg2 = o.bg2 || o.bg;
            if (o.rbg) {
                //repeated image background
                o.bg2 = 'transparent';
            }
            if (typeof o === 'string') {
                o = {
	                color: prefs.theme_color || '#000',
	                bg: prefs.theme_bg || '#fff',
                    hl: o
                };
            }
            
            //current_time
            var current_time = (new Date()).getHours();
            current_time = current_time - current_time % 2;//pair number
            daytime = daytimes[current_time];
            //day
            var day = (new Date()).getDay();
            
            //placeholders replacement
            var holders = {
                day: daycodes[day - 1],
                fullday: fulldaycodes[day - 1],
                time: current_time,
                daytime: daytime,
                daynight: ((current_time < 8 || current_time > 20) ? 'night' : 'day')
            };
            if (o.vars) {
                iterate(o.vars, function(varname, varvalues){
                    var variable = false;
                    //random choice
                    variable = randomselect(varvalues);
                    holders[varname] = variable;
                });
            }
            
            
            //choose random image if multiples...
            iterate(o, function(key, a){
                if (key !== 'vars') {
                    if (isArray(a)) {
                        o[key] = randomselect(a);
                    }
                    else if (typeof a === 'object') {
                        var k = holders[a.selector]; //selector specific (day...)
                        if (k && k !== 'random') {
                            o[key] = o[key][k];
                        }
                        else {
                            delete a.selector;
                            //multiple images per day possible
                            o[key] = randomselect(a);
                        }
                    }
                }
            });
            
            //placeholders replacement
            if (holders) {
                iterate(holders, function(name, value){
                    iterate(o, function(key, a){
                        if (typeof a === 'string') {
                            o[key] = a.replace('{' + name + '}', value);
                        }
                    });
                });
            }
            
        }
        else {
            //custom
            o = {
                color: prefs.theme_color || '#aaa',
                bg: prefs.theme_bg || '#ffc'
            };
			
			foreach(items, function(itm){
	            if (prefs['theme_img'+itm]) {
	                o[itm]=prefs['theme_'+itm];
	            }
	        });
		
        }
        
        var css = fillTpl(tplCss, o);
        
        
        var html = '';
        
        foreach(items, function(itm){
            html += '<div id="rp-' + itm + '"></div>';
            if (o[itm]) {
                css = cleancss(css, itm);
            }
        });
        
        var c = dh(document.body, 'div', {
            id: 'rp-cs',
            html: html
        });
        
        GM_addStyle(css, 'rps_mytheme');
        //cache css
        GM_setValue('theme_mytheme', css, false);
        
        if (o.resize) {
            fireResize();
        }
    }
    
    function cleancss(css, id){
        return css.replace('/*--' + id + '>--*//*', '').replace('*//*--<' + id + '--*/', '');
    }
};

GRP.getExternalThemes = function(){
     var urlgmail = window.location.protocol + '//mail.google.com/mail/';
	 return {
        gmail_chrome: {
            bg: '#fff',
            color: '#2a5db0'
        },
        gmail_c: {
            bg: '#fff',
            color: '#00c'
        },
        gmail_newblue: {
            bg: '#79b',
            color: '#fff'
        },
        gmail_coldshower: {
            bg: '#99b1c3',
            color: '#333944',
            rbg: urlgmail + 'images/2/5/coldshower/blue-tile.png'
        },
        gmail_steel: {
            bg: '#fff',
            color: '#4263ab',
            rh: urlgmail + 'images/2/5/steel/bg-main.png'
        },
        gmail_lightbright: {
            bg: '#fff',
            color: '#222',
            rh: urlgmail + 'images/2/5/lightbright/bg-main.png'
        },
        gmail_greensky: {
            bg: '#fff',
            color: '#33c'
        },
        gmail_lightsoft: {
            bg: '#fff',
            color: '#0065cc'
        },
        gmail_cherry: {
            bg: '#fff',
            color: '#942e06',
            rbg: urlgmail + 'images/2/5/cherry/bg-main.png'
        },
        gmail_nightshade: {
            bg: '#55688a',
            color: '#fff',
            rh: urlgmail + 'images/2/5/nightshade/ns_bg.gif'
        },
        gmail_medsoft: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/medsoft/bg-main.gif'
        },
        gmail_medred: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/medred/bg-main.gif'
        },
        gmail_darkwarm: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/darkwarm/bg-main.png'
        },
        gmail_greyrain: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/darkwarm/bg-main.png'
        },
        gmail_contrastblack: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/darkwarm/bg-main.png'
        },
        gmail_shiny: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/shiny/canvastile_bg2.jpg'
        },
        gmail_desk: {
            bg: '#000',
            sbg: urlgmail + 'images/2/5/desk/canvas_bg.jpg',
            hl: [ /* .wp */urlgmail + 'images/2/5/desk/logo_splatter.png', urlgmail + 'images/2/5/desk/logo_splatter_pencil.png'],
            hr: [ /* .wq */urlgmail + 'images/2/5/desk/header_bg_padpins.png', urlgmail + 'images/2/5/desk/header_bg_sharpenerenvelope.png', urlgmail + 'images/2/5/desk/header_bg_ruler.png', urlgmail + 'images/2/5/desk/header_bg_tape.png', urlgmail + 'images/2/5/desk/header_bg_vase.png'],
            fl: [ /* .wn */urlgmail + 'images/2/5/desk/footer_bg_paperclips.png', urlgmail + 'images/2/5/desk/footer_bg_applecalendar1.png', urlgmail + 'images/2/5/desk/footer_bg_postcard.png', urlgmail + 'images/2/5/desk/footer_bg_envelopebusstop1.png', urlgmail + 'images/2/5/desk/footer_bg_photos1.png'],
            fr: [ /* .wo */urlgmail + 'images/2/5/desk/footer_bg_cupring.png', urlgmail + 'images/2/5/desk/footer_bg_cdclips1.png', urlgmail + 'images/2/5/desk/footer_bg_teacookie.png', urlgmail + 'images/2/5/desk/footer_bg_pencilladybug.png', urlgmail + 'images/2/5/desk/footer_bg_calculatorclips1.png']
        },
        gmail_tree: {
            bg: '#cde4f3',
            color: '#074D8F',
            rh: urlgmail + 'images/2/5/tree/mostlycloudy/header_tile.jpg',
            rf: urlgmail + 'images/2/5/tree/mostlycloudy/footer_tile.jpg',
            fl: urlgmail + 'images/2/5/tree/mostlycloudy/footer_bg.jpg'
        },
        gmail_beach: {
            bg: '#fff',
            color: '#fff',
            rh: urlgmail + 'images/2/5/beach/{daytime}/headertile_bg.jpg',
            h: urlgmail + 'images/2/5/beach/{daytime}/header_bg.jpg',
            f: urlgmail + 'images/2/5/beach/{daytime}/footer_bg.jpg',
            rbg: urlgmail + 'images/2/5/beach/{daytime}/canvastile_bg.jpg'
        },
        gmail_mountains: {
            bg: '#6D6C68',
            color: '#fff',
            hl: {
                selector: 'day',
                mon: urlgmail + 'images/2/5/mountains/mon/monday1.jpg',
                tue: [urlgmail + 'images/2/5/mountains/tue/tuesday1.jpg', urlgmail + 'images/2/5/mountains/tue/tuesday3.jpg'],
                thu: urlgmail + 'images/2/5/mountains/thu/thursday1.jpg',
                wed: urlgmail + 'images/2/5/mountains/wed/wednesday.jpg',
                fri: urlgmail + 'images/2/5/mountains/fri/friday1.jpg',
                sat: urlgmail + 'images/2/5/mountains/sat/saturday1.jpg',
                sun: urlgmail + 'images/2/5/mountains/sun/sunday.jpg'
            }
        },
        gmail_pebbles: {
            bg: '#6d6c68',
            color: '#fff',
            hl: urlgmail + 'images/2/5/pebbles/rocks_tile.jpg'
        },
        gmail_ocean: {
            bg: '#af947f',
            color: '#fff',
            hl: urlgmail + 'images/2/5/ocean/weekdays/weekday_header.jpg',
            hr: urlgmail + 'images/2/5/ocean/weekdays/header_tile.jpg'
        },
        gmail_phantasea: {
            bg: '#003142',
            color: '#fff',
            hl: urlgmail + 'images/2/5/phantasea/night_header_bg1.jpg',
            hr: urlgmail + 'images/2/5/phantasea/night_header_tile1.jpg'
        },
        gmail_graffiti: {
            bg: '#000',
            color: '#fff',
            hl: {
                selector: 'day',
                mon: urlgmail + 'images/2/5/graffiti/monday_bg1.jpg',
                tue: urlgmail + 'images/2/5/graffiti/tuesday_bg1.jpg',
                thu: urlgmail + 'images/2/5/graffiti/thursday_bg1.jpg',
                wed: urlgmail + 'images/2/5/graffiti/wednesday_bg1.jpg',
                fri: urlgmail + 'images/2/5/graffiti/friday_bg1.jpg',
                sat: urlgmail + 'images/2/5/graffiti/saturday_bg.jpg',
                sun: urlgmail + 'images/2/5/graffiti/sunday_bg.jpg'
            },
            fl: urlgmail + 'images/2/5/graffiti/footer_bg1.jpg'
        },
        gmail_planets: {
            bg: '#0c1319',
            color: '#fff',
            hl: [urlgmail + 'images/2/5/planets/sun/sun.jpg', urlgmail + 'images/2/5/planets/moon/moon.jpg', urlgmail + 'images/2/5/planets/mercury/mercury.jpg', urlgmail + 'images/2/5/planets/venus/venus.jpg', urlgmail + 'images/2/5/planets/mars/mars.jpg', urlgmail + 'images/2/5/planets/jupiter/jupiter.jpg', urlgmail + 'images/2/5/planets/saturn/saturn.jpg', urlgmail + 'images/2/5/planets/uranus/uranus.jpg', urlgmail + 'images/2/5/planets/neptune/neptune.jpg'],
            rbg: urlgmail + 'images/2/5/planets/base/star_tile.gif'
        },
        gmail_gizmos: {
            bg: '#fff',
            color: '#0065cc',
            fl: urlgmail + 'images/2/5/gizmos/footer.png'
        },
        gmail_candy: {
            bg: '#fff',
            color: '#603913',
            hl: urlgmail + 'images/2/5/candy/header_bg.gif',
            hr: urlgmail + 'images/2/5/candy/headertile_bg.gif',
            fl: urlgmail + 'images/2/5/candy/footer_bg.gif',
            rbg: urlgmail + 'images/2/5/candy/canvastile_bg.gif'
        },
        gmail_busstop: {
            bg: '#78726b',
            bg2: {
                selector: 'weather',
                sunny: '#AFDBE5',
                windy: '#AEDAE3',
                rainy: '#7495A8'
            },
            color: '#196b7b',
            /*Snowy? / Rainy / Sunny / Windy*/
            vars: {
                weather: ['sunny', 'windy', 'rainy']
            },
            rh: urlgmail + 'images/2/5/busstop/{weather}/header_bg.jpg',
            fl: urlgmail + 'images/2/5/busstop/{weather}/footer_bg.gif',
            rf: urlgmail + 'images/2/5/busstop/{weather}/footertile_bg.jpg'
        },
        gmail_ninja: {
            bg: '#006f8a',
            color: '#fff',
            rh: urlgmail + 'images/2/5/ninja/header_bg.gif',
            rf: urlgmail + 'images/2/5/ninja/footer_bg.gif'
        },
        gmail_teahouse: {
            bg: '#8ba451',
            color: '#5c4520',
            hl: urlgmail + 'images/2/5/teahouse/{daytime}/headertile_bg.jpg',
            rh: urlgmail + 'images/2/5/teahouse/{daytime}/headertile_bg.jpg',
            fl: urlgmail + 'images/2/5/teahouse/{daytime}/footer_bg.jpg',
            rf: urlgmail + 'images/2/5/teahouse/{daytime}/footertile_bg.jpg',
            rbg: urlgmail + 'images/2/5/teahouse/{daytime}/canvastile_bg.jpg'
        },
        gmail_terminal: {
            bg: '#000',
            color: '#0c0'
        },
        gmail_orcasisland: {
            bg: '#5e7056',
            color: '#000',
            hl: [urlgmail + 'images/2/5/orcasisland/{fullday}_01.jpg', urlgmail + 'images/2/5/orcasisland/{fullday}_02.jpg']
        },
        gmail_highscore: {
            bg: '#090',
            bg2: '#47B3DA',
            color: '#fff',
            hl: urlgmail + 'images/2/5/highscore/{daynight}_background.png',
            rf: urlgmail + 'images/2/5/highscore/{daynight}_hills_footer.png'
        },
        gmail_turf: {
            bg: '#254a14',
            color: '#fff',
            hl: urlgmail + 'images/2/5/turf/header_tile.jpg'
        },
        gmail_lapinscretins: {
            vars: {
                numero: [1, 2, 3]
            },
            bg: {
                selector: 'numero',
                1: '#3275AC',
                2: '#31669A',
                3: '#B7E0E4'
            },
            color: '#fff',
            sbg: urlgmail + 'images/2/5/lapinscretins/rabbids_header{numero}_final.png'
        },
        gmail_assasinscreed2: {
			bg: '#3C4844',
            color: '#fff',
            sbg: [urlgmail + 'images/2/5/assassinscreed2/ac2_header1_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header2_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header3_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header4_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header5_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header6_final.png']
        },
        
/* editors_picks */
"editor_5478752472500006610":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhwWJen7tI/AAAAAAAAAIY/QNQcTiWN9l8/","editor_5478752827007585634":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhwqyH0TWI/AAAAAAAAAI8/APTtF3_y2cI/","editor_5478752842710333378":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhwrsnpN8I/AAAAAAAAAJE/ym-TNB-ipDU/","editor_5478753114195988130":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhw7f-3jqI/AAAAAAAAAJc/YGO5_ldyj-Y/","editor_5478753075316627266":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhw5PJTl0I/AAAAAAAAAJU/rS6YK1WW8-A/","editor_5478753460334726146":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhxPpcxjAI/AAAAAAAAAJs/URghLUy99YA/","editor_5478752501519603442":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhwX1lb1vI/AAAAAAAAAIk/Ksf6-SnvVPo/","editor_5478753089633816370":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhw6EeyjzI/AAAAAAAAAJY/BDvPIiaoi2U/","editor_5478752819223180210":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhwqVH3s7I/AAAAAAAAAI0/xhmZlouBW6Q/","editor_5478753117486370930":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhw7sPW0HI/AAAAAAAAAJg/wiRaz9nNtUw/","editor_5478752835087677362":"http://lh6.ggpht.com/_fxkujw2mA9U/TAhwrQOQt7I/AAAAAAAAAJA/H6GQMElt9Jg/","editor_5478752493997894098":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhwXZkHqdI/AAAAAAAAAIg/PR_JvDoSUUo/","editor_5478752822146891810":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhwqgA8ACI/AAAAAAAAAI4/mBFPhy-c3Dg/","editor_5478753058608504226":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhw4Q5x3aI/AAAAAAAAAJQ/CnTyXr3Q8uQ/","editor_5480987905094465154":"http://lh4.ggpht.com/_fxkujw2mA9U/TBBhdc1eNoI/AAAAAAAAAPg/VL7O_YocFWY/","editor_5480987906200029490":"http://lh6.ggpht.com/_fxkujw2mA9U/TBBhdg9DyTI/AAAAAAAAAPk/1jXNNml5Fvs/","editor_5480998621006856338":"http://lh6.ggpht.com/_fxkujw2mA9U/TBBrNMuFAJI/AAAAAAAAARU/52PQOquzhC8/","editor_5480987916726984130":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBheIK4XcI/AAAAAAAAAPo/BR4cS1ib3xM/","editor_5480987917979934498":"http://lh3.ggpht.com/_fxkujw2mA9U/TBBheM1m3yI/AAAAAAAAAPs/uKFlfn704Q8/","editor_5480987925727076290":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBhepsq38I/AAAAAAAAAPw/Ida0LeDX0fE/","editor_5480988005113749330":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBhjRb7X1I/AAAAAAAAAP4/TUTmK3R2KAE/","editor_5480988012864676114":"http://lh4.ggpht.com/_fxkujw2mA9U/TBBhjuT5IRI/AAAAAAAAAP8/3zSixI6EFwM/","editor_5478753466167683746":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhxP_LdaqI/AAAAAAAAAJw/D3WLPN6-uhk/","editor_5478753483552159554":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhxQ_8Pd0I/AAAAAAAAAJ0/IuvA0kBkziw/","editor_5478755559461692018":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhzJ1TpInI/AAAAAAAAAL4/SRH8g8xRsRE/","editor_5478755572322259650":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhzKlN10sI/AAAAAAAAAL8/B-akepWsw9Q/","editor_5478753799989312658":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhxjawvPJI/AAAAAAAAAKE/Uo0oCE22FnM/","editor_5478753813630017442":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhxkNk736I/AAAAAAAAAKI/cbq956vqL7o/","editor_5478753819961634386":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhxklKgrlI/AAAAAAAAAKM/a95O10f-NEg/","editor_5478752511525657170":"http://lh6.ggpht.com/_fxkujw2mA9U/TAhwYa3EGlI/AAAAAAAAAIo/Wi7XY2Bxgrc/","editor_5478753832267149810":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhxlTAX8fI/AAAAAAAAAKQ/pfQT3foJPRs/","editor_5480997862386069170":"http://lh3.ggpht.com/_fxkujw2mA9U/TBBqhCoybrI/AAAAAAAAAQs/IRrOw-q56ig/","editor_5480997893054118498":"http://lh3.ggpht.com/_fxkujw2mA9U/TBBqi04numI/AAAAAAAAAQw/dEVESx_pvBs/","editor_5480998186992651026":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBqz75ByxI/AAAAAAAAARE/CAq1-arltkE/","editor_5478769425598313058":"http://lh6.ggpht.com/_fxkujw2mA9U/TAh_w8sO8mI/AAAAAAAAAMs/E5kjeXUIQOc/","editor_5478769428183578882":"http://lh3.ggpht.com/_fxkujw2mA9U/TAh_xGUm-QI/AAAAAAAAAMw/TlYQUgOsAOs/","editor_5478769428473291154":"http://lh4.ggpht.com/_fxkujw2mA9U/TAh_xHZroZI/AAAAAAAAAM0/fZ8ZGI4gEHs/","editor_5478769530404012082":"http://lh4.ggpht.com/_fxkujw2mA9U/TAh_3DH3ADI/AAAAAAAAAM4/09PbIsWavv4/","editor_5478769535168997586":"http://lh4.ggpht.com/_fxkujw2mA9U/TAh_3U366NI/AAAAAAAAAM8/fUctF4T897M/","editor_5480596593254567266":"http://lh6.ggpht.com/_fxkujw2mA9U/TA79kGonjWI/AAAAAAAAAO8/wgt1U7ogm0k/",
/* public_gallery */
"public_5468005866288280370":"http://lh5.ggpht.com/_W6mjt7mDgno/S-JCXVndczI/AAAAAAAA3y0/fQWo9r8k0ks/","public_5480525382039743330":"http://lh4.ggpht.com/_3rqotzCU1sY/TA68zEL9q2I/AAAAAAAAA80/cZhz0pxQSM0/","public_5469661666160577106":"http://lh5.ggpht.com/_Z4rK3Ss0bFg/S-gkTk0SilI/AAAAAAAAADw/DDTeQLjTfWA/","public_5464847589870262818":"http://lh6.ggpht.com/_rfAz5DWHZYs/S9cJ7dHd2iI/AAAAAAAAcg8/kx3xyB7P6fc/","public_5468620555541748930":"http://lh3.ggpht.com/_0YSlK3HfZDQ/S-Rxa9h3HMI/AAAAAAAAXiI/fStJVANexYc/","public_5465726438613138322":"http://lh6.ggpht.com/_W6mjt7mDgno/S9opPLz_O5I/AAAAAAAA3yw/yYZekAKroI4/","public_5480525372525642866":"http://lh5.ggpht.com/_3rqotzCU1sY/TA68ygvoBHI/AAAAAAAAA9c/k7jhmLYmw78/","public_5468095309182211138":"http://lh6.ggpht.com/__75Y1wEu2H0/S-KTtmXJFEI/AAAAAAAAAFA/JzlqhzF7Vt4/","public_5467968585789456354":"http://lh5.ggpht.com/_aIZoxdfNfNk/S-IgdU75v-I/AAAAAAAAB7A/jL1VMOt7DgM/","public_5467968606322662898":"http://lh6.ggpht.com/_aIZoxdfNfNk/S-IgehbZnfI/AAAAAAAAB7E/v_h-Pq9AqeU/","public_5394978350593597026":"http://lh5.ggpht.com/_A5ssqXnsoMw/St7QOd4N3mI/AAAAAAAAE98/xKvtFXjUN_U/","public_5468030760630111442":"http://lh4.ggpht.com/_daORpSs2nxc/S-JZAYRETNI/AAAAAAAAAFA/kuOmpgEENNU/","public_5461268259373019506":"http://lh5.ggpht.com/_KFSyWTTuLjA/S8pSi_8LcXI/AAAAAAAAWTA/Ne49ieWVSV8/","public_5418083111186176690":"http://lh6.ggpht.com/_unJLPNmBC1U/SzDl4iXLmrI/AAAAAAABWv4/kkFFBMpXvdM/","public_5465064542962429986":"http://lh6.ggpht.com/_3UYvaY5uN7E/S9fPPyXbsCI/AAAAAAAAAbc/w9YyUMXol5k/","public_5465267981519769410":"http://lh3.ggpht.com/_Z6STI8lIz68/S9iIReDNT0I/AAAAAAAAVn8/1VWscVg0VHI/","public_5464637264209516562":"http://lh4.ggpht.com/_yjAEkPM8eKE/S9ZKo4-SGBI/AAAAAAAAExM/Yolg3yv48ZE/","public_5469816275349772930":"http://lh4.ggpht.com/_aIZoxdfNfNk/S-iw7A7fmoI/AAAAAAAAB7I/uX8etH_Zh8s/","public_5405276903498929458":"http://lh5.ggpht.com/_KFSyWTTuLjA/SwNmtJGtVTI/AAAAAAAAWS8/m3yzK6SE-9k/","public_5464602659331416274":"http://lh3.ggpht.com/_mlwpgEPyjKM/S9YrKnwaoNI/AAAAAAAAL8o/qERJYeK9SOY/","public_5468081125425097026":"http://lh5.ggpht.com/_LgRsf0mgy_M/S-KGz_v7KUI/AAAAAAAABNU/GYTn-LSj3lw/","public_5480525380508846738":"http://lh4.ggpht.com/_3rqotzCU1sY/TA68y-e-CpI/AAAAAAAAA8g/Fb18jqd2T18/","public_5465064395281172466":"http://lh6.ggpht.com/_3UYvaY5uN7E/S9fPHMNeh_I/AAAAAAAAAbY/teuqnGf7uT8/","public_5427875955486466754":"http://lh3.ggpht.com/_K29ox9DWiaM/S1OwbGOnosI/AAAAAAAASqs/Wg5OAoix0tk/","public_5480525385832476034":"http://lh6.ggpht.com/_3rqotzCU1sY/TA68zSUOLYI/AAAAAAAAA9I/JpGyEL5lx9s/","public_5464721817854022450":"http://lh5.ggpht.com/_7V85eCJY_fg/S9aXij2EEzI/AAAAAAAAMsc/rUXq7chzQZo/","public_5468499236979512002":"http://lh6.ggpht.com/_RXIvzqFA_h8/S-QDFSqoksI/AAAAAAAABss/q8Hs_Y6Ojco/","public_5465811371224046274":"http://lh3.ggpht.com/_7SB5-VS6jYo/S9p2e6cZmsI/AAAAAAAAAPk/CdITAmRcDNU/","public_5468499251879550482":"http://lh6.ggpht.com/_RXIvzqFA_h8/S-QDGKLFHhI/AAAAAAAABso/mMXhQIO_rIY/","public_5468011240643552594":"http://lh5.ggpht.com/_q82cg6OMtCs/S-JHQKpm5VI/AAAAAAAAQDs/eQKsBn336_w/","public_5464721917635140242":"http://lh3.ggpht.com/_7V85eCJY_fg/S9aXoXjvGpI/AAAAAAAAMsg/8LweEHXvC8E/","public_5465963404565598994":"http://lh3.ggpht.com/_4HzkBj4VmKw/S9sAwaxq0xI/AAAAAAAAy3s/595Du9f3xbQ/","public_5464886839716494226":"http://lh6.ggpht.com/_as1xi-WX02U/S9ctoGMCO5I/AAAAAAAAC2o/G348G26qKR0/","public_5464644514748019778":"http://lh5.ggpht.com/_dAaguGcsRfA/S9ZRO7VXtEI/AAAAAAAAENA/jQ1y0m7u7FE/","public_5465825398133839090":"http://lh3.ggpht.com/_7SB5-VS6jYo/S9qDPYwTVPI/AAAAAAAAANo/39f76y32uiA/","public_5467921205742594898":"http://lh3.ggpht.com/_aDwLqnCx5xE/S-H1Xcgc61I/AAAAAAAACAQ/zmy2_wM2j4Y/","public_5436863789388960962":"http://lh5.ggpht.com/_uqT1DECwpD8/S3Oez4q2lMI/AAAAAAAAO6c/aGrJoPQEzbY/","public_5464721845849026242":"http://lh4.ggpht.com/_7V85eCJY_fg/S9aXkMIl7sI/AAAAAAAAMsY/hbwwd2lB1ns/","public_5467928286294729906":"http://lh4.ggpht.com/_6NwUsKnkxdc/S-H7zlnoZLI/AAAAAAAAJ2Y/qYD_7yeqVOw/","public_5469782237294118322":"http://lh3.ggpht.com/_iGI-XCxGLew/S-iR9vSoRbI/AAAAAAAABLQ/n5Ix1uZx1qc/","public_5463830940035733394":"http://lh4.ggpht.com/_1rL3G0Y32aQ/S9NtSpWeV5I/AAAAAAAAJd4/wJdXRCWA-_c/","public_5470258900410180098":"http://lh5.ggpht.com/_n8uHgnu6KsU/S-pDfLxeIgI/AAAAAAAAAZY/uPP45av8Tls/","public_5467976005541355106":"http://lh5.ggpht.com/_loGyjar4MMI/S-InNNqm3mI/AAAAAAAAB9s/XKcK0UhQhHk/","public_5467975931636282290":"http://lh6.ggpht.com/_loGyjar4MMI/S-InI6WQ87I/AAAAAAAACEs/WaRxi6D4WCs/","public_5467936023478442338":"http://lh4.ggpht.com/_aDwLqnCx5xE/S-IC183-mWI/AAAAAAAACAU/x5M3XSm-z38/","public_5468630655462131890":"http://lh5.ggpht.com/_vegCfczOoKA/S-R6m2qhyLI/AAAAAAAAIJg/VbgtlWc1YVs/","public_5468499216650860930":"http://lh6.ggpht.com/_RXIvzqFA_h8/S-QDEG75-YI/AAAAAAAABsw/qbL5p3ubU8U/","public_5464708695072547106":"http://lh6.ggpht.com/_s60pF2QNbck/S9aLmtrJoSI/AAAAAAAAeOo/cPMni36CmMk/","public_5464721937652197202":"http://lh4.ggpht.com/_7V85eCJY_fg/S9aXpiILJ1I/AAAAAAAAMsU/m2f6UsfQfEA/","public_5464593346215231826":"http://lh4.ggpht.com/_4HzkBj4VmKw/S9YishsfQVI/AAAAAAAAy3w/2Hg6_XEPri4/"
    };
    
}
