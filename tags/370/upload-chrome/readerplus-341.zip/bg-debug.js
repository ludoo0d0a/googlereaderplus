/* ReaderPlus Chrome Extension by LudoO */

/**
 * @author Valente
 */
window.GRP={
	VERSION: "3.4.0",
	setVersion:function(text){
		var ver = document.getElementById('version');
		ver.innerHTML = (text||'') + GRP.VERSION;
	}
};
/**
 * Crossbrowser implementation for native browser
 *
 * @param {Object} a
 * @param {Object} fn
 */
var mycore = {
    env: {
        background: false,
        chrome: (typeof chrome !== "undefined" && chrome.extension),
        safari: (typeof safari !== "undefined"),
        prefix: '',
        autoparse: true
    },
    application: {
        sendRequest: function(a, fn, b){
            if (mycore.env.chrome) {
            
            } else if (mycore.env.safari) {
                safari.application.addEventListener(a.message, fn, false);
            }
        }
        
    },
    extension: {
        sendRequest: function(){
            //to bg
            var guid = false, a, fn, l = arguments.length;
            if (l > 2) {
                guid = arguments[0];
                a = arguments[1];
                fn = arguments[2];
            } else {
                a = arguments[0];
                fn = arguments[1];
            }
            
            if (mycore.env.chrome) {
                if (guid) {
                    if (fn) {
                        chrome.extension.sendRequest(guid, a, fn);
                    } else {
                        chrome.extension.sendRequest(guid, a);
                    }
                } else {
                    if (fn) {
                        chrome.extension.sendRequest(a, fn);
                    } else {
                        chrome.extension.sendRequest(a);
                    }
                }
                //chrome.extension.sendRequest(arguments);
            } else if (mycore.env.safari) {
                safari.self.addEventListener('crossaction', function(e){
                    var a = e;
                    a.message = a.name;
                    delete a.name;
                    fn(a);
                }, false);
                safari.self.tab.dispatchMessage('crossaction', a);
            }
        },
        onRequest: {
            addListener: function(fn){
                //from bg
                if (mycore.env.chrome) {
                    chrome.extension.onRequest.addListener(fn);
                } else if (mycore.env.safari) {
                    safari.application.addEventListener('crossaction', fn, false);
                }
            }
        },
        onRequestExternal: {
            addListener: function(fn){
                if (mycore.env.chrome) {
                    chrome.extension.onRequestExternal.addListener(fn);
                } else if (mycore.env.safari) {
                    safari.application.addEventListener('crossaction', fn, false);
                }
            }
        }
    },
    page: {
        listen: function(cb){
			if (mycore.env.chrome) {
				chrome.extension.onConnect.addListener(function(port){
					port.onMessage.addListener(cb);
				});
			}
		},
		postMessage: function(msg, cb, options){
            function post(msg, cb, options, tab){
                if (mycore.env.chrome) {
                    var port = chrome.tabs.connect(tab.id);
                    port.postMessage({
                        message: msg,
                        tab: tab.tabId,
                        options: options
                    });
                    port.onMessage.addListener(cb);
                } else if (mycore.env.safari) {
                    //safari
                }
            }
            
            if (options && options.tab) {
                post(msg, cb, options, tab);
            } else {
                mycore.tabs.getSelected(null, function(tab){
                    post(msg, cb, options, tab);
                });
            }
            
        }
    },
    tabs: {
        create: function(options){
            if (mycore.env.chrome) {
                chrome.tabs.create(options);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        get: function(id, fn){
            if (mycore.env.chrome) {
                chrome.tabs.get(id, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        getSelected: function(options, fn){
            if (mycore.env.chrome) {
                chrome.tabs.getSelected(options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        update: function(id, options, fn){
            if (mycore.env.chrome) {
                chrome.tabs.update(id, options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        executeScript: function(id, options){
            if (mycore.env.chrome) {
                chrome.tabs.executeScript(id, options);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        onRemoved: {
            addListener: function(fn){
                if (mycore.env.chrome) {
                    chrome.tabs.onRemoved.addListener(fn);
                } else if (mycore.env.safari) {
                    //safari
                }
            }
        }
    },
    windows: {
        getAll: function(options, fn){
            if (mycore.env.chrome) {
                chrome.windows.getAll(options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        }
    },
    storage: {
        getItem: function(name, def, cb){
            var v = null;
            if (mycore.env.chrome) {
                if (cb && !mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'get',
                        name: name
                    }, function(o){
                        cb(o || def);
                    });
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    v = localStorage.getItem(name);
                }
            } else if (mycore.env.safari) {
                v = localStorage.getItem(name);
                //return safari.extension.settings.getItem(name);
            }
            if (v && typeof v === 'string' && mycore.env.autoparse) {
                try {
                    v = JSON.parse(v);
                } catch (e) {
                    //
                }
            }
            v = v || def;
            if (cb && typeof v === 'function') {
                cb(v);
            }
            return v;
        },
        removeItem: function(name){
            if (mycore.env.chrome) {
                if (!mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'remove',
                        name: name
                    }, cb);
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    localStorage.removeItem(name);
                }
            } else if (mycore.env.safari) {
                localStorage.removeItem(name);
            }
        },
        setItem: function(name, value, cb){
            var s = value;
            if (s && mycore.env.autoparse && typeof s === 'object') {
                s = JSON.stringify(s);
            }
            if (mycore.env.chrome) {
                if (cb !== false && !mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'set',
                        name: name,
                        value: value
                    }, cb);
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    localStorage.setItem(name, s);
                }
            } else if (mycore.env.safari) {
                localStorage.setItem(name, s);
            }
        },
        key: function(i){
            if (mycore.env.chrome) {
                return localStorage.key(i);
            } else if (mycore.env.safari) {
                return localStorage.key(i);
                //return safari.extension.settings.key(i);
            }
        },
        getLength: function(cb){
            var v = -1;
            if (mycore.env.chrome) {
                v = localStorage.length;
            } else if (mycore.env.safari) {
                v = localStorage.length;
                //return safari.extension.settings.length;
            }
            if (cb && typeof v === 'function') {
                cb(v);
            }
            return v;
        },
        clear: function(){
            localStorage.clear();
        }
    },
    getUrl: function(path){
        if (mycore.env.chrome) {
            return 'chrome-extension://' + mycore.getGUID() + path;
        } else if (mycore.env.safari) {
            return safari.extension.baseURI;
            //return 'safari-extension://' + mycore.getGUID() + path;
        }
    },
    getGUID: function(){
        if (mycore.env.chrome) {
            var url = chrome.extension.getURL('bg.html');
            var m = /:\/\/(\w+)/.exec(url);
            return m[1];
        } else if (mycore.env.safari) {
            //TODO
            var namespace = 'com.pitaso.readerplus';
            var guid = '37PA8NKYKP';
            return namespace + '-' + guid;
        }
    },
    getLocalPath: function(){
        return mycore.getProtocol() + mycore.getGUID();
    },
    getProtocol: function(){
        if (mycore.env.chrome) {
            return 'chrome-extension://';
        } else if (mycore.env.safari) {
            return 'safari-extension://';
        }
    }
};

//
// Global util functions
//
function hasClass(el, clazz){
    if (!el || !el.className) {
        return false;
    }
    var reClassname = new RegExp("(^|\\s)" + clazz + "(\\s|$)");
    return (reClassname.test(el.className));
}

function addClass(el, clazz, checked){
    if (checked && hasClass(el, clazz)) {
        return;
    }
    if (el) {
        el.className = (el.className || '') + ' ' + clazz;
    }
}

function addClassChecked(el, clazz){
    addClass(el, clazz, true);
}

function addClassIf(el, cls, status, cls2){
    if (typeof status === 'string') {
        cls2 = status;
        status = null;
    }
    if (typeof status === 'undefined' || status === null) {
        status = !hasClass(el, cls);
    }
    if (status) {
        addClass(el, cls, true);
        if (cls2) {
            removeClass(el, cls2);
        }
    } else {
        removeClass(el, cls);
        if (cls2) {
            addClass(el, cls2);
        }
    }
}

function addAttr(el, name, value){
    var attr = document.createAttribute(name);
    attr.value = value;
    el.attributes.setNamedItem(attr);
}

function findParentNode(eel, etag, clazz){
    var tag = etag.toUpperCase();
    var el = eel.parentNode;
    if (clazz) {
        // Find first element's parent node matching tag and className
        while (el && el.tagName !== 'BODY' && (el.tagName !== tag || !hasClass(el, clazz))) {
            // console.log(el.tagName+'.'+el.className);
            el = el.parentNode;
            /*
             * if (!el){ console.log('el null for clazz '+clazz ); }
             */
        }
    } else {
        while (el && el.tagName !== 'BODY' && el.tagName !== tag) {
            el = el.parentNode;
        }
    }
    return ((el && el.tagName !== 'BODY') ? el : false);
}

function getFirstNode(el){
    var o = el.firstChild;
    //if (typeof o == "HTMLDivElement"){
    if (o && o.nodeType == 1) {
        return o;
    }
    //
    //while(typeof o !== "undefined" && typeof o !== "HTMLDivElement"){
    while (typeof o !== "undefined" && o.nodeType !== 1) {
        o = o.nextSibling;
    }
    return o;
}

function getIndex(el){
    var pos = 0, o = el;
    while ((o = o.previousSibling)) {
        pos++;
    }
    return (pos + 1);
}

function getPos(obj){
    var output = {};
    var mytop = 0, myleft = 0;
    while (obj) {
        mytop += obj.offsetTop;
        myleft += obj.offsetLeft;
        obj = obj.offsetParent;
    }
    output.left = myleft;
    output.top = mytop;
    return output;
}

//native getElementsByClassName
function getFirstElementByClassName(root, clazz){
	return root.getElementsByClassName(clazz)[0];
}

function getElementText(root, cls, html, firstchild){
    var txt = '', el = getFirstElementByClassName(root || document, cls);
    if (el) {
        if (firstchild) {
            el = el.firstChild;
        }
        if (html) {
            txt = el.innerHTML;
        } else {
            txt = el.innerText || el.textContent;
        }
    }
    return txt;
}

function copyAttributes(src, dest){
    var ats;
    if (src && dest && src.attributes && src.attributes.length > 0) {
        for (var i = 0, len = src.attributes.length; i < len; i++) {
            ats = src.attributes[i];
            addAttr(dest, ats.nodeName, ats.nodeValue);
        }
    }
}

/**
 *
 * @param {Object} root
 * @param {Object} tag
 * @param {Object} clazz
 * @deprecated use getFirstElementByClassName
 */
function getFirstElementMatchingClassName(root, tag, clazz){
    var elements = root.getElementsByTagName(tag);
    var i = 0;
    while (elements[i] && !hasClass(elements[i], clazz)) {
        i++;
    }
    return ((!elements[i]) ? null : (elements[i]));
}

function getLastElementMatchingClassName(root, tag, clazz){
    var elements = root.getElementsByTagName(tag);
    var i = elements.length, j = 0;
    while (i >= 0 && elements[i] && !hasClass(elements[i], clazz)) {
        i--;
    }
    return ((i < 0 || !elements[i]) ? null : (elements[i]));
}

function getElementsByClazzName(clazz, itag, ielm){
    var tag = itag || "*";
    var elm = ielm || document;
    var elements = (tag == "*" && elm.all) ? elm.all : elm.getElementsByTagName(tag);
    var returnElements = [];
    var current;
    var length = elements.length;
    for (var i = 0; i < length; i++) {
        current = elements[i];
        if (hasClass(current, clazz)) {
            returnElements.push(current);
        }
    }
    return returnElements;
}

function getElements(xpath, context){
    var res = false, doc = (context) ? context.ownerDocument : document;
    try {
        var r = doc.evaluate(xpath, (context || doc), null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        for (var i = 0, l = r.snapshotLength, res = new Array(l); i < l; i++) {
            res[i] = r.snapshotItem(i);
        }
    } catch (e) {
        console.error('xpath error : ' + xpath);
    }
    return res;
}

function serializeXml(nodes){
    var html = '';
    nodes.forEach(function(node){
        html += node.outerHTML;
    });
    return html;
}

/*
 * From jQuery
 */
function serializePost(a, traditional){
    var e = encodeURIComponent, s = [];
    if (isArray(a) || a.jquery) {
        forEeach(a, function(){
            add(this.name, this.value);
        });
    } else {
        for (var prefix in a) {
            buildParams(prefix, a[prefix]);
        }
    }
    return s.join("&").replace(/%20/g, "+");
    
    function buildParams(prefix, obj){
        if (isArray(obj)) {
            iterate(obj, function(i, v){
                if (traditional || /\[\]$/.test(prefix)) {
                    add(prefix, v);
                } else {
                    buildParams(prefix + "[" + (typeof v === "object" || isArray(v) ? i : "") + "]", v);
                }
            });
            
        } else if (!traditional && obj != null && typeof obj === "object") {
            // Serialize object item.
            iterate(obj, function(k, v){
                buildParams(prefix + "[" + k + "]", v);
            });
            
        } else {
            // Serialize scalar item.
            add(prefix, obj);
        }
    }
    
    function add(key, value){
        // If value is a function, invoke it and return its value
        value = (typeof value === 'function') ? value() : value;
        s[s.length] = e(key) + "=" + e(value);
    }
}

function get_id(id){
    return document.getElementById(id);
}

function getElementValue(query, context){
    var doc = (context) ? context.ownerDocument : document;
    return doc.evaluate(query, (context || doc), null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

function parseXml(xmlText){
    var dom = new DOMParser().parseFromString(xmlText, "application/xml");
    //urlinput.value = dom.getElementsByTagName('shortUrl')[0].textContent;
    return dom;
}

if (typeof Array.forEach === "undefined") {
    Array.forEach = function(arr, fn){
        Array.prototype.forEach.call(arr, fn);
    };
}
function insertAfter(el, ref){
    var next = ref.nextSibling;
    if (next) {
        insertBefore(el, next);
    } else {
        ref.parentNode.appendChild(el);
    }
}

function insertBefore(el, ref){
    ref.parentNode.insertBefore(el, ref);
}

function insertFirst(el, ref){
    if (ref.firstChild) {
        insertBefore(el, ref.firstChild);
    } else {
        ref.parentNode.appendChild(el);
    }
}

function remove(el){
    if (el && el.parentNode) {
        el.parentNode.removeChild(el);
    }
}

/**
 * Strings
 */
function normalizeUrl(url){
    if (!(/^http(s)?:/i.test(url))) {
        return 'http://' + url;
    } else {
        return url;
    }
}

//without parameter
function cleanUrl(url){
    var m = /([^\?]+)\??(.*)/.exec(url);
    if (m) {
        return m[1];
    } else {
        return url;
    }
}

function ellipsis(text, max){
    var match = text || '';
    max = max || 24;
    if (match.length > max) {
        match = match.substr(0, max - 3) + '...';
    }
    return match;
}

String.prototype.toMaj = function(){
    return this.replace(/(^\w)/, function(m){
        return m.toUpperCase();
    });
};

//To Camel Case
String.prototype.toCamel = function(){
    return this.replace(/(\-[a-z])/g, function($1){
        return $1.toUpperCase().replace('-', '');
    });
};
//To Dashed from Camel Case
String.prototype.toDash = function(){
    return this.replace(/([A-Z])/g, function($1){
        return "-" + $1.toLowerCase();
    });
};
//To Underscore from Camel Case
String.prototype.toUnderscore = function(){
    return this.replace(/([A-Z])/g, function($1){
        return "_" + $1.toLowerCase();
    });
};
function isArray(obj){
    return (obj && obj.constructor == Array);
}

/**
 * Shortcuts
 *
 */
/**
 *
 * @param fn
 * @param keys
 *  [{keycode, shift, ctrl, alt}]
 * @return
 */
function initKey(keys){
    document.addEventListener('keydown', function(e){
        var target = e.target;
        var tag = target.tagName;
        //console.log('keydown on '+tag+'.'+(tag.className||''));
        if (tag !== 'INPUT' && tag !== 'SELECT' && tag !== 'TEXTAREA') {
            if (!isArray(keys)) {
                keys = [keys];
            }
            for (var i = 0, len = keys.length; i < len; i++) {
                var k = keys[i];
                if (k.keyCode == e.keyCode &&
                ((k.shiftKey && e.shiftKey) || (!k.shiftKey && !e.shiftKey)) &&
                ((k.ctrlKey && e.ctrlKey) || (!k.ctrlKey && !e.ctrlKey)) &&
                ((k.altKey && e.altKey) || (!k.altKey && !e.altKey))) {
                    e.preventDefault();
                    //e.stopPropagation();
                    //k.fn(e);
                    if (!target.locked) {
                        //console.log('run fn for keyCode='+k.keyCode);
                        k.fn(e);
                        target.locked = true;
                        window.setTimeout(function(){
                            target.locked = false;
                        }, 300);
                    } else {
                        console.log('LOCK run fn for keyCode=' + k.keyCode);
                    }
                    break;
                }
            }
        }
    }, false);
}

function notEmpty(o){
    if (o) {
        if (isArray(o) && o.length > 0) {
            return o;
        } else if (typeof o === "object" && !isObjectEmpty(o)) {
            return o;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function isFunction(fn){
    return (fn && typeof fn === 'function');
}


function isObjectEmpty(o){
    if (!o) {
        return true;
    }
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        return false;
    }
    return true;
}

function findInArray(a, value){
    for (var i = 0, len = a.length; i < len; i++) {
        if (a[i] === value) {
            return i;
        }
    }
    return false;
}

function find(o, key, value){
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (o[p][key] === value) {
            return o[p];
        }
    }
    return false;
}

function findre(o, key, re){
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (re.test(o[p][key])) {
            return o[p];
        }
    }
    return false;
}

function getCount(o){
    var count = 0;
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        count++;
    }
    return count;
}

function returnItemAtPosition(o, i){
    var count = 0;
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (count == i) {
            return o;
        }
    }
    return false;
}

function randomselect(ar){
    if (isArray(ar)) {
        return ar[Math.round(Math.random() * (ar.length - 1))];
    } else if (typeof ar == 'object') {
        var i = Math.round(Math.random() * (getCount(ar) - 1));
        return returnItemAtPosition(ar, i);
    } else {
        return false;
    }
    
}

function removeClass(el, classname){
    //todo: use regex word boundary
    var s = (el.className || '').split(' ');
    for (var i = 0, len = s.length; i < len; i++) {
        if (s[i] == classname) {
            s[i] = '';
        }
    }
    el.className = s.join(' ').trim();
//el.className = el.className.replace(classname, '').trim();
}

function toggleClass(el, classDelete, classAdd){
    removeClass(el, classDelete);
    addClass(el, classAdd);
}

function fireResizeDefer(){
    window.setTimeout(fireResize, 500);
}

function fireResize(){
    fitHeight('sub-tree');
    fitHeight('entries', 'viewer-footer');
}

function fitHeight(id, bottom){
    var el = document.getElementById(id);
    var h = findTop(el);
    if (bottom) {
        var elb = document.getElementById(bottom);
        if (elb) {
            h -= elb.clientHeight;
        }
    }
    el.style.height = (window.innerHeight - h) + 'px';
}

function findTop(obj, relative){
    var curtop = 0;
    if (obj.offsetParent) {
        do {
            curtop += obj.offsetTop;
        } while ((obj = obj.offsetParent) && (!relative || (relative && relative!==obj)) );
        return curtop;
    }
}

function getStyle(el, property){
    if (el && el.style && el.style[property]) {
        return parseInt(el.style[property].replace('px', ''), 10);
    } else {
        return 0;
    }
}

function simulateClick(node){
    var event = node.ownerDocument.createEvent("MouseEvents");
    event.initMouseEvent("click", true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
    /* ReadByMouse
 event.initMouseEvent("click", true, // can bubble
 true, // cancellable
 node.ownerDocument.defaultView, 1, // clicks
 50, 50, // screen coordinates
 50, 50, // client coordinates
 false, false, false, false, // control/alt/shift/meta
 0, // button,
 node);
 */
    node.dispatchEvent(event);
}

function simulateKeypress(node, keycode){
    var event = node.ownerDocument.createEvent("KeyboardEvent");
    if (typeof keycode === "string") {
        keycode = keycode.charCodeAt(0);
    }
    event.initKeyEvent("keypress", true, true, window, 0, 0, 0, 0, 0, keycode);
    //event.initKeyboardEvent('keypress', true, true, window, "U+0041");
    node.dispatchEvent(evt);
}

/**
 * Shortcuts
 * @param {Object} e
 */
function getStringFromCharCode(codePt){
    if (codePt > 0xFFFF) {
        codePt -= 0x10000;
        return String.fromCharCode(0xD800 + (codePt >> 10), 0xDC00 + (codePt & 0x3FF));
    } else if (keycodes && keycodes[codePt]) {
        return keycodes[codePt];
    } else {
        return String.fromCharCode(codePt);
    }
}

//saved under format CTRL[0,1]ALT[0,1]SHIFT[0,1]keyCode
function unmarshallKey(text){
    var m = /(\d)(\d)(\d)(\d+)/.exec(text || '');
    var key = {};
    if (m) {
        key = {
            ctrlKey: (m[1] === '1'),
            altKey: (m[2] === '1'),
            shiftKey: (m[3] === '1'),
            keyCode: m[4]
        };
    }
    return key;
}

function marshallKey(e){
    return ((e.ctrlKey) ? '1' : '0') + ((e.altKey) ? '1' : '0') + ((e.shiftKey) ? '1' : '0') + e.keyCode;
}

function formatKey(e, keyFirst){
    if (e && e.keyCode) {
		var keyLetter = getStringFromCharCode(e.keyCode);
		if (keyFirst) {
			return keyLetter + ((e.ctrlKey) ? '+ctrl' : '') + ((e.altKey) ? '+alt' : '') + ((e.shiftKey) ? '+shift' : '');
		} else {
			return ((e.ctrlKey) ? 'ctrl+' : '') + ((e.altKey) ? 'alt+' : '') + ((e.shiftKey) ? 'shift+' : '') + keyLetter;
		}
	}else{
		return '';
	}
}

/**
 * Cookies
 *
 */
function readCookie(name){
    name = name.replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
    var regex = new RegExp('(?:^|;)\\s?' + name + '=(.*?)(?:;|$)', 'i'), match = document.cookie.match(regex);
    return match && unescape(match[1]);
}

/**
 * Templates
 */
function fillTpl(tpl, o){
    var txt = '' + tpl;
    for (var k in o) {
        if (o.hasOwnProperty(k)) {
            if (typeof o[k] !== "object") {
                var re = new RegExp("\\{" + k + "\\}", "g");
                txt = txt.replace(re, (o[k]) ? ('' + o[k]) : '');
            }
        }
    }
    return txt;
}

//Format text using number {0}
function formatText(tpl){
    if (!arguments) {
        return '';
    }
    var args = Array.prototype.slice.call(arguments, 1);
    var values = {};
    for (var i = 0, len = args.length; i < len; i++) {
        values[i] = args[i];
    }
    return fillTpl(tpl, values);
}

function getGlobal(){
    return (window.GRP = window.GRP || {});
}

var keycodes = {
    8: 'backspace',
    9: 'tab',
    13: 'enter',
    16: 'shift',
    17: 'ctrl',
    18: 'alt',
    19: 'pause',
    20: 'capslock',
    27: 'escape',
    33: 'pageup',
    32: 'space',
    34: 'pagedown',
    35: 'end',
    36: 'home',
    37: 'arrowleft',
    38: 'arrowup',
    39: 'arrowright',
    40: 'arrowdown',
    44: 'printscreen',
    45: 'insert',
    46: 'delete',
    48: '0',
    49: '1',
    50: '2',
    51: '3',
    52: '4',
    53: '5',
    54: '6',
    55: '7',
    56: '8',
    57: '9',
    65: 'a',
    66: 'b',
    67: 'c',
    68: 'd',
    69: 'e',
    70: 'f',
    71: 'g',
    72: 'h',
    73: 'i',
    74: 'j',
    75: 'k',
    76: 'l',
    77: 'm',
    78: 'n',
    79: 'o',
    80: 'p',
    81: 'q',
    82: 'r',
    83: 's',
    84: 't',
    85: 'u',
    86: 'v',
    87: 'w',
    88: 'x',
    89: 'y',
    90: 'z',
    91: 'leftwindowkey',
    92: 'rightwindowkey',
    93: 'selectkey',
    96: '0 pad',
    97: '1 pad',
    98: '2 pad',
    99: '3 pad',
    100: '4 pad',
    101: '5 pad',
    102: '6 pad',
    103: '7 pad',
    104: '8 pad',
    105: '9 pad',
    106: '*',
    107: '+',
    109: '-',
    110: '.',
    111: '/',
    112: 'f1',
    113: 'f2',
    114: 'f3',
    115: 'f4',
    116: 'f5',
    117: 'f6',
    118: 'f7',
    119: 'f8',
    120: 'f9',
    121: 'f10',
    122: 'f11',
    123: 'f12',
    144: 'numlock',
    145: 'scrolllock',
    182: 'MyComputer',
    183: 'MyCalculator',
    186: ';',
    187: '=',
    188: ',',
    189: 'dash',
    190: 'period',
    191: '/',
    219: '(',
    220: '\\',
    221: ')',
    222: '\''
};
//a.href sometimes truncated
function getHref(a){
    var url = a.protocol + '//' + a.host + a.pathname + (a.hash || '');
    return url;
}

function adjustIframeHeight(iframe, heightMaxi){
    var el;
    if (iframe.document.height) {
        el = parent.document.getElementById(iframe.name);
        el.style.height = iframe.document.height + 'px';
    //el.style.width = iframe.document.width + 'px';
    } else if (document.all) {
        el = parent.document.all[iframe.name];
        if (iframe.document.compatMode &&
        iframe.document.compatMode != 'BackCompat') {
            el.style.height = iframe.document.documentElement.scrollHeight + 5 + 'px';
        //el.style.width = iframe.document.documentElement.scrollWidth + 5 + 'px';
        } else {
            el.style.height = iframe.document.body.scrollHeight + 5 + 'px';
        //el.style.width = iframe.document.body.scrollWidth + 5 + 'px';
        }
    }
}

function bind(func, thisArg){
    var args = Array.prototype.slice.call(arguments, 2);
    return function(){
        var bargs = args.concat(Array.prototype.slice.call(arguments));
        func.apply(thisArg, bargs);
    };
}

function foreach(array, fn, scope){
    if (!array) {
        return;
    }
    if (typeof array.length == "undefined") {
        array = [array];
    }
    for (var i = 0, len = array.length; i < len; i++) {
        if (fn.call(scope || array[i], array[i], i, array) === false) {
            return i;
        }
    }
}

function map2array(o, key, value, flat, eu){
    var r = [];
    iterate(o, function(p, o){
        var a = {};
        a[key || 'key'] = p;
        if (flat && typeof o === "object") {
            iterate(o, function(k, obj){
                a[k] = obj;
            });
        } else {
            a[value || 'value'] = o;
        }
        r.push(a);
    });
    return r;
}

function iterate(o, fn, scope, id){
    if (o) {
        for (var p in o) {
            if (!hasOwnProperty.call(o, p)) {
                continue;
            }
            if (typeof id !== 'undefined') {
                o[p][(typeof id === "string") ? id : 'id'] = p;
            }
            fn.call(scope || this, p, o[p]);
        }
    }
    return false;
}

function namespace(){
    var o, d;
    foreach(arguments, function(v){
        d = v.split(".");
        o = window[d[0]] = window[d[0]] || {};
        foreach(d.slice(1), function(v2){
            o = o[v2] = o[v2] || {};
        });
    });
    return o;
}

function apply(o, c, defaults){
    if (defaults) {
        apply(o, defaults);
    }
    if (o && c && typeof c === 'object') {
        for (var p in c) {
            o[p] = c[p];
        }
    }
    return o;
}

//Override text with last item
function merge(o, c, defaults){
    if (defaults) {
        merge(o, defaults);
    }
    if (typeof o !== "undefined" && typeof c !== "undefined") {
        /*if (isArray(c)) {
 for (var i = 0, len = c.length; i < len; i++) {
 //o[i] = c[i];
 //console.log(c[i] + ' Amerge['+i+']> ' + o[i]);
 if (typeof c[i] === 'object' || isArray(c[i])) {
 merge(o[i], c[i]);
 } else {
 o[i] = c[i];
 }
 }
 //console.log('after: ' + c[i] + ' Amerge[' + i + ']> ' + o[i]);
 } else */
        if (typeof c === 'object') {
            for (var p in c) {
                //console.log(c[p] + ' Omerge['+p+']> ' + o[p]);
                if (typeof c[p] === 'object' || isArray(c[p])) {
                    merge(o[p], c[p]);
                } else {
                    o[p] = c[p];
                }
            }
        } else {
            //o[p] = c[p];
            //console.log(c + ' -> ' + o);
            o = c;
        }
    }
    return o;
}

function isundef(o){
    return (typeof o === 'undefined');
}

function group(a, name){
    var r = {};
    iterate(a, function(id, o){
        var val = o[name] || 'other';
        if (!r[val]) {
            r[val] = {};
        }
        r[val][id] = o;
    });
    return r;
}

function applyRemoteLang(lang, base, id, o, fn, scope){
    GM_xmlhttpRequest({
        method: 'GET',
        url: base + '_locales/' + lang + '/' + id + '.json',
        onload: function(res){
            var data = eval(xhr.responseText);
            if (data) {
                //merge data into o
                applyLast(o[id], data);
            }
        },
        onerror: function(res, a){
            if (a && a.url) {
                console.error(a.url);
            }
            console.error(res);
        }
    });
}

//http://snipplr.com/view/9649/escape-regular-expression-characters-in-string/
//http://simonwillison.net/2006/Jan/20/escape/
var re_encodeRE = new RegExp("[.*+?|()\\[\\]{}\\\\]", "g"); // .*+?|()[]{}\
function encodeRE(s){
    return s.replace(re_encodeRE, "\\$&").replace(' ', '\\W');
}

function urlDecode(string){
    var obj = {}, pairs = string.split('&'), d = decodeURIComponent, name, value;
    for (var i = 0, len = pairs.length; i < len; i++) {
        var pair = pairs[i];
        pair = pair.split('=');
        name = d(pair[0]);
        value = d(pair[1]);
        obj[name] = !obj[name] ? value : [].concat(obj[name]).concat(value);
    }
    return obj;
}

function getDomain(url, withProtocol){
    var m = url.split(/\/|\?/);
    if (withProtocol) {
        return m[0] + '/' + m[1] + '/' + m[2];
    } else {
        return m[2];
    }
}

/*
 isChromeVersionMini('5.0.342.1')
 compareVersion('5.1', '5.0.342.1');->=true
 compareVersion('5.0.100', '5.0.342.1');->=false
 */
function getChromeVersion(){
    var version = /Chrome\/([\d\.]+)/.exec(window.navigator.appVersion);
    return version[1];
}

//Chrome mini version required
function isChromeVersionMini(ref){
    return (compareVersion(getChromeVersion(), ref) >= 0);
}

function isOsMac(){
	return window.navigator.platform.toLowerCase().indexOf('mac')>=0;
}
function isOsLinux(){
	return window.navigator.platform.toLowerCase().indexOf('linux')>=0;
}
//compare 2 first segments
function isVersionMajorUpdated(oldVersion, newVersion){
    return (compareVersion(newVersion, oldVersion, 2) > 0);
}

function compareVersion(version, ref, count){
    if (!ref) {
        //new version, no previous version
        return 1;
    }
    var versions = version.split('.');
    var refs = ref.split('.');
    count = count || versions.length;
    for (var i = 0, len = count; i < len; i++) {
        versions[i] = parseInt(versions[i], 10);
        if (i <= refs.length) {
            refs[i] = parseInt(refs[i], 10);
            if (versions[i] < refs[i]) {
                return -1;
            } else if (versions[i] > refs[i]) {
                return 1;
            }
        }
    }
    return 0;
}

function textareaTab(){
    //Let handle tab on textarea
    var areas = document.getElementsByTagName('textarea');
    if (areas) {
        for (var i = 0, len = areas.length; i < len; i++) {
            areas[i].addEventListener('keydown', function(e){
                var t = e.target;
                if (e.keyCode == 9) {
                    e.preventDefault();
                    var tab = '\t';
                    var ss = t.selectionStart;
                    var se = t.selectionEnd;
                    var currentScroll = t.scrollTop;
                    // Indent
                    if (ss != se && t.value.slice(ss, se).indexOf("\n") != -1) {
                        var pre = t.value.slice(0, ss);
                        var selb = t.value.slice(ss, se);
                        if (e.shiftKey) {
                            //un-indent
                            sel = selb.replace(/^\t/mg, "\n");
                        } else {
                            //indent
                            sel = selb.replace(/\n/g, "\n" + tab);
                        }
                        var post = t.value.slice(se, t.value.length);
                        t.value = pre.concat(tab).concat(sel).concat(post);
                        t.selectionStart = ss + tab.length;
                        t.selectionEnd = se + (sel.length - selb.length);
                    } else {
                        t.value = t.value.slice(0, ss).concat(tab).concat(t.value.slice(ss, t.value.length));
                        if (ss == se) {
                            t.selectionStart = t.selectionEnd = ss + tab.length;
                        } else {
                            t.selectionStart = ss + tab.length;
                            t.selectionEnd = se + tab.length;
                        }
                    }
                    t.scrollTop = currentScroll;
                    t.focus();
                    return false;
                } else {
                    return true;
                }
            });
        }
    }
}

function waitlib(check, fn, scope){
    if (check()) {
        if (fn) {
            fn.call(scope || this);
        }
    } else {
        window.setTimeout(function(){
            waitlib(check, fn);
        }, 200);
    }
}

function waitImages(images, cb, scope){
    var count = (images) ? images.length : 0;
    if (count <= 0) {
        cb.call(scope || this, true);
    } else {
        var timeout = window.setTimeout(function(){
            console.log("Images are not all loaded: " + count);
            cb.call(scope || this, false);
        }, 3000);
        function check(){
            if (count === 0) {
                window.clearTimeout(timeout);
                cb.call(scope || this, true);
            }
        }
        for (var i = 0, len = images.length; i < len; i++) {
            var image = images[i];
            if (image.complete) {
                count--;
            } else {
                image.addEventListener('load', function(){
                    count--;
                    check();
                });
            }
        }
        check();
    }
}

function isShown(el){
    return (el && el.style && el.style.display !== 'none' && el.visibility !== 'hidden');
}

function show(el, value){
    if (el) {
        if (!el.style) {
            el.style = {};
        }
        el.style.display = value || '';
    }
}

function hide(el){
    if (el) {
        el.style.display = 'none';
    }
}

function toggle(el){
    if (isShown(el)) {
        hide(el);
    } else {
        show(el);
    }
}

function showas(el, hideme){
    if (hideme) {
        hide(el);
    } else {
        show(el);
    }
}

//http://forums.mozillazine.org/viewtopic.php?f=19&t=1806595
//http://forums.mozillazine.org/viewtopic.php?f=19&t=1594275
//https://developer.mozilla.org/En/Code_snippets:HTML_to_DOM
function loadXml(html, id){
    var el = document.createElement('div');
	el.id = id || ('_grp_xml_'+Math.round(Math.random()*999+1));
    el.style.display = 'none';
    el.innerHTML = (html.split(/<body[^>]*>((?:.|\n)*)<\/body>/i)[1]) || html;
    return el;
}

function loadText(url, cb){
    GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        onload: function(r){
            var txt = r.responseText;
            cb(txt);
        }
    });
}

function loadCss(url, cb, option){
    loadText(url, function(txt){
        var css = txt;
        if (!option || option.compact) {
            css = compact(css);
        }
        if (!option || option.clean) {
            css = css.replace(/\/\*.*?\*\//g, '');
        }
        cb(css);
    });
}

function compact(text){
    return text.replace(/[\n\t]/g, '').replace(/\s+/g, ' ');
}

//Only works with XML well-formed
function getDocumentXml(html, id){
    var h = html.replace(/^(.*\n)*.*<html/i, "<html");
    h = h.replace(/<\/html>(.*\n)*.*$/i, "</html>");
    var parser = new DOMParser();
    var dom = parser.parseFromString(t, "text/xml");
    return dom;
}

function loadXMLDoc(url){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, false);
    xhr.send("");
    return xhr.responseXML;
}

function applyXsl(xml, xsl){
    var oxml = loadXMLDoc(xml);
    var oxsl = loadXMLDoc(xsl);
    var xp = new XSLTProcessor();
    xp.importStylesheet(oxsl);
    var doc = xp.transformToFragment(oxml, document);
    return doc;
}

var tmaps = {
    id: 'id',
    cls: 'className',
    style: 'style',
    href: 'href',
    alt: 'alt',
    title: 'title',
    text: 'innerText',
    html: 'innerHTML'
};
function dh(root, tag, attrs, events){
    var config = attrs;
    if (root) {
        config.root = root;
    }
    if (tag) {
        config.tag = tag;
    }
    if (events) {
        config.events = events;
    }
    return dhc(config);
}

function dhc(config){
    if (!config) {
        return false;
    }
    var root = config.root;
    if (!root) {
        root = document.body;
    } else if (typeof config.root == "string") {
        root = get_id(config.root);
        if (!root) {
            return false;
        }
    }
    var excepts = {
        root: 1,
        tag: 1,
        events: 1,
        el: 1,
        position: 1
    };
    var el = document.createElement(config.tag || 'div');
    iterate(config, function(k, o){
        if (typeof o !== 'undefined') {
            if (excepts[k] !== 1) {
                if (tmaps[k]) {
                    el[tmaps[k]] = o;
                } else {
                    addAttr(el, k, o);
                }
            }
        }
    });
    iterate(config.events, function(event, fn){
        el.addEventListener(event, fn, false);
    });
    if (config.el) {
        //recurse
        var cfg = config.el;
        cfg.root = el;
        dhc(cfg);
    }
    if (config.position) {
        if (config.position === 'before') {
            insertBefore(el, root);
        } else {
            insertAfter(el, root);
        }
    } else {
        root.appendChild(el);
    }
    return el;
}

function newel(id, cls){
    var el = get_id(id);
    if (el) {
        return el;
    } else {
        return dh('', 'div', {
            id: id,
            cls: cls
        });
    }
}

function randomItem(items){
    return items[Math.round(Math.random() * (items.length - 1))];
}

function loadjQuery(cb, version, local){
    version = version || '1';
    var url = (local) ? (LOCALPATH + '/lib/jquery.min.js') : ('http://ajax.googleapis.com/ajax/libs/jquery/' + version + '/jquery.min.js');
    GM_loadScript(url, false, function(){
        return (typeof jQuery !== "undefined");
    }, cb);
}

function runfn(fn, id, priority, delay){
    GRP.fns.push({
        fn: fn,
        id: id,
        delay: delay,
        priority: priority
    });
}

function encodeu(el){
    return escape(encodeURIComponent(el));
}

function decodeu(el){
    return decodeURIComponent(unescape(el));
}

function getBoolean(val){
    return (val && (val === true || val.toLowerCase() === 'true'));
}


function getTypedValue(o){
    var text;
    if (typeof o === 'object') {
        text = o.value || '';
    } else {
        text = o;
    }
    if (text === "true") {
        return true;
    } else if (text === "false") {
        return false;
    } else {
        return text;
    }
}
/**
 * @author Valente
 */
var GUID_CORE = mycore.getGUID(), 
GUID_CORE_PROD = 'hhcknjkmaaeinhdjgimjnophgpbdgfmg', 
GUID_ICON = 'ecpcafinfpjgabomoamkhkgnpgpmdmeo',
LOCALPATH = mycore.getLocalPath();

if (GUID_CORE!==GUID_CORE_PROD){
	GUID_ICON = 'cgpgjbahhnkejmclppnpkcoildokbmem';
}

function call_icon(message, options, callback){
	external_call(GUID_ICON, message, options, callback);
}
function call_core(message, options, callback){
	external_call(GUID_CORE, message, options, callback);
}
function external_call(guid, message, options, callback){
    //console.log('CORE external_call ['+message+'] to '+guid);
	var emptyFn = function(){
    };
    mycore.extension.sendRequest(guid, 
    {
        message: message,
		keypass: "##ReaderPlus",
        options: options || {}
    }, callback || emptyFn);
}

/**
 * @author Valente
 */
GRP.scripts = {
    general: {
        name: "General",
        category: 'main',
		status: 'updated',
        options: {
            secure: false,

			text_layout:{
                xtype: 'h'
            },
            topcurrent: false,
            floatactions: false,
			bottomup:false,
			currdir:true,
			icons:false,
            /*antisocial:true,*/

			text_pageicon:{
                xtype: 'h'
            },
			pageicon:true,
			
			text_toolbaricon: {
                xtype: 'h'
            },
			icontoolbar_add: {
                xtype: 'p',
                label: true
            },
			counter: true,
			counterinterval: 2,
			opendirect: false,
            icontoolbar_text: {
                xtype: 'p',
                label: true
            },
			
			text_private:{
                xtype: 'h'
            },
			stats:true,
            noupdatepopup: false,
			
			text_export:{
                xtype: 'h'
            },
            importexport_text: {
                xtype: 'p',
                label: true
            },
            preferences: {
                xtype: 'html',
                label: true,
                value: '<input id="ieprefs" class="ignore" type="text" size="30"/><input type="button" id="bimport" value="import" onclick="importprefs();"/><input type="button" id="bexport" value="export" onclick="exportprefs();"/>'
            }
        }
    },
    theme: {
        name: "Theme",
        category: 'theme',
        status: 'updated',
        options: {
            skin: '',
            noborder: false,
            mytheme: {
                xtype: 'p',
                label: true,
                parent: 'mytheme'
            },
            externaltheme: {
                value: '',
                values: {
                    none: '',
					gmail_chrome: 'Gmail Bold Blue',
					gmail_c: 'Gmail Classic',
					gmail_newblue: 'Gmail New Blue',
					gmail_coldshower: 'Gmail Cold Shower',
					gmail_steel: 'Gmail Steel',
					gmail_lightbright: 'Gmail Minimalist',
					gmail_greensky: 'Gmail Green Sky',
					gmail_lightsoft: 'Gmail Bubblegum',
					gmail_cherry: 'Gmail Cherry Blossom',
					gmail_nightshade: 'Gmail Night Shade',
					gmail_medsoft: 'Gmail marina',
					gmail_medred: 'Gmail dusk',
					gmail_darkwarm: 'Gmail sunset',
					gmail_greyrain: 'Gmail Silver Lining',
					gmail_contrastblack: 'Gmail Contrast Black',
					gmail_shiny: 'Gmail shiny',
					gmail_desk: 'Gmail Desk',
					gmail_tree: 'Gmail Tree',
					gmail_beach: 'Gmail Beach',
					gmail_mountains: 'Gmail Mountains',
					gmail_pebbles: 'Gmail pebbles',
					gmail_ocean: 'Gmail Summer ocean',
                    gmail_phantasea: 'Gmail Phantasea',
					gmail_graffiti: 'Gmail Graffiti',
					gmail_planets: 'Gmail Planets',
					gmail_gizmos: 'Gmail Zoozimps',
					gmail_candy: 'Gmail Candy',
					gmail_busstop: 'Gmail Bus Stop',
					gmail_ninja: 'Gmail Ninja',
					gmail_teahouse: 'Gmail Tea House',
		            gmail_terminal: 'Gmail Terminal',
					gmail_orcasisland: 'Gmail Orcas Island',
					gmail_highscore: 'Gmail Highscore',
					gmail_turf: 'Gmail Turf',
					gmail_lapinscretins: 'Gmail lapinscretins',
					gmail_assasinscreed2: 'Gmail assasinscreed2',				
/* editors_picks */
"editor_5478752472500006610":"Google, artist, Dale Chihuly, 01_chihuly_06.jpg","editor_5478752827007585634":"Google, artist, Dale Chihuly, 08_chihuly_02.jpg","editor_5478752842710333378":"Google, artist, Dale Chihuly, 10_chihuly_05.jpg","editor_5478753114195988130":"Google, artist, Dale Chihuly, 14_chihuly_01.jpg","editor_5478753075316627266":"Google, artist, Dale Chihuly, 12_chihuly_03.jpg","editor_5478753460334726146":"Google, artist, Dale Chihuly, 16_chihuly_07.jpg","editor_5478752501519603442":"Google, \u00a9 Jeff Koons, 04_koons_02.jpg","editor_5478753089633816370":"Google, \u00a9 Jeff Koons, 13_koons_01.jpg","editor_5478752819223180210":"Google, Polly Apfelbaum, 06_apfelbaum_01.jpg","editor_5478753117486370930":"Google, Polly Apfelbaum, 15_apfelbaum_03.jpg","editor_5478752835087677362":"Google, Polly Apfelbaum, 09_apfelbaum_02.jpg","editor_5478752493997894098":"Google, \u00a9 Tom Otterness, 03_otterness_02.jpg","editor_5478752822146891810":"Google, \u00a9 Tom Otterness, 07_otterness_03.jpg","editor_5478753058608504226":"Google, \u00a9 Tom Otterness, 11_otterness_01.jpg","editor_5480987905094465154":"Google, \u00a9 Kengo Kuma (???), kengo_kuma.jpg","editor_5480987906200029490":"Google, \u00a9 Tord Boontje, tord_boontje.jpg","editor_5480998621006856338":"Google, \u00a9 Kwon, Ki-soo (???), ki_soo_kwon.jpg","editor_5480987916726984130":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_01.jpg","editor_5480987917979934498":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_02.jpg","editor_5480987925727076290":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_03.jpg","editor_5480988005113749330":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_04.jpg","editor_5480988012864676114":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_05.jpg","editor_5478753466167683746":"Google, National Geographic Stock, natgeo_01.jpg","editor_5478753483552159554":"Google, National Geographic Stock, natgeo_02.jpg","editor_5478755559461692018":"Google, National Geographic Stock, natgeo_03.jpg","editor_5478755572322259650":"Google, National Geographic Stock, natgeo_04.jpg","editor_5478753799989312658":"Google, National Geographic Stock, natgeo_06.jpg","editor_5478753813630017442":"Google, National Geographic Stock, natgeo_07.jpg","editor_5478753819961634386":"Google, National Geographic Stock, natgeo_08.jpg","editor_5478752511525657170":"Google, National Geographic Stock, 05_natgeo_10.jpg","editor_5478753832267149810":"Google, National Geographic Stock, natgeo_09.jpg","editor_5480997862386069170":"Google, National Geographic Stock, NationalGeographic_1143826.jpg","editor_5480997893054118498":"Google, National Geographic Stock, NationalGeographic_1146940.jpg","editor_5480998186992651026":"Google, National Geographic Stock, NationalGeographic_1223429.jpg","editor_5478769425598313058":"Google, Blue, Color_Google_blue.jpg","editor_5478769428183578882":"Google, Green, Color_Google_green.jpg","editor_5478769428473291154":"Google, Grey, Color_Google_grey.jpg","editor_5478769530404012082":"Google, Red, Color_Google_red.jpg","editor_5478769535168997586":"Google, Yellow-Orange, Color_Google_yelloworange.jpg","editor_5480596593254567266":"Google, White, white-2000x1500.jpg",
/* public_gallery */
"public_5468005866288280370":"Google, EricasJoys/HorizontalMambo","public_5480525382039743330":"Google, 116086157836169916177/Favorites","public_5469661666160577106":"Google, 114728257341600814985/PicasaWebPublicPictures","public_5464847589870262818":"Google, juliantoledo/Best","public_5468620555541748930":"Google, bdowney/ClassicPlus","public_5465726438613138322":"Google, EricasJoys/HorizontalMambo","public_5480525372525642866":"Google, 116086157836169916177/Favorites","public_5468095309182211138":"Google, climent/Travels","public_5467968585789456354":"Google, max.braun/Homepage","public_5467968606322662898":"Google, max.braun/Homepage","public_5394978350593597026":"Google, bluan01/JiuZhaiGouYellowDragonNationalParks","public_5468030760630111442":"Google, 109244757320221408388/Test2006","public_5461268259373019506":"Google, jclilot/Portfolio_Flowers","public_5418083111186176690":"Google, fkarpelevitch/200806","public_5465064542962429986":"Google, snoozy.koala/Images","public_5465267981519769410":"Google, magdalar/Backgrounds","public_5464637264209516562":"Google, brettw/Taiwan","public_5469816275349772930":"Google, max.braun/Homepage","public_5405276903498929458":"Google, jclilot/Portfolio_Nature","public_5464602659331416274":"Google, maeve.mara/FeaturedPhotos","public_5468081125425097026":"Google, michos.conradt/Public","public_5480525380508846738":"Google, 116086157836169916177/Favorites","public_5465064395281172466":"Google, snoozy.koala/Images","public_5427875955486466754":"Google, sandysroom/VerdugoNorthTraverse","public_5480525385832476034":"Google, 116086157836169916177/Favorites","public_5464721817854022450":"Google, mjwiacek/PhotosILike","public_5468499236979512002":"Google, uffishmpk/SelectedFavourites","public_5465811371224046274":"Google, 103752943986656263237/Night","public_5468499251879550482":"Google, uffishmpk/SelectedFavourites","public_5468011240643552594":"Google, sweth.c/ForGoogle","public_5464721917635140242":"Google, mjwiacek/PhotosILike","public_5465963404565598994":"Google, arendsf/ThomasFavoriteShared","public_5464886839716494226":"Google, mariusm/ILikeThese","public_5464644514748019778":"Google, simon.tong/Wallpapers","public_5465825398133839090":"Google, 103752943986656263237/Background","public_5467921205742594898":"Google, TenSafeFrogs/Favorites","public_5436863789388960962":"Google, marius.schilder/Trona","public_5464721845849026242":"Google, mjwiacek/PhotosILike","public_5467928286294729906":"Google, merciniebres/HelloWorld","public_5469782237294118322":"Google, peter.norvig/Pictures","public_5463830940035733394":"Google, mattgundersen/LandmarksOfTahoe","public_5470258900410180098":"Google, kevin.cantrell/PublicAlbum","public_5467976005541355106":"Google, romain.guy/Wallpapers","public_5467975931636282290":"Google, romain.guy/Wallpapers","public_5467936023478442338":"Google, TenSafeFrogs/Favorites","public_5468630655462131890":"Google, RussHaig/SFNightD40","public_5468499216650860930":"Google, uffishmpk/SelectedFavourites","public_5464708695072547106":"Google, pawliger/Homepage","public_5464721937652197202":"Google, mjwiacek/PhotosILike","public_5464593346215231826":"Google, arendsf/ThomasFavoriteShared"
					
},
                xtype: 'select',
                parent: 'mytheme'
            },
			color: {
                value: '#565656',
                xtype: 'picker',
                parent: 'mytheme'
            },
            bg: {
                value: '#FFC',
                xtype: 'picker',
                parent: 'mytheme'
            },
			imgsbg: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgrbg: {
                value: '',
                size: 80,
                parent: 'mytheme'
            },imgrh: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgh: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imghr: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imghl: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgrf: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgf: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgfr: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgfl: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, ncolumns: {
	            value: 2,
	            parent: 'portal'
	       }	
        }
    },
    ig: {
        name: "iGoogle Theme",
        category: 'theme',
        desc: "Use iGoogle Theme in your Google Reader (Beta)",
        options: {
            warning: {
                xtype: 'p',
                label: true,
                cls: 'warning center'
            },
            skin_name: {
                value: '',
                size: 80
            },
            skin_url: {
                value: '',
                size: 80
            },
            skin_id: {
                xtype: 'hidden'
            },
            /*debug: false,*/
            randomtime: true,
            userandomthemes: false,
            randomthemes: {
                value: 30,
                lcls: 'large'
            },
            themes: {
                xtype: 'html',
                label: true,
                value: '<div id="ig_themes"></div>'
            }
        },
        shortcuts: {
            'random': {
                id: 'random',
                title: 'Random theme',
                key: {
                    //82 r
                    keyCode: 82,
                    shiftKey: true
                }
            }
        }
    },
    relook: {
        name: "Relook",
        category: 'theme',
        desc: "Relook yourself GoogleReader using custom stylesheets",
        options: {
            resize: false,
            css: {
                xtype: 'textarea',
                cls: 'code',
                rows: 40,
                value: '/* This CSS sample alternates green entry, red border */\n/* green entry */\n.entry:nth-child(even) .card-common, \n.entry:nth-child(even) .card-actions, \n#entries .entry:nth-child(even) .collapsed {\n border:1px solid #FFACAC;\n}\n/* red border */\n.entry:nth-child(odd) .card-common, \n.entry:nth-child(odd) .card-actions, \n#entries .entry:nth-child(odd) .collapsed {\n background-color:#C4DFC0;\n}\n'
            }
        }
    },
    favicons: {
        name: "Favicons",
        category: 'icons',
        options: {
            providerpageicons: false,
            sidebaronly: false,
			cloud:true,
            custom: {
                xtype: 'p',
                label: true
            },
            domains: {
                xtype: 'crud'
            },
            tip: {
                xtype: 'p',
                label: true
            },
            manual: false,
            parsing: {
                xtype: 'p',
                label: true
            }
        }
    },
    unreadcount: {
        category: 'counter',
        name: "Show all unread count"
    },
    fixlayout: {
        category: 'layout',
        name: "Fix layout"
    },
    count: {
        category: 'counter',
        name: "Fix counter (1000+)"
    },
    counticon: {
        category: 'counter',
        name: "Icon counter"
    },
    removeads: {
        name: "Remove ads",
        category: 'content',
        options: {
            links: {
                xtype: 'textarea',
                value: "da\.feedsportal\.com|res\.feedsportal\.com|doubleclick\.net|/ads"
            },
            images: {
                xtype: 'textarea',
                value: "feedsportal\.com|doubleclick\.net|/ads"
            },
            iframes: {
                xtype: 'textarea',
                value: "feedsportal\.com|doubleclick\.net|googlesyndication\.com/pagead/ads"
            }
        }
    },
    column: {
        name: "Text multi columns",
        category: 'layout',
        options: {
            count: 3,
            /*maxcolumns:6,*/
            pagebreak: true,
			miniparas:5,
            locked: false,
            filter: {
                xtype: 'crud'
            }
        },
        shortcuts: {
            'columns': {
                id: 'columns',
                title: 'Multi columns',
                key: {
                    //67 c
                    keyCode: 67
                }
            }
        }
    },
    preview: {
        name: "Integrated preview",
        category: 'layout',
        options: {
            onicon: false,
            overlay: false,
            locked: false,
            filter: {
                xtype: 'crud'
            }
        },
        //shortcut: "shift+R",
        shortcuts: {
            'prview': {
                id: 'prview',
                title: 'Entry preview',
                key: {
                    //81 q
                    keyCode: 81
                }
            },
			'next': {
                id: 'next',
                title: 'Next preview',
                key: {
                    //81 q
                    keyCode: 81,
					shiftKey:true
                }
            },
			'previous': {
                id: 'previous',
                title: 'Previous preview',
                key: {
                    //81 q
                    keyCode: 81,
					ctrlKey:true
                }
            },
			'close': {
                id: 'close',
                title: 'Close preview',
                key: {
                    //88 x
                    keyCode: 88,
					shiftKey:true
                }
            }
        }
    },
    colorful: {
        name: "Colorful listview",
        category: 'layout',
        options: {
            tree: false,
            usebasecolor: false,
            background: {
                value: '#BCBCBC',
                xtype: 'picker'
            },
            color: {
                value: '#000000',
                xtype: 'picker'
            }
        }
    },
    filter: {
        name: "Filter entries",
        category: 'layout',
        options: {
            searchbody: false,
			excludes: {xtype:'textarea',list:true,cls:'xlist'},
			highlights: {xtype:'textarea',list:true,cls:'xlist'}
        }
    },
    readbymouse: {
        name: "Read by mouse",
        category: 'navigation'
    },
    facebook: {
        name: "Facebook integration",
        category: 'share',
        shortcuts: {
            'gofacebook': {
                id: 'gofacebook',
                title: 'Post on Facebook',
                key: {
                    //70 f
                    keyCode: 70
                }
            }
        }
    },
    twitter: {
        name: "Twitter integration",
        category: 'share',
        options: {
            shortener: {
                xtype: 'select',
                values: {
                    tinyurl: 'TinyUrl',
                    bitly: 'BitLy'
                }
            },
            shortener_bitly: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            shortener_login: {
                value: '',
                size: 20
            },
            shortener_apikey: {
                value: '',
                size: 30
            }
        },
        shortcuts: {
            'tweet': {
                id: 'tweet',
                title: 'Post on Twitter',
                key: {
                    //87 w
                    keyCode: 87
                }
            }
        }
    },
    instapaper: {
        name: "Instapaper integration",
        category: 'share',
        options: {
            auth: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            username: '',
            password: {
                input: 'password',
                value: ''
            }
        },
        shortcuts: {
            'share': {
                id: 'share',
                title: 'Read Later with Instapaper',
                key: {
                    //73 i
                    keyCode: 73
                }
            }
        }
    },
    readitlater: {
        name: "ReadItLater integration",
        category: 'share',
        options: {
            auth: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            username: '',
            password: {
                input: 'password',
                value: ''
            }
        },
        shortcuts: {
            'share': {
                id: 'share',
                title: 'Read Later with ReadItLater',
                key: {
                    //76 l
                    keyCode: 76
                }
            }
        }
    },
    mark: {
        name: "Mark As Read",
        category: 'navigation',
        shortcuts: {
            'markprev': {
                id: 'markprev',
                title: 'Mark items before As Read',
                key: {
                    //87 w
                    keyCode: 87
                }
            },
            'marknext': {
                id: 'marknext',
                title: 'Mark items after As Read',
                key: {
                    //89 y
                    keyCode: 89
                }
            }
        }
    },
    jump: {
        name: "Add top/bottom links",
        category: 'navigation',
        shortcuts: {
            'goup': {
                id: 'goup',
                title: 'Goto top',
                key: {
                    //84 Shift+T
                    keyCode: 84,
                    shiftKey: true
                }
            },
            'godown': {
                id: 'godown',
                title: 'Goto bottom',
                key: {
                    //66 Shift+B
                    keyCode: 66,
                    shiftKey: true
                }
            }
        }
    },
    fitheight: {
        name: "Fit height",
        category: 'layout',
        options: {
            locked: false
        },
        shortcuts: {
            'fit': {
                id: 'fit',
                title: 'Fit height',
                key: {
                    //72 h
                    keyCode: 72
                }
            }
        }
    },
    closeentry: {
        name: "Close entry",
        category: 'action',
        shortcuts: {
            'close': {
                id: 'close',
                title: 'Close entry',
                key: {
                    //88 x
                    keyCode: 88
                }
            }
        }
    },
    openbackground: {
        name: "Open in background",
        category: 'action',
        shortcuts: {
            'openback': {
                id: 'openback',
                title: 'Open in background tab',
                key: {
                    shiftKey: true,
                    keyCode: 86
                }
            }
        }
    },
    translate: {
        name: "Translate",
        category: 'content',
        options: {
            lang: 'en',
            locked: false,
            include: false,
            filter: {
                xtype: 'crud'
            }
        },
        shortcuts: {
            'translate': {
                id: 'translate',
                title: 'Translate entry',
                key: {
                    //84 alt+T
                    keyCode: 84,
                    altKey: true
                }
            }
        }
    },
    limit: {
        name: "Limit",
        category: 'layout',
        options: {
            mini: 30,
            maxi: 200
        }
    },
	prefetch: {
        name: "Prefetch",
        category: 'layout',
        status: 'new',
        options: {
            first: 25,
			next: 15,
			list: 60
        }
    },
	nested: {
        name: "Nested folders",
        category: 'layout',
        status: 'new',
        options: {
            separator: ":"
        }
    },
    replacer: {
        name: "Replacer",
        category: 'content',
        status: 'updated',
        options: {
            intro: {
                xtype: 'p',
                label: true
            },
			cloud: true,
            items: {
                xtype: 'crud'
            }
        }
    },
   /* menu: {
     name: "Smart menu",
	 category: 'navigation',
     desc: "Smart menu to add extra capabilites on each entry"
    },*/
    aero: {
        name: "Google Aero Toolbar",
        category: 'theme'
    },
    /*antisocial: {
        name: "Antisocial",
        category: 'layout',
        status: 'new',
        options: {
            status: false
        }
    },*/
    /*hover: {
     name: "Hover selection"
     },*/
    info: {
        name: "SysInfo",
        link: true,
        options: {
            sysinfo: {
                xtype: 'html',
                label: true,
                value: '<div id="sysinfo"></div>'
            }
        }
    },
    extshortcuts: {
        name: "Shortcuts",
        link: true
    },
    pack: {
        name: "Packages",
        link: true
    },
    thanks: {
        name: "Thanks",
        link: true
    }
};
GRP.packages = {
    'none': {
        general: {
            secure: true,
			stats:true
        }
    },
	'mini': {
        general: {
            secure: true,
			stats:true
        },
		favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true
    },
    'ludoo': {
        general: {
            secure: true,
            counter: false,
			pageicon: true,
			stats:true
        },
        favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true,
        column: true,
        mark: true,
        jump: true,
        fitheight: true,
        closeentry: true,
        openbackground: true,
        replacer: {
			cloud:true
		},
        preview: {
            onicon: true,
            overlay: true
        },
        theme: {
            skin:'mytheme',
			externaltheme: 'gmail_coldshower'
        }
    },
    'full': {
        general: {
            secure: true,
            counter: false,
			pageicon: true,
			stats:true
        },
		theme: {
            skin: 'osxblack',
			stats:true
        },
        favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true,
        column: true,
        mark: true,
        jump: true,
        preview: true,
        colorful: true,
        filter: true,
        readbymouse: true,
        twitter: true,
        facebook: true,
        fitheight: true,
        closeentry: true,
        openbackground: true,
        aero: true,
        instapaper: true,
        readitlater: true,
        translate: true,
        replacer: true,
        limit: true
    }
};
GRP.skins = {
    none: {
        name: "None"
    },
    mytheme: {
        name: "My Theme <span class='updated'>Updated!</span>"
    },
    nativecompact: {
        name: "Native compact"
    },
    player: {
        name: "Player Theme"
    },
    osxblue: {
        name: "Mac OS X Snow Leopard - Blue"
    },
    osxblack: {
        name: "Mac OS X Snow Leopard - Black"
    },
    portal: {
        name: "Portal Theme"
    },
    helvetireader: {
        name: "Helvetireader Skin"
    },
    minimal: {
        name: "Minimalistic Skin"
    },
    optimized: {
        name: "Optimized Skin"
    },
    air: {
        name: "Air Skin"
    },
    aircomic: {
        name: "Air Skin Comic Sans"
    },
    black: {
        name: "Google Enhanced Black"
    },
    dark: {
        name: "Dark Skin"
    },
    darkgray: {
        name: "Dark Gray Skin"
    },
    calibri: {
        name: "Calibri Skin"
    },
	sublimelight: {
        name: "Sublime Reader Light",
		ref:'https://code.google.com/p/sublimereader/'
    },
	sublimedark: {
        name: "Sublime Reader Dark",
		ref:'https://code.google.com/p/sublimereader'
    },
	redesigned: {
        name: "Redesigned",
		ref:'http://www.globexdesigns.com/products/gr/'
    },
	webbizgeek: {
		name: "WebBizGeek Skin <span class='new'>New!</span>",
		pic: 'http://www.webbizgeek.com/wp-content/uploads/2010/07/Google-Reader-custom-skin1.jpg'
	},
    glassblackgold: {
        name: "Glass Black Gold Skin",
        /*
         url: 'http://userstyles.org/styles/userjs/26569/Google%20Reader%20-%20Glass%20BlackGold%20.user.js',
         */
        pic: 'http://userstyles.org/style_screenshots/26569_after.png',
        ref: 'http://userstyles.org/styles/26569',
        fix: '#chrome-view-links,#lhn-selectors .selected,#lhn-selectors .selected:hover{background-color: transparent !important;}',
        desc: 'userstyles.org'
    },
    simpleclean: {
        name: "Simple and Clean",
        url: 'http://userstyles.org/styles/userjs/17120/Google%20Reader%20simple%20and%20clean.user.js',
        pic: 'http://userstyles.org/style_screenshots/17120_after.gif',
        ref: 'http://userstyles.org/styles/17120',
        fix: '.entry-actions{height: auto!important;}',
        desc: 'userstyles.org'
    },
    peacockfeather: {
        name: "Peacock Feather",
        url: 'http://userstyles.org/styles/userjs/3014/Google%20Reader%20-%20peacock%20feather.user.js',
        pic: 'http://userstyles.org/style_screenshots/3014_after.gif',
        ref: 'http://userstyles.org/styles/3014',
        desc: 'userstyles.org',
        resize: true
    },
    myowngooglereader: {
        name: "My Own Google Reader",
        url: 'http://userstyles.org/styles/userjs/13384/My%20Own%20Google%20Reader.user.js',
        pic: 'http://userstyles.org/style_screenshots/13384_after.png',
        ref: 'http://userstyles.org/styles/13384',
        desc: 'userstyles.org',
        resize: true
    },
    compactcleantweaked: {
        name: "Compact, Clean & Tweaked",
        url: 'http://userstyles.org/styles/userjs/16117/Google%20Reader%20-%20Compact%2C%20Clean%20%26%20Tweaked.user.js',
        pic: 'http://userstyles.org/style_screenshots/16117_after.png',
        ref: 'http://userstyles.org/styles/16117',
        desc: 'userstyles.org'
    },
    /*
     '31d1remix':
     {
     name: "31d1 remix",
     url:'http://userstyles.org/styles/userjs/3519/Google%20Reader%20-%2031d1%20remix%20.user.js',
     pic:'http://userstyles.org/style_screenshots/3519_after.png',
     ref:'http://userstyles.org/styles/3519',
     desc: 'userstyles.org'
     },
     */
    absolutelycompact: {
        name: "Absolutely Compact",
        url: 'http://userstyles.org/styles/userjs/12691/Google%20Reader%20Absolutely%20Compact.user.js',
        pic: 'http://userstyles.org/style_screenshots/12691_after.png',
        ref: 'http://userstyles.org/styles/12691',
        desc: 'userstyles.org'
    },
    darkshinyblue: {
        name: "Dark Shiny Blue",
        url: 'http://userstyles.org/styles/userjs/8935/iGoogle%2FGoogle%20Dark%20Shiny%20Blue%2C%20transparency.user.js',
        pic: 'http://userstyles.org/style_screenshots/8935_after.jpeg',
        ref: 'http://userstyles.org/styles/8935',
        desc: 'userstyles.org'
    },
    persian: {
        name: "Optimized Persian",
        url: 'http://userstyles.org//styles/userjs/2375/Optimized%20Persian%20Google%20Reader%20.user.js',
        pic: 'http://userstyles.org/style_screenshots/2375_after.png',
        ref: 'http://userstyles.org/styles/2375',
        desc: 'userstyles.org'
    }
};
GRP.googleshortcuts = {
    'j': {
        text: 'item down : selects the next item in the list',
        key: {
            keyCode: 74
        }
    },
    'k': {
        text: 'item up : selects the previous item in the list',
        key: {
            keyCode: 75
        }
    },
    'space': {
        text: 'page down : moves the page down',
        key: {
            keyCode: 32
        }
    },
    'shift+space': {
        text: 'page up : moves the page up',
        key: {
            keyCode: 32,
            shiftKey: true
        }
    },
    'n': {
        text: 'scan down : in list view, selects the next item without opening it',
        key: {
            keyCode: 78
        }
    },
    'p': {
        text: 'scan up : in list view, selects the next item without opening it',
        key: {
            keyCode: 80
        }
    },
    'shift+n': {
        text: 'navigation down : selects the next subscription or folder in the navigation',
        key: {
            keyCode: 78,
            shiftKey: true
        }
    },
    'shift+p': {
        text: 'navigation up : selects the previous subscription or folder in the navigation',
        key: {
            keyCode: 80,
            shiftKey: true
        }
    },
    'shift+x': {
        text: 'navigation expand/collapse : expands or collapses a folder selected in the navigation',
        key: {
            keyCode: 88,
            shiftKey: true
        }
    },
    'o': {
        text: 'open/close item : in list view, expands or collapses the selected item',
        key: {
            keyCode: 79
        }
    },
    'enter': {
        text: 'open/close item : in list view, expands or collapses the selected item',
        key: {
            keyCode: 13
        }
    },
    'shift+o': {
        text: 'navigation open subscription : opens the subscription or folder currently selected in the navigation',
        key: {
            keyCode: 79,
            shiftKey: true
        }
    },
    '-': {
        text: 'zoom out : decreases the font size of the current item',
        key: {
            keyCode: 109
        }
    },
    '=': {
        text: 'zoom in : increases the font size of the current item',
        key: {
            keyCode: 187
        }
    },
    's': {
        text: 'toggle star : stars or un-stars the selected item',
        key: {
            keyCode: 83
        }
    },
    'shift+s': {
        text: 'toggle share : shares or un-shares the selected item',
        key: {
            keyCode: 83,
            shiftKey: true
        }
    },
    'shift+d': {
        text: 'share with note : shares the selected item with a note',
        key: {
            keyCode: 68,
            shiftKey: true
        }
    },
    'v': {
        text: 'view original : opens the original source for this article in a new window',
        key: {
            keyCode: 86
        }
    },
    't': {
        text: 'tag an item : opens the tagging field for the selected item',
        key: {
            keyCode: 84
        }
    },
    'm': {
        text: 'mark as read/unread : switches the read status of the selected item',
        key: {
            keyCode: 77
        }
    },
    'shift+a': {
        text: 'mark all as read : marks all items in the current view as read',
        key: {
            keyCode: 65,
            shiftKey: true
        }
    },
    'e': {
        text: 'email item : opens the email form to send an item to a friend',
        key: {
            keyCode: 69
        }
    },
    'g then h': {
        text: 'go to home : goes to the Google Reader homepage',
        key: {
            keyCode: 71
        }
    },
    'g then a': {
        text: 'go to all items : goes to the "All items" view',
        key: {
            keyCode: 71
        }
    },
    'g then s': {
        text: 'go to starred items : goes to the "Starred items" view',
        key: {
            keyCode: 71
        }
    },
    'g then shift-s': {
        text: 'go to shared items : goes to the "Your shared items" view',
        key: {
            keyCode: 71
        }
    },
    'g then u': {
        text: 'go to subscription : allows you to navigate to a subscription by entering the subscription name',
        key: {
            keyCode: 71
        }
    },
    'g then t': {
        text: 'go to tag : allows you to navigate to a tag by entering the tag name',
        key: {
            keyCode: 71
        }
    },
    'g then f': {
        text: 'go to friend : allows you to navigate to a friend\'s shared items by entering the friend\'s name',
        key: {
            keyCode: 71
        }
    },
    'g then shift-f': {
        text: 'go to all friends\' shared items : shows all of your friends\' shared items',
        key: {
            keyCode: 71
        }
    },
    'g then shift-t': {
        text: 'go to trends : goes to the "Trends" view',
        key: {
            keyCode: 71
        }
    },
    'g then d': {
        text: 'go to feed discovery : shows the recommendations page, or the browse page if there are no recommendations',
        key: {
            keyCode: 71
        }
    },
    'r': {
        text: 'refresh : refreshes the unread counts in the navigation',
        key: {
            keyCode: 82
        }
    },
    'u': {
        text: 'toggle full screen mode : hides or shows the list of subscriptions',
        key: {
            keyCode: 85
        }
    },
    '1': {
        text: 'expanded view : displays the subscription as expanded items',
        key: {
            keyCode: 49
        }
    },
    '2': {
        text: 'list view : displays the subscription as a list of headlines',
        key: {
            keyCode: 50
        }
    },
    '1 pad': {
        text: 'expanded view : displays the subscription as expanded items',
        key: {
            keyCode: 97
        }
    },
    '2 pad': {
        text: 'list view : displays the subscription as a list of headlines',
        key: {
            keyCode: 98
        }
    },
    '/': {
        text: 'search : moves your cursor to the search box',
        key: {
            keyCode: 111
        }
    },
    'a': {
        text: 'add a subscription : opens the "Add a subscription" box in the sidebar',
        key: {
            keyCode: 65
        }
    },
    '?': {
        text: 'keyboard shortcuts help : displays a quick guide to all of Reader\'s shortcuts',
        key: {
            keyCode: 219
        }
    }
};
mycore.env.prefix = "readerplus.";
//GreaseKit
//http://groups.google.com/group/greasekit-users/browse_thread/thread/d0ed6e8919bb6b42
if (typeof GM_getValue === "undefined") {
    GM_getValue = function(name, def, cb){
        //Move old nameing value to new prefixed place
        /*var value = mycore.storage.getItem(name, cb);
         if (value) {
         GM_setValue(PREFIX + name, value);
         mycore.storage.removeItem(name);//remove old
         }*/
        value = mycore.storage.getItem(name, def, cb);
        return value;
    };
}
if (typeof GM_getCookieValue === "undefined") {
    GM_getCookieValue = function(name, def){
        var value;
        var nameEQ = escape(name) + "=", ca = document.cookie.split(';');
        for (var i = 0, c; i < ca.length; i++) {
            c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1, c.length);
            }
            if (c.indexOf(nameEQ) === 0) {
                value = unescape(c.substring(nameEQ.length, c.length));
                break;
            }
        }
        if (value === null && def !== null) {
            value = def;
        }
        return value;
    };
}
if (typeof GM_setValue === "undefined") {
    GM_setValue = function(name, value, cb){
        try {
            mycore.storage.setItem(name, value, cb);
        } catch (e) {
            console.log('error on GM_setValue[' + n + ']=' + value);
        }
    };
}
if (typeof GM_setCookieValue === "undefined") {
    GM_setCookieValue = function(name, value, options){
        options = (options || {});
        if (options.expiresInOneYear) {
            var today = new Date();
            today.setFullYear(today.getFullYear() + 1, today.getMonth, today.getDay());
            options.expires = today;
        }
        var curCookie = escape(name) +
        "=" +
        escape(value) +
        ((options.expires) ? "; expires=" +
        options.expires.toGMTString() : "") +
        ((options.path) ? "; path=" + options.path : "") +
        ((options.domain) ? "; domain=" + options.domain : "") +
        ((options.secure) ? "; secure" : "");
        document.cookie = curCookie;
    };
}
function clearcache(lang){
    var name, v;
    for (var i = 0; i <= mycore.storage.getLength() - 1; i++) {
        name = mycore.storage.key(i);
        if ((/^readerplus\.theme_/.test(name)) || (/^readerplus\.rps_/.test(name)) || (/^readerplus\.cache/.test(name))) {
            mycore.storage.removeItem(name);
        }
    }
    alert(getTextPrefs(lang, 'global', 'cachecleared', 'en', "Cache cleared"));
}

function openWindow(o, cb){
    sendMessage("window", o, cb);
}

function sendMessage(message, o, callback){
    var a = clone(o) || {};
    a.message = message;
    var fns = ['onload', 'onreadystatechange', 'onerror'];
    for (var i = 0, len = fns.length; i < len; i++) {
        if (o[fns[i]]) {
            a[fns[i]] = true;
        }
    }
    mycore.extension.sendRequest(a, callback);
}


if (typeof GM_xmlhttpRequest === "undefined") {
    GM_xmlhttpRequest = function(o){
        o.method = (o.method) ? o.method.toUpperCase() : "GET";
        if (!o.url) {
            throw ("GM_xmlhttpRequest requires an URL.");
        }
        
        var om = o;
        sendMessage("request", om, function(a){
            if (a.message === (om.callback || "requestdone")) {
                if (a.action === "load") {
                    if (typeof om.onload == "function") {
                        om.onload(a, a.request);
                    }
                } else if (a.action === "readystatechange") {
                    if (typeof om.onreadystatechange == "function") {
                        om.onreadystatechange(a, a.request);
                    }
                } else if (a.action === "error") {
                    GM_log('error: ' + a.responseText);
                    if (typeof om.onerror == "function") {
                        om.onerror(a, a.request);
                    }
                }
            }
        });
        
    };
}
if (typeof GM_addStyle === "undefined") {
    function GM_addStyle(/* String */styles, id){
        var el;
        if (id) {
            el = document.getElementById(id);
        }
        if (!el) {
            el = document.createElement("style");
            el.setAttribute("type", "text\/css");
            if (id) {
                el.id = id;
            }
            el.appendChild(document.createTextNode(styles));
            document.getElementsByTagName("head")[0].appendChild(el);
        } else {
            //update
            el.innerText = styles;//textContent??
        }
        return el;
    }
}
if (typeof GM_addCss === "undefined") {
    function GM_addCss(css, id){
        var el = document.createElement("link");
        el.setAttribute("rel", "stylesheet");
        el.setAttribute("type", "text\/css");
        el.setAttribute("href", css);
        if (id) {
            el.id = id;
        }
        document.getElementsByTagName("head")[0].appendChild(el);
    }
}
if (typeof GM_addScript === "undefined") {
    function GM_addScript(script, remote, cb, cbonerror, scope, time){
        //var id = script.replace(/[\.:-_\/\\]/g, '');
        var id = script;
        var s = document.getElementById(id);
        if (s) {
            if (cbonerror && cb) {
                cb.call(this);
            }
        } else {
            if (remote) {
                GM_xmlhttpRequest({
                    method: 'get',
                    url: script,
                    onload: function(r){
                        if (remote === 'inline') {
                            GM_addjs(script, true, id, cb, scope, time);
                        } else {
                            eval(r.responseText);
                            if (cb) {
                                cb.call(scope || this);
                            }
                        }
                    },
                    onerror: function(r){
                        if (cbonerror && cb) {
                            cb.call(scope || this);
                        }
                        console.error('Error on loading Javascript ' + script);
                    }
                });
            } else {
                GM_addjs(script, false, id, cb, scope, time);
            }
        }
    }
    function GM_addjs(script, inline, id, cb, scope, time){
        var el = document.createElement("script");
        el.setAttribute("type", "text\/javascript");
        if (inline) {
            el.innerText = script;
        } else {
            el.setAttribute("src", script);
        }
        if (id) {
            el.setAttribute("id", id);
        }
        document.getElementsByTagName("head")[0].appendChild(el);
        if (cb) {
            window.setTimeout(function(){
                cb.call(scope || this);
            }, time || 500);
        }
    }
    /**
     * Pack for GM_addScript + check + callback
     * @param {Object} script
     * @param {Object} remote
     * @param {Object} check
     * @param {Object} cb
     * @param {Object} scope
     */
    function GM_loadScript(script, remote, check, cb, scope){
        function cbwait(){
            waitlib(check, cb, scope);
        }
        function cbonerror(){
            if (cb) {
                cb.call(scope || this);
            }
        }
        GM_addScript(script, remote, cbwait, cbonerror, scope);
    }
}
if (typeof GM_log === "undefined") {
    function GM_log(log){
        console.log(log);
    }
}
if (typeof GM_registerMenuCommand === "undefined") {
    function GM_registerMenuCommand(a, b){
        //
    }
}
if (typeof GM_openInTab === "undefined") {
    GM_openInTab = function(url, selected, search, index, windowId){
        //send request port to bg
        if (typeof selected == "undefined") {
            selected = true;
        }
        var data = {
            message: 'opentab',
            url: url,
            search: search || url,
            selected: selected,
            index: index,
            windowId: windowId
        };
        mycore.extension.sendRequest(data);
    };
}
if (typeof unsafeWindow === "undefined") {
    unsafeWindow = window;
}
if (typeof(this['clone']) !== 'function') {
    clone = function(o){
        try {
            return eval(uneval(o));
        } catch (e) {
            throw (e);
        }
    };
}
/**
 * uneval for prefetch !!
 */
if (typeof(this['uneval']) !== 'function') {
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var protos = [];
    var char2esc = {
        '\t': 't',
        '\n': 'n',
        '\v': 'v',
        '\f': 'f',
        '\r': '\r',
        '\'': '\'',
        '\"': '\"',
        '\\': '\\'
    };
    var escapeChar = function(c){
        if (c in char2esc) 
            return '\\' + char2esc[c];
        var ord = c.charCodeAt(0);
        return ord < 0x20 ? '\\x0' + ord.toString(16) : ord < 0x7F ? '\\' + c : ord < 0x100 ? '\\x' + ord.toString(16) : ord < 0x1000 ? '\\u0' + ord.toString(16) : '\\u' + ord.toString(16);
    };
    var uneval_asis = function(o){
        return o.toString();
    };
    /* predefine objects where typeof(o) != 'object' */
    var name2uneval = {
        'boolean': uneval_asis,
        'number': uneval_asis,
        'string': function(o){
            return '\'' +
            o.toString().replace(/[\x00-\x1F\'\"\\\u007F-\uFFFF]/g, escapeChar) +
            '\'';
        },
        'undefined': function(o){
            return 'undefined';
        },
        'function': uneval_asis
    };
    var uneval_default = function(o, np){
        var src = []; // a-ha!
        for (var p in o) {
            if (!hasOwnProperty.call(o, p)) 
                continue;
            src[src.length] = uneval(p) + ':' + uneval(o[p], 1);
        }
        // parens needed to make eval() happy
        return np ? '{' + src.toString() + '}' : '({' + src.toString() + '})';
    };
    uneval_set = function(proto, name, func){
        protos[protos.length] = [proto, name];
        name2uneval[name] = func || uneval_default;
    };
    uneval_set(Array, 'array', function(o){
        var src = [];
        for (var i = 0, l = o.length; i < l; i++) 
            src[i] = uneval(o[i]);
        return '[' + src.toString() + ']';
    });
    uneval_set(RegExp, 'regexp', uneval_asis);
    uneval_set(Date, 'date', function(o){
        return '(new Date(' + o.valueOf() + '))';
    });
    var typeName = function(o){
        // if (o === null) return 'null';
        var t = typeof o;
        if (t != 'object') 
            return t;
        // we have to lenear-search. sigh.
        for (var i = 0, l = protos.length; i < l; i++) {
            if (o instanceof protos[i][0]) 
                return protos[i][1];
        }
        return 'object';
    };
    uneval = function(o, np){
        // if (o.toSource) return o.toSource();
        if (o === null) 
            return 'null';
        var func = name2uneval[typeName(o)] || uneval_default;
        return func(o, np);
    };
}
GRP.api_rest = function(name, local){
    //http://wedata.net/help/api
    var SL = {
		error:'Error $status on sending data using REST'
	};
    var config = {
        base: 'http://wedata.net',
        successCodes: {201:true, 200:true},
		api_key:'4b64b4cd064456a86a'+'847907fb6707c89ff560e5',
        errors: {
            201: 'Created - Database or item was created successfully.',
            200: ' OK - No error.',
            403: 'Forbidden - The API key is wrong or you are editing a database that was created by other user.',
            400: 'Bad Request - Request parameter is invalid.'
        },
        all: {
            getall:'/databases',
			get: '/databases/'+name+'.json',
            create: '/databases',
			update: '/databases/'+name,
			remove:'/databases/'+name
        },
		item: {
            getall:'/databases/'+name+'/items.json',
			get: '/items/:id.json',
            create: '/databases/'+name+'/items',
			update: '/items/:id',
			remove:'/items/:id'
        }
    }
    
    function send(method, url, params, cb){
		function response(xhr){
			if (config.successCodes[xhr.status]) {
				if (cb) {
					var o = JSON.parse(xhr.responseText);
					cb(o, true);
				}
			} else {
				console.error((SL[xhr.status]||config.errors[xhr.status]||SL.error).replace('$status', xhr.status||''));
			}
		}
		var o = {
			method: method,
			url: config.base + url,
			data: params,
			headers:{
				"Content-Type": "application/x-www-form-urlencoded"
			},
			onload: function(xhr){
				if (xhr.readyState == 4) {
					response(xhr);
				}
			},
			onerror: function(xhr){
				if (cb) {
					cb(xhr, false);
				}
			}
		};
		if (local) {
			request(o, true, response);
		} else {
			GM_xmlhttpRequest(o);
		}
    }
    
    return ({
        all: {
            getAll: function(o /* page */, success, error){
                var url = config.all.getall;
				o=o||{};
                var params = {
                    page: o.page||1
                };
                send('get', url, params, success, error);
            },
			get: function(o /* name, page */, success, error){
                var url = config.all.get;
                var params = {
                    page: o.page
                };
                send('get', url, params, success, error);
            },
            create: function(o /* api_key name,description, required_keys,optional_keys, permit_other_keys */, success, error){
                var url = config.all.create;
                var params = {
                    api_key: o.api_key||config.api_key,
                    database: {
                        name: o.name,
                        description: o.description,
                        required_keys: o.required_keys,
                        optional_keys: o.optional_keys,
                        permit_other_keys: o.permit_other_keys
                    }
                };
				send('post', url, params, success, error);
            },
            update: function(o /* api_key name,description, required_keys,optional_keys, permit_other_keys*/, success, error){
                var url = config.all.update;
                var params = {
                    api_key: o.api_key||config.api_key,
                    database: {
                        name: o.name,
                        description: o.description,
                        required_keys: o.required_keys,
                        optional_keys: o.optional_keys,
                        permit_other_keys: o.permit_other_keys
                    }
                };
				send('put', url, params, success, error);
            },
            remove: function(o/* api_key, name */, success, error){
             	//Remove DB
				var url = config.all.remove;
                var params = {
                    api_key: o.api_key||config.api_key
                };
                send('delete', url, params, success, error);
            }
        },
        item: {
            getAll: function(o /* name, page */, success, error){
                var url = config.item.getall;
                var params = {
                    page: o.page
                };
                send('get', url, params, success, error);
            },
			get: function(o /* name, page, id */, success, error){
                var url = config.item.get.replace(':id', o.id);
                var params = {
                    page: o.page
                };
                send('get', url, params, success, error);
            },
            create: function(o /* name, api_key, name, values */, success, error){
                var url = config.item.create;
                var params = {
                    api_key: o.api_key||config.api_key,
					name: o.name,
                    data: o.values /* [] key/value */
                };
				send('post', url, params, success, error);
            },
            update: function(o /*  api_key, id, data */, success, error){
                var url = config.item.update.replace(':id', o.id);
                var params = {
                    api_key: o.api_key||config.api_key,
                    data: o.values /* [] key/value */
                };
				send('put', url, params, success, error);
            },
			createOrUpdate: function(ci, o , success, error){
                if (ci){
					//object already exist
					if (ci.name !== o.name || !compareObject(ci.values, o.values)){
						o.id = getIdFromResourceUrl(ci);
						console.log('objects different-> update '+o.name + ' '+o.id);
						this.update(o);
					}
				}else{
					this.create(o);
				}
            },
            remove: function(o/* api_key, id */, success, error){
             	var url = config.item.get.replace(':id', o.id);
                var params = {
                    api_key: o.api_key||config.api_key
                };
                send('delete', url, params, success, error);
            },
			removeAll: function(o/* api_key */, success, error){
             	var me = this;
				o=o||{};
				this.getAll(o,function(items){
					foreach(items,function(item){
						var id = getIdFromResourceUrl(item);
						if (id) {
							me.remove({
								id: id,
								api_key: o.api_key || config.api_key
							});
						}
					});
					if (success) {
						success(true);
					}
				},error);
            }
        }
    });
}


function getIdFromResourceUrl(o){
	return (o.resource_url)?(o.resource_url.replace(/^.*\/items\//, '')):false;
}

function compareObject(a,b){
	var eq=true;
	iterate(a, function(i,o){
		if (typeof o !=='undefined' && o!==b[i]){
			eq = false;
			//exit
		}
	});
	return eq;
}
var cloudItems={};
function setFavicon(title, icon, url, FAVICON){
    if (FAVICON) {
        var key = ellipsis(title);
        FAVICON[key] = {
            icon: icon,
            url: url,
            title: title
        };
    }
}

/**
 * Extract sites list from google reader xml
 */
function loadIcons(a, cb){
    var FAVICON_TPL_URL = a.FAVICON_TPL_URL;
    var prefs = getPrefs();
    request({
        url: a.url,
        onload: function(xhr){
            var xml = xhr.responseXML;
            var FAVICON = parseXml(xml, FAVICON_TPL_URL);
            
            var prefs = getPrefs();
            //Load wedata cloud data
			if (prefs.favicons_cloud) {
                var r = new GRP.api_rest('Favicons', true);
                r.item.getAll({}, function(items, success){
                    if (success) {
                        cloudItems={};
						foreach(items, function(item){
                            setFavicon(item.data.title, item.data.icon, item.data.url, FAVICON);
							cloudItems[item.data.url]=item;
                        });
                    }
                    sendResponse({
                        message: "iconsloaded",
                        FAVICON: FAVICON
                    }, cb);
                });
            } else {
                sendResponse({
                    message: "iconsloaded",
                    FAVICON: FAVICON
                }, cb);
            }
        }
    }, true);
}

function extractFavicon(a, cb){
    var xhr = new XMLHttpRequest();
    var url, title, key = a.key, FAVICON = a.FAVICON;
    if (!key) {
        //url+title
        key = ellipsis(title);
        url = a.url;
        title = a.title;
    } else {
        //key only
        var f = FAVICON[key];
        url = f.url;
        title = f.title;
    }
    xhr.open(a.method || 'get', normalizeUrl(url), true);
    xhr.onload = function(o){
        var xhr = o.target;
        if (xhr) {
            var html = xhr.responseText; //responseBody
            var icon = parseFavicon(html, url);
            if (icon) {
                setFavicon(title, icon, url, FAVICON);
                saveFavicon(url, icon, title);
            }
            sendResponse({
                message: "iconget",
                title: title,
                icon: icon,
                url: url,
                FAVICON: FAVICON
            }, cb);
        }
    };
    xhr.send({});
}

/**
 * Save just one icon on get Favicon menu
 */
function saveFavicon(url, icon, title){
    var prefs = getPrefs();
    prefs.favicons_domains[url] = icon;
    setPrefs(prefs);
    
    //send to remote db
    var r = new GRP.api_rest('Favicons', true);	
    var name = getNameFromUrl(url);
	
	//Check if already exist
	var ci = cloudItems[url];
	r.item.createOrUpdate(ci, {
				name: name,
				values: {
					url: url,
					icon: icon,
					title: title
				}
			});
}

function getNameFromUrl(url){
	return url.replace(/^http:\/\//, '').replace(/\/$/, '');
}

function parseFavicon(html, url){
    var icon, link;
    var relink = /<LINK[^>]*?REL=["'](SHORTCUT\W+)?ICON["'][^>]*?>/i;
    var rehref = /href=["'](.*?)["']/i;
    var m = relink.exec(html);
    if (m) {
        link = m[0];
        m = rehref.exec(link);
        if (m) {
            icon = m[1];
        }
    }
    if (!icon) {
        icon = cleanUrl(url) + "/favicon.ico";
    } else {
        //Add domain if relative url
        var re = new RegExp("^http:", "i");
        if (!re.test(icon)) {
            icon = url + '/' + icon;
        }
    }
    icon = normalizeUrl(icon);
    return icon;
}


function checkIconDomains(prefs){
    //Check domains
    if (!prefs.favicons_domains) {
        prefs.favicons_domains = {};
    }
    if (typeof prefs.favicons_domains == "string") {
        var favicons = {};
        var sites = prefs.favicons_domains.split(',');
        for (var j = 0, ln = sites.length; i < ln; i++) {
            var site = sites[j];
            if (site && site != 'null') {
                favicons[site] = '';
            }
        }
        prefs.favicons_domains = favicons;
    }
}


function parseXml(xml, FAVICON_TPL_URL){
    var prefs = getPrefs();
    var domains = prefs.favicons_domains;
    var FAVICON = {};
    var manual = mycore.storage.getItem("favicons_manual");
    Array.forEach(xml.getElementsByTagName('outline'), function(outline){
        if (!outline.hasAttribute('htmlUrl')) {
            return;
        }
        var title = outline.getAttribute('title');
        var url = outline.getAttribute('htmlUrl');
        var favicon;
        var domain = url.split(/\/|\?/)[2];
        var icon = FAVICON_TPL_URL + domain;
        setFavicon(title, icon, url, FAVICON);
        
        /*
         var icond = domains[url];//domains store site->faviconUrl
         var manualDomain = (typeof icond !== "undefined");
         if (manualDomain){
         icon=icond;
         }
         //manualmode + (empty or null or not defined)
         //or EXCEPTION + empty (autofill)
         if ((manual && !icon) || (!manual && manualDomain && icon==='')) {
         extractFavicon(
         {
         url: url,
         title: title,
         FAVICON: FAVICON
         });
         }else{
         setFavicon(title, icon, url, FAVICON);
         }
         */
    });
    
    //upload parsing results
    //createWorkerIcons(FAVICON);
    
    return FAVICON;
}
/*
function createWorkerIcons(icons){
    createWorker({
        url: "worker/wfavicons.js",
        data: {
            icons: icons
        },
		job: function(worker){
			console.log('Job here');
		},
        onmessage: function(data, e){
        	console.log('onmessage here');
        },
        onerror: function(data, e){
            console.error('Error on worker favicon ' + data);
        }
    });
}
*/

function getValue(a, cb){
	var prefs = readPrefs(a);
	var value = prefs[a.name];
	if (isFunction(cb)){
		cb(prefs[a.name]);
	}
}
function setValue(a, cb){
	var prefs = readPrefs(a);
	prefs[a.name]=a.value;
	savePrefs(prefs);
	if (isFunction(cb)) {
		cb(prefs[a.name]);
	}
}
function removeValue(a, cb){
	var prefs = readPrefs(a);
	delete prefs[a.name];
	savePrefs(prefs);
	if (isFunction(cb)) {
		cb(true);
	}
}

function savePrefs(prefs){
    mycore.storage.setItem('grp_prefs', prefs);
}
function setPrefs(prefs, cleanall){
    savePrefs(prefs);
    if (cleanall) {
        mycore.storage.setItem('grp_favicons', '');
    }
    runOnSave(prefs);
}

function setPreferences(a){
    mycore.storage.clear();
    mycore.storage.setItem('grp_version', GRP.VERSION);
    setPrefs(a.prefs, a.cleanall);
}

function readPrefs(prefs){
    return mycore.storage.getItem('grp_prefs');
}

function getPrefs(a, ignoreCheck){
    var prefs = readPrefs();
    prefs = checkPrefs(prefs);
    return prefs;
}

function getPreferences(a, cb){
    initVersion();
    var prefs = getPrefs();
    if (cb) {
        cb.call(this, {
            message: "prefs",
            prefs: prefs
        });
    } else {
        sendResponse({
            message: "prefs",
            prefs: prefs
        }, cb);
    }
    return prefs;
}

function checkPrefs(prefs){
    prefs = prefs || {};
    //set default if not
    iterate(GRP.scripts, function(id, script){
        //options
        iterate(script.options, function(option, o){
            if (!(o && typeof o === 'object' && o.label)) {
                id = script.id + '_' + option;
                if (typeof prefs[id] === "undefined") {
                    prefs[id] = getTypedValue(o);
                }
            }
        });
        //shortcuts
        iterate(script.shortcuts, function(shortcut, o){
            id = script.id + '_key_' + shortcut;
            if (typeof prefs[id] === "undefined") {
                prefs[id] = o;
            }
        });
    }, this, true);
    checkIconDomains(prefs);
    return prefs;
}
function request(a, local, cb){
    if (a.injected) {
		/*chrome.tabs.getSelected(null, function(tab){
            chrome.tabs.executeScript(tab.id, {
                code: getInjectedXhrCode(a)
            });
        });*/
		//GM_addjs(getInjectedXhrCode(a), true, '_grp_xhr');
    } else {
		bg_request(a, local, cb);
    }
}
function getInjectedXhrCode(o){
	var p = null;
	if (o.method.toLowerCase() === 'post') {
		p = '"'+serializePost(o.parameters)+'"';
	}
	var code =  'var xhr = new XMLHttpRequest();\n'+
	'xhr.open("'+o.method+'", "'+o.url+'", true);\n'+
	'xhr.onload=function(x){\n'+
	'  var xhr=x.target;\n'+
	'  console.log(xhr.status);\n'+
	'};\n'+
	'xhr.onerror=function(x){\n'+
	'  console.log(x.target);\n'+
	'};\n'+
	'xhr.send('+p+');\n';
	
	return "(function(){\n" + code +"\n}());\n";
}

function bg_request(a, local, cb){
    var xhr = new XMLHttpRequest();
    var method = a.method || 'get';
    method = method.toLowerCase();
    var url = a.url;
    if (a.parameters && (method === 'get')) {
        var params = [];
        for (var k in a.parameters) {
            params.push(k + '=' + encodeURIComponent(a.parameters[k]));
        }
        var sep = (url.indexOf('?') > 0) ? '&' : '?';
        url += sep + params.join('&');
    }
    xhr.open(method, url, true);
    //headers
    if (a.headers) {
        for (var kh in a.headers) {
            xhr.setRequestHeader(kh, a.headers[kh]);
        }
    }
    //a['onload']=true;//force onload
    var fns = ['readystatechange', 'error', 'load'];
    var xpath = a.xpath;
    for (var i = 0, len = fns.length; i < len; i++) {
        var name = fns[i];
        if (a['on' + name]) {
            var f = '' + name;
            xhr['on' + f] = function(o){
                var xhr = o.target;
                if (xhr) {
                    if (local && typeof a['on' + f] === "function") {
                        var res = enhanceResponse(a, xhr);
                        a['on' + f].call(this, res);
                    } else {
                        var res = {
                            message: a.callback || "requestdone",
                            action: f,
                            responseXML: null, //xhr.responseXML,
                            responseText: xhr.responseText,
                            responseHeaders: xhr.responseHeaders,
                            status: xhr.status,
                            statusText: xhr.statusText,
                            request: a
                        };
                        res = enhanceResponse(a, res);
                        sendResponse(res, cb);
                    }
                }
            };
        }
    }
    try {
        var typesSend = {
            post: true,
            put: true,
            'delete': true
        };
        var d = typesSend[method] ? a.data : null;
        if (d && typeof d !== 'string') {
            d = serializePost(d);
        }
        xhr.send(d);
    } catch (e) {
        console.log('Error catched on xhr');
        var o = {
            message: a.callback || "requestdone",
            responseText: e.message || 'Error',
            status: (e.name || '') + ' ' + (e.code || 0),
            statusText: (e.name || '') + ' ' + (e.code || 0),
            action: 'error',
            error: e
        };
        if (local && typeof a.onerror === "function") {
            a.onerror.call(this, o);
        } else {
            sendResponse(o, cb);
        }
    }
    
}

function enhanceResponse(a, res){
    if (a.dataType === 'json' && res.responseText) {
        try {
            res.responseJson = JSON.parse(res.responseText);
        } catch (e) {
        }
    }
    if (a.xpath && xhr.responseXML) {
        res.xml = serializeXml(getElements(a.xpath, xhr.responseXML));
    }
    return res;
}

function sendResponse(a, cb){
    if (cb) {
        cb(a);
    } else {
        //myport.postMessage(a);
    }
}

function sendNull(cb){
    if (cb) {
        cb({});
    }
}


//Try to find opened tab before open it
function open_tab(a){
    if (a.search) {
        var o = {
            search: new RegExp(a.search.replace(/^https?/, 'https?').replace(/#.*$/, '')),
            url: a.url
        };
        selecttab(o, a.selected, a.create || true, a.fn);
    } else {
        opentab(a);
    }
}


function selecttab(a, selected, create, fn){
    findtab(a, function(tab){
        if (tab) {
            if (selected) {
                mycore.tabs.update(tab.id, {
                    url: a.url,
                    selected: true
                }, function(tab){
                    mycore.tabs.executeScript(tab.id, 'hashchange();');
                });
            }
        } else {
            if (create) {
                a.selected = selected;
                opentab(a);
            }
        }
        if (fn && typeof fn === "function") {
            fn.call(this, tab);
        }
    });
}

function findtab(a, fn){
    mycore.windows.getAll({
        populate: true
    }, function(windows){
        var tab = false, found = false;
        for (var i = 0, len = windows.length; i < len; i++) {
            var window = windows[i];
            for (var j = 0, jlen = window.tabs.length; j < jlen; j++) {
                tab = window.tabs[j];
                var check = false;
                if (a.search && a.search.test) {
                    check = (a.search.test(tab.url));
                } else {
                    check = (tab.url.indexOf(a.search) >= 0);
                }
                if (check) {
                    found = true;
                    fn.call(this, tab);
                    break;
                }
            }
        }
        if (!found) {
            fn.call(this, false);
        }
    });
}

function opentab(a){
    mycore.tabs.getSelected(null, function(tab){
        var o = {
            url: a.url,
            selected: (a.selected || typeof a.selected === "undefined"),
            windowId: a.windowId,
            index: a.index || (tab.index + 1)
        };
        mycore.tabs.create(o);
    });
}

function openNewPage(a, id){
    chrome.tabs.getSelected(null, function(tab){
        var oldUrl = tab.url;
        var blankUrl = chrome.extension.getURL('blank.html');
        blankUrl += '#' + id;
        chrome.tabs.create({
            url: blankUrl,
            index: tab.index + 1
        }, function(tab){
            var tabs = chrome.extension.getExtensionTabs();
            for (var i = 0; i < tabs.length; i++) {
                var tab = tabs[i];
                if (tab.location.href == blankUrl && !tab.dataAlreadySet) {
                    tab.printSource(a);
                    tab.dataAlreadySet = true;
                    break;
                }
            }
        });
    });
}

var lastTabReader = false;
function monitorCloseTab(){
    //Check if greader were closed
    mycore.tabs.onRemoved.addListener(function(tabId){
        if (lastTabReader && tabId == lastTabReader.id) {
            lastTabReader = false;
        }
    });
}
//var READING_LIST_RE_ = new RegExp('user/[\\d]+/state/com\\.google/reading-list');
var reReader = {
    reading: /user\/[\d]+\/state\/com\.google\/reading\-list/,
    search: /https?\:\/\/www.google.com\/reader\/view\//,
    url: 'http://www.google.com/reader/view/'
};
mycore.env.background = true;
mycore.extension.onRequest.addListener(onMessageReceived);
mycore.extension.onRequestExternal.addListener(function(request, sender, sendResponse){
    if (request.keypass === "##ReaderPlusIcon") {
        console.log('CORE onRequestExternal id=' + sender.id + ' ' + request.message);
        onMessageReceived(request, false, sendResponse);
        //GUID_ICON = sender.id;
    }
});

function activePageAction(mprefs){
    //Selective tab for page icon
    chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
        if (reReader.search.test(tab.url)) {
            var prefs = mprefs || getPrefs();
            var active = (prefs && prefs.general_pageicon);
            if (active) {
                chrome.pageAction.show(tabId);
                chrome.pageAction.setPopup({
                    tabId: tabId,
                    popup: 'menu.html'
                });
                /*chrome.pageAction.onClicked.addListener(function(tab){ });*/
            } else {
                chrome.pageAction.hide(tabId);
            }
        }
    });
}

function runOnSave(mprefs){
    var prefs = mprefs || getPrefs();
    var rc = prefs._replacer_changed;
    delete prefs._replacer_changed;
    monitorIcon(prefs);
    sendPrefsToIcon(prefs);
    activePageAction(prefs);
    //sure we changed replacer items and click save
    if (mprefs && rc) {
        sendReplacerToCloud(prefs);
    }
}

runOnSave();

//request, sender, callback
function onMessageReceived(a, p, cb){
    if (a.message == "track") {
        track(a);
    } else if (a.message == "loadicons") {
        loadIcons(a, cb);
    } else if (a.message == "setprefs") {
        setPreferences(a);
        sendNull(cb);
    } else if (a.message == "get") {
        getValue(a, cb);
    } else if (a.message == "set") {
        setValue(a, cb);
    } else if (a.message == "remove") {
        removeValue(a, cb);
    } else if (a.message == "getprefs") {
        getPreferences(a, cb);
    } else if (a.message == "openprefs") {
        opentab({
            url: "preferences.html"
        });
        sendNull(cb);
    } else if (a.message == "opentab") {
        open_tab(a);
        sendNull(cb);
    } else if (a.message == "findreader") {
        findreader(true, true);
        sendNull(cb);
    } else if (a.message == "geticon") {
        extractFavicon(a, cb);
    } else if (a.message == "iconcounter") {
        monitorIcon();
    } else if (a.message == "request") {
        request(a, false, cb);
    } else if (a.message == "window") {
        openwindow(a, cb);
    } else if (a.message == "igtheme") {
        igtheme(a, cb);
    } else if (a.message == "translate") {
        translate(a, cb);
    } else if (a.message == "clouddata") {
        getCloudData(a, cb);
    } else if (a.message == "exported") {
        exportitems(a);
    }
}

function exportitems(a){
    openNewPage(a, 'export');
}

var mappers = {
    def: function(item){
        return {
            name: item.name,
            resource_url: item.resource_url,
            values: item.data
        };
    }
    /*Replacer: function(item){
     return {
     name: item.name,
     resource_url: item.resource_url,
     title: item.name,
     url: item.data.url,
     search: item.data.xpath,
     replace: item.data.replace
     };
     },
     LDRFullFeed: function(item){
     return {
     name: item.name,
     resource_url: item.resource_url,
     values: {
     title: item.name,
     url: item.data.url,
     search: 'xpath:' + item.data.xpath,
     replace: "$1"
     }
     };
     }*/
};

function getCloudData(a, cb, mapper){
    request({
        url: a.url || ('http://wedata.net/databases/' + a.name + '/items.json'),
        onload: function(xhr){
            if (xhr.status == 200) {
                console.log(a.name + ' get');
                var items = JSON.parse(xhr.responseText);
                //cache value
                var i = 0, selectors = {};
                var f = mappers[a.name] || mappers.def;
                foreach(items, function(item){
                    selectors[item.name] = f(item);
                    i++;
                });
                //store it now as cache (needs timestamp)
                mycore.storage.setItem('grp_cloud_' + a.name, selectors);
                console.log('Store Cloud DB ' + a.name + ' : ' + i + ' items');
                sendResponse(selectors, cb);
            }
        },
        onerror: function(){
            var selectors = mycore.storage.getItem('grp_cloud_' + a.name, false);
            sendResponse(selectors, cb);
        }
    }, true);
}

function sendReplacerToCloud(prefs){
    console.log('sendReplacerToCloud items...');
    var r = new GRP.api_rest('Replacer', true);
    var cloud_items = false; //mycore.storage.getItem('grp_cloud_Replacer');
    //r.item.remove_All();
    if (!cloud_items) {
        getCloudData({
            name: 'Replacer'
        }, function(items){
            sendReplacerToCloud2(r, prefs, items);
        });
    } else {
        sendReplacerToCloud2(r, prefs, cloud_items);
    }
}

function sendReplacerToCloud2(r, prefs, cloud_items){
    iterate(prefs.replacer_items, function(id, o){
        var ci = false;
        if (cloud_items) {
            ci = cloud_items[id];
        }
        r.item.createOrUpdate(ci, {
            name: id,
            values: o
        });
    });
}


/**
 * Icon monitor for unreead count
 */
var monitorId;
function monitorIcon(mprefs){
    var prefs = mprefs || getPrefs();
    if (monitorId) {
        window.clearInterval(monitorId);
    }
	var t = 2000;
	if (prefs && prefs.general_counterinterval) {
		t = prefs.general_counterinterval * 1000;
	}
    if (prefs && prefs.general_counter) {
		getUnreadCount();
        //TODO: ensure not used
        monitorId = window.setInterval(function(){
            getUnreadCount();
            /*function(status){
             //stop on error
             if (status===false){
             if (monitorId) {
             window.clearInterval(monitorId);
             }
             }
             });*/
        }, t);
    }
}

function sendPrefsToIcon(mprefs){
    var prefs = mprefs || getPrefs();
    var iconprefs = {
        opendirect: prefs.general_opendirect || false
    };
    call_icon('prefs', {
        prefs: iconprefs
    }, function(){
        //
    });
}

var lastText, lastLogged;
function updateIcon(logged, text){
    var refresh = ((!lastLogged || logged !== lastLogged) && (!lastText || text !== lastText));
    refresh = true;
    if (refresh) {
        var a = {
            logged: logged,
            text: text
        };
        call_icon('updateicon', a);
        lastLogged = logged;
        lastText = text;
    }
}


monitorCloseTab();

function getUnreadCount(cb){
    if (lastTabReader) {
        updateFromTabtitle(lastTabReader);
    } else {
        findreader(false, false, function(tab){
            if (tab) {
                lastTabReader = tab;
                //From tab title
                updateFromTabtitle(tab);
            } else {
                //from xhr (1000+ limitations)
                request({
                    url: 'http://www.google.com/reader/api/0/unread-count?output=json&client=readerplus&refresh=true',
                    onload: function(xhr){
                        if (xhr.status == 200) {
                            var count = parseUnread(xhr.responseText);
                            var text;
                            if (lastText && count == 1000) {
                                //Let the last text since tab wereclosed and xhr cannot tell us more info on count
                                text = lastText;
                            } else {
                                text = formatUnread(count);
                            }
                            updateIcon(true, text);
                        } else {
                            updateIcon(false, '');
                        }
                    },
                    onerror: function(o){
                        updateIcon(false, '');
                        if (cb) {
                            cb(false);
                        }
                    }
                }, true);
            }
        });
    }
}

function formatUnread(count){
    if (!count) {
        return '';
    }
    var text = '' + count;
    if (text.length > 4 && text.lenth < 6) {
        text = text.substring(0, text.length - 3) + "k";
    } else if (count.lenth >= 6) {
        text = ">1M";
    }
    return text;
}

function updateFromTabtitle(tab, cb){
    var count = parseTabtitle(tab, function(count){
        var text = formatUnread(count);
        updateIcon(true, text);
    });
}

function parseTabtitle(tb, cb){
    //Needs update data 
    mycore.tabs.get(tb.id, function(tab){
        var checkurl = /^https?:\/\/www\.google\.com\/reader\/view/.test(tab.url);
        if (checkurl) {
            var m = /\((\d+)\+?\)/.exec(tab.title);
            var text = (m) ? m[1] : '0';
            cb.call(this, text);
        } else {
            tb = false;
        }
    });
}

function parseUnread(json){
    var o = JSON.parse(json);
    for (var i = 0, len = o.unreadcounts.length; i < len; i++) {
        var f = o.unreadcounts[i];
        if (reReader.reading.test(f.id)) {
            count = f.count;
            continue;
        }
    }
    return count;
}

function findreader(selected, create, fn){
    selecttab(reReader, selected, create, fn);
}

function openwindow(a, cb){
    delete a.message;
    chrome.windows.create(a, cb);
}

function igtheme(o, cb){
    if (o.type === 'random') {
        //random theme
        getRandomTheme(o.current, function(entry){
            prefs = getPrefs();
            prefs.ig_skin_name = entry.title;
            prefs.ig_skin_id = entry.skin_id;
            prefs.ig_skin_url = entry.link;
            setPrefs(prefs);
            cb(entry);
        }, true);
    }
}

function translate(o, cb){
    function trad(){
        google.language.translate(o.text, o.from || '', o.to, function(a){
            cb(a);
        });
    }
    if (!google.language) {
        google.load("language", "1", {
            "callback": trad
        });
    } else {
        trad();
    }
}


//+favicons_providerpageicons
function upgrade(){
    var prefs = getPrefs();
    if (prefs) {
        /*if (prefs.favicons) {
         prefs.favicons_providerpageicons = true;
         }*/
        if (isundef(prefs.general_stats)) {
            prefs.general_stats = true;
        }
        if (isundef(prefs.general_pageicon)) {
            prefs.general_pageicon = true;
        }
        setPrefs(prefs);
    }
}

function initVersion(){
    var v = mycore.storage.getItem('grp_version');
    if (v === null || v !== GRP.VERSION) {
        mycore.storage.setItem('grp_version', GRP.VERSION);
        upgrade();
        var prefs = getPrefs();
        if (prefs.general_noupdatepopup === false) {
            //no popup on minor updates
            if (isVersionMajorUpdated(v, GRP.VERSION)) {
                opentab({
                    url: "about.html"
                });
            }
        }
    }
}
function initstats(){
	//crash on macOsX + chrome<6.4.458
	if (isOsLinux() || isOsMac()) {
		console.log('Statistics track OFF for platform : ' + window.navigator.platform);
	} else {
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-183120-12']);
		_gaq.push(['_trackPageview']);
		window.GRP = window.GRP || {};
		window.GRP.useStats = true;
		console.log('Statistics track ON');
		(function(){
			var ga = document.createElement('script');
			ga.type = 'text/javascript';
			ga.async = true;
			ga.src = 'https://ssl.google-analytics.com/ga.js';
			(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(ga);
		})();
	}
}
setTimeout(initstats,50);

function track(name, value){
    if (typeof name === 'object') {
        value = name.value;
        name = name.name;
    }
    if (GRP.useStats && _gaq) {
		if (typeof name === 'object') {
            value = name.value;
            name = name.name;
        }
        _gaq.push(['_trackEvent', name, value]);
        //console.log('track '+name+':'+value);
    }
}
