/* ReaderPlus Chrome Extension by LudoO */

/**
 * Crossbrowser implementation for native browser
 *
 * @param {Object} a
 * @param {Object} fn
 */
var mycore = {
    env: {
        background: false,
        chrome: (typeof chrome !== "undefined" && chrome.extension),
        safari: (typeof safari !== "undefined"),
        prefix: '',
        autoparse: true
    },
    application: {
        sendRequest: function(a, fn, b){
            if (mycore.env.chrome) {
            
            } else if (mycore.env.safari) {
                safari.application.addEventListener(a.message, fn, false);
            }
        }
        
    },
    extension: {
        sendRequest: function(){
            //to bg
            var guid = false, a, fn, l = arguments.length;
            if (l > 2) {
                guid = arguments[0];
                a = arguments[1];
                fn = arguments[2];
            } else {
                a = arguments[0];
                fn = arguments[1];
            }
            
            if (mycore.env.chrome) {
                if (guid) {
                    if (fn) {
                        chrome.extension.sendRequest(guid, a, fn);
                    } else {
                        chrome.extension.sendRequest(guid, a);
                    }
                } else {
                    if (fn) {
                        chrome.extension.sendRequest(a, fn);
                    } else {
                        chrome.extension.sendRequest(a);
                    }
                }
                //chrome.extension.sendRequest(arguments);
            } else if (mycore.env.safari) {
                safari.self.addEventListener('crossaction', function(e){
                    var a = e;
                    a.message = a.name;
                    delete a.name;
                    fn(a);
                }, false);
                safari.self.tab.dispatchMessage('crossaction', a);
            }
        },
        onRequest: {
            addListener: function(fn){
                //from bg
                if (mycore.env.chrome) {
                    chrome.extension.onRequest.addListener(fn);
                } else if (mycore.env.safari) {
                    safari.application.addEventListener('crossaction', fn, false);
                }
            }
        },
        onRequestExternal: {
            addListener: function(fn){
                if (mycore.env.chrome) {
                    chrome.extension.onRequestExternal.addListener(fn);
                } else if (mycore.env.safari) {
                    safari.application.addEventListener('crossaction', fn, false);
                }
            }
        }
    },
    page: {
        listen: function(cb){
			if (mycore.env.chrome) {
				chrome.extension.onConnect.addListener(function(port){
					port.onMessage.addListener(cb);
				});
			}
		},
		postMessage: function(msg, cb, options){
            function post(msg, cb, options, tab){
                if (mycore.env.chrome) {
                    var port = chrome.tabs.connect(tab.id);
                    port.postMessage({
                        message: msg,
                        tab: tab.tabId,
                        options: options
                    });
                    port.onMessage.addListener(cb);
                } else if (mycore.env.safari) {
                    //safari
                }
            }
            
            if (options && options.tab) {
                post(msg, cb, options, tab);
            } else {
                mycore.tabs.getSelected(null, function(tab){
                    post(msg, cb, options, tab);
                });
            }
            
        }
    },
    tabs: {
        create: function(options){
            if (mycore.env.chrome) {
                chrome.tabs.create(options);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        get: function(id, fn){
            if (mycore.env.chrome) {
                chrome.tabs.get(id, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        getSelected: function(options, fn){
            if (mycore.env.chrome) {
                chrome.tabs.getSelected(options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        update: function(id, options, fn){
            if (mycore.env.chrome) {
                chrome.tabs.update(id, options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        executeScript: function(id, options){
            if (mycore.env.chrome) {
                chrome.tabs.executeScript(id, options);
            } else if (mycore.env.safari) {
                //safari
            }
        },
        onRemoved: {
            addListener: function(fn){
                if (mycore.env.chrome) {
                    chrome.tabs.onRemoved.addListener(fn);
                } else if (mycore.env.safari) {
                    //safari
                }
            }
        }
    },
    windows: {
        getAll: function(options, fn){
            if (mycore.env.chrome) {
                chrome.windows.getAll(options, fn);
            } else if (mycore.env.safari) {
                //safari
            }
        }
    },
    storage: {
        getItem: function(name, def, cb){
            var v = null;
            if (mycore.env.chrome) {
                if (cb && !mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'get',
                        name: name
                    }, function(o){
                        cb(o || def);
                    });
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    v = localStorage.getItem(name);
                }
            } else if (mycore.env.safari) {
                v = localStorage.getItem(name);
                //return safari.extension.settings.getItem(name);
            }
            if (v && typeof v === 'string' && mycore.env.autoparse) {
                try {
                    v = JSON.parse(v);
                } catch (e) {
                    //
                }
            }
            v = v || def;
            if (cb && typeof v === 'function') {
                cb(v);
            }
            return v;
        },
        removeItem: function(name){
            if (mycore.env.chrome) {
                if (!mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'remove',
                        name: name
                    }, cb);
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    localStorage.removeItem(name);
                }
            } else if (mycore.env.safari) {
                localStorage.removeItem(name);
            }
        },
        setItem: function(name, value, cb){
            var s = value;
            if (s && mycore.env.autoparse && typeof s === 'object') {
                s = JSON.stringify(s);
            }
            if (mycore.env.chrome) {
                if (cb !== false && !mycore.env.background) {
                    mycore.extension.sendRequest({
                        message: 'set',
                        name: name,
                        value: value
                    }, cb);
                } else {
                    if (!mycore.env.background) {
                        name = mycore.env.prefix + name;
                    }
                    localStorage.setItem(name, s);
                }
            } else if (mycore.env.safari) {
                localStorage.setItem(name, s);
            }
        },
        key: function(i){
            if (mycore.env.chrome) {
                return localStorage.key(i);
            } else if (mycore.env.safari) {
                return localStorage.key(i);
                //return safari.extension.settings.key(i);
            }
        },
        getLength: function(cb){
            var v = -1;
            if (mycore.env.chrome) {
                v = localStorage.length;
            } else if (mycore.env.safari) {
                v = localStorage.length;
                //return safari.extension.settings.length;
            }
            if (cb && typeof v === 'function') {
                cb(v);
            }
            return v;
        },
        clear: function(){
            localStorage.clear();
        }
    },
    getUrl: function(path){
        if (mycore.env.chrome) {
            return 'chrome-extension://' + mycore.getGUID() + path;
        } else if (mycore.env.safari) {
            return safari.extension.baseURI;
            //return 'safari-extension://' + mycore.getGUID() + path;
        }
    },
    getGUID: function(){
        if (mycore.env.chrome) {
            var url = chrome.extension.getURL('bg.html');
            var m = /:\/\/(\w+)/.exec(url);
            return m[1];
        } else if (mycore.env.safari) {
            //TODO
            var namespace = 'com.pitaso.readerplus';
            var guid = '37PA8NKYKP';
            return namespace + '-' + guid;
        }
    },
    getLocalPath: function(){
        return mycore.getProtocol() + mycore.getGUID();
    },
    getProtocol: function(){
        if (mycore.env.chrome) {
            return 'chrome-extension://';
        } else if (mycore.env.safari) {
            return 'safari-extension://';
        }
    }
};

//
// Global util functions
//
function hasClass(el, clazz){
    if (!el || !el.className) {
        return false;
    }
    var reClassname = new RegExp("(^|\\s)" + clazz + "(\\s|$)");
    return (reClassname.test(el.className));
}

function addClass(el, clazz, checked){
    if (checked && hasClass(el, clazz)) {
        return;
    }
    if (el) {
        el.className = (el.className || '') + ' ' + clazz;
    }
}

function addClassChecked(el, clazz){
    addClass(el, clazz, true);
}

function addClassIf(el, cls, status, cls2){
    if (typeof status === 'string') {
        cls2 = status;
        status = null;
    }
    if (typeof status === 'undefined' || status === null) {
        status = !hasClass(el, cls);
    }
    if (status) {
        addClass(el, cls, true);
        if (cls2) {
            removeClass(el, cls2);
        }
    } else {
        removeClass(el, cls);
        if (cls2) {
            addClass(el, cls2);
        }
    }
}

function addAttr(el, name, value){
    var attr = document.createAttribute(name);
    attr.value = value;
    el.attributes.setNamedItem(attr);
}

function findParentNode(eel, etag, clazz){
    var tag = etag.toUpperCase();
    var el = eel.parentNode;
    if (clazz) {
        // Find first element's parent node matching tag and className
        while (el && el.tagName !== 'BODY' && (el.tagName !== tag || !hasClass(el, clazz))) {
            // console.log(el.tagName+'.'+el.className);
            el = el.parentNode;
            /*
             * if (!el){ console.log('el null for clazz '+clazz ); }
             */
        }
    } else {
        while (el && el.tagName !== 'BODY' && el.tagName !== tag) {
            el = el.parentNode;
        }
    }
    return ((el && el.tagName !== 'BODY') ? el : false);
}

function getFirstNode(el){
    var o = el.firstChild;
    //if (typeof o == "HTMLDivElement"){
    if (o && o.nodeType == 1) {
        return o;
    }
    //
    //while(typeof o !== "undefined" && typeof o !== "HTMLDivElement"){
    while (typeof o !== "undefined" && o.nodeType !== 1) {
        o = o.nextSibling;
    }
    return o;
}

function getIndex(el){
    var pos = 0, o = el;
    while ((o = o.previousSibling)) {
        pos++;
    }
    return (pos + 1);
}

function getPos(obj){
    var output = {};
    var mytop = 0, myleft = 0;
    while (obj) {
        mytop += obj.offsetTop;
        myleft += obj.offsetLeft;
        obj = obj.offsetParent;
    }
    output.left = myleft;
    output.top = mytop;
    return output;
}

//native getElementsByClassName
function getFirstElementByClassName(root, clazz){
	return root.getElementsByClassName(clazz)[0];
}

function getElementText(root, cls, html, firstchild){
    var txt = '', el = getFirstElementByClassName(root || document, cls);
    if (el) {
        if (firstchild) {
            el = el.firstChild;
        }
        if (html) {
            txt = el.innerHTML;
        } else {
            txt = el.innerText || el.textContent;
        }
    }
    return txt;
}

function copyAttributes(src, dest){
    var ats;
    if (src && dest && src.attributes && src.attributes.length > 0) {
        for (var i = 0, len = src.attributes.length; i < len; i++) {
            ats = src.attributes[i];
            addAttr(dest, ats.nodeName, ats.nodeValue);
        }
    }
}

/**
 *
 * @param {Object} root
 * @param {Object} tag
 * @param {Object} clazz
 * @deprecated use getFirstElementByClassName
 */
function getFirstElementMatchingClassName(root, tag, clazz){
    var elements = root.getElementsByTagName(tag);
    var i = 0;
    while (elements[i] && !hasClass(elements[i], clazz)) {
        i++;
    }
    return ((!elements[i]) ? null : (elements[i]));
}

function getLastElementMatchingClassName(root, tag, clazz){
    var elements = root.getElementsByTagName(tag);
    var i = elements.length, j = 0;
    while (i >= 0 && elements[i] && !hasClass(elements[i], clazz)) {
        i--;
    }
    return ((i < 0 || !elements[i]) ? null : (elements[i]));
}

function getElementsByClazzName(clazz, itag, ielm){
    var tag = itag || "*";
    var elm = ielm || document;
    var elements = (tag == "*" && elm.all) ? elm.all : elm.getElementsByTagName(tag);
    var returnElements = [];
    var current;
    var length = elements.length;
    for (var i = 0; i < length; i++) {
        current = elements[i];
        if (hasClass(current, clazz)) {
            returnElements.push(current);
        }
    }
    return returnElements;
}

function getElements(xpath, context){
    var res = false, doc = (context) ? context.ownerDocument : document;
    try {
        var r = doc.evaluate(xpath, (context || doc), null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
        for (var i = 0, l = r.snapshotLength, res = new Array(l); i < l; i++) {
            res[i] = r.snapshotItem(i);
        }
    } catch (e) {
        console.error('xpath error : ' + xpath);
    }
    return res;
}

function serializeXml(nodes){
    var html = '';
    nodes.forEach(function(node){
        html += node.outerHTML;
    });
    return html;
}

/*
 * From jQuery
 */
function serializePost(a, traditional){
    var e = encodeURIComponent, s = [];
    if (isArray(a) || a.jquery) {
        forEeach(a, function(){
            add(this.name, this.value);
        });
    } else {
        for (var prefix in a) {
            buildParams(prefix, a[prefix]);
        }
    }
    return s.join("&").replace(/%20/g, "+");
    
    function buildParams(prefix, obj){
        if (isArray(obj)) {
            iterate(obj, function(i, v){
                if (traditional || /\[\]$/.test(prefix)) {
                    add(prefix, v);
                } else {
                    buildParams(prefix + "[" + (typeof v === "object" || isArray(v) ? i : "") + "]", v);
                }
            });
            
        } else if (!traditional && obj != null && typeof obj === "object") {
            // Serialize object item.
            iterate(obj, function(k, v){
                buildParams(prefix + "[" + k + "]", v);
            });
            
        } else {
            // Serialize scalar item.
            add(prefix, obj);
        }
    }
    
    function add(key, value){
        // If value is a function, invoke it and return its value
        value = (typeof value === 'function') ? value() : value;
        s[s.length] = e(key) + "=" + e(value);
    }
}

function get_id(id){
    return document.getElementById(id);
}

function getElementValue(query, context){
    var doc = (context) ? context.ownerDocument : document;
    return doc.evaluate(query, (context || doc), null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}

function parseXml(xmlText){
    var dom = new DOMParser().parseFromString(xmlText, "application/xml");
    //urlinput.value = dom.getElementsByTagName('shortUrl')[0].textContent;
    return dom;
}

if (typeof Array.forEach === "undefined") {
    Array.forEach = function(arr, fn){
        Array.prototype.forEach.call(arr, fn);
    };
}
function insertAfter(el, ref){
    var next = ref.nextSibling;
    if (next) {
        insertBefore(el, next);
    } else {
        ref.parentNode.appendChild(el);
    }
}

function insertBefore(el, ref){
    ref.parentNode.insertBefore(el, ref);
}

function insertFirst(el, ref){
    if (ref.firstChild) {
        insertBefore(el, ref.firstChild);
    } else {
        ref.parentNode.appendChild(el);
    }
}

function remove(el){
    if (el && el.parentNode) {
        el.parentNode.removeChild(el);
    }
}

/**
 * Strings
 */
function normalizeUrl(url){
    if (!(/^http(s)?:/i.test(url))) {
        return 'http://' + url;
    } else {
        return url;
    }
}

//without parameter
function cleanUrl(url){
    var m = /([^\?]+)\??(.*)/.exec(url);
    if (m) {
        return m[1];
    } else {
        return url;
    }
}

function ellipsis(text, max){
    var match = text || '';
    max = max || 24;
    if (match.length > max) {
        match = match.substr(0, max - 3) + '...';
    }
    return match;
}

String.prototype.toMaj = function(){
    return this.replace(/(^\w)/, function(m){
        return m.toUpperCase();
    });
};

//To Camel Case
String.prototype.toCamel = function(){
    return this.replace(/(\-[a-z])/g, function($1){
        return $1.toUpperCase().replace('-', '');
    });
};
//To Dashed from Camel Case
String.prototype.toDash = function(){
    return this.replace(/([A-Z])/g, function($1){
        return "-" + $1.toLowerCase();
    });
};
//To Underscore from Camel Case
String.prototype.toUnderscore = function(){
    return this.replace(/([A-Z])/g, function($1){
        return "_" + $1.toLowerCase();
    });
};
function isArray(obj){
    return (obj && obj.constructor == Array);
}

/**
 * Shortcuts
 *
 */
/**
 *
 * @param fn
 * @param keys
 *  [{keycode, shift, ctrl, alt}]
 * @return
 */
function initKey(keys){
    document.addEventListener('keydown', function(e){
        var target = e.target;
        var tag = target.tagName;
        //console.log('keydown on '+tag+'.'+(tag.className||''));
        if (tag !== 'INPUT' && tag !== 'SELECT' && tag !== 'TEXTAREA') {
            if (!isArray(keys)) {
                keys = [keys];
            }
            for (var i = 0, len = keys.length; i < len; i++) {
                var k = keys[i];
                if (k.keyCode == e.keyCode &&
                ((k.shiftKey && e.shiftKey) || (!k.shiftKey && !e.shiftKey)) &&
                ((k.ctrlKey && e.ctrlKey) || (!k.ctrlKey && !e.ctrlKey)) &&
                ((k.altKey && e.altKey) || (!k.altKey && !e.altKey))) {
                    e.preventDefault();
                    //e.stopPropagation();
                    //k.fn(e);
                    if (!target.locked) {
                        //console.log('run fn for keyCode='+k.keyCode);
                        k.fn(e);
                        target.locked = true;
                        window.setTimeout(function(){
                            target.locked = false;
                        }, 300);
                    } else {
                        console.log('LOCK run fn for keyCode=' + k.keyCode);
                    }
                    break;
                }
            }
        }
    }, false);
}

function notEmpty(o){
    if (o) {
        if (isArray(o) && o.length > 0) {
            return o;
        } else if (typeof o === "object" && !isObjectEmpty(o)) {
            return o;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function isFunction(fn){
    return (fn && typeof fn === 'function');
}


function isObjectEmpty(o){
    if (!o) {
        return true;
    }
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        return false;
    }
    return true;
}

function findInArray(a, value){
    for (var i = 0, len = a.length; i < len; i++) {
        if (a[i] === value) {
            return i;
        }
    }
    return false;
}

function find(o, key, value){
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (o[p][key] === value) {
            return o[p];
        }
    }
    return false;
}

function findre(o, key, re){
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (re.test(o[p][key])) {
            return o[p];
        }
    }
    return false;
}

function getCount(o){
    var count = 0;
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        count++;
    }
    return count;
}

function returnItemAtPosition(o, i){
    var count = 0;
    for (var p in o) {
        if (!hasOwnProperty.call(o, p)) {
            continue;
        }
        if (count == i) {
            return o;
        }
    }
    return false;
}

function randomselect(ar){
    if (isArray(ar)) {
        return ar[Math.round(Math.random() * (ar.length - 1))];
    } else if (typeof ar == 'object') {
        var i = Math.round(Math.random() * (getCount(ar) - 1));
        return returnItemAtPosition(ar, i);
    } else {
        return false;
    }
    
}

function removeClass(el, classname){
    //todo: use regex word boundary
    var s = (el.className || '').split(' ');
    for (var i = 0, len = s.length; i < len; i++) {
        if (s[i] == classname) {
            s[i] = '';
        }
    }
    el.className = s.join(' ').trim();
//el.className = el.className.replace(classname, '').trim();
}

function toggleClass(el, classDelete, classAdd){
    removeClass(el, classDelete);
    addClass(el, classAdd);
}

function fireResizeDefer(){
    window.setTimeout(fireResize, 500);
}

function fireResize(){
    fitHeight('sub-tree');
    fitHeight('entries', 'viewer-footer');
}

function fitHeight(id, bottom){
    var el = document.getElementById(id);
    var h = findTop(el);
    if (bottom) {
        var elb = document.getElementById(bottom);
        if (elb) {
            h -= elb.clientHeight;
        }
    }
    el.style.height = (window.innerHeight - h) + 'px';
}

function findTop(obj, relative){
    var curtop = 0;
    if (obj.offsetParent) {
        do {
            curtop += obj.offsetTop;
        } while ((obj = obj.offsetParent) && (!relative || (relative && relative!==obj)) );
        return curtop;
    }
}

function getStyle(el, property){
    if (el && el.style && el.style[property]) {
        return parseInt(el.style[property].replace('px', ''), 10);
    } else {
        return 0;
    }
}

function simulateClick(node){
    var event = node.ownerDocument.createEvent("MouseEvents");
    event.initMouseEvent("click", true, true, window, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
    /* ReadByMouse
 event.initMouseEvent("click", true, // can bubble
 true, // cancellable
 node.ownerDocument.defaultView, 1, // clicks
 50, 50, // screen coordinates
 50, 50, // client coordinates
 false, false, false, false, // control/alt/shift/meta
 0, // button,
 node);
 */
    node.dispatchEvent(event);
}

function simulateKeypress(node, keycode){
    var event = node.ownerDocument.createEvent("KeyboardEvent");
    if (typeof keycode === "string") {
        keycode = keycode.charCodeAt(0);
    }
    event.initKeyEvent("keypress", true, true, window, 0, 0, 0, 0, 0, keycode);
    //event.initKeyboardEvent('keypress', true, true, window, "U+0041");
    node.dispatchEvent(evt);
}

/**
 * Shortcuts
 * @param {Object} e
 */
function getStringFromCharCode(codePt){
    if (codePt > 0xFFFF) {
        codePt -= 0x10000;
        return String.fromCharCode(0xD800 + (codePt >> 10), 0xDC00 + (codePt & 0x3FF));
    } else if (keycodes && keycodes[codePt]) {
        return keycodes[codePt];
    } else {
        return String.fromCharCode(codePt);
    }
}

//saved under format CTRL[0,1]ALT[0,1]SHIFT[0,1]keyCode
function unmarshallKey(text){
    var m = /(\d)(\d)(\d)(\d+)/.exec(text || '');
    var key = {};
    if (m) {
        key = {
            ctrlKey: (m[1] === '1'),
            altKey: (m[2] === '1'),
            shiftKey: (m[3] === '1'),
            keyCode: m[4]
        };
    }
    return key;
}

function marshallKey(e){
    return ((e.ctrlKey) ? '1' : '0') + ((e.altKey) ? '1' : '0') + ((e.shiftKey) ? '1' : '0') + e.keyCode;
}

function formatKey(e, keyFirst){
    if (e && e.keyCode) {
		var keyLetter = getStringFromCharCode(e.keyCode);
		if (keyFirst) {
			return keyLetter + ((e.ctrlKey) ? '+ctrl' : '') + ((e.altKey) ? '+alt' : '') + ((e.shiftKey) ? '+shift' : '');
		} else {
			return ((e.ctrlKey) ? 'ctrl+' : '') + ((e.altKey) ? 'alt+' : '') + ((e.shiftKey) ? 'shift+' : '') + keyLetter;
		}
	}else{
		return '';
	}
}

/**
 * Cookies
 *
 */
function readCookie(name){
    name = name.replace(/([.*+?^=!:${}()|[\]\/\\])/g, '\\$1');
    var regex = new RegExp('(?:^|;)\\s?' + name + '=(.*?)(?:;|$)', 'i'), match = document.cookie.match(regex);
    return match && unescape(match[1]);
}

/**
 * Templates
 */
function fillTpl(tpl, o){
    var txt = '' + tpl;
    for (var k in o) {
        if (o.hasOwnProperty(k)) {
            if (typeof o[k] !== "object") {
                var re = new RegExp("\\{" + k + "\\}", "g");
                txt = txt.replace(re, (o[k]) ? ('' + o[k]) : '');
            }
        }
    }
    return txt;
}

//Format text using number {0}
function formatText(tpl){
    if (!arguments) {
        return '';
    }
    var args = Array.prototype.slice.call(arguments, 1);
    var values = {};
    for (var i = 0, len = args.length; i < len; i++) {
        values[i] = args[i];
    }
    return fillTpl(tpl, values);
}

function getGlobal(){
    return (window.GRP = window.GRP || {});
}

var keycodes = {
    8: 'backspace',
    9: 'tab',
    13: 'enter',
    16: 'shift',
    17: 'ctrl',
    18: 'alt',
    19: 'pause',
    20: 'capslock',
    27: 'escape',
    33: 'pageup',
    32: 'space',
    34: 'pagedown',
    35: 'end',
    36: 'home',
    37: 'arrowleft',
    38: 'arrowup',
    39: 'arrowright',
    40: 'arrowdown',
    44: 'printscreen',
    45: 'insert',
    46: 'delete',
    48: '0',
    49: '1',
    50: '2',
    51: '3',
    52: '4',
    53: '5',
    54: '6',
    55: '7',
    56: '8',
    57: '9',
    65: 'a',
    66: 'b',
    67: 'c',
    68: 'd',
    69: 'e',
    70: 'f',
    71: 'g',
    72: 'h',
    73: 'i',
    74: 'j',
    75: 'k',
    76: 'l',
    77: 'm',
    78: 'n',
    79: 'o',
    80: 'p',
    81: 'q',
    82: 'r',
    83: 's',
    84: 't',
    85: 'u',
    86: 'v',
    87: 'w',
    88: 'x',
    89: 'y',
    90: 'z',
    91: 'leftwindowkey',
    92: 'rightwindowkey',
    93: 'selectkey',
    96: '0 pad',
    97: '1 pad',
    98: '2 pad',
    99: '3 pad',
    100: '4 pad',
    101: '5 pad',
    102: '6 pad',
    103: '7 pad',
    104: '8 pad',
    105: '9 pad',
    106: '*',
    107: '+',
    109: '-',
    110: '.',
    111: '/',
    112: 'f1',
    113: 'f2',
    114: 'f3',
    115: 'f4',
    116: 'f5',
    117: 'f6',
    118: 'f7',
    119: 'f8',
    120: 'f9',
    121: 'f10',
    122: 'f11',
    123: 'f12',
    144: 'numlock',
    145: 'scrolllock',
    182: 'MyComputer',
    183: 'MyCalculator',
    186: ';',
    187: '=',
    188: ',',
    189: 'dash',
    190: 'period',
    191: '/',
    219: '(',
    220: '\\',
    221: ')',
    222: '\''
};
//a.href sometimes truncated
function getHref(a){
    var url = a.protocol + '//' + a.host + a.pathname + (a.hash || '');
    return url;
}

function adjustIframeHeight(iframe, heightMaxi){
    var el;
    if (iframe.document.height) {
        el = parent.document.getElementById(iframe.name);
        el.style.height = iframe.document.height + 'px';
    //el.style.width = iframe.document.width + 'px';
    } else if (document.all) {
        el = parent.document.all[iframe.name];
        if (iframe.document.compatMode &&
        iframe.document.compatMode != 'BackCompat') {
            el.style.height = iframe.document.documentElement.scrollHeight + 5 + 'px';
        //el.style.width = iframe.document.documentElement.scrollWidth + 5 + 'px';
        } else {
            el.style.height = iframe.document.body.scrollHeight + 5 + 'px';
        //el.style.width = iframe.document.body.scrollWidth + 5 + 'px';
        }
    }
}

function bind(func, thisArg){
    var args = Array.prototype.slice.call(arguments, 2);
    return function(){
        var bargs = args.concat(Array.prototype.slice.call(arguments));
        func.apply(thisArg, bargs);
    };
}

function foreach(array, fn, scope){
    if (!array) {
        return;
    }
    if (typeof array.length == "undefined") {
        array = [array];
    }
    for (var i = 0, len = array.length; i < len; i++) {
        if (fn.call(scope || array[i], array[i], i, array) === false) {
            return i;
        }
    }
}

function map2array(o, key, value, flat, eu){
    var r = [];
    iterate(o, function(p, o){
        var a = {};
        a[key || 'key'] = p;
        if (flat && typeof o === "object") {
            iterate(o, function(k, obj){
                a[k] = obj;
            });
        } else {
            a[value || 'value'] = o;
        }
        r.push(a);
    });
    return r;
}

function iterate(o, fn, scope, id){
    if (o) {
        for (var p in o) {
            if (!hasOwnProperty.call(o, p)) {
                continue;
            }
            if (typeof id !== 'undefined') {
                o[p][(typeof id === "string") ? id : 'id'] = p;
            }
            fn.call(scope || this, p, o[p]);
        }
    }
    return false;
}

function namespace(){
    var o, d;
    foreach(arguments, function(v){
        d = v.split(".");
        o = window[d[0]] = window[d[0]] || {};
        foreach(d.slice(1), function(v2){
            o = o[v2] = o[v2] || {};
        });
    });
    return o;
}

function apply(o, c, defaults){
    if (defaults) {
        apply(o, defaults);
    }
    if (o && c && typeof c === 'object') {
        for (var p in c) {
            o[p] = c[p];
        }
    }
    return o;
}

//Override text with last item
function merge(o, c, defaults){
    if (defaults) {
        merge(o, defaults);
    }
    if (typeof o !== "undefined" && typeof c !== "undefined") {
        /*if (isArray(c)) {
 for (var i = 0, len = c.length; i < len; i++) {
 //o[i] = c[i];
 //console.log(c[i] + ' Amerge['+i+']> ' + o[i]);
 if (typeof c[i] === 'object' || isArray(c[i])) {
 merge(o[i], c[i]);
 } else {
 o[i] = c[i];
 }
 }
 //console.log('after: ' + c[i] + ' Amerge[' + i + ']> ' + o[i]);
 } else */
        if (typeof c === 'object') {
            for (var p in c) {
                //console.log(c[p] + ' Omerge['+p+']> ' + o[p]);
                if (typeof c[p] === 'object' || isArray(c[p])) {
                    merge(o[p], c[p]);
                } else {
                    o[p] = c[p];
                }
            }
        } else {
            //o[p] = c[p];
            //console.log(c + ' -> ' + o);
            o = c;
        }
    }
    return o;
}

function isundef(o){
    return (typeof o === 'undefined');
}

function group(a, name){
    var r = {};
    iterate(a, function(id, o){
        var val = o[name] || 'other';
        if (!r[val]) {
            r[val] = {};
        }
        r[val][id] = o;
    });
    return r;
}

function applyRemoteLang(lang, base, id, o, fn, scope){
    GM_xmlhttpRequest({
        method: 'GET',
        url: base + '_locales/' + lang + '/' + id + '.json',
        onload: function(res){
            var data = eval(xhr.responseText);
            if (data) {
                //merge data into o
                applyLast(o[id], data);
            }
        },
        onerror: function(res, a){
            if (a && a.url) {
                console.error(a.url);
            }
            console.error(res);
        }
    });
}

//http://snipplr.com/view/9649/escape-regular-expression-characters-in-string/
//http://simonwillison.net/2006/Jan/20/escape/
var re_encodeRE = new RegExp("[.*+?|()\\[\\]{}\\\\]", "g"); // .*+?|()[]{}\
function encodeRE(s){
    return s.replace(re_encodeRE, "\\$&").replace(' ', '\\W');
}

function urlDecode(string){
    var obj = {}, pairs = string.split('&'), d = decodeURIComponent, name, value;
    for (var i = 0, len = pairs.length; i < len; i++) {
        var pair = pairs[i];
        pair = pair.split('=');
        name = d(pair[0]);
        value = d(pair[1]);
        obj[name] = !obj[name] ? value : [].concat(obj[name]).concat(value);
    }
    return obj;
}

function getDomain(url, withProtocol){
    var m = url.split(/\/|\?/);
    if (withProtocol) {
        return m[0] + '/' + m[1] + '/' + m[2];
    } else {
        return m[2];
    }
}

/*
 isChromeVersionMini('5.0.342.1')
 compareVersion('5.1', '5.0.342.1');->=true
 compareVersion('5.0.100', '5.0.342.1');->=false
 */
function getChromeVersion(){
    var version = /Chrome\/([\d\.]+)/.exec(window.navigator.appVersion);
    return version[1];
}

//Chrome mini version required
function isChromeVersionMini(ref){
    return (compareVersion(getChromeVersion(), ref) >= 0);
}

function isOsMac(){
	return window.navigator.platform.toLowerCase().indexOf('mac')>=0;
}
function isOsLinux(){
	return window.navigator.platform.toLowerCase().indexOf('linux')>=0;
}
//compare 2 first segments
function isVersionMajorUpdated(oldVersion, newVersion){
    return (compareVersion(newVersion, oldVersion, 2) > 0);
}

function compareVersion(version, ref, count){
    if (!ref) {
        //new version, no previous version
        return 1;
    }
    var versions = version.split('.');
    var refs = ref.split('.');
    count = count || versions.length;
    for (var i = 0, len = count; i < len; i++) {
        versions[i] = parseInt(versions[i], 10);
        if (i <= refs.length) {
            refs[i] = parseInt(refs[i], 10);
            if (versions[i] < refs[i]) {
                return -1;
            } else if (versions[i] > refs[i]) {
                return 1;
            }
        }
    }
    return 0;
}

function textareaTab(){
    //Let handle tab on textarea
    var areas = document.getElementsByTagName('textarea');
    if (areas) {
        for (var i = 0, len = areas.length; i < len; i++) {
            areas[i].addEventListener('keydown', function(e){
                var t = e.target;
                if (e.keyCode == 9) {
                    e.preventDefault();
                    var tab = '\t';
                    var ss = t.selectionStart;
                    var se = t.selectionEnd;
                    var currentScroll = t.scrollTop;
                    // Indent
                    if (ss != se && t.value.slice(ss, se).indexOf("\n") != -1) {
                        var pre = t.value.slice(0, ss);
                        var selb = t.value.slice(ss, se);
                        if (e.shiftKey) {
                            //un-indent
                            sel = selb.replace(/^\t/mg, "\n");
                        } else {
                            //indent
                            sel = selb.replace(/\n/g, "\n" + tab);
                        }
                        var post = t.value.slice(se, t.value.length);
                        t.value = pre.concat(tab).concat(sel).concat(post);
                        t.selectionStart = ss + tab.length;
                        t.selectionEnd = se + (sel.length - selb.length);
                    } else {
                        t.value = t.value.slice(0, ss).concat(tab).concat(t.value.slice(ss, t.value.length));
                        if (ss == se) {
                            t.selectionStart = t.selectionEnd = ss + tab.length;
                        } else {
                            t.selectionStart = ss + tab.length;
                            t.selectionEnd = se + tab.length;
                        }
                    }
                    t.scrollTop = currentScroll;
                    t.focus();
                    return false;
                } else {
                    return true;
                }
            });
        }
    }
}

function waitlib(check, fn, scope){
    if (check()) {
        if (fn) {
            fn.call(scope || this);
        }
    } else {
        window.setTimeout(function(){
            waitlib(check, fn);
        }, 200);
    }
}

function waitImages(images, cb, scope){
    var count = (images) ? images.length : 0;
    if (count <= 0) {
        cb.call(scope || this, true);
    } else {
        var timeout = window.setTimeout(function(){
            console.log("Images are not all loaded: " + count);
            cb.call(scope || this, false);
        }, 3000);
        function check(){
            if (count === 0) {
                window.clearTimeout(timeout);
                cb.call(scope || this, true);
            }
        }
        for (var i = 0, len = images.length; i < len; i++) {
            var image = images[i];
            if (image.complete) {
                count--;
            } else {
                image.addEventListener('load', function(){
                    count--;
                    check();
                });
            }
        }
        check();
    }
}

function isShown(el){
    return (el && el.style && el.style.display !== 'none' && el.visibility !== 'hidden');
}

function show(el, value){
    if (el) {
        if (!el.style) {
            el.style = {};
        }
        el.style.display = value || '';
    }
}

function hide(el){
    if (el) {
        el.style.display = 'none';
    }
}

function toggle(el){
    if (isShown(el)) {
        hide(el);
    } else {
        show(el);
    }
}

function showas(el, hideme){
    if (hideme) {
        hide(el);
    } else {
        show(el);
    }
}

//http://forums.mozillazine.org/viewtopic.php?f=19&t=1806595
//http://forums.mozillazine.org/viewtopic.php?f=19&t=1594275
//https://developer.mozilla.org/En/Code_snippets:HTML_to_DOM
function loadXml(html, id){
    var el = document.createElement('div');
	el.id = id || ('_grp_xml_'+Math.round(Math.random()*999+1));
    el.style.display = 'none';
    el.innerHTML = (html.split(/<body[^>]*>((?:.|\n)*)<\/body>/i)[1]) || html;
    return el;
}

function loadText(url, cb){
    GM_xmlhttpRequest({
        method: 'GET',
        url: url,
        onload: function(r){
            var txt = r.responseText;
            cb(txt);
        }
    });
}

function loadCss(url, cb, option){
    loadText(url, function(txt){
        var css = txt;
        if (!option || option.compact) {
            css = compact(css);
        }
        if (!option || option.clean) {
            css = css.replace(/\/\*.*?\*\//g, '');
        }
        cb(css);
    });
}

function compact(text){
    return text.replace(/[\n\t]/g, '').replace(/\s+/g, ' ');
}

//Only works with XML well-formed
function getDocumentXml(html, id){
    var h = html.replace(/^(.*\n)*.*<html/i, "<html");
    h = h.replace(/<\/html>(.*\n)*.*$/i, "</html>");
    var parser = new DOMParser();
    var dom = parser.parseFromString(t, "text/xml");
    return dom;
}

function loadXMLDoc(url){
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, false);
    xhr.send("");
    return xhr.responseXML;
}

function applyXsl(xml, xsl){
    var oxml = loadXMLDoc(xml);
    var oxsl = loadXMLDoc(xsl);
    var xp = new XSLTProcessor();
    xp.importStylesheet(oxsl);
    var doc = xp.transformToFragment(oxml, document);
    return doc;
}

var tmaps = {
    id: 'id',
    cls: 'className',
    style: 'style',
    href: 'href',
    alt: 'alt',
    title: 'title',
    text: 'innerText',
    html: 'innerHTML'
};
function dh(root, tag, attrs, events){
    var config = attrs;
    if (root) {
        config.root = root;
    }
    if (tag) {
        config.tag = tag;
    }
    if (events) {
        config.events = events;
    }
    return dhc(config);
}

function dhc(config){
    if (!config) {
        return false;
    }
    var root = config.root;
    if (!root) {
        root = document.body;
    } else if (typeof config.root == "string") {
        root = get_id(config.root);
        if (!root) {
            return false;
        }
    }
    var excepts = {
        root: 1,
        tag: 1,
        events: 1,
        el: 1,
        position: 1
    };
    var el = document.createElement(config.tag || 'div');
    iterate(config, function(k, o){
        if (typeof o !== 'undefined') {
            if (excepts[k] !== 1) {
                if (tmaps[k]) {
                    el[tmaps[k]] = o;
                } else {
                    addAttr(el, k, o);
                }
            }
        }
    });
    iterate(config.events, function(event, fn){
        el.addEventListener(event, fn, false);
    });
    if (config.el) {
        //recurse
        var cfg = config.el;
        cfg.root = el;
        dhc(cfg);
    }
    if (config.position) {
        if (config.position === 'before') {
            insertBefore(el, root);
        } else {
            insertAfter(el, root);
        }
    } else {
        root.appendChild(el);
    }
    return el;
}

function newel(id, cls){
    var el = get_id(id);
    if (el) {
        return el;
    } else {
        return dh('', 'div', {
            id: id,
            cls: cls
        });
    }
}

function randomItem(items){
    return items[Math.round(Math.random() * (items.length - 1))];
}

function loadjQuery(cb, version, local){
    version = version || '1';
    var url = (local) ? (LOCALPATH + '/lib/jquery.min.js') : ('http://ajax.googleapis.com/ajax/libs/jquery/' + version + '/jquery.min.js');
    GM_loadScript(url, false, function(){
        return (typeof jQuery !== "undefined");
    }, cb);
}

function runfn(fn, id, priority, delay){
    GRP.fns.push({
        fn: fn,
        id: id,
        delay: delay,
        priority: priority
    });
}

function encodeu(el){
    return escape(encodeURIComponent(el));
}

function decodeu(el){
    return decodeURIComponent(unescape(el));
}

function getBoolean(val){
    return (val && (val === true || val.toLowerCase() === 'true'));
}


function getTypedValue(o){
    var text;
    if (typeof o === 'object') {
        text = o.value || '';
    } else {
        text = o;
    }
    if (text === "true") {
        return true;
    } else if (text === "false") {
        return false;
    } else {
        return text;
    }
}
mycore.env.prefix = "readerplus.";
//GreaseKit
//http://groups.google.com/group/greasekit-users/browse_thread/thread/d0ed6e8919bb6b42
if (typeof GM_getValue === "undefined") {
    GM_getValue = function(name, def, cb){
        //Move old nameing value to new prefixed place
        /*var value = mycore.storage.getItem(name, cb);
         if (value) {
         GM_setValue(PREFIX + name, value);
         mycore.storage.removeItem(name);//remove old
         }*/
        value = mycore.storage.getItem(name, def, cb);
        return value;
    };
}
if (typeof GM_getCookieValue === "undefined") {
    GM_getCookieValue = function(name, def){
        var value;
        var nameEQ = escape(name) + "=", ca = document.cookie.split(';');
        for (var i = 0, c; i < ca.length; i++) {
            c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1, c.length);
            }
            if (c.indexOf(nameEQ) === 0) {
                value = unescape(c.substring(nameEQ.length, c.length));
                break;
            }
        }
        if (value === null && def !== null) {
            value = def;
        }
        return value;
    };
}
if (typeof GM_setValue === "undefined") {
    GM_setValue = function(name, value, cb){
        try {
            mycore.storage.setItem(name, value, cb);
        } catch (e) {
            console.log('error on GM_setValue[' + n + ']=' + value);
        }
    };
}
if (typeof GM_setCookieValue === "undefined") {
    GM_setCookieValue = function(name, value, options){
        options = (options || {});
        if (options.expiresInOneYear) {
            var today = new Date();
            today.setFullYear(today.getFullYear() + 1, today.getMonth, today.getDay());
            options.expires = today;
        }
        var curCookie = escape(name) +
        "=" +
        escape(value) +
        ((options.expires) ? "; expires=" +
        options.expires.toGMTString() : "") +
        ((options.path) ? "; path=" + options.path : "") +
        ((options.domain) ? "; domain=" + options.domain : "") +
        ((options.secure) ? "; secure" : "");
        document.cookie = curCookie;
    };
}
function clearcache(lang){
    var name, v;
    for (var i = 0; i <= mycore.storage.getLength() - 1; i++) {
        name = mycore.storage.key(i);
        if ((/^readerplus\.theme_/.test(name)) || (/^readerplus\.rps_/.test(name)) || (/^readerplus\.cache/.test(name))) {
            mycore.storage.removeItem(name);
        }
    }
    alert(getTextPrefs(lang, 'global', 'cachecleared', 'en', "Cache cleared"));
}

function openWindow(o, cb){
    sendMessage("window", o, cb);
}

function sendMessage(message, o, callback){
    var a = clone(o) || {};
    a.message = message;
    var fns = ['onload', 'onreadystatechange', 'onerror'];
    for (var i = 0, len = fns.length; i < len; i++) {
        if (o[fns[i]]) {
            a[fns[i]] = true;
        }
    }
    mycore.extension.sendRequest(a, callback);
}


if (typeof GM_xmlhttpRequest === "undefined") {
    GM_xmlhttpRequest = function(o){
        o.method = (o.method) ? o.method.toUpperCase() : "GET";
        if (!o.url) {
            throw ("GM_xmlhttpRequest requires an URL.");
        }
        
        var om = o;
        sendMessage("request", om, function(a){
            if (a.message === (om.callback || "requestdone")) {
                if (a.action === "load") {
                    if (typeof om.onload == "function") {
                        om.onload(a, a.request);
                    }
                } else if (a.action === "readystatechange") {
                    if (typeof om.onreadystatechange == "function") {
                        om.onreadystatechange(a, a.request);
                    }
                } else if (a.action === "error") {
                    GM_log('error: ' + a.responseText);
                    if (typeof om.onerror == "function") {
                        om.onerror(a, a.request);
                    }
                }
            }
        });
        
    };
}
if (typeof GM_addStyle === "undefined") {
    function GM_addStyle(/* String */styles, id){
        var el;
        if (id) {
            el = document.getElementById(id);
        }
        if (!el) {
            el = document.createElement("style");
            el.setAttribute("type", "text\/css");
            if (id) {
                el.id = id;
            }
            el.appendChild(document.createTextNode(styles));
            document.getElementsByTagName("head")[0].appendChild(el);
        } else {
            //update
            el.innerText = styles;//textContent??
        }
        return el;
    }
}
if (typeof GM_addCss === "undefined") {
    function GM_addCss(css, id){
        var el = document.createElement("link");
        el.setAttribute("rel", "stylesheet");
        el.setAttribute("type", "text\/css");
        el.setAttribute("href", css);
        if (id) {
            el.id = id;
        }
        document.getElementsByTagName("head")[0].appendChild(el);
    }
}
if (typeof GM_addScript === "undefined") {
    function GM_addScript(script, remote, cb, cbonerror, scope, time){
        //var id = script.replace(/[\.:-_\/\\]/g, '');
        var id = script;
        var s = document.getElementById(id);
        if (s) {
            if (cbonerror && cb) {
                cb.call(this);
            }
        } else {
            if (remote) {
                GM_xmlhttpRequest({
                    method: 'get',
                    url: script,
                    onload: function(r){
                        if (remote === 'inline') {
                            GM_addjs(script, true, id, cb, scope, time);
                        } else {
                            eval(r.responseText);
                            if (cb) {
                                cb.call(scope || this);
                            }
                        }
                    },
                    onerror: function(r){
                        if (cbonerror && cb) {
                            cb.call(scope || this);
                        }
                        console.error('Error on loading Javascript ' + script);
                    }
                });
            } else {
                GM_addjs(script, false, id, cb, scope, time);
            }
        }
    }
    function GM_addjs(script, inline, id, cb, scope, time){
        var el = document.createElement("script");
        el.setAttribute("type", "text\/javascript");
        if (inline) {
            el.innerText = script;
        } else {
            el.setAttribute("src", script);
        }
        if (id) {
            el.setAttribute("id", id);
        }
        document.getElementsByTagName("head")[0].appendChild(el);
        if (cb) {
            window.setTimeout(function(){
                cb.call(scope || this);
            }, time || 500);
        }
    }
    /**
     * Pack for GM_addScript + check + callback
     * @param {Object} script
     * @param {Object} remote
     * @param {Object} check
     * @param {Object} cb
     * @param {Object} scope
     */
    function GM_loadScript(script, remote, check, cb, scope){
        function cbwait(){
            waitlib(check, cb, scope);
        }
        function cbonerror(){
            if (cb) {
                cb.call(scope || this);
            }
        }
        GM_addScript(script, remote, cbwait, cbonerror, scope);
    }
}
if (typeof GM_log === "undefined") {
    function GM_log(log){
        console.log(log);
    }
}
if (typeof GM_registerMenuCommand === "undefined") {
    function GM_registerMenuCommand(a, b){
        //
    }
}
if (typeof GM_openInTab === "undefined") {
    GM_openInTab = function(url, selected, search, index, windowId){
        //send request port to bg
        if (typeof selected == "undefined") {
            selected = true;
        }
        var data = {
            message: 'opentab',
            url: url,
            search: search || url,
            selected: selected,
            index: index,
            windowId: windowId
        };
        mycore.extension.sendRequest(data);
    };
}
if (typeof unsafeWindow === "undefined") {
    unsafeWindow = window;
}
if (typeof(this['clone']) !== 'function') {
    clone = function(o){
        try {
            return eval(uneval(o));
        } catch (e) {
            throw (e);
        }
    };
}
/**
 * uneval for prefetch !!
 */
if (typeof(this['uneval']) !== 'function') {
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var protos = [];
    var char2esc = {
        '\t': 't',
        '\n': 'n',
        '\v': 'v',
        '\f': 'f',
        '\r': '\r',
        '\'': '\'',
        '\"': '\"',
        '\\': '\\'
    };
    var escapeChar = function(c){
        if (c in char2esc) 
            return '\\' + char2esc[c];
        var ord = c.charCodeAt(0);
        return ord < 0x20 ? '\\x0' + ord.toString(16) : ord < 0x7F ? '\\' + c : ord < 0x100 ? '\\x' + ord.toString(16) : ord < 0x1000 ? '\\u0' + ord.toString(16) : '\\u' + ord.toString(16);
    };
    var uneval_asis = function(o){
        return o.toString();
    };
    /* predefine objects where typeof(o) != 'object' */
    var name2uneval = {
        'boolean': uneval_asis,
        'number': uneval_asis,
        'string': function(o){
            return '\'' +
            o.toString().replace(/[\x00-\x1F\'\"\\\u007F-\uFFFF]/g, escapeChar) +
            '\'';
        },
        'undefined': function(o){
            return 'undefined';
        },
        'function': uneval_asis
    };
    var uneval_default = function(o, np){
        var src = []; // a-ha!
        for (var p in o) {
            if (!hasOwnProperty.call(o, p)) 
                continue;
            src[src.length] = uneval(p) + ':' + uneval(o[p], 1);
        }
        // parens needed to make eval() happy
        return np ? '{' + src.toString() + '}' : '({' + src.toString() + '})';
    };
    uneval_set = function(proto, name, func){
        protos[protos.length] = [proto, name];
        name2uneval[name] = func || uneval_default;
    };
    uneval_set(Array, 'array', function(o){
        var src = [];
        for (var i = 0, l = o.length; i < l; i++) 
            src[i] = uneval(o[i]);
        return '[' + src.toString() + ']';
    });
    uneval_set(RegExp, 'regexp', uneval_asis);
    uneval_set(Date, 'date', function(o){
        return '(new Date(' + o.valueOf() + '))';
    });
    var typeName = function(o){
        // if (o === null) return 'null';
        var t = typeof o;
        if (t != 'object') 
            return t;
        // we have to lenear-search. sigh.
        for (var i = 0, l = protos.length; i < l; i++) {
            if (o instanceof protos[i][0]) 
                return protos[i][1];
        }
        return 'object';
    };
    uneval = function(o, np){
        // if (o.toSource) return o.toSource();
        if (o === null) 
            return 'null';
        var func = name2uneval[typeName(o)] || uneval_default;
        return func(o, np);
    };
}
/*
 * Entries
 */
var stackFeatures = [], externals = [];
function registerFeature(fn, bid, params){
    params = params || {};
    params.bid = 'e' + bid;
    stackFeatures.push({
        fn: fn,
        params: params
    });
    if (params && params.loader) {
        if (isArray(params.loader)) {
            externals = externals.concat(params.loader);
        } else {
            externals.push(params.loader);
        }
    }
    if (params && params.globalFn) {
        params.globalFn.call(this);
    }
}

function execAll(el, entry, mode, force){
    window.setTimeout(function(){
        execAllOffset(el, entry, mode, force);
    }, 400);
}

function execAllOffset(el, entry, mode, force){
    for (var i = 0, len = stackFeatures.length; i < len; i++) {
        var p = stackFeatures[i].params;
        if (el) {
            //ListView-opened + ExpandedView
            if (!isTagged(el, p.bid)) {
                stackFeatures[i].fn.call(this, el, entry, mode);
            }
        } else {
            //ListView-closed
            if (p && p.onlistviewtitle) {
                //only for favcions (onlistviewtitle=true)
                if (force || !isTagged(entry.firstChild, p.bid)) {
                    stackFeatures[i].fn.call(this, el, entry, mode);
                }
            }
        }
    }
}

function monitorEntries(el){
    var root = el || get_id('entries');
    root.addEventListener('DOMNodeInserted', function(e){
        checkEntry(e.target, execAll);
    }, false);
    catchAllEntries(execAll);
    loadExternal(function(){
        catchAllEntries(execAll);
    });
}

function loadExternal(cb){
    var ext = {};
    if (externals && externals.length > 0) {
        for (var i = 0, len = externals.length; i < len; i++) {
            var o = externals[i];
            ext[i] = o;
            if (typeof o === "function") {
                o.call(this, function(){
                    delete ext[i];
                    if (ext.length === 0) {
                        cb();
                    }
                });
            } else if (typeof o === "string") {
                GM_addScript(o, true);
            }
        }
    } else {
        cb();
    }
}

/*
 //ListView
 entry
 -collapsed
 if open{
 -entry-container
 -entry-comments
 -entry-actions
 }
 //ExpandedView
 entry
 -card card-common
 --card-content
 --card-comments
 --card-actions card-bottom
 ---entry-actions
 //ListView -closed
 DIV.hidden
 DIV.
 DIV.entry entry-0(*)
 //ListView -opened
 DIV.entry-container
 DIV.entry-comments
 DIV.entry-actions(*)
 DIV.entry-title-maximize
 //ExpandedView
 DIV.entry entry-0(*)
 DIV.entry-title-maximize
 */
function checkEntry(el, fn, params){
    if (el.tagName == "DIV") {
        if (hasClass(el, 'entry')) {
            if (hasClass(el.firstChild, 'card')) {
                // *********** Expanded view
                //var ea = getFirstElementByClassName(el, 'entry-actions');
                var ea = el.firstChild.lastChild.firstChild;
                //console.log("Run as ExpandedView for "+el.tagName + "." + el.className);
                catchEntry(el, ea, fn, params, false);
            } else {
                // *********** Closed article in List view
                //console.log("Run as ListView-closed for "+el.tagName + "." + el.className);
                catchEntry(el, false, fn, params, true);
            }
        } else if (hasClass(el, 'entry-actions')) {
            // *********** Expand article in List view
            //console.log("Run as ListView-opened for "+el.tagName + "." + el.className);
            var entry = findParentNode(el, 'div', 'entry');
            catchEntry(entry, el, fn, params, true, true);
        }
    }
}

function filterEntry(entry, rx){
    var o = getEntryLink(entry);
    return (rx && (rx.test(o.url) || (o.feed && rx.test(o.feed))));
}

function getRegex(urls){
    if (!urls || urls.length == 0) {
        return false;
    }
    var escaped = [];
    for (var i = 0, len = urls.length; i < len; i++) {
        if (urls[i]) {
            escaped.push(encodeRE(urls[i]));
        }
    }
    return new RegExp(escaped.join("|"), "i");
}

function forAllEntries(fn){
    var root = get_id('entries');
    //var entries = getElementsByClazzName('entry', 'div', root);
    var entries = root.getElementsByClassName('entry');
    for (var i = 0; i < entries.length; i++) {
        fn.call(this, entries[i]);
    }
}

function catchAllEntries(fn, params){
    forAllEntries(function(entry){
        checkEntry(entry, fn, params);
    });
}

function catchEntry(entry, el, fn, params, listview, force){
    //var mode = getMode(entry);
    var mode = (listview) ? 'list' : 'expanded';
    fn.call(this, el, entry, mode, force);
}

/*
 * Side bar
 */
function initCatchSidebars(fn, bid){
    document.body.addEventListener('DOMNodeInserted', function(e){
        catchSidebarAdded(e, fn, bid);
    }, false);
    catchAllSidebars(fn, bid);
}

function catchSidebarAdded(e, fn, bid){
    var el = e.target;
    //console.log("catchSidebarAdded > "+el.tagName + "." + el.className);
    if (el.tagName == "LI" && hasClass(el, 'sub')) {
        fn.call(this, el);
    } else if (el.tagName == "LI" && hasClass(el, 'folder') && (el.parentNode.id === 'sub-tree')) {
        catchAllSidebars(fn, bid);
    }
}

function forAllSidebars(fn){
    var root = document.getElementById('nav');
    var links = getElementsByClazzName('sub', 'li', root);
    for (var i = 0; i < links.length; i++) {
        fn.call(this, links[i]);
    }
}

function catchAllSidebars(fn, bid){
    forAllSidebars(function(el){
        catchSidebarAdded({
            target: el
        }, fn, bid);
    });
}

function getMode(entry){
    if (entry) {
        return hasClass(entry.firstChild, 'collapsed') ? 'list' : 'expanded';
    } else {
        return hasClass(get_id('view-cards'), 'link-selected') ? 'expanded' : 'list';
    }
}

function getOriginalEntryLink(entry){
    return getFirstElementByClassName(entry, 'entry-title-link');
}

function getEntrySiteTitle(ent){
    var entry = ent || getCurrentEntry();
    var point, match;
    //var mode = getMode(entry);
    //if (mode === 'collapsed') {
    point = getFirstElementByClassName(entry, 'entry-source-title');//'span'
    if (!point) {
        point = getFirstElementByClassName(entry, 'entry-source-title');//'a'
    }
    if (point) {
        match = point.textContent;
    }
    return match;
}

function getEntryLink(ent){
    //<a class="ilink entry-title-link" href="#" title="Open as preview [q]"> Il écope de 5 ans pour avoir parlé de sexe à la télé</a>
    //<a class="entry-title-link iframe title-link-url" target="_blank" href="http://www.lessentiel.lu/news/monde/story/17066269" title="Open in a new window"><div class="entry-title-maximize"></div></a>	
    var o = {
        feed: ''
    }, entry = ent || getCurrentEntry();
    var link = getFirstElementByClassName(entry, 'grp-link-url');//'a'
    if (!link) {
        //Normal way
        link = getFirstElementByClassName(entry, 'entry-title-link');//'a'
        if (link) {
            o.url = link.href;
            o.link = link;
            o.title = link.textContent;
            o.eltitle = link;
            
        } else {
            //Feed from html (non RSS page)
            var etitle = getFirstElementByClassName(entry, 'entry-title');//'h2'
            if (etitle) {
                var m = /"(.*)"/.exec(etitle.textContent);
                o.url = '';
                if (m) {
                    o.url = m[0];
                }
                o.title = etitle.textContent;
                o.eltitle = etitle;
                o.link = null;
            }
        }
    } else {
        //preview on 
        var link2 = getFirstElementByClassName(entry, 'grp-link-title');//'a'
        o = {
            title: link2.textContent,
            eltitle: link2,
            url: link.href,
            link: link
        };
    }
    //
    o.feed = getFeedEntry(entry);
    
    return o;
}

function getFeedEntry(entry){
    var url;
    var est = getFirstElementByClassName(entry, 'entry-source-title');//'a'
    //TODO/ listview=span but no href (could we use text label to match in nav tree?)
    if (est && est.href) {
        url = decodeURIComponent(est.href.replace(/^.*?view\/feed\//, ''));
        if (!url) {
            //Find using current selected nav item 
            var nav = get_id('nav'), tls = getFirstElementByClassName(nav, 'tree-link-selected');//'a'
            if (tls) {
                url = decodeURIComponent(tls.href.replace(/^.*?view\/feed\//, ''));
            }
        }
    }
    
    return url;
}

function openEntryInNewTab(entry, selected){
    var link = getEntryLink(entry);
    var url = link.url;
    GM_openInTab(url, selected);
}

function getCurrentEntry(){
    return document.getElementById('current-entry');
}

function selectCurrentEntry(el){
    if (el) {
        var cur = getCurrentEntry();
        if (cur) {
            delete cur.id;
        }
        el.id = 'current-entry';
    }
}

function getEntry(e){
    var el = (e && e.target) ? e.target : (e.localName ? e : null);
    var entry;
    if (el) {
        entry = findParentNode(el, 'div', 'entry');
    }
    if (!entry) {
        entry = getCurrentEntry();
    }
    return entry;
}

function jump(entry, dirtop){
    if (!entry) {
        return false;
    }
    var entries = get_id('entries');
    var height = parseInt(entries.style.height.replace('px', ''), 10);
    var top = 0;
    if (dirtop) {
        top = entry.offsetTop; // - height;
    } else {
        top = entry.offsetTop + entry.offsetHeight - height;
    }
    if (top >= 0) {
        entries.scrollTop = top;
    }
}

function getWidthEntries(){
    var entries = get_id('entries');
    return entries.clientWidth;
}

function getHeightEntries(alone){
    var height = 500;
    var entries = get_id('entries');
    if (entries) {
        var offset = 0;
        if (!alone) {
            var eb = getFirstElementByClassName(entries, 'entry-body');
            if (eb) {
                offset += eb.offsetTop;
            }
            var ea = getFirstElementByClassName(entries, 'entry-actions');
            if (ea) {
                offset += ea.clientHeight;
            }
            offset = Math.max(110, offset);
        }
        height = parseInt(entries.style.height.replace('px', ''), 10) - offset;
    }
    return height;
}

function getBody(entry){
    var body = getFirstElementByClassName(entry, 'item-body');//div
    // why a sub body sometimes ??
    if (body) {
        var subbody = getFirstElementByClassName(body, 'item-body');//div
        if (subbody) {
            body = subbody;
        }
    } else {
        //get Snippet in list view
        body = getFirstElementByClassName(entry, 'snippet');
    }
    return body;
}

function getEntryBody(body){
    var entryBody = getFirstElementByClassName(body, 'entry-enclosure');//div
    if (!entryBody) {
        entryBody = getFirstElementByClassName(body, 'item-body');//div
    }
    return entryBody;
}

function initResize(fn){
    window.addEventListener('resize', function(e){
        if (typeof fn === "function") {
            fn.call(this);
        }
    }, false);
}

function addButton(reference, text, title, fn, position){
    position = position || 0;
    var div = document.createElement('div');
    div.style.marginLeft = '0.5em';
    div.className = 'goog-button goog-button-base unselectable goog-inline-block goog-button-float-left goog-button-tight';
    div.setAttribute('tabindex', '0');
    if (title) {
        div.setAttribute('title', title);
    }
    div.setAttribute('role', 'wairole:button');
    div.innerHTML = '<div class="goog-button-base-outer-box goog-inline-block"><div class="goog-button-base-inner-box goog-inline-block"><div class="goog-button-base-pos"><div class="goog-button-base-top-shadow">&nbsp;</div><div class="goog-button-base-content"><div class="goog-button-body">' + text + '</div></div></div></div></div>';
    if (position == 1) {
        //after
        if (reference.nextSibling) {
            reference.parentNode.insertBefore(div, reference.nextSibling);
        } else {
            //last item
            reference.parentNode.appendChild(div);
        }
    } else if (position == 2) {
        //before
        reference.parentNode.insertBefore(div, reference);
    } else {
        //append
        reference.appendChild(div);
    }
    var me = this;
    div.addEventListener('click', function(e){
        fn.call(me);
    }, false);
}

function onKey(cls, fn){
    var entry = getCurrentEntry();
    var btn = getFirstElementByClassName(entry, cls);//'span'
    fn.call(this, btn, entry);
}

function addBottomLink(el, text, title, script, cls, button, callback, locked, entry, mode){
    var span = document.createElement('span');
    span.className = 'btn-' + script + ' ' + cls + (button ? ' read-state-not-kept-unread read-state' : '') + ' link unselectable';
    span.innerHTML = text;
    span.title = title;
    el.appendChild(span);
    var lcked = locked;
    function onClick(e){
        var btn = e.target;
        var entry = findParentNode(el, 'div', 'entry');
        callback(btn, entry, lcked, e);
    }
    span.addEventListener('click', onClick, false);
    if (locked) {
        //activate it
        if (callback) {
            callback(span, entry, true);
        }
    }
}

function isActive(btn, entry, cls, locked){
    var active = false;
    if (locked || !hasClass(btn, 'read-state-kept-unread')) {
        addClass(entry, cls);
        if (btn) {
            toggleClass(btn, 'read-state-not-kept-unread', 'read-state-kept-unread');
        }
        active = true;
    } else {
        removeClass(entry, cls);
        if (btn) {
            toggleClass(btn, 'read-state-kept-unread', 'read-state-not-kept-unread');
        }
        active = false;
    }
    return active;
}

function isTagged(entry, cls){
    var tagged = entry.getAttribute(cls);
    if (!tagged) {
        entry.setAttribute(cls, 'true');
    }
    return tagged;
}

function formatShortcut(script, shortcut, prefs){
    var t = '';
    if (prefs) {
        //var key = prefs[script + '-key-' + shortcut];
        var key = getShortcutKey(script, shortcut, prefs);
        if (key) {
            t = formatKey(key);
            if (t) {
                t = ' [' + t + ']';
            }
        }
    }
    return t;
}

function getShortcutKey(script, shortcut, prefs){
    var key, keyhash = prefs[script + '_key_' + shortcut];
	if (keyhash && typeof keyhash === 'object' && keyhash.key) {
		key = keyhash.key;
	}else if (keyhash && typeof keyhash === 'string') {
		key = unmarshallKey(keyhash);
    } else {
        try {
            var s = getScriptObject(script);
            key = s.shortcuts[shortcut];
        } catch (e) {
            console.error("Failed to get default shortcut " + shortcut + " for script " + script);
        }
    }
    return key;
}

function getScriptObject(id){
    return GRP.scripts[id];
}

function toggle(el){
    if (!el.style.display) {
        hide(el);
    } else {
        show(el);
    }
}

function createMenu(items){
    var menu = document.createElement('div');
    menu.className = "goog-menu goog-menu-vertical";
    menu.style = "-moz-user-select: none; left: 228px; top: 20.1px; max-height: 300px;";
    menu.role = "menu";
    //menu['aria-haspopup']=true;
    menu.tabindex = -1;
    menu.id = "stream-prefs-menu-menu";
    addMenuItems(menu, items);
}

function addMenuItems(menu, items){
    var item, i, len, html = '';
    var tplInner = '<div class="goog-menuitem-content"><div class="goog-menuitem-checkbox"></div>{text}</div>';
    for (i = 0, len = items.length; i < len; i++) {
        item = items[i];
        var el = document.createElement('div');
        addClass(el, 'goog-menuitem goog-option ' + ((item.selected) ? 'goog-option-selected' : ''));
        el.role = "menuitem";
        el.style = "-moz-user-select: none;";
        el.id = ':grp' + i;
        el.innerHTML = fillTpl(tplInner, item);
        var callback = function(){
            item.fn.call(el, [item, el]);
        };
        el.addEventListener('click', callback, false);
    }
}

function addReaderMenuItem(text, cb, checkbox){
    var html = text;
    GM_addStyle('.grp-menu{background: transparent url(/reader/ui/3607832474-entry-action-icons.png) no-repeat;padding: 1px 8px 1px 16px;}' +
    '.grp-menu-checked{background-position:-80px -160px;}' +
    '.grp-menu-unchecked{background-position:-64px -128px;}', 'grp_menusettings');
    
    if (checkbox) {
        html = '<span class="grp-menu grp-menu-unchecked">' + text + '</span>';
    }
    
    dh('gbg', 'a', {
        href: '#',
        cls: 'gb2',
        html: html
    }, {
        click: function(e){
            if (checkbox) {
                var span = e.target;
                addClassIf(span, 'grp-menu-checked', 'grp-menu-unchecked');
            }
            cb(e);
        }
    });
}

function toggleCheckMenu(el){
    addClassIf(el, 'goog-option-selected');
}

function getLanguage(){
    var m, lang = 'en';
    var cookie = readCookie('GRLD') || '';
    if (cookie !== '') {
        //GRLD Not visible !!
        m = /((\w+)-(\w+)):\d+/.exec(cookie);
        if (m) {
            lang = m[2];//en
            //lang = m[1];en-US
        }
    } else {
        cookie = readCookie('PREF') || '';
        //855ba6572:LD=en:CR=2:TM=12
        m = /:LD=(\w+):/.exec(cookie);
        if (m) {
            lang = m[1];//en
        }
    }
    return lang;
}

function getSelectedDir(node){
    var o = {
        url: ''
    };
    //a.tree-link-selected
    var el = node || getFirstElementByClassName(document, 'tree-link-selected');
    if (el) {
        o = {
            text: getElementText(el, 'name-text'),
            count: getElementText(el, 'unread-count').replace(/[\(\)]/g, ''),
            url: el.href
        };
    } else {
        //div.selector.selected
        el = getFirstElementByClassName(document, 'selected');
        if (el) {
            o = {
                text: getElementText(el, 'text', false, true),
                count: getElementText(el, 'unread-count').replace(/[\(\)]/g, ''),
                url: el.href
            };
        }
    }
	if (o.url) {
		o.url = o.url.replace('/reader/view', '');
	}
    return o;
}

function getMetadata(){
    var s = document.head.getElementsByTagName('script')[0];
    var c = s.innerHTML;
    var m, re = /([_A-Z]+)\s+=\s+([^,]+),/g;
    var metadata = {};
    while ((m = re.exec(c)) !== null) {
        metadata[m[1]] = m[2].replace(/^"|"$/g, '');
    }
    return metadata;
}


/*
 * Various useful methods
 */
function sublime_update(){
    //hide searh
    var s = get_id('search');
    hide(s);
    s.addEventListener('click', function(e){
        e.stopPropagation();
    }, false);
    //new search
    dh(false, 'searchicon', {
        id: 'searchicon',
        html: 'SEARCH'
    }, {
        click: function(){
            toggle(s);
        }
    });
}

function showallfolders(){
    var saf = 'grp_showallfolders';
    var elsaf = get_id(saf);
    if (elsaf) {
        remove(elsaf);
    } else {
        GM_addStyle('.folder li{display:block !important;}', saf);
    }
}

function removeReadItems(ent, deleteMarkAsRead){
    var currentry = ent || getCurrentEntry();
	
	if (deleteMarkAsRead) {
		var entries = get_id('entries');
		var items = entries.getElementsByClassName('read');
		foreach(items, function(item){
			if (item && currentry !== item) {
				console.log('remove ' + item.className);
				remove(item);
			}
		});
	} else {
		entry = currentry.previousSibling;
		while (entry) {
			var prev = entry.previousSibling;
			console.log('Remove ' + entry.className)
			remove(entry);
			entry = prev;
		}
	}
	setTimeout(function(){
    	jump(currentry, true);
	},200);
}

function markallasread(entry, since){
        console.log('entry: ' + entry.className);
        var url, text;
        var a = getFirstElementByClassName(entry, 'entry-source-title');//a
        if (a) {
            console.log('entry-source-title: ' + a.href);
            url = 'feed/' + (decodeURIComponent(a.href).replace(/.*?\/feed\//, ''));
            //url = 'feed/' + (a.href.replace(/.*?\/feed\//, ''));
            text = a.innerText;
        } else {
            //No link found -> get from nav
            var d = getSelectedDir();
            text = d.text;
        }
        var domain = getDomain(window.location.href, true);
        var metadata = getMetadata();
        console.log('_COMMAND_TOKEN: ' + metadata._COMMAND_TOKEN);
        console.log('url: ' + url);
        console.log('text: ' + text);
        console.log('domain: ' + domain);
        var params = {
            T: metadata._COMMAND_TOKEN,
            s: url,
            t: text,
            ts: 1000 * (new Date()).getTime() + 999 //since
        };
        var urlpost = domain + '/reader/api/0/mark-all-as-read';
        console.log('url: ' + urlpost);
        console.log('params: ' + JSON.stringify(params));
        GM_xmlhttpRequest({
            method: 'post',
			injected:true,
            headers: {
                Origin: domain,
                Referer: domain + '/reader/view/'
            },
            url: urlpost,
            parameters: params,
            onload: function(r){
				if (r.status == 200 && r.responsText === 'OK') {
                    console.log('Mark all as read done');
                } else {
                    console.error(r);
                    alert(r.status + ':' + r.statusText);
                }
            },
            onerror: function(r){
                console.error(r);
                alert(r.status + ':' + r.statusText);
            }
        });
    }/**
 * @author Valente
 */
function getText(lang, script, option, deflang, deftext){
    var text = '';
    if (GRP.langs[lang] && GRP.langs[lang].texts[script] && GRP.langs[lang].texts[script][option]) {
        text = GRP.langs[lang].texts[script][option];
    }
    if (!text && deflang) {
        text = getText(deflang, script, option, false, deftext);
    }
    if (!text && !deflang) {
        text = deftext || '';
    }
    return text;
}

function getCategory(lang, name, deflang){
    var text = '';
    if (GRP.langs[lang] && GRP.langs[lang].categories && GRP.langs[lang].categories[name]) {
        text = GRP.langs[lang].categories[name];
    }
    if (!text && deflang) {
        text = getCategory(deflang, name);
    }
    if (!text && !deflang) {
        text = name.toMaj();
    }
    return text;
}


function getTextPrefs(lang, script, option, deflang, deftext){
    var text = '';
    if (GRP.langs[lang] && GRP.langs[lang].prefs[script] && GRP.langs[lang].prefs[script][option]) {
        text = GRP.langs[lang].prefs[script][option];
    }
    if (!text && deflang) {
        text = getTextPrefs(deflang, script, option, false, deftext);
    }
    if (!text && !deflang) {
        text = deftext || '';
    }
    return text;
}


function autoTranslate(name){
    var params = urlDecode(window.location.search.substring(1));
    var lang = params.lang || 'en';
    loadLangs(lang, function(){
        translatePage(lang, name);
    });
}

/*
 //Dynamical translation (too complex ; not useful)
 function onLang(){
 var lang = get_id('language_lang').value;
 loadLangs(lang, function(){
 translatePage(lang, 'cat', 'categories',0);
 translatePage(lang);
 });
 }
 */
function translatePage(lang, name, section, level){
    section = section || 'prefs';
    var translations = GRP.langs[lang][section];
    if (translations) {
        function replaceTexts(name, texts){
            for (var key in texts) {
                var id = 't_' + ((name === 'global') ? '' : (name + '_')) + key;
                var el = document.getElementById(id);
                if (el) {
                    var text = texts[key];
                    if (/^val-/.test(key)) {
                        el.value = text;
                    } else {
                        el.innerHTML = text;
                    }
                }
            }
        }
        if (name) {
            var texts = (level == 0) ? translations : translations[name];
            replaceTexts(name, texts);
        } else {
            for (var nam in translations) {
                var texts = translations[nam];
                replaceTexts(nam, texts);
            }
        }
    }
}

function getAllTexts(){
    var texts = getElements("//*[starts-with(@id, 't_')]");
    var translations = {};
    for (var i = 0, len = texts.length; i < len; i++) {
        var id = texts[i].id;
        var o = splitId(id);
        
        var text = texts[i].innerHTML;
        text = text.replace(/\n/g, '');
        if (!translations[o.name]) {
            translations[o.name] = {};
        }
        translations[o.name][o.key] = text.trim();
    }
    //document.write("<!--" + JSON.stringify(translations) + "-->");
}

function splitId(id){
    var key, name;
    var m = id.split('_');
    if (m.length == 2) {
        name = 'global';
        key = m[1];
    } else {
        name = m[1];
        m.shift();
        m.shift();
        key = m.join('_');
    }
    return {
        key: key,
        name: name
    };
}

function loadLangs(lang, cb, scope){
    //TODO: load json here instead evald js
    if (GRP.langs && GRP.langs[lang]) {
        merge(GRP, GRP.langs[lang]);
		if (cb) {
            cb.call(scope || this);
        }
    } else {
        GM_addScript('lang/' + lang + '/features.js', true, function(){
            GM_addScript('lang/' + lang + '/langs.js', true, function(){
                //override locale texts
                if (GRP.langs) {
                    merge(GRP, GRP.langs[lang]);
                }
                if (cb) {
                    cb.call(scope || this);
                }
            }, true);
        }, true);
    }
}
/**
 * @author Valente
 */
var GUID_CORE = mycore.getGUID(), 
GUID_CORE_PROD = 'hhcknjkmaaeinhdjgimjnophgpbdgfmg', 
GUID_ICON = 'ecpcafinfpjgabomoamkhkgnpgpmdmeo',
LOCALPATH = mycore.getLocalPath();

if (GUID_CORE!==GUID_CORE_PROD){
	GUID_ICON = 'cgpgjbahhnkejmclppnpkcoildokbmem';
}

function call_icon(message, options, callback){
	external_call(GUID_ICON, message, options, callback);
}
function call_core(message, options, callback){
	external_call(GUID_CORE, message, options, callback);
}
function external_call(guid, message, options, callback){
    //console.log('CORE external_call ['+message+'] to '+guid);
	var emptyFn = function(){
    };
    mycore.extension.sendRequest(guid, 
    {
        message: message,
		keypass: "##ReaderPlus",
        options: options || {}
    }, callback || emptyFn);
}

/*************************************************
**  jQuery Masonry version 1.2.0
**  copyright David DeSandro, licensed GPL & MIT
**  http://desandro.com/resources/jquery-masonry
**************************************************/
;(function($){  

    /*!
     * smartresize: debounced resize event for jQuery
     * http://github.com/lrbabe/jquery-smartresize
     *
     * Copyright (c) 2009 Louis-Remi Babe
     * Licensed under the GPL license.
     * http://docs.jquery.com/License
     *
     */
    var event = $.event,
    	resizeTimeout;

    event.special[ "smartresize" ] = {
    	setup: function() {
    		$( this ).bind( "resize", event.special.smartresize.handler );
    	},
    	teardown: function() {
    		$( this ).unbind( "resize", event.special.smartresize.handler );
    	},
    	handler: function( event, execAsap ) {
    		// Save the context
    		var context = this,
    			args = arguments;

    		// set correct event type
            event.type = "smartresize";

    		if(resizeTimeout)
    			clearTimeout(resizeTimeout);
    		resizeTimeout = setTimeout(function() {
    			jQuery.event.handle.apply( context, args );
    		}, execAsap === "execAsap"? 0 : 100);
    	}
    };

    $.fn.smartresize = function( fn ) {
    	return fn ? this.bind( "smartresize", fn ) : this.trigger( "smartresize", ["execAsap"] );
    };



    // masonry code begin
    $.fn.masonry = function(options, callback) { 

        function getBricks(props, opts) {
            props.$bricks = opts.itemSelector == undefined ?
                        opts.$brickParent.children() :
                        opts.$brickParent.find(opts.itemSelector);
        }

        function placeBrick($brick, setCount, setY, setSpan, props, opts) {
            var shortCol = 0;
            
            for ( i=0; i < setCount; i++ ) {
                if ( setY[i] < setY[ shortCol ] ) shortCol = i;
            }
            
            var position = {
                left: props.colW * shortCol + props.posLeft,
                top: setY[ shortCol ]
            };


            if( props.masoned && opts.animate ) {
                $brick.animate( position, {
                    duration: opts.animationOptions.duration, 
                    easing: opts.animationOptions.easing,
                    complete: opts.animationOptions.complete,
                    step: opts.animationOptions.step,
                    queue: opts.animationOptions.queue,
                    specialEasing: opts.animationOptions.specialEasing
                });
            } else {
                $brick.css(position);
            }

            for ( i=0; i < setSpan; i++ ) {
                props.colY[ shortCol + i ] = setY[ shortCol ] + $brick.outerHeight(true) ;
            }
        };


        function masonrySetup($wall, opts, props) {
             getBricks(props, opts);

            if ( opts.columnWidth == undefined) {
                props.colW = props.masoned ?
                        $wall.data('masonry').colW :
                        props.$bricks.outerWidth(true);
            } else {
                props.colW = opts.columnWidth;
            }

            props.colCount = Math.floor( $wall.width() / props.colW ) ;
            props.colCount = Math.max( props.colCount, 1 );
        };


        function masonryArrange($wall, opts, props) {
            // if masonry hasn't been called before
            if( !props.masoned ) $wall.css( 'position', 'relative' );            
            
            if ( !props.masoned || opts.appendedContent != undefined ) {
                // just the new bricks
                props.$bricks.css( 'position', 'absolute' );
            }

            // get top left position of where the bricks should be
            var cursor = $('<div />');
            $wall.prepend( cursor );
            props.posTop =  Math.round( cursor.position().top );
            props.posLeft = Math.round( cursor.position().left );
            cursor.remove();

            // set up column Y array
            if ( props.masoned && opts.appendedContent != undefined ) {
                // if appendedContent is set, use colY from last call
                props.colY = $wall.data('masonry').colY;
                
                /*
                *  in the case that the wall is not resizeable,
                *  but the colCount has changed from the previous time
                *  masonry has been called
                */
                for (i= $wall.data('masonry').colCount; i < props.colCount; i++) {
                    props.colY[i] = props.posTop;
                };
                
            } else {
                props.colY = [];
                for ( i=0; i < props.colCount; i++) {
                    props.colY[i] = props.posTop;
                }    
            }
            
            
            // layout logic
            if ( opts.singleMode ) {
                props.$bricks.each(function(){
                    var $brick = $(this);
                    placeBrick($brick, props.colCount, props.colY, 1, props, opts);
                });            
            } else {
                props.$bricks.each(function() {
                    var $brick = $(this);
                
                    //how many columns does this brick span
                    var colSpan = Math.ceil( $brick.outerWidth(true) / props.colW);
                    colSpan = Math.min( colSpan, props.colCount );

                    
                    if ( colSpan == 1 ) {
                        // if brick spans only one column, just like singleMode
                        placeBrick($brick, props.colCount, props.colY, 1, props, opts);
                    } else {
                        // brick spans more than one column

                        //how many different places could this brick fit horizontally
                        var groupCount = props.colCount + 1 - colSpan; 
                        var groupY = [0];
                        // for each group potential horizontal position
                        for ( i=0; i < groupCount; i++ ) {
                            groupY[i] = 0;
                            // for each column in that group
                            for ( j=0; j < colSpan; j++ ) {
                                // get the maximum column height in that group
                                groupY[i] = Math.max( groupY[i], props.colY[i+j] );
                            }
                        }
                
                        placeBrick($brick, groupCount, groupY, colSpan, props, opts);
                    }
                }); //        /props.bricks.each(function() {
            }  //         /layout logic
        
            // set the height of the wall to the tallest column
            props.wallH = 0;
            for ( i=0; i < props.colCount; i++ ) {
                props.wallH = Math.max( props.wallH, props.colY[i] );
            }
            var wallCSS = { height: props.wallH - props.posTop };
//wallCSS = {  };
            // $wall.height( props.wallH - props.posTop );
            if ( props.masoned && opts.animate ) {
                $wall.animate(wallCSS, {
                    duration: opts.animationOptions.duration, 
                    easing: opts.animationOptions.easing,
                    complete: opts.animationOptions.complete,
                    step: opts.animationOptions.step,
                    queue: opts.animationOptions.queue,
                    specialEasing: opts.animationOptions.specialEasing
                });
            } else {
                $wall.css(wallCSS);
            }

            // add masoned class first time around
            if ( !props.masoned ) $wall.addClass('masoned');

            // provide props.bricks as context for the callback
            callback.call( props.$bricks );
            
            // set all data so we can retrieve it for appended appendedContent
            //        or anyone else's crazy jquery fun
            $wall.data('masonry', props );


        }; //  /masonryArrange function


        function masonryResize($wall, opts, props) {
            props.masoned = $wall.data('masonry') != undefined;
            var prevColCount = $wall.data('masonry').colCount;
            masonrySetup($wall, opts, props);
            if ( props.colCount != prevColCount ) masonryArrange($wall, opts, props); 
        };


        /*
        *  let's begin
        *  IN A WORLD...
        */
        return this.each(function() {  

            var $wall = $(this);

            var props = $.extend( {}, $.masonry );

            // checks if masonry has been called before on this object
            props.masoned = $wall.data('masonry') != undefined;
        
            var previousOptions = props.masoned ? $wall.data('masonry').options : {};

            var opts =  $.extend(
                            {},
                            props.defaults,
                            previousOptions,
                            options
                        );  

            // should we save these options for next time?
            props.options = opts.saveOptions ? opts : previousOptions;

            //picked up from Paul Irish
            callback = callback || function(){};


            if ( props.masoned && opts.appendedContent != undefined ) {
                // if we're dealing with appendedContent
                opts.$brickParent = opts.appendedContent;
            } else {
                opts.$brickParent = $wall;
            }
            
            getBricks(props, opts);


            if ( props.$bricks.length ) {
                // call masonry layout
                masonrySetup($wall, opts, props);
                masonryArrange($wall, opts, props);
            
                // binding window resizing
                var resizeOn = previousOptions.resizeable;
                if ( !resizeOn && opts.resizeable ) {
                    $(window).bind('smartresize.masonry', function() { masonryResize($wall, opts, props); } );
                }
                if ( resizeOn && !opts.resizeable ) $(window).unbind('smartresize.masonry');
            } else {
                // brickParent is empty, do nothing, go back home and eat chips
                return this;
            }

        });        //        /return this.each(function()
    };            //        /$.fn.masonry = function(options)



    $.masonry = {
        defaults : {
            singleMode: false,
            columnWidth: undefined,
            itemSelector: undefined,
            appendedContent: undefined,
            saveOptions: true,
            resizeable: true,
            animate: false,
            animationOptions: {}
        },
        colW: undefined,
        colCount: undefined,
        colY: undefined,
        wallH: undefined,
        masoned: undefined,
        posTop: 0,
        posLeft: 0,
        options: undefined,
        $bricks: undefined,
        $brickParent: undefined
    };

})(jQuery);/**
 * @author Valente
 */
window.GRP={
	VERSION: "3.4.0",
	setVersion:function(text){
		var ver = document.getElementById('version');
		ver.innerHTML = (text||'') + GRP.VERSION;
	}
};
/**
 * @author Valente
 */
GRP.scripts = {
    general: {
        name: "General",
        category: 'main',
		status: 'updated',
        options: {
            secure: false,

			text_layout:{
                xtype: 'h'
            },
            topcurrent: false,
            floatactions: false,
			bottomup:false,
			currdir:true,
			icons:false,
            /*antisocial:true,*/

			text_pageicon:{
                xtype: 'h'
            },
			pageicon:true,
			
			text_toolbaricon: {
                xtype: 'h'
            },
			icontoolbar_add: {
                xtype: 'p',
                label: true
            },
			counter: true,
			counterinterval: 2,
			opendirect: false,
            icontoolbar_text: {
                xtype: 'p',
                label: true
            },
			
			text_private:{
                xtype: 'h'
            },
			stats:true,
            noupdatepopup: false,
			
			text_export:{
                xtype: 'h'
            },
            importexport_text: {
                xtype: 'p',
                label: true
            },
            preferences: {
                xtype: 'html',
                label: true,
                value: '<input id="ieprefs" class="ignore" type="text" size="30"/><input type="button" id="bimport" value="import" onclick="importprefs();"/><input type="button" id="bexport" value="export" onclick="exportprefs();"/>'
            }
        }
    },
    theme: {
        name: "Theme",
        category: 'theme',
        status: 'updated',
        options: {
            skin: '',
            noborder: false,
            mytheme: {
                xtype: 'p',
                label: true,
                parent: 'mytheme'
            },
            externaltheme: {
                value: '',
                values: {
                    none: '',
					gmail_chrome: 'Gmail Bold Blue',
					gmail_c: 'Gmail Classic',
					gmail_newblue: 'Gmail New Blue',
					gmail_coldshower: 'Gmail Cold Shower',
					gmail_steel: 'Gmail Steel',
					gmail_lightbright: 'Gmail Minimalist',
					gmail_greensky: 'Gmail Green Sky',
					gmail_lightsoft: 'Gmail Bubblegum',
					gmail_cherry: 'Gmail Cherry Blossom',
					gmail_nightshade: 'Gmail Night Shade',
					gmail_medsoft: 'Gmail marina',
					gmail_medred: 'Gmail dusk',
					gmail_darkwarm: 'Gmail sunset',
					gmail_greyrain: 'Gmail Silver Lining',
					gmail_contrastblack: 'Gmail Contrast Black',
					gmail_shiny: 'Gmail shiny',
					gmail_desk: 'Gmail Desk',
					gmail_tree: 'Gmail Tree',
					gmail_beach: 'Gmail Beach',
					gmail_mountains: 'Gmail Mountains',
					gmail_pebbles: 'Gmail pebbles',
					gmail_ocean: 'Gmail Summer ocean',
                    gmail_phantasea: 'Gmail Phantasea',
					gmail_graffiti: 'Gmail Graffiti',
					gmail_planets: 'Gmail Planets',
					gmail_gizmos: 'Gmail Zoozimps',
					gmail_candy: 'Gmail Candy',
					gmail_busstop: 'Gmail Bus Stop',
					gmail_ninja: 'Gmail Ninja',
					gmail_teahouse: 'Gmail Tea House',
		            gmail_terminal: 'Gmail Terminal',
					gmail_orcasisland: 'Gmail Orcas Island',
					gmail_highscore: 'Gmail Highscore',
					gmail_turf: 'Gmail Turf',
					gmail_lapinscretins: 'Gmail lapinscretins',
					gmail_assasinscreed2: 'Gmail assasinscreed2',				
/* editors_picks */
"editor_5478752472500006610":"Google, artist, Dale Chihuly, 01_chihuly_06.jpg","editor_5478752827007585634":"Google, artist, Dale Chihuly, 08_chihuly_02.jpg","editor_5478752842710333378":"Google, artist, Dale Chihuly, 10_chihuly_05.jpg","editor_5478753114195988130":"Google, artist, Dale Chihuly, 14_chihuly_01.jpg","editor_5478753075316627266":"Google, artist, Dale Chihuly, 12_chihuly_03.jpg","editor_5478753460334726146":"Google, artist, Dale Chihuly, 16_chihuly_07.jpg","editor_5478752501519603442":"Google, \u00a9 Jeff Koons, 04_koons_02.jpg","editor_5478753089633816370":"Google, \u00a9 Jeff Koons, 13_koons_01.jpg","editor_5478752819223180210":"Google, Polly Apfelbaum, 06_apfelbaum_01.jpg","editor_5478753117486370930":"Google, Polly Apfelbaum, 15_apfelbaum_03.jpg","editor_5478752835087677362":"Google, Polly Apfelbaum, 09_apfelbaum_02.jpg","editor_5478752493997894098":"Google, \u00a9 Tom Otterness, 03_otterness_02.jpg","editor_5478752822146891810":"Google, \u00a9 Tom Otterness, 07_otterness_03.jpg","editor_5478753058608504226":"Google, \u00a9 Tom Otterness, 11_otterness_01.jpg","editor_5480987905094465154":"Google, \u00a9 Kengo Kuma (???), kengo_kuma.jpg","editor_5480987906200029490":"Google, \u00a9 Tord Boontje, tord_boontje.jpg","editor_5480998621006856338":"Google, \u00a9 Kwon, Ki-soo (???), ki_soo_kwon.jpg","editor_5480987916726984130":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_01.jpg","editor_5480987917979934498":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_02.jpg","editor_5480987925727076290":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_03.jpg","editor_5480988005113749330":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_04.jpg","editor_5480988012864676114":"Google, \u00a9 Yann Arthus-Bertrand, y_a_b_05.jpg","editor_5478753466167683746":"Google, National Geographic Stock, natgeo_01.jpg","editor_5478753483552159554":"Google, National Geographic Stock, natgeo_02.jpg","editor_5478755559461692018":"Google, National Geographic Stock, natgeo_03.jpg","editor_5478755572322259650":"Google, National Geographic Stock, natgeo_04.jpg","editor_5478753799989312658":"Google, National Geographic Stock, natgeo_06.jpg","editor_5478753813630017442":"Google, National Geographic Stock, natgeo_07.jpg","editor_5478753819961634386":"Google, National Geographic Stock, natgeo_08.jpg","editor_5478752511525657170":"Google, National Geographic Stock, 05_natgeo_10.jpg","editor_5478753832267149810":"Google, National Geographic Stock, natgeo_09.jpg","editor_5480997862386069170":"Google, National Geographic Stock, NationalGeographic_1143826.jpg","editor_5480997893054118498":"Google, National Geographic Stock, NationalGeographic_1146940.jpg","editor_5480998186992651026":"Google, National Geographic Stock, NationalGeographic_1223429.jpg","editor_5478769425598313058":"Google, Blue, Color_Google_blue.jpg","editor_5478769428183578882":"Google, Green, Color_Google_green.jpg","editor_5478769428473291154":"Google, Grey, Color_Google_grey.jpg","editor_5478769530404012082":"Google, Red, Color_Google_red.jpg","editor_5478769535168997586":"Google, Yellow-Orange, Color_Google_yelloworange.jpg","editor_5480596593254567266":"Google, White, white-2000x1500.jpg",
/* public_gallery */
"public_5468005866288280370":"Google, EricasJoys/HorizontalMambo","public_5480525382039743330":"Google, 116086157836169916177/Favorites","public_5469661666160577106":"Google, 114728257341600814985/PicasaWebPublicPictures","public_5464847589870262818":"Google, juliantoledo/Best","public_5468620555541748930":"Google, bdowney/ClassicPlus","public_5465726438613138322":"Google, EricasJoys/HorizontalMambo","public_5480525372525642866":"Google, 116086157836169916177/Favorites","public_5468095309182211138":"Google, climent/Travels","public_5467968585789456354":"Google, max.braun/Homepage","public_5467968606322662898":"Google, max.braun/Homepage","public_5394978350593597026":"Google, bluan01/JiuZhaiGouYellowDragonNationalParks","public_5468030760630111442":"Google, 109244757320221408388/Test2006","public_5461268259373019506":"Google, jclilot/Portfolio_Flowers","public_5418083111186176690":"Google, fkarpelevitch/200806","public_5465064542962429986":"Google, snoozy.koala/Images","public_5465267981519769410":"Google, magdalar/Backgrounds","public_5464637264209516562":"Google, brettw/Taiwan","public_5469816275349772930":"Google, max.braun/Homepage","public_5405276903498929458":"Google, jclilot/Portfolio_Nature","public_5464602659331416274":"Google, maeve.mara/FeaturedPhotos","public_5468081125425097026":"Google, michos.conradt/Public","public_5480525380508846738":"Google, 116086157836169916177/Favorites","public_5465064395281172466":"Google, snoozy.koala/Images","public_5427875955486466754":"Google, sandysroom/VerdugoNorthTraverse","public_5480525385832476034":"Google, 116086157836169916177/Favorites","public_5464721817854022450":"Google, mjwiacek/PhotosILike","public_5468499236979512002":"Google, uffishmpk/SelectedFavourites","public_5465811371224046274":"Google, 103752943986656263237/Night","public_5468499251879550482":"Google, uffishmpk/SelectedFavourites","public_5468011240643552594":"Google, sweth.c/ForGoogle","public_5464721917635140242":"Google, mjwiacek/PhotosILike","public_5465963404565598994":"Google, arendsf/ThomasFavoriteShared","public_5464886839716494226":"Google, mariusm/ILikeThese","public_5464644514748019778":"Google, simon.tong/Wallpapers","public_5465825398133839090":"Google, 103752943986656263237/Background","public_5467921205742594898":"Google, TenSafeFrogs/Favorites","public_5436863789388960962":"Google, marius.schilder/Trona","public_5464721845849026242":"Google, mjwiacek/PhotosILike","public_5467928286294729906":"Google, merciniebres/HelloWorld","public_5469782237294118322":"Google, peter.norvig/Pictures","public_5463830940035733394":"Google, mattgundersen/LandmarksOfTahoe","public_5470258900410180098":"Google, kevin.cantrell/PublicAlbum","public_5467976005541355106":"Google, romain.guy/Wallpapers","public_5467975931636282290":"Google, romain.guy/Wallpapers","public_5467936023478442338":"Google, TenSafeFrogs/Favorites","public_5468630655462131890":"Google, RussHaig/SFNightD40","public_5468499216650860930":"Google, uffishmpk/SelectedFavourites","public_5464708695072547106":"Google, pawliger/Homepage","public_5464721937652197202":"Google, mjwiacek/PhotosILike","public_5464593346215231826":"Google, arendsf/ThomasFavoriteShared"
					
},
                xtype: 'select',
                parent: 'mytheme'
            },
			color: {
                value: '#565656',
                xtype: 'picker',
                parent: 'mytheme'
            },
            bg: {
                value: '#FFC',
                xtype: 'picker',
                parent: 'mytheme'
            },
			imgsbg: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgrbg: {
                value: '',
                size: 80,
                parent: 'mytheme'
            },imgrh: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgh: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imghr: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imghl: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgrf: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgf: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgfr: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, imgfl: {
                value: '',
                size: 80,
                parent: 'mytheme'
            }, ncolumns: {
	            value: 2,
	            parent: 'portal'
	       }	
        }
    },
    ig: {
        name: "iGoogle Theme",
        category: 'theme',
        desc: "Use iGoogle Theme in your Google Reader (Beta)",
        options: {
            warning: {
                xtype: 'p',
                label: true,
                cls: 'warning center'
            },
            skin_name: {
                value: '',
                size: 80
            },
            skin_url: {
                value: '',
                size: 80
            },
            skin_id: {
                xtype: 'hidden'
            },
            /*debug: false,*/
            randomtime: true,
            userandomthemes: false,
            randomthemes: {
                value: 30,
                lcls: 'large'
            },
            themes: {
                xtype: 'html',
                label: true,
                value: '<div id="ig_themes"></div>'
            }
        },
        shortcuts: {
            'random': {
                id: 'random',
                title: 'Random theme',
                key: {
                    //82 r
                    keyCode: 82,
                    shiftKey: true
                }
            }
        }
    },
    relook: {
        name: "Relook",
        category: 'theme',
        desc: "Relook yourself GoogleReader using custom stylesheets",
        options: {
            resize: false,
            css: {
                xtype: 'textarea',
                cls: 'code',
                rows: 40,
                value: '/* This CSS sample alternates green entry, red border */\n/* green entry */\n.entry:nth-child(even) .card-common, \n.entry:nth-child(even) .card-actions, \n#entries .entry:nth-child(even) .collapsed {\n border:1px solid #FFACAC;\n}\n/* red border */\n.entry:nth-child(odd) .card-common, \n.entry:nth-child(odd) .card-actions, \n#entries .entry:nth-child(odd) .collapsed {\n background-color:#C4DFC0;\n}\n'
            }
        }
    },
    favicons: {
        name: "Favicons",
        category: 'icons',
        options: {
            providerpageicons: false,
            sidebaronly: false,
			cloud:true,
            custom: {
                xtype: 'p',
                label: true
            },
            domains: {
                xtype: 'crud'
            },
            tip: {
                xtype: 'p',
                label: true
            },
            manual: false,
            parsing: {
                xtype: 'p',
                label: true
            }
        }
    },
    unreadcount: {
        category: 'counter',
        name: "Show all unread count"
    },
    fixlayout: {
        category: 'layout',
        name: "Fix layout"
    },
    count: {
        category: 'counter',
        name: "Fix counter (1000+)"
    },
    counticon: {
        category: 'counter',
        name: "Icon counter"
    },
    removeads: {
        name: "Remove ads",
        category: 'content',
        options: {
            links: {
                xtype: 'textarea',
                value: "da\.feedsportal\.com|res\.feedsportal\.com|doubleclick\.net|/ads"
            },
            images: {
                xtype: 'textarea',
                value: "feedsportal\.com|doubleclick\.net|/ads"
            },
            iframes: {
                xtype: 'textarea',
                value: "feedsportal\.com|doubleclick\.net|googlesyndication\.com/pagead/ads"
            }
        }
    },
    column: {
        name: "Text multi columns",
        category: 'layout',
        options: {
            count: 3,
            /*maxcolumns:6,*/
            pagebreak: true,
			miniparas:5,
            locked: false,
            filter: {
                xtype: 'crud'
            }
        },
        shortcuts: {
            'columns': {
                id: 'columns',
                title: 'Multi columns',
                key: {
                    //67 c
                    keyCode: 67
                }
            }
        }
    },
    preview: {
        name: "Integrated preview",
        category: 'layout',
        options: {
            onicon: false,
            overlay: false,
            locked: false,
            filter: {
                xtype: 'crud'
            }
        },
        //shortcut: "shift+R",
        shortcuts: {
            'prview': {
                id: 'prview',
                title: 'Entry preview',
                key: {
                    //81 q
                    keyCode: 81
                }
            },
			'next': {
                id: 'next',
                title: 'Next preview',
                key: {
                    //81 q
                    keyCode: 81,
					shiftKey:true
                }
            },
			'previous': {
                id: 'previous',
                title: 'Previous preview',
                key: {
                    //81 q
                    keyCode: 81,
					ctrlKey:true
                }
            },
			'close': {
                id: 'close',
                title: 'Close preview',
                key: {
                    //88 x
                    keyCode: 88,
					shiftKey:true
                }
            }
        }
    },
    colorful: {
        name: "Colorful listview",
        category: 'layout',
        options: {
            tree: false,
            usebasecolor: false,
            background: {
                value: '#BCBCBC',
                xtype: 'picker'
            },
            color: {
                value: '#000000',
                xtype: 'picker'
            }
        }
    },
    filter: {
        name: "Filter entries",
        category: 'layout',
        options: {
            searchbody: false,
			excludes: {xtype:'textarea',list:true,cls:'xlist'},
			highlights: {xtype:'textarea',list:true,cls:'xlist'}
        }
    },
    readbymouse: {
        name: "Read by mouse",
        category: 'navigation'
    },
    facebook: {
        name: "Facebook integration",
        category: 'share',
        shortcuts: {
            'gofacebook': {
                id: 'gofacebook',
                title: 'Post on Facebook',
                key: {
                    //70 f
                    keyCode: 70
                }
            }
        }
    },
    twitter: {
        name: "Twitter integration",
        category: 'share',
        options: {
            shortener: {
                xtype: 'select',
                values: {
                    tinyurl: 'TinyUrl',
                    bitly: 'BitLy'
                }
            },
            shortener_bitly: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            shortener_login: {
                value: '',
                size: 20
            },
            shortener_apikey: {
                value: '',
                size: 30
            }
        },
        shortcuts: {
            'tweet': {
                id: 'tweet',
                title: 'Post on Twitter',
                key: {
                    //87 w
                    keyCode: 87
                }
            }
        }
    },
    instapaper: {
        name: "Instapaper integration",
        category: 'share',
        options: {
            auth: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            username: '',
            password: {
                input: 'password',
                value: ''
            }
        },
        shortcuts: {
            'share': {
                id: 'share',
                title: 'Read Later with Instapaper',
                key: {
                    //73 i
                    keyCode: 73
                }
            }
        }
    },
    readitlater: {
        name: "ReadItLater integration",
        category: 'share',
        options: {
            auth: {
                xtype: 'p',
                label: true,
                cls: 'subtitle'
            },
            username: '',
            password: {
                input: 'password',
                value: ''
            }
        },
        shortcuts: {
            'share': {
                id: 'share',
                title: 'Read Later with ReadItLater',
                key: {
                    //76 l
                    keyCode: 76
                }
            }
        }
    },
    mark: {
        name: "Mark As Read",
        category: 'navigation',
        shortcuts: {
            'markprev': {
                id: 'markprev',
                title: 'Mark items before As Read',
                key: {
                    //87 w
                    keyCode: 87
                }
            },
            'marknext': {
                id: 'marknext',
                title: 'Mark items after As Read',
                key: {
                    //89 y
                    keyCode: 89
                }
            }
        }
    },
    jump: {
        name: "Add top/bottom links",
        category: 'navigation',
        shortcuts: {
            'goup': {
                id: 'goup',
                title: 'Goto top',
                key: {
                    //84 Shift+T
                    keyCode: 84,
                    shiftKey: true
                }
            },
            'godown': {
                id: 'godown',
                title: 'Goto bottom',
                key: {
                    //66 Shift+B
                    keyCode: 66,
                    shiftKey: true
                }
            }
        }
    },
    fitheight: {
        name: "Fit height",
        category: 'layout',
        options: {
            locked: false
        },
        shortcuts: {
            'fit': {
                id: 'fit',
                title: 'Fit height',
                key: {
                    //72 h
                    keyCode: 72
                }
            }
        }
    },
    closeentry: {
        name: "Close entry",
        category: 'action',
        shortcuts: {
            'close': {
                id: 'close',
                title: 'Close entry',
                key: {
                    //88 x
                    keyCode: 88
                }
            }
        }
    },
    openbackground: {
        name: "Open in background",
        category: 'action',
        shortcuts: {
            'openback': {
                id: 'openback',
                title: 'Open in background tab',
                key: {
                    shiftKey: true,
                    keyCode: 86
                }
            }
        }
    },
    translate: {
        name: "Translate",
        category: 'content',
        options: {
            lang: 'en',
            locked: false,
            include: false,
            filter: {
                xtype: 'crud'
            }
        },
        shortcuts: {
            'translate': {
                id: 'translate',
                title: 'Translate entry',
                key: {
                    //84 alt+T
                    keyCode: 84,
                    altKey: true
                }
            }
        }
    },
    limit: {
        name: "Limit",
        category: 'layout',
        options: {
            mini: 30,
            maxi: 200
        }
    },
	prefetch: {
        name: "Prefetch",
        category: 'layout',
        status: 'new',
        options: {
            first: 25,
			next: 15,
			list: 60
        }
    },
	nested: {
        name: "Nested folders",
        category: 'layout',
        status: 'new',
        options: {
            separator: ":"
        }
    },
    replacer: {
        name: "Replacer",
        category: 'content',
        status: 'updated',
        options: {
            intro: {
                xtype: 'p',
                label: true
            },
			cloud: true,
            items: {
                xtype: 'crud'
            }
        }
    },
   /* menu: {
     name: "Smart menu",
	 category: 'navigation',
     desc: "Smart menu to add extra capabilites on each entry"
    },*/
    aero: {
        name: "Google Aero Toolbar",
        category: 'theme'
    },
    /*antisocial: {
        name: "Antisocial",
        category: 'layout',
        status: 'new',
        options: {
            status: false
        }
    },*/
    /*hover: {
     name: "Hover selection"
     },*/
    info: {
        name: "SysInfo",
        link: true,
        options: {
            sysinfo: {
                xtype: 'html',
                label: true,
                value: '<div id="sysinfo"></div>'
            }
        }
    },
    extshortcuts: {
        name: "Shortcuts",
        link: true
    },
    pack: {
        name: "Packages",
        link: true
    },
    thanks: {
        name: "Thanks",
        link: true
    }
};
GRP.packages = {
    'none': {
        general: {
            secure: true,
			stats:true
        }
    },
	'mini': {
        general: {
            secure: true,
			stats:true
        },
		favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true
    },
    'ludoo': {
        general: {
            secure: true,
            counter: false,
			pageicon: true,
			stats:true
        },
        favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true,
        column: true,
        mark: true,
        jump: true,
        fitheight: true,
        closeentry: true,
        openbackground: true,
        replacer: {
			cloud:true
		},
        preview: {
            onicon: true,
            overlay: true
        },
        theme: {
            skin:'mytheme',
			externaltheme: 'gmail_coldshower'
        }
    },
    'full': {
        general: {
            secure: true,
            counter: false,
			pageicon: true,
			stats:true
        },
		theme: {
            skin: 'osxblack',
			stats:true
        },
        favicons: {
			cloud:true
		},
        unreadcount: true,
        fixlayout: true,
        count: true,
        counticon: true,
        removeads: true,
        column: true,
        mark: true,
        jump: true,
        preview: true,
        colorful: true,
        filter: true,
        readbymouse: true,
        twitter: true,
        facebook: true,
        fitheight: true,
        closeentry: true,
        openbackground: true,
        aero: true,
        instapaper: true,
        readitlater: true,
        translate: true,
        replacer: true,
        limit: true
    }
};
GRP.skins = {
    none: {
        name: "None"
    },
    mytheme: {
        name: "My Theme <span class='updated'>Updated!</span>"
    },
    nativecompact: {
        name: "Native compact"
    },
    player: {
        name: "Player Theme"
    },
    osxblue: {
        name: "Mac OS X Snow Leopard - Blue"
    },
    osxblack: {
        name: "Mac OS X Snow Leopard - Black"
    },
    portal: {
        name: "Portal Theme"
    },
    helvetireader: {
        name: "Helvetireader Skin"
    },
    minimal: {
        name: "Minimalistic Skin"
    },
    optimized: {
        name: "Optimized Skin"
    },
    air: {
        name: "Air Skin"
    },
    aircomic: {
        name: "Air Skin Comic Sans"
    },
    black: {
        name: "Google Enhanced Black"
    },
    dark: {
        name: "Dark Skin"
    },
    darkgray: {
        name: "Dark Gray Skin"
    },
    calibri: {
        name: "Calibri Skin"
    },
	sublimelight: {
        name: "Sublime Reader Light",
		ref:'https://code.google.com/p/sublimereader/'
    },
	sublimedark: {
        name: "Sublime Reader Dark",
		ref:'https://code.google.com/p/sublimereader'
    },
	redesigned: {
        name: "Redesigned",
		ref:'http://www.globexdesigns.com/products/gr/'
    },
	webbizgeek: {
		name: "WebBizGeek Skin <span class='new'>New!</span>",
		pic: 'http://www.webbizgeek.com/wp-content/uploads/2010/07/Google-Reader-custom-skin1.jpg'
	},
    glassblackgold: {
        name: "Glass Black Gold Skin",
        /*
         url: 'http://userstyles.org/styles/userjs/26569/Google%20Reader%20-%20Glass%20BlackGold%20.user.js',
         */
        pic: 'http://userstyles.org/style_screenshots/26569_after.png',
        ref: 'http://userstyles.org/styles/26569',
        fix: '#chrome-view-links,#lhn-selectors .selected,#lhn-selectors .selected:hover{background-color: transparent !important;}',
        desc: 'userstyles.org'
    },
    simpleclean: {
        name: "Simple and Clean",
        url: 'http://userstyles.org/styles/userjs/17120/Google%20Reader%20simple%20and%20clean.user.js',
        pic: 'http://userstyles.org/style_screenshots/17120_after.gif',
        ref: 'http://userstyles.org/styles/17120',
        fix: '.entry-actions{height: auto!important;}',
        desc: 'userstyles.org'
    },
    peacockfeather: {
        name: "Peacock Feather",
        url: 'http://userstyles.org/styles/userjs/3014/Google%20Reader%20-%20peacock%20feather.user.js',
        pic: 'http://userstyles.org/style_screenshots/3014_after.gif',
        ref: 'http://userstyles.org/styles/3014',
        desc: 'userstyles.org',
        resize: true
    },
    myowngooglereader: {
        name: "My Own Google Reader",
        url: 'http://userstyles.org/styles/userjs/13384/My%20Own%20Google%20Reader.user.js',
        pic: 'http://userstyles.org/style_screenshots/13384_after.png',
        ref: 'http://userstyles.org/styles/13384',
        desc: 'userstyles.org',
        resize: true
    },
    compactcleantweaked: {
        name: "Compact, Clean & Tweaked",
        url: 'http://userstyles.org/styles/userjs/16117/Google%20Reader%20-%20Compact%2C%20Clean%20%26%20Tweaked.user.js',
        pic: 'http://userstyles.org/style_screenshots/16117_after.png',
        ref: 'http://userstyles.org/styles/16117',
        desc: 'userstyles.org'
    },
    /*
     '31d1remix':
     {
     name: "31d1 remix",
     url:'http://userstyles.org/styles/userjs/3519/Google%20Reader%20-%2031d1%20remix%20.user.js',
     pic:'http://userstyles.org/style_screenshots/3519_after.png',
     ref:'http://userstyles.org/styles/3519',
     desc: 'userstyles.org'
     },
     */
    absolutelycompact: {
        name: "Absolutely Compact",
        url: 'http://userstyles.org/styles/userjs/12691/Google%20Reader%20Absolutely%20Compact.user.js',
        pic: 'http://userstyles.org/style_screenshots/12691_after.png',
        ref: 'http://userstyles.org/styles/12691',
        desc: 'userstyles.org'
    },
    darkshinyblue: {
        name: "Dark Shiny Blue",
        url: 'http://userstyles.org/styles/userjs/8935/iGoogle%2FGoogle%20Dark%20Shiny%20Blue%2C%20transparency.user.js',
        pic: 'http://userstyles.org/style_screenshots/8935_after.jpeg',
        ref: 'http://userstyles.org/styles/8935',
        desc: 'userstyles.org'
    },
    persian: {
        name: "Optimized Persian",
        url: 'http://userstyles.org//styles/userjs/2375/Optimized%20Persian%20Google%20Reader%20.user.js',
        pic: 'http://userstyles.org/style_screenshots/2375_after.png',
        ref: 'http://userstyles.org/styles/2375',
        desc: 'userstyles.org'
    }
};
GRP.googleshortcuts = {
    'j': {
        text: 'item down : selects the next item in the list',
        key: {
            keyCode: 74
        }
    },
    'k': {
        text: 'item up : selects the previous item in the list',
        key: {
            keyCode: 75
        }
    },
    'space': {
        text: 'page down : moves the page down',
        key: {
            keyCode: 32
        }
    },
    'shift+space': {
        text: 'page up : moves the page up',
        key: {
            keyCode: 32,
            shiftKey: true
        }
    },
    'n': {
        text: 'scan down : in list view, selects the next item without opening it',
        key: {
            keyCode: 78
        }
    },
    'p': {
        text: 'scan up : in list view, selects the next item without opening it',
        key: {
            keyCode: 80
        }
    },
    'shift+n': {
        text: 'navigation down : selects the next subscription or folder in the navigation',
        key: {
            keyCode: 78,
            shiftKey: true
        }
    },
    'shift+p': {
        text: 'navigation up : selects the previous subscription or folder in the navigation',
        key: {
            keyCode: 80,
            shiftKey: true
        }
    },
    'shift+x': {
        text: 'navigation expand/collapse : expands or collapses a folder selected in the navigation',
        key: {
            keyCode: 88,
            shiftKey: true
        }
    },
    'o': {
        text: 'open/close item : in list view, expands or collapses the selected item',
        key: {
            keyCode: 79
        }
    },
    'enter': {
        text: 'open/close item : in list view, expands or collapses the selected item',
        key: {
            keyCode: 13
        }
    },
    'shift+o': {
        text: 'navigation open subscription : opens the subscription or folder currently selected in the navigation',
        key: {
            keyCode: 79,
            shiftKey: true
        }
    },
    '-': {
        text: 'zoom out : decreases the font size of the current item',
        key: {
            keyCode: 109
        }
    },
    '=': {
        text: 'zoom in : increases the font size of the current item',
        key: {
            keyCode: 187
        }
    },
    's': {
        text: 'toggle star : stars or un-stars the selected item',
        key: {
            keyCode: 83
        }
    },
    'shift+s': {
        text: 'toggle share : shares or un-shares the selected item',
        key: {
            keyCode: 83,
            shiftKey: true
        }
    },
    'shift+d': {
        text: 'share with note : shares the selected item with a note',
        key: {
            keyCode: 68,
            shiftKey: true
        }
    },
    'v': {
        text: 'view original : opens the original source for this article in a new window',
        key: {
            keyCode: 86
        }
    },
    't': {
        text: 'tag an item : opens the tagging field for the selected item',
        key: {
            keyCode: 84
        }
    },
    'm': {
        text: 'mark as read/unread : switches the read status of the selected item',
        key: {
            keyCode: 77
        }
    },
    'shift+a': {
        text: 'mark all as read : marks all items in the current view as read',
        key: {
            keyCode: 65,
            shiftKey: true
        }
    },
    'e': {
        text: 'email item : opens the email form to send an item to a friend',
        key: {
            keyCode: 69
        }
    },
    'g then h': {
        text: 'go to home : goes to the Google Reader homepage',
        key: {
            keyCode: 71
        }
    },
    'g then a': {
        text: 'go to all items : goes to the "All items" view',
        key: {
            keyCode: 71
        }
    },
    'g then s': {
        text: 'go to starred items : goes to the "Starred items" view',
        key: {
            keyCode: 71
        }
    },
    'g then shift-s': {
        text: 'go to shared items : goes to the "Your shared items" view',
        key: {
            keyCode: 71
        }
    },
    'g then u': {
        text: 'go to subscription : allows you to navigate to a subscription by entering the subscription name',
        key: {
            keyCode: 71
        }
    },
    'g then t': {
        text: 'go to tag : allows you to navigate to a tag by entering the tag name',
        key: {
            keyCode: 71
        }
    },
    'g then f': {
        text: 'go to friend : allows you to navigate to a friend\'s shared items by entering the friend\'s name',
        key: {
            keyCode: 71
        }
    },
    'g then shift-f': {
        text: 'go to all friends\' shared items : shows all of your friends\' shared items',
        key: {
            keyCode: 71
        }
    },
    'g then shift-t': {
        text: 'go to trends : goes to the "Trends" view',
        key: {
            keyCode: 71
        }
    },
    'g then d': {
        text: 'go to feed discovery : shows the recommendations page, or the browse page if there are no recommendations',
        key: {
            keyCode: 71
        }
    },
    'r': {
        text: 'refresh : refreshes the unread counts in the navigation',
        key: {
            keyCode: 82
        }
    },
    'u': {
        text: 'toggle full screen mode : hides or shows the list of subscriptions',
        key: {
            keyCode: 85
        }
    },
    '1': {
        text: 'expanded view : displays the subscription as expanded items',
        key: {
            keyCode: 49
        }
    },
    '2': {
        text: 'list view : displays the subscription as a list of headlines',
        key: {
            keyCode: 50
        }
    },
    '1 pad': {
        text: 'expanded view : displays the subscription as expanded items',
        key: {
            keyCode: 97
        }
    },
    '2 pad': {
        text: 'list view : displays the subscription as a list of headlines',
        key: {
            keyCode: 98
        }
    },
    '/': {
        text: 'search : moves your cursor to the search box',
        key: {
            keyCode: 111
        }
    },
    'a': {
        text: 'add a subscription : opens the "Add a subscription" box in the sidebar',
        key: {
            keyCode: 65
        }
    },
    '?': {
        text: 'keyboard shortcuts help : displays a quick guide to all of Reader\'s shortcuts',
        key: {
            keyCode: 219
        }
    }
};
/**
 * API for entry
 *
 */
GRP.api_entry = function(prefs, langs, ID, SL, lang, edata){
    var locked = getPref('locked');
	var include = getPref('include');//CRUD for include/exclude
	var rx = getRegex(getPref('filter'));
	
	function getPref(name){
		if (prefs && prefs[ID + '_' + name]) {
			return prefs[ID + '_' + name];
		}else{
			return false;
		}
	}
	
    function addButton(el, entry, mode){
        var title = (SL.text || ID) + formatShortcut(ID, edata.action, prefs); //[x]
        var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
        addBottomLink(el, text, title, ID, '', true, filterize, locked||include, entry, mode);
    }
	
	function filterize(btn, entry, lcked, e){
        if (typeof e === "undefined") {
			//auto
			if (locked) {
				if (filterEntry(entry, rx)) {
					//In exclusion list
					return false;
				}
			}
			if (include) {
				if (!filterEntry(entry, rx)) {
					//Not in inclusion list
					return false;
				}
			}
		}
		var active = isActive(btn, entry, '', locked);
		if (edata.cb){
			edata.cb(entry, active, btn, e);
		}
	}
	
    function addKey(e){
        var entry = getEntry(e);
        filterize('btn-' + ID, entry);
    }
    if (edata.css) {
        var css;
        if (edata.css.code) {
            css = edata.css.code;
        } else if (edata.css.image) {
            //http://images.google.com/images/isr_c.gif
            css = ".btn-" + ID + " {margin-left: 4px;padding: 1px 8px 1px 16px;;width:14px;height:14px;background-repeat:no-repeat;}";
            if (edata.css.image.url) {
				css += ".background-image:url(" + edata.css.image.url + ");";
			}else if (edata.css.image.base64) {
				css += ".background-image:url(data:image/png;base64," + edata.css.image.base64 + ");";
			}
            css += "}";
        }
        if (css) {
            GM_addStyle(css);
        }
    }
    registerFeature(addButton, ID);
    var keycode = getShortcutKey(ID, edata.action, prefs); 
    if (keycode) {
        keycode.fn = addKey;
        initKey(keycode);
    }
};
/**
 * Readitlater and instapaper API
 */
GRP.api_readit = function(prefs, langs, ID, scriptlangs, lang, api){
    var o = apply({}, langs.readit);
	var SL = apply(o, scriptlangs);
    function addButton(el, entry, mode){
        var title = SL.text + formatShortcut(ID, ID, prefs);
		var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
        addBottomLink(el, text, title, ID, 'item-star star', false, readitlaterClick, false, entry, mode);
    }
    function addKey(){
        onKey('btn-' + ID, readitlaterClick);
    }
    function readitlaterClick(btn, entry, locked){
        //var active = isActive(btn, entry, ID, locked);
        readitlater(entry, btn);
    }
    function readitlater(entry, btn){
        var auth = getAuth();
        if (!auth) {
            return;
        }
        var link = getEntryLink(entry);
        var body = getBody(entry);
        var params = {
            url: link.url,
            title: link.title,
            selection: body.innerText
            //selection: window.getSelection().toString()
        };
        //login(auth, params, btn);
        //direct
        post(auth, params, btn);
    }
    function login(auth, params, btn){
        GM_xmlhttpRequest({
            method: 'GET',
            url: api.auth,
            parameters: auth,
            onload: function(r){
                if (r.status == api.successCode) {
                    //login success
                    post(auth, params, btn);
                } else if (api.errors[r.status]) {
                    alert(SL[api.errors[r.status]]);
                } else {
                    alert(SL.error);
                }
            }
        });
    }
    function post(auth, params, btn){
        params.username = auth.username;
        if (auth.password) {
            params.password = auth.password;
        }
        GM_xmlhttpRequest({
            method: 'GET',
            url: api.add,
            parameters: params,
            onload: function(r){
                if (r.status == api.successCode) {
                    //set star active
                    addClass(btn, 'item-star-active');
                    removeClass(btn, 'item-star');
                } else if (api.errors[r.status]) {
                    alert(SL[api.errors[r.status]]);
                } else {
                    alert(SL.error);
                }
            }
        });
    }
    function getAuth(){
        var username = prefs[ID+'_username'];
        var password = prefs[ID+'_password'];
        if (typeof username === "undefined" || username === '') {
            alert(SL.nologin);
            return false;
        }
        return {
            username: username,
            password: password
        };
    }
    function clearAuth(){
        //GM_setValue(ID+'_username', '');
        //GM_setValue(ID+'_password', '');
    }
    registerFeature(addButton, ID);
    var keycode = getShortcutKey(ID, 'share', prefs);
    keycode.fn = addKey;
    initKey(keycode);
};
/**
 * General configuration
 * @version  0.1
 * @date 2010
 *
 */
GRP.general = function(prefs, langs, ID, SL, lang){
    var CLS_CURRENT = 'grp_current';
    if (prefs.general_secure) {
        if (/^http\:/.test(window.location.href)) {
            window.location.href = window.location.href.replace(/^http\:/, 'https:');
        }
    }
    var entries = get_id('entries');
    if (prefs.general_bottomup) {
        var el = get_id('viewer-footer'), ref = get_id('viewer-header'), c = get_id('chrome');
        ref = get_id('stream-prefs-menu');
        var h = el.clientHeight;
        insertAfter(el, ref);
        entries.style.height = (getStyle(entries, 'height') + h) + 'px';
    }
	if (prefs.general_currdir) {
        var lastUrl='';
		GM_addStyle('.tree-sel{background-color:#dedede;}', 'rps_currdir');
		var st = get_id('sub-tree');
		setInterval(function(){
			var e = get_id('current-entry');
			if (e) {
				var el = getFirstElementByClassName(e, 'entry-source-title');
				if (el) {
					var url = el.getAttribute('href');
					if (url && url !== lastUrl) {
						var l = getFirstElementByClassName(st, 'tree-sel');
						if (l) {
							removeClass(l, 'tree-sel');
						}
						//var a = Sizzle('#sub-tree a.link[href="' + url + '"]');
						var a = getElements(".//a[@class='link'][@href='" + url + "']", st);
						if (a && a.length > 0) {
							addClass(a[0], 'tree-sel');
							lastUrl = url;
							//ensure visible
							var h = findTop(a[0], st);
							st.scrollTop = h;
						}
					}
				}
			}
		},2000);
		
		
    }
    if (prefs.general_topcurrent) {
        function updateSpacer(){
            var scrollspacer = get_id('scrollspacer');
            if (!scrollspacer) {
                var h = getHeightEntries();//screen.height
                scrollspacer = dh(entries, 'div', {
                    id: 'scrollspacer',
                    html: '&nbsp;'
                });
                scrollspacer.style.height = h + 'px';
            }
        }
        updateSpacer();
        var cur, oldcur;
        window.setInterval(function(){
            cur = get_id('current-entry');
            //check if current entry hans changed!
            if (cur && !hasClass(cur, CLS_CURRENT)) {
                updateSpacer();
                oldcur = getFirstElementByClassName(entries, CLS_CURRENT);
                if (oldcur) {
                    removeClass(oldcur, CLS_CURRENT);
                }
                addClass(cur, CLS_CURRENT);
                entries.scrollTop = cur.offsetTop;
            }
        }, 500);
    }
    
    function floatactions(){
        //Remove #entries.list .entry .entry-actions {left:0px;}
        var ss = findre(document.styleSheets, 'href', /en-scroll\.css/);
        if (ss) {
            var rule = find(ss.cssRules, 'selectorText', '#entries.list .entry .entry-actions');
            if (rule) {
                rule.style.left = '';
            }
        }
        var main = get_id('main');
        var top = main.offsetTop; //getStyle(main, 'top');
        top = Math.max(142, top + 77);
        //ig    : main.top=140 top=217 (+77)
        //normal: main.top=65  top=142 (+77)
        var css = '.entry:not(#current-entry) .card-actions{display:none}#current-entry .card-actions,#entries.list #current-entry .entry-actions{position:fixed;right:32px!important;top:' + top + 'px!important;left:!important;width:140px;z-index:9999;-webkit-box-shadow:#E3E5EB 0 1px 1px;border-bottom-left-radius:5px 5px;border-bottom-right-radius:5px 5px;border-top-left-radius:5px 5px;border-top-right-radius:5px 5px;border:2px solid #68E;opacity:0.2}#current-entry .card-actions:hover,#entries.list #current-entry .entry-actions:hover{opacity:1}#current-entry .entry-main{margin-right:140px}#current-entry .entry-actions > span,#entries.list #current-entry .entry-actions > span{display:block}';
        GM_addStyle(css, 'rps_floatactions');
    }
    if (prefs.general_floatactions) {
        runfn(floatactions, 'floatactions', 99, 2000);
        //defer to get right #main.top
    }
	
	if (prefs.general_icons) {
		function changeIconsButton(el, entry, mode){
			var items = el.getElementsByClassName('link');
			foreach(items, function(item){
				if (item && !hasClass(item, 'read-state')) {
					item.title=item.innerText;
					var s = item.getElementsByTagName('span');
					var b = (s && s[0])?(s[0]):item;
					b.innerHTML='';
				}
			});
		}
		//RAZ labels because google rewrite labels after selection
		//Xp MArquer comme lu = chekbox
		var o = ['Wp','Yp','Zp','$p','aq','bq'];
		var js = '';
		foreach(o,function(e){
			js += e+".Gf.Pb='';"+e+".Hf.Pb='';";
		});
		GM_addjs(js, true, 'clearlabel');
		registerFeature(changeIconsButton, ID);
	}
};
/**
 * FixLayout 
 * @version  0.3
 * @date 2010-01-22
 * @author LudoO
 *
 * Fit entry height
 *
 */
GRP.fixlayout = function(prefs, langs, ID, SL, lang){
	function checkImage(root, href) {
		var links = getElements(".//img[@src='" + href + "']", root);
		return (links && links.length > 0);
	}
	function fixEnclosures() {
		var nodes = getElements("//a[span[@class='view-enclosure']]");
		if (!nodes || !nodes.length) {
			return;
		}

		nodes.forEach(function(o) {
			var entry = findParentNode(o, 'div', 'entry');
			if (entry) {
				var found = checkImage(entry, o.href);
				var p = o.parentNode.parentNode;
				if (found) {
					if (p && p.parentNode) {
						p.parentNode.removeChild(p);
					}
				} else {
					var div = document.createElement('div');
					div.className = "item-pict";
					var img = document.createElement('img');
					div.appendChild(img);
					img.src = o.href;
					img.align = "left";
					if (p && p.parentNode) {
						p.parentNode.replaceChild(div, p);
					}
				}
			}
		});
	}
	
	//fix image width
	var css = ".entry-body img {max-width:100%;}";
	
	//fix width of entry
	css+".entry .entry-body, .entry .entry-title{ display: inline !important; max-width: 100% !important; }";

	//#253 fix width of add localized subscription
	var ws={pt:200,de:190,ru:197,nl:190};
	if (ws[lang]){
    	css+='#quickadd{width:'+ws[lang]+'px !important;}';
	}
	GM_addStyle(css, 'rps_fixlayout');
	
	var e = document.getElementById('entries');
	if (e) {
		e.addEventListener('DOMNodeInserted', function() {
			fixEnclosures();
		}, false);
	}
	fixEnclosures();// on load
};
/**
 * Show unread count
 * @version  0.1
 * @date 2009
 * @author LudoO
 *
 * Show hidde nunread count on folder
 *
 */
GRP.unreadcount = function(prefs, langs, ID, SL, lang){
	var css = '.lhn-section-no-unread-counts .unread-count{display:inline !important}';
	GM_addStyle(css);
};/**
 * Google Reader - Mark Until Current As Read
 * @version  1.3
 * @date 2007-06-01
 *
 * Mark all entries upto the current entry as read
 *
 * Original author :
 * Gautham Pai (http://buzypi.in/)
 * http://userscripts.org/scripts/show/24955
 */

GRP.mark = function(prefs, langs, ID, SL, lang){
	var currentElement, modeList=false;
	function setConfig(){
		currentElement = getCurrentEntry();
		modeList=(getMode(currentElement)==='list');
	}
	function clickEntry(entry, modeList){
		if (!hasClass(entry,'read')){
			var el = (modeList)?entry.firstChild:entry;
			simulateClick(el);
		}
	}
	function markUntilCurrentAsRead() {
		setConfig();
		var nextElement=currentElement.previousSibling;
		while(nextElement){
			clickEntry(nextElement, modeList);
			nextElement=nextElement.previousSibling;
		}
		
		simulateClick(currentElement.childNodes[0]);
	}

	function markAfterCurrentAsRead() {
		setConfig();
		var nextElement=currentElement.nextSibling;
		while(nextElement){
			clickEntry(nextElement, modeList);
			nextElement=nextElement.nextSibling;
		}
		simulateClick(currentElement.childNodes[0]);
	}

    var keycodeUp = getShortcutKey('mark', 'markprev', prefs); //87;//w
    keycodeUp.fn = markUntilCurrentAsRead;
    var keycodeDown = getShortcutKey('mark', 'marknext', prefs); //75;//k
    keycodeDown.fn = markAfterCurrentAsRead;
    initKey([keycodeUp, keycodeDown]);
};/**
 * Remove ads
 * @version  0.1
 * @date 2010
 * @author LudoO
 *
 * Simple advertising cleaner
 *
 */

GRP.removeads = function(prefs, langs, ID, SL, lang){
	function removeAds() {
		var i,re, link;

		// DIV#tads
		var ads = document.getElementById("tads");
		if (ads) {
			ads.parentNode.removeChild(ads);
		}
		
		//start from entry ??
		
		
		// Remove Search-Tracking
		var links = document.getElementsByTagName("a");
		// var links = document.querySelector("a,img");
		if (links && prefs.removeads_links) {
			re = new RegExp(prefs.removeads_links);
			//var re = /da\.feedsportal\.com|res\.feedsportal\.com|doubleclick\.net|\/ads/;
			for (i = 0; i < links.length; i++) {
				link = links[i];
				if (link.className == "l") {
					link.removeAttribute("onmousedown");
				}
				if (re.test(link.href)) {
					//console.log("REMOVE AD a : "+link.href);
					link.parentNode.removeChild(link);
				}
			}
		}

		links = document.getElementsByTagName("img");
		if (links && prefs.removeads_images) {
			re = new RegExp(prefs.removeads_images);
			//var re = /feedsportal\.com|feedburner\.com|doubleclick\.net|\/ads/;
			for (i = 0; i < links.length; i++) {
				link = links[i];
				if (re.test(link.src)) {
					//console.log("REMOVE AD img : "+link.src);
					link.parentNode.removeChild(link);
				}
			}
		}

		// Remove Right-side Ads
		var iframe = document.getElementsByTagName("iframe");
		if (iframe && prefs.removeads_iframes) {
			re = new RegExp(prefs.removeads_iframes);
			//var re = /feedsportal\.com|doubleclick\.net|googlesyndication.com\/pagead\/ads/;
			for (i = 0; i < iframe.length; i++) {
				var s = iframe[i].src;
				if (re.test(s)) {
					//console.log("REMOVE AD iframe : "+s);
					iframe[i].height = 0;
					iframe[i].width = 0;
					iframe[i].src = '';
				}

			}
		}
	}

	document.body.addEventListener('DOMNodeInserted', function(e){
		removeAds();
	}, false);
	removeAds();

};
/**
 * Google Reader Favicon ++
 * @version  4.0.3/4.1.0
 *
 *
 * Adds favicons to feeds and entries
 *
 * Original author :
 * Yamamaya
 * http://userscripts.org/scripts/show/40120
 *
 * +Google Reader Favicon ++ v1.5.0 (LudoO)
 */
GRP.favicons = function(prefs, langs, ID, SL, lang){
    var GRP_INFO = GM_getValue('grp_favicons', '{}');
    var FAVICON = GRP_INFO.icon || (GRP_INFO.icon = {});
    updateFavicons();
    var protocol = document.location.protocol;
    var FAVICON_TPL_URL = protocol + '//s2.googleusercontent.com/s2/favicons?alt=feed&domain=';
    var FAVICON_TPL_DEF_URL = protocol + '//s2.googleusercontent.com/s2/favicons';
    if (prefs.favicons_providerpageicons) {
        FAVICON_TPL_URL = 'http://pageicons.appspot.com/favicons?f=1&url=';
        FAVICON_TPL_DEF_URL = 'http://pageicons.appspot.com/favicons';
    }
	//FAVICON_TPL_URL = 'http://getfavicons.appspot.com?domain=';
	
    //var LOADING_IMAGE = "chrome-extension://'+GUID_CORE+'/images/loading.gif";
    var LOADING_IMAGE = GRP.IMAGES_PATH+"/loading.gif";
	
    var RSS = getElements('id("sub-tree-item-0-main")/ul/li/ul/li').length;
    var FOLDER = getElements('id("sub-tree-item-0-main")/ul/li').length;
    var RSS_NUMBERS = GRP_INFO.rss || null;
    var FOLDER_NUMBERS = GRP_INFO.dirs || null;
	
    function init(){
        if (true || isObjectEmpty(FAVICON) || RSS_NUMBERS === null || FOLDER_NUMBERS === null || RSS !== RSS_NUMBERS || FOLDER !== FOLDER_NUMBERS) {
            loadFavicons();
        } else {
            initFavicons();
        }
        GRP_INFO.rss = RSS;
        GRP_INFO.dirs = FOLDER;
        setValue();
    }
    
    function loadFavicons(){
        //clearCache();
        chrome.extension.sendRequest(
        {
            message: "loadicons",
            method: 'get',
            url: protocol + '//www.google.com/reader/subscriptions/export',
            FAVICON_TPL_URL: FAVICON_TPL_URL
        }, function(a){
            if (a.FAVICON) {
                FAVICON = a.FAVICON;
                updateFavicons();
            }
            initFavicons();
            setValue();
        });
    }
    
    function initFavicons(){
        if (!prefs.favicons_sidebaronly) {
            registerFeature(addFaviconEntry, ID, 
            {
                onlistviewtitle: true
            });
        }
        initCatchSidebars(addFaviconSidebar, 'sidebar-favicons');
    }
    
    function addFaviconEntry(el, entry, mode){
        if (isTagged(entry, 'tfavicon')) {
            //stop entry was already scanned
            return;
        }
        
        var icon = document.createElement('img');
        icon.className = 'entry-favicon grf-favicon grf-entry';       
        var siteTitle = getEntrySiteTitle(entry);
        var match = ellipsis(siteTitle);
        
        icon.title = match;
        
        var t = FAVICON[match];
        if (t) {
            icon.src = t.icon;
        } else { // popular items | recommended sources
            var fs = entry.getElementsByClassName('entry-original')[0] ||
            entry.getElementsByClassName('entry-title-link')[0];
            if (fs) {
                fs = FAVICON_TPL_URL + getDomain(fs.href);
                icon.src = fs;
            } else {
                icon.src = FAVICON_TPL_DEF_URL;
            }
        }
        
        var point;
        if (mode === "expanded") {
            var entryTitle = getFirstElementByClassName(entry, 'entry-title');//h2
            insertFirst(icon, entryTitle);
        } else {
            var entrySourceTitle = getFirstElementByClassName(entry, 'entry-source-title');//span
            insertBefore(icon, entrySourceTitle);
        }
        
        
        //icon.removeEventListener('error', revertFavicon, false);
        //icon.addEventListener('error', revertFavicon, false);
    
    }
    function addFaviconSidebar(el, mode){
        if (isTagged(el, 'tfavicon')) {
            //stop entry was already scanned
            return;
        }
        
        var elsubicon = getFirstElementByClassName(el, 'sub-icon');//span
        var title = elsubicon.nextSibling;
        var match = ellipsis(title.firstChild.textContent);
        title.style.paddingLeft = '7px';
        var icon = document.createElement('img');
        icon.className = 'grf-favicon grf-sidebar';
        icon.title = match;
        elsubicon.parentNode.insertBefore(icon, elsubicon);
        elsubicon.parentNode.removeChild(elsubicon);
		
		function setIcon(match){
			//console.log('setIcon:'+match);
			//var t = findFaviconByTitle(FAVICON, match);
			var t = FAVICON[match];
			if (t) {
				icon.src = t.icon;
			} else {
				icon.src = FAVICON_TPL_DEF_URL;
			}
		}
		var tim= (hasClass(el, 'unread')) ?0:2000;
		window.setTimeout(function(){
			setIcon(match);
		}, tim);
        //icon.removeEventListener('error', revertFavicon, false);
        //icon.addEventListener('error', revertFavicon, false);
    }
    
    
    function renderFavicons(url, title, icon){
        var match = ellipsis(title);
        //var tree = document.getElementById('sub-tree');
        //var main = document.getElementById('main');
        getElements(".//img[@title='" + match + "']").forEach(function(img){
            img.src = icon;
        });
    }
    
    //Override with manual favicons
    function updateFavicons(){
        var domains = prefs.favicons_domains;
        if (!domains || !FAVICON) {
            return;
        }
        for (var key in FAVICON) {
            var f = FAVICON[key];
            var icon = domains[f.url];
            if (icon) {
                f.icon = icon;
            }
        }
    }
    /*
     function revertFavicon(event){
     this.src = FAVICON_TPL_DEF_URL;
     }
     */
    function findFaviconByTitle(FAVICON, title){
        return find(FAVICON, 'title', title);
    }
    
    function setValue(){
        GRP_INFO.icon = FAVICON;
		//cache only in webpage storage
        GM_setValue('grp_favicons', GRP_INFO, false);
    }
    
    function clearCache(){
        GM_setValue('grp_favicons', '');
    }
    
    function attachMenu(){
        var me = this;
        document.body.addEventListener('DOMNodeInserted', function(e){
            var target = e.target;
            if (!target.grfm && target.className && target.className.indexOf("goog-menu") >= 0) {
                target.grfm = "1";
                target.addEventListener('DOMNodeInserted', function(e){
                    var node = e.target;
                    if (target.grfm !== "2") {
                        setTimeout(function(){
                            showMenuItem(target, me);
                        }, 500);
                        target.grfm = "2";
                    }
                }, false);
            }
        }, false);
    }
    function showMenuItem(menu, scope){
        if (!menu) {
            return;
        }
        // find first separator
        var seps = menu.getElementsByClassName('goog-menuseparator');
        if (seps && seps.length > 0) {
            var sep = seps[0];
            var div = document.createElement('div');
            div.className = 'goog-menuitem goog-option grf-menuitem';
            div.style = '-webkit-user-select: none;';
            div.innerHTML = '<div class="goog-menuitem-content">' + SL.getfavicon + '</div>';
            sep.parentNode.insertBefore(div, sep.nextSibling);// insert after
            // +separator
            var separator = document.createElement('div');
            separator.className = 'goog-menuseparator';
            separator.style = '-webkit-user-select: none;';
            div.parentNode.insertBefore(separator, div.nextSibling);
            
            var me = this;
            div.addEventListener('click', function(e){
                var node = document.getElementsByClassName('menu-open')[0];
                if (node) {
                    var img = node.firstChild;// grf-favicon
                    // grf-sidebar
                    var key = '';
                    if (img.tagName === "IMG") {
                        key = img.title;
                    } else {
                        // img not there, used 2nd span.name/@title
                        key = img.nextSibling.title;
                    }
                    var f = FAVICON[key];
                    if (!f) {
                        //try to get url+title
						var dir = getSelectedDir(node);
						if (dir) {
							FAVICON[key] = {
								url: dir.url,
								title: dir.text
							};
						}
						
						/*
                        var nameText = getFirstElementByClassName(node, 'name-text');//span
                        if (nameText) {
                            f = 
                            {
                                url: unescape(node.href.replace('/\/reader\/view\/feed\/', '')),
                                title: ellipsis(nameText.innerText)
                            };
                            
                            FAVICON[key] = f;
                        }*/
						
                    }
                    if (f) {
                        img.src = '';
                        img.src = LOADING_IMAGE;
                        chrome.extension.sendRequest(
                        {
                            message: "geticon",
                            key: key,
                            FAVICON: FAVICON
                        }, function(a){
                            if (a.icon) {
                                if (a.FAVICON) {
                                    FAVICON = a.FAVICON;
                                    updateFavicons();
                                }
                                renderFavicons(a.url, a.title, a.icon);
                                setValue();
                            } else {
                                alert('Error: Cannot found favicon for "' + a.title + '"');
                            }
                        });
                        // ->iconget
                    } else {
                        var msg = formatText(SL.notfoundicon, key);
                        alert(msg);
                    }
                }
                // hide menu
                menu.blur();
                node.focus();
            }, false);
            div.addEventListener('mouseover', function(e){
                e.target.parentNode.className += ' goog-menuitem-highlight';
            }, false);
            div.addEventListener('mouseout', function(e){
                e.target.parentNode.className = e.target.parentNode.className.replace('goog-menuitem-highlight', '');
            }, false);
        }
    }
    
	//TODO : entry-source-title optional
	//TODO : hide entry-source-title, if label selected 
    var css = "img.entry-favicon{ width:16px !important; height:16px !important; border:none !important; margin-right:5px}.collapsed img.entry-favicon{ position:absolute !important; top:3px !important; left:1.6em !important; margin-right:0px !important; vertical-align:baseline !important}#entries.list .collapsed .entry-main .entry-source-title{ left:3.25em !important; width:9em !important}#sub-tree a img{ width:16px; height:16px; border:none; vertical-align:middle}#entries.list .collapsed .entry-secondary{ margin:0 8.5em 0 14em !important}#entries.single-source .collapsed .entry-source-title{ display:block !important}.colorful-view-content{ color:#EEE !important}.colorful-view-base-top-shadow{ background-color:#999 !important; border-bottom-color:#888 !important}.colorful-view-inner-box{ background-color:#777 !important; background:#F9F9F9 none repeat scroll 0 0 !important; border-color:#888 !important}.colorful-view-base-pos{ background-color:#777 !important; border-color:#888 !important}";
    css += '.samedir #entries.single-source .collapsed div.entry-secondary{margin-left:14em !important;}';
    GM_addStyle(css);
    
    attachMenu();
    init();
    
};


/**
 * Multi column layout
 * @version  0.2
 * @date 2010
 *
 * Display entry using multi colum layout
 *
 */
GRP.column = function(prefs, langs, ID, SL, lang){
    var locked = prefs.column_locked;
    var cols = 3;
	var hpage = getHeightEntries();
    var maxcolumns = 6; //between 1 and 6
    var entries = get_id('entries');
    var rx = getRegex(prefs.column_filter);
	var miniparas = prefs.column_miniparas || 5;
    
    function addButton(el, entry, mode){
        var title = SL.text + formatShortcut(ID, 'columns', prefs); //[c]
        //var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
		var text = (SL.keyword || ID);//checkbox
        addBottomLink(el, text, title, ID, '', true, columnize, locked, entry, mode);
    }
    
    function addKey(){
        onKey('btn-column', columnize);
    }
    
    function columnize(btn, entry, lcked, e){
        var locked = (lcked && (typeof e === "undefined"));
        if (locked && filterEntry(entry, rx)) {
            //Regex filtered
            return false;
        }
        
        var active = isActive(btn, entry, 'columnize', locked);
        
        var body = getBody(entry);
        
        var divoriginal = body.firstChild;
        var divwrap = getFirstElementByClassName(entry, 'wrap-container');//div
        
		if (divwrap && hasClass(divwrap, 'canceled')){
			//abort
			return false;
		}
        if (divwrap && active && prefs.column_pagebreak) {
            //already exists but height changed
            var h = divwrap.firstChild.style['max-height'];
            if (h) {
                var oldHeight = parseInt(h.replace('px', ''), 10);
                if (hpage !== oldHeight) {
                    divwrap.parentNode.removeChild(divwrap);
                    divwrap = null;
                }
            }
        }
        
        if (!divwrap) {
            divoriginal.className = "column-original";
            
			divwrap = document.createElement('div');
            divwrap.visibility = "hidden";
            divwrap.className = "wrap-container";
            
            //check height
			/*
            if (prefs.column_pagebreak) {
                hpage = getHeightEntries();
                // if (prefs && prefs.column_maxcolumns) {
                // var colsCount = Math.ceil(divoriginal.clientHeight / hpage);
                // if (colsCount < maxcolumns) {
                // divwrap.style['-webkit-column-count'] = colsCount;
                // }
                // }
            }
			*/
            //first append to monitor scrollwidth
            body.appendChild(divwrap);
            
			//wait images loading
			var imgs = getElements("img[not(@height)]", divoriginal);
			waitImages(imgs, function(loaded){
            	var wrapped = wrapHtml(entries, divwrap, hpage, divoriginal);
				if (!wrapped){
					//cancel
					addClass(divwrap, 'canceled');
				}
			});
        }
		if (hasClass(divwrap, 'canceled')) {
			hide(divwrap);
			show(divoriginal);
		} else {
			// toggle to correct body
			showas(divoriginal, active);
			showas(divwrap, !active);
			if (!locked) {
				jump(entry, true);
			}
		}
    }
	
    
    function wrapHtml(entries, divwrap, hpage, divoriginal){
        var paras = divoriginal.childNodes;
		if (paras.length < miniparas){
			//too little
			return false;
		}
		
		var ecw = entries.clientWidth;
        var div = createDiv(divwrap, hpage);
        var length = paras.length;
        var cwh = getColumWidth();
        
        if (paras && length > 0) {
            var cp, top, h, tag, line, offset;
            for (var i = 0; i < length; i++) {
                tag = paras[i].nodeName;
                line = '';
				cp=true;
                if (tag === "P") {
                    line = paras[i].innerHTML + '<br/>';
                } else if (tag === "#text") {
                    line = paras[i].textContent;//nodeValue
                    cp=false;
                } else if (tag === "IFRAME") {
                    //ignore iframe
                } else if (tag === "OBJECT" || tag === "EMBED" || tag === "VIDEO") {
                    line = paras[i].outerHTML;
                } else if (tag === "DIV") {
                    line = paras[i].innerHTML;
                } else if (/^[ABIU]$/.test(tag)) {
                    line = paras[i].outerHTML;
					cp=false;
                }else {
                    line = paras[i].outerHTML;
                }
                
                //line = line.trim();
                if (line !== '') {
					if (!cp && div.lastChild){
						div.lastChild.innerHTML += line;
					}else{
						var para = document.createElement('p');
						para.innerHTML = line;
						div.appendChild(para);
					}
					
                    //fix it up if width > page.width
                    if (prefs.column_pagebreak && div.scrollWidth > ecw) {
                        //new div
                        var newdiv = createDiv(divwrap, hpage);
                        newdiv.appendChild(para);
                        div = newdiv;
                    }
                }
            }
			//ensure videos size();
			fitall(true);
        }
        
        divwrap.visibility = "visible";
		return true;
    }
    
    function createDiv(parent, hpage){
        var div = document.createElement('div');
        div.className = 'column-wrapped';
        if (prefs.column_pagebreak) {
            if (hpage > 0) {
                div.style['max-height'] = hpage + 'px';
            }
        }
        parent.appendChild(div);
        return div;
    }
    
    // clean up
    function cleanHtml(txt){
        return txt.replace(/<iframe.*?>?.*?>/, '').replace(/<embed.*?>?.*?>/, '').replace(/<object.*?>?.*?>/, '');
    }
    
    //column_count
    if (prefs && prefs.column_count) {
        var c = parseInt(prefs.column_count, 10);
        cols = Math.max(0, c);
    }
    //maxi columns enable to fit from 1 to n columns automatically
    if (prefs && prefs.column_maxcolumns) {
        var d = parseInt(prefs.column_maxcolumns, 10);
        maxcolumns = Math.max(1, Math.min(6, d));
    }
    
    function getContainer(entry){
        var cwh = 300;
        var cw = getFirstElementByClassName(entry, 'entry-main');//div
        if (!cw) {
            cw = entries; //get_id('entries');
        }
        return cw;
    }
    
    var cw = getContainer(entries);
    function getColumWidth(){
        var cwh = 300;
        //var entries = get_id('entries');
        //var cw = getContainer(entries);
        if (cw) {
            cwh = Math.max(Math.round((cw.clientWidth-80) / cols), 150);
        }
        return cwh;
    }
    var cwh = getColumWidth();
    
    var lastcwh = -1;
    function fitall(force){
        //Images
        var cwh = getColumWidth();
        if (force || lastcwh !== cwh) {
            var css = '.column-wrapped img{max-width:' + cwh + 'px !important;height: auto !important;}';
            GM_addStyle(css, 'column_css_imgfit');
            
            //videos
            fitVideos(cwh);
            lastcwh = cwh;
        }
    }
    
    function fitVideos(width){
        var objects = entries.querySelectorAll(".column-wrapped OBJECT,.column-wrapped EMBED,.column-wrapped VIDEO");
        for (var i = 0, len = objects.length; i < len; i++) {
            var o = objects[i];
            if (!o.w) {
                o.w = o.width;
                o.h = o.height;
            }
            o.width = width;
            o.height = Math.round(o.h * width / o.w);
        }
    }
    
    window.addEventListener('resize', function(e){
        fitall();
    }, false);
    window.setInterval(function(){
        fitall();
    }, 2000);
    fitall();
    
	function onResize(height){
		hpage = getHeightEntries();
	}
	
    // copy of fixwidth to fit content
    GM_addStyle(".entry .entry-body, .entry .entry-title{ display: inline !important; max-width: 100% !important; }");
    
    var css = ".column-wrapped{ text-align: justify; -webkit-column-count: " + cols + "; -webkit-column-gap: 1.5em; -webkit-column-rule: 1px solid #dedede;overflow:visible;padding-bottom:4px;border-bottom:1px solid #dedede;} ";
    //css += '.column-wrapped p{page-break-after:auto;}';
    GM_addStyle(css);
    
    
    registerFeature(addButton, ID);
    var keycode = getShortcutKey(ID, 'columns', prefs); //67 c
    keycode.fn = addKey;
    initKey(keycode);
	initResize(onResize);
    
};
/**
 * Jump
 * @version  0.3
 * @date 2010-01-22
 * @author LudoO
 *
 * Add 2 jump buttons to go to top and bottom of entry
 *
 */
GRP.jump = function(prefs, langs, ID, SL, lang){
    function addJumpButtons(el, entry, mode){
        if (isTagged(entry, 'tjump')) {
            //stop entry was already scanned
            return;
        }
		
		//var title = getFirstElementByClassName(entry,  'entry-title');//h2
		var link = getOriginalEntryLink(entry);
        if (link) {
            var div = document.createElement('div');
            div.className = 'entry-title-go-to-bottom';
            
            var a = document.createElement('a');
            a.href = "#";
            a.title = SL.textbottom + formatShortcut(ID, 'godown', prefs);// [Shift+B] 
            a.appendChild(div);
            
            //title.appendChild(a);
			insertAfter(a, link);
            div.addEventListener('click', gotobottom, false);
        }
        
        var title =  SL.texttop + formatShortcut(ID, 'goup', prefs); //[Shift+T]
        var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
        addBottomLink(el, text, title, ID, 'item-go-to-top', false, gototop, false, entry, mode);
    }
    
    function gototop(e){
        var entry = getEntry(e);
        jump(entry, true);
    }
    
    function gotobottom(e){
        var entry = getEntry(e);
        jump(entry, false);
    }
    
    var css = ".entry-title-go-to-bottom{margin-left: 4px;padding-left:16px;width:14px;height:14px;background-repeat:no-repeat;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAMAAAAolt3jAAAAAXNSR0IArs4c6QAAASxQTFRFy9jwydfx+IoAGUuXy9jwydfx+IoAGUuXy9jw+IoA1N/0y9jwydfx+IoASm+RGUuXztvyy9jw+IoANV+Ly9jwydfx+IoAGUuXy9jw+IoAztvyy9jw+IoAMFyNztvyy9jw+IoALlqZztvyy9jw+IoAMFyNy9jw+IoAy9jw+IoAztvyy9jw+IoAK1iPJ1WYztvyy9jw+IoAK1iPIVGU////+Pj49/n9//XP//Wv//SX6+/65+35//Jp4+n4//E9//Az3uX48emX/+V71N/08edD093v8eY5ztn0y9jwydfxytbq4ttAws/x5LsAmrHVmbDVka7ZmqhfjJ+XjJ6A+IoAjJ1lXoXDcIlxWIHBjnkYUHSdSHO7RHG5UHJ/Qmu1Omm2QmmHKl2wIVGUGUuX1C6NdwAAAAF0Uk5TAEDm2GYAAAABYktHRACIBR1IAAAACXBIWXMAAArwAAAK8AFCrDSYAAAAB3RJTUUH2QwRDigzPKPYCgAAAGRJREFUCNddjzsKwDAMQ30oo6GlIPDgRfc/T5W0pJ83RSTPViIiwJKKiMnemvQ+kxbOaJG+b1KNoHQkJOQhMTxFWwK5+VAxJeR4YEYky9h1rLdbY9TjcixarhddNaruGv+Sny+cz9ItvUepxrcAAAAASUVORK5CYII=);}";
    css += " .item-go-to-top{padding:1px 8px 1px 16px;width:14px;height:14px;background-repeat:no-repeat;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAMAAAAolt3jAAAAAXNSR0IArs4c6QAAASlQTFRFydfx+IoAGUuXy9jwydfx+IoAGUuXy9jw+IoA1N/0y9jwydfx+IoASm+RGUuXztvyy9jw+IoANV+Ly9jwydfx+IoAGUuXy9jw+IoAztvyy9jw+IoAMFyNztvyy9jw+IoALlqZztvyy9jw+IoAMFyNy9jw+IoAy9jw+IoAztvyy9jw+IoAK1iPJ1WYztvyy9jw+IoAK1iPIVGU////+Pj49/n9//XP//Wv//SX6+/65+35//Jp4+n4//E9//Az3uX48emX/+V71N/08edD093v8eY5ztn0y9jwydfxytbq4ttAws/x5LsAmrHVmbDVka7ZmqhfjJ+XjJ6A+IoAjJ1lXoXDcIlxWIHBjnkYUHSdSHO7RHG5UHJ/Qmu1Omm2QmmHKl2wIVGUGUuX+XEqGwAAAAF0Uk5TAEDm2GYAAAABYktHRACIBR1IAAAACXBIWXMAAArwAAAK8AFCrDSYAAAAB3RJTUUH2QwREAEtlFL0+AAAAGZJREFUCNdlT0EOBCEM4k8NB80kJD148f//WXAmmd0sBy1SSgUAqvduEQdz7YM1D0vZndOc0VjF6IR8jSJruBDcdUViXfYgb2pD6cMZ+nhN+9vbGfV6lSDJYcteB91r3Jj/S/584QNxmi0RW7THUgAAAABJRU5ErkJggg==);}";
    GM_addStyle(css);
    
    registerFeature(addJumpButtons, ID);
    var keycodeUp = getShortcutKey(ID, 'goup', prefs); //84 Shift+T
    keycodeUp.fn = gototop;
    var keycodeDown = getShortcutKey(ID, 'godown', prefs); //66 Shift+B
    keycodeDown.fn = gotobottom;
    initKey([keycodeUp, keycodeDown]);
};
/**
 * Google Reader Preview Enhanced
 * @version  1.0.7g
 * @date 2009-01-16
 *
 * Adds a "Preview button" to Google Reader that allows you to view actual article in a frame.
 * Clicking again on that button goes back to RSS view.
 * Does work both in List view and expanded view.
 *
 * Original author :
 * Bryan Tsai
 * Julien Carosi
 * http://userscripts.org/scripts/show/12352
 * http://userscripts.org/scripts/show/9455
 */
GRP.preview = function(prefs, langs, ID){
    var SL = langs.preview;
    var locked = false;
    var overlay;
    var rx = getRegex(prefs.preview_filter);
    function addPreviewButton(el, entry, mode){
        // Top link
        //[preview as text] [maximize as icon]
        var previewOnIcon = prefs.preview_onicon || false;
        var keytext = formatShortcut(ID, 'prview', prefs);
        var link = getOriginalEntryLink(entry);
		if (!link){
			return;
		}
        //addClass(link, 'iframe');
        var plink;
        if (previewOnIcon) {
            addClass(link, 'grp-link-url');
            addClass(link, 'grp-link-title');
            //add a button right after the title
            plink = document.createElement('a');
            plink.title = SL.title + keytext; //[Shift+V]
            plink.href = '#';
            plink.innerHTML = '<div class="entry-title-preview"></div>';
            insertAfter(plink, link);
            plink.addEventListener('click', previewTitleClick, false);
        } else {
            //clean current a.href link to keep open link
            var txt = link.innerText;
            link.title = SL.opennewtab;
            addClass(link, 'grp-link-url');
            link.innerHTML = '<div class="entry-title-maximize"></div>';
            //create a second link before the previous one to used as preview
            //var title = link.parentNode;// h2.entry-title
            plink = document.createElement('a');
            //plink.className = 'ilink entry-title-link';
            addClass(plink, 'grp-link-title');
            plink.href = '#';
            plink.title = SL.title + keytext; //[Shift+V]
            plink.innerText = ' ' + txt;
            link.parentNode.insertBefore(plink, link);
            plink.addEventListener('click', previewTitleClick, false);
        }
        // Bottom button
		var title = SL.text + keytext;
		//var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
		var text = (SL.keyword || ID);//checkbox
        addBottomLink(el, text, title, ID, '', true, previewize, locked, entry, mode);
    }
    function previewShortcut(){
        onKey('btn-preview', previewize);
    }
	function previewGoNext(){
        siblingentry(true);
    }
	function previewGoPrev(){
        siblingentry(false);
    }
	
    /**
     * Click on faked title link to open preview
     */
    function previewTitleClick(e){
        e.preventDefault();
        var entry = getEntry(e);
        if (e.ctrlKey) {
            //Ctrl+click : open in a new tab
            openEntryInNewTab(entry);
        } else {
            var btn = getFirstElementByClassName(entry, 'btn-preview');//span
            previewize(btn, entry, locked, e);
        }
    }
    function previewize(btn, entry, lcked, e){
        var locked = (lcked && (typeof e === "undefined"));
        if (filterEntry(entry, rx)) {
            //Regex filtered
			if (locked) {
				//do nothing
            	
			} else {
				//open in a popup
				var urlLink = getEntryLink(entry);
				openWindow({
					url: urlLink.url
				});
			}
			return false;
        }
        // Need to scroll before changing entry-body, because scrolling repaints
        // article from scratch (list view only)
        if (!locked) {
            jump(entry, true);
        }
        var ebody = getFirstElementByClassName(entry, 'entry-body');//div
        var entryBody = getFirstElementByClassName(ebody, 'entry-enclosure');//div
        if (!entryBody) {
            entryBody = getFirstElementByClassName(ebody, 'item-body');//div
        }
        var iframe, active;
        if (prefs.preview_overlay) {
            renderoverlay(entry);
            if (overlay) {
                updateFrame(overlay.iframe, entry);
            }
        } else {
            //toggle button only when not overlay
            active = isActive(btn, entry, 'preview', locked);
            iframe = getFirstElementByClassName(entry, 'if-preview');//'iframe'
            if (active) {
                // classic mode-> preview mode
                if (iframe) {
                    // iframe already in document, display it
                    updateFrame(iframe, entry);
                } else {
                    // iframe not in document, create it
                    iframe = document.createElement('iframe');
                    iframe.className = 'if-preview';
                    updateFrame(iframe, entry);
                    setIframesize(iframe);
                    ebody.appendChild(iframe);
                    //if (prefs.preview_adjustframe) { adjustIframeHeight(iframe, h); }
                }
				show(iframe);
				hide(entryBody);
                // Scale article container to fullwidth
                ebody.setAttribute('style', 'max-width: 98%');
            } else {
                // preview mode -> classic mode
                hide(iframe);
                show(entryBody);
                ebody.removeAttribute('style', '');
                if (!locked) {
                    jump(entry, true);
                }
            }
        }
    }
    function updateFrame(iframe, entry){
        var urlLink = getEntryLink(entry);
        var url = urlLink.url;
        if (overlay) {
            if (overlay.title) {
                overlay.title.innerHTML = '<a href="' + urlLink.url + '">' + urlLink.title + '</a>';
            }
            if (overlay.subtitle) {
                var d = getSelectedDir();
                var p = getIndex(entry);
                overlay.subtitle.innerHTML = SL.overlay_category + ' : ' + d.text + ' - ' + p + '/' + d.count;
            }
        }
		iframe.setAttribute('src', '');
        var locksite = isSiteLocked(url);
        if (locksite) {
			GM_xmlhttpRequest({
                url: url,
                onload: function(r){
                    iframe.setAttribute('src', cleanHtml(r.responseText, url));
                }
            });
        } else {
            //get url fron hidden link
            iframe.setAttribute('src', url);
        }
        if (overlay) {
            jump(overlay.entry, true);
            simulateClick(overlay.entry);//mark as read
        }
    }
    function isSiteLocked(url){
		//Site doesn't allow to be iframe embedded (reopen themself in the main window opener) 
        return false;
    }
    function cleanHtml(html, url){
        var base = (/(.*)\//.exec(url))[0];
        //compress
        var text = html.replace(/\n\r/, "");
        //remove scripts
        text = text.replace(/<script.*<\/script>/gi, '');
        //add base
        text = text.replace('<head>', '<head><base href="' + base + '" />');
        //render html
        var htmlurl = 'data:text/html;,' + encodeURIComponent(text);
        return htmlurl;
    }
    function renderoverlay(entry){
		if (overlay && overlay.root) {
			showoverlay();
        } else {
            overlay = {};
            var urlLink = getEntryLink(entry);
            overlay.root = newel('pov');
            overlay.mask = dh(overlay.root, 'div', {
                id: 'pov_mask'
            });
            overlay.btn_next = dh(overlay.root, 'div', {
                id: 'pov_next',
				alt:'Next',
                title: SL.overlay_next+formatShortcut(ID, 'next', prefs)
            }, {
                click: function(){
                    siblingentry(true);
                }
            });
            overlay.btn_previous = dh(overlay.root, 'div', {
                id: 'pov_previous',
				alt:'Previous',
                title: SL.overlay_previous+formatShortcut(ID, 'previous', prefs)
            }, {
                click: function(){
                    siblingentry(false);
                }
            });
            overlay.btn_close = dh(overlay.root, 'div', {
                id: 'pov_close',
				alt:'Close',
                title: SL.overlay_close+formatShortcut(ID, 'close', prefs)
            }, {
                click: function(){
                    hideoverlay();
                }
            });
            overlay.title = dh(overlay.root, 'div', {
                id: 'pov_title',
                html: '<a href="' + urlLink.url + '">' + urlLink.title + '</a>'
            });
			overlay.visible = true;
            var d = getSelectedDir();
            var p = getIndex(entry);
            overlay.subtitle = dh(overlay.root, 'div', {
                id: 'pov_subtitle',
                html: SL.overlay_category + ' : ' + d.text + ' - ' + p + '/' + d.count
            });
            overlay.content = dh(overlay.root, 'div', {
                id: 'pov_content'
            });
            overlay.iframe = dh(overlay.content, 'iframe', {
                cls: 'if-preview',
                src: ''
            });
        }
		if (entry) {
			overlay.entry = entry;
		}
        overlay.content.style.height = (window.innerHeight - 40) + 'px';
        overlay.content.style.width = (window.innerWidth - 40) + 'px';
        overlay.iframe.setAttribute('width', (window.innerWidth - 40) + 'px');
        overlay.iframe.setAttribute('height', (window.innerHeight - 80) + 'px');
    }
    function hideoverlay(){
       if (overlay) {
	   	overlay.root.style.display = 'none';
	   	overlay.visible = false;
	   }
    }
	function showoverlay(){
        overlay.root.style.display = '';
		overlay.visible=true;
    }
    function siblingentry(next){
        var entry;
		if (overlay) {
			if (next) {
				entry = overlay.entry.nextSibling;
			} else {
				entry = overlay.entry.previousSibling;
			}
			if (entry && entry.id !== 'scroll-filler') {
				overlay.entry = entry;
				updateFrame(overlay.iframe, overlay.entry);
			}
		}
    }
    function onResize(height){
        if (prefs.preview_overlay) {
            if (overlay && overlay.visible){
				//Resize overlay
	            renderoverlay();
			}
        } else {
            var iframes = getElementsByClazzName('if-preview', 'iframe', document);
            var h = getHeightEntries();
            foreach(iframes, function(iframe){
                iframe.setAttribute('height', h + 'px');
            });
        }
    }
    function setIframesize(iframe){
        iframe.setAttribute('width', '100%');
        var h = getHeightEntries();
        iframe.setAttribute('height', h + 'px');
    }
    //column_locked
    locked = false;
    if (prefs && prefs.preview_locked) {
        locked = prefs.preview_locked;
    }
    var css = ".entry-title-maximize {margin-left: 4px;padding-left:16px;width:14px;height:14px;background-repeat:no-repeat;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAAZiS0dEAMIAzwDxOt8TMwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9kMERYGFfecphMAAAIYSURBVDjLjVK/a1NRGD3fffcleUlaSRpjiylBCTV0FTc3cXXRDkVB0bGDUnRxqCB2VKE4qCDSwcGt/4G66GBBpEOt1RolsTHBJLT58X7ez6H58fLU6lk+Lufe75zvfJewD0zbm9nYtuYsmzUiH8EACBg1hEP4B9qme3t1vTUPIBbkdEmr0rS8Ez9qzknFTK6rmIgAIijFGDugy2hELhQrZn6rZJ3b0x2AAMhPRXOxtuOeZuYBQQRB+JrLGHd2Wu7jdx9bM3+zKk1bxSZS+kouYywFFGqVhnPmw5fOeSKAAaaAAwCQABDWRZ2IXvQzYhb1pntvo9C56rNLg/j6FeJPthq77t21zfZlZoAIHOSz4+EVAC0G6LcG1Ya9uPa5fQ3ASHd1PUUAcKePGMuHD4XOHs/Hl0I6WXJY2Xn4frN9YS/Igc0ecpnI/eSofN3sqIXRmLzZtrwrwje3UarYKRBigVkZgJXPGo8mUqGnb9ebt75XbQcAomHtiRhsjjrTR6Oz6YR8TsTE3G9C+ayxfDChzwFIWDZPaVpgC0TQul0cpdR1Zqhq3Z1lwJmajDxIJ0PzXZfw5TFo4KsQQhSV517yPA6lk6HddEK/sd9XlwCgCRoKU2jSVkpdFEK0Avdd9n9ZAJIIXmHbOlat2888xV6PqNQdlH9aQ6+/lc04EY2QbzlyMh1+VShbp7ZKZg7/gbghXo6P6W9651+wUN+npzFYbAAAAABJRU5ErkJggg==);}";
    css += ".entry-title-preview {margin-left: 4px;padding-left:16px;width:14px;height:14px;background-repeat:no-repeat;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9oCAQg3C7TLiegAAAB3SURBVCjPYzx0/uN/BnIBuZoPnf/4nwXB+fCLgYHxAQMDAxMuDf8Z/v9jZGBQsDMUYGNgYGBgQUgxPrAz5FcjwsZbMDayLUxEupiJVA34TRnVTLrmf8Rp+Q9Xh5RI/itAEwBu1/z//4+BgVEBQzMsyZECGCnJVQB9eSYmMdOF/wAAAABJRU5ErkJggg==);}";
    css += ".preview .entry-likers, .preview .entry-annotations, .preview .entry-via, .preview .card-comments{display:none;}";
	css +=" #if-preview{left:0px;}";
    css += "#pov_mask{position:absolute;top:0px;left:0px;width:100%;height:100%;z-index:15000;background-color:#333;opacity:0.8;}";
    css += "#pov_content{position:absolute;top:0px;left:0px;margin:20px;text-align:center;vertical-align:middle;z-index:15001;color:#ddd;opacity:1;}";
    css += "#pov_content iframe{padding-top:40px;}";
    css += "#pov_title{position:absolute;width:95%;left: 20px;top:5px;height:40px;text-align:center;z-index:15002;}";
    css += "#pov_subtitle{position:absolute;width:95%;left:20px;top:40px;height:10px;text-align:left;z-index:15002;color:#ddd;}";
    css += "#pov_title a,#pov_title a:visited{color:#ddd !important;text-decoration:none;font-size:20px;}";
    css += "#pov_next{position:absolute;right:40px;top:45px;background:url(" + GRP.IMAGES_PATH + "/next1.png);width:24px;height:24px;z-index:15002;cursor:pointer;}";
    css += "#pov_previous{position:absolute;right:70px;top:45px;background:url(" + GRP.IMAGES_PATH + "/prev1.png);width:24px;height:24px;z-index:15002;cursor:pointer;}";
    css += "#pov_close{position:absolute;right:8px;top:45px;background:url(" + GRP.IMAGES_PATH + "/close2.png);width:24px;height:24px;z-index:15002;cursor:pointer;}";
    //css += "#pov_close{position:absolute;right:10px;top:45px;background:url("+GRP.IMAGES_PATH+"/close.png);width:22px;height:22px;z-index:15002;cursor:pointer;}";
    GM_addStyle(css);
    registerFeature(addPreviewButton, ID);
    initResize(onResize);
    
	var mykeys = {'prview':previewShortcut,'next':previewGoNext,'previous':previewGoPrev,'close':hideoverlay };
	iterate(mykeys, function(key, fn){
		var keycode = getShortcutKey(ID, key, prefs); //81 q
    	keycode.fn = fn;
    	initKey(keycode);
	});

	
};
/**
 * Open in background
 * @version  0.1
 * @date 2010
 * @author LudoO
 *
 * Open the news in a background tab
 *
 */

GRP.openbackground = function(prefs, langs, ID, SL, lang){
	var selectTab = prefs.openbackground_selectTab||false;
	
	function addButtons(el, entry, mode) {
		var title = SL.text + formatShortcut(ID, 'openback', prefs); //[Shift+V]
		var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
		addBottomLink(el, text, title, ID, '', false, openbackground, false, entry, mode);
	}

	function openbackground(e) {
		var entry = getEntry(e);
		openEntryInNewTab(entry, selectTab);
	}

	var css = ".btn-openbackground{padding:1px 8px 1px 16px;width:14px;height:14px;background-repeat:no-repeat;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAMAAAAolt3jAAAAAXNSR0IArs4c6QAAASlQTFRFydfx+IoAGUuXy9jwydfx+IoAGUuXy9jw+IoA1N/0y9jwydfx+IoASm+RGUuXztvyy9jw+IoANV+Ly9jwydfx+IoAGUuXy9jw+IoAztvyy9jw+IoAMFyNztvyy9jw+IoALlqZztvyy9jw+IoAMFyNy9jw+IoAy9jw+IoAztvyy9jw+IoAK1iPJ1WYztvyy9jw+IoAK1iPIVGU////+Pj49/n9//XP//Wv//SX6+/65+35//Jp4+n4//E9//Az3uX48emX/+V71N/08edD093v8eY5ztn0y9jwydfxytbq4ttAws/x5LsAmrHVmbDVka7ZmqhfjJ+XjJ6A+IoAjJ1lXoXDcIlxWIHBjnkYUHSdSHO7RHG5UHJ/Qmu1Omm2QmmHKl2wIVGUGUuX+XEqGwAAAAF0Uk5TAEDm2GYAAAABYktHRACIBR1IAAAACXBIWXMAAArwAAAK8AFCrDSYAAAAB3RJTUUH2QwREAEtlFL0+AAAAGZJREFUCNdlT0EOBCEM4k8NB80kJD148f//WXAmmd0sBy1SSgUAqvduEQdz7YM1D0vZndOc0VjF6IR8jSJruBDcdUViXfYgb2pD6cMZ+nhN+9vbGfV6lSDJYcteB91r3Jj/S/584QNxmi0RW7THUgAAAABJRU5ErkJggg==);}";
	GM_addStyle(css);
	
	registerFeature(addButtons, ID);
	
	var keycode = getShortcutKey(ID, 'openback', prefs); 
	keycode.fn = openbackground;
	initKey(keycode);
};
/**
 * Google Reader Filter
 * @version  0.6
 * @date 2009-08-14
 *
 * Filters duplicated entries and unwanted content or highlight chosen content based on keywords (with regex support).
 *
 * Original author :
 * Elad Ossadon (http://twitter.com/elado | http://www.devign.co.il | elado7@gmail.com)
 * http://userscripts.org/scripts/show/23671
 *
 */
GRP.filter = function(prefs, langs, ID, SL, lang){
    var locked = false;
    
    function addButton(el, entry, mode){
        var title = SL.text;
		var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
        addBottomLink(el, text, title, ID, '', true, filterEntries, locked, entry, mode);
    }
    
    function findPosition(element){
        var point = {
            x: 0,
            y: 0
        };
        var parent = element;
        while (parent) {
            point.x += parent.offsetLeft;
            point.y += parent.offsetTop;
            parent = parent.offsetParent;
        }
        return point;
    }
    function trim(s){
        return s ? s.replace(/^\s+|\s+$/g, "") : "";
    }
    
    // preferences
    var _excludes = [];
    var _highlights = [];
    var _hideExcluds, _hideDuplicates, _preferHighlights;
    
    function init(){
        //_excludes = JSON.parse(decodeURI("" + trim(GM_getValue("excludes", JSON.stringify(_excludes)))));
        //_highlights = JSON.parse(decodeURI("" + trim(GM_getValue("highlights", JSON.stringify(_highlights)))));
        
		GM_getValue("filter_excludes", [], function(o){
			_excludes=o||[];
			_excludes.sort(stringSort);
        	GM_getValue("filter_highlights", [], function(o){
				_highlights=o||[];
				_highlights.sort(stringSort);
				setRegExps();
		
				GM_getValue("filter_settings", {}, function(o){
					_hideExcluds = o.hideExcluds;
			        _hideDuplicates = o.hideDuplicates;
			        _preferHighlights = o.preferHighlights;
				});
			});
		});
		/*
		_excludes = GM_getValue("excludes", []);
		_highlights = GM_getValue("highlights", []);
		
        _hideExcluds = +GM_getValue("hideExcluds", 0);
        _hideDuplicates = +GM_getValue("hideDuplicates", 0);
        _preferHighlights = +GM_getValue("preferHighlights", 0);
        */
       
        initInterface();
        registerFeature(filterEntries, ID, {onlistviewtitle: true});
    }
    
    var _rxExcludes, _rxHighlights;
    
    function setRegExps(){
        if (_excludes.length) {
            _rxExcludes = getRegExp(_excludes);
        }
        if (_highlights.length) {
            _rxHighlights = getRegExp(_highlights);
        }
    }
    
    // (0) all until 0 (2f) , [0-9], above 9 (3a) to @ (40), [A-Z], above Z (5b)
    // to
    // a (60), [a-z], above z (7b) to european characters (bf), another unicode
    // character
    // this regex contains all symbols between 0-255 char codes, such as
    // ~!@#$%^&*()_+- etc in order to replace them with a single space
    // that way, both "hello: world!" and "hello.world" become "hello world" and
    // than regex in exclude/highlight stays simple
    // var
    // _minifyRx=/[\u0000-\u002f\u003a-\u0040\u005b-\u0060\u007b-\u00bf\u201d\u202b]+/g;
    var _minifyRx = /[~!@#$%^&*()_+-]+/g;
    
    function getRegExp(items){
        return new RegExp("(^| )(" + items.join("|") + ")($| )", "i");
    }
    
    function stringSort(a, b){
        return (a > b)?1:((a < b)?-1:0);
    }
    
    function initInterface(){
        GM_addStyle(".filter-settings-button,.filter-settings-window *,.filter-settings-entry-window *{font-family:verdana;font-size:11px;color:#000;} .filter-settings-window textarea,.filter-settings-entry-window input[type=text]{font-family:'courier new';border:1px solid #669CB9;} .filter-settings-button{cursor:pointer;background-color:#ADCBDA;padding:4px;position:absolute;top:30px;right:10px;z-index:1000;} .filter-settings-button:hover{background-color:#B46B8F;} .filter-settings-window{background-color:#ADCBDA;border:1px solid #669CB9;padding:4px;position:absolute;top:30px;right:10px;z-index:1000;} .filter-settings-window label.ta{float:left;width:250px;} .filter-settings-window textarea{height:300px;width:250px;} .filter-settings-entry-window{width:300px;background-color:#ADCBDA;border:1px solid #669CB9;font-size:11px;padding:4px;position:fixed;top:30px;right:10px;z-index:1000;} .filter-settings-entry-window input[type=text]{width:300px;} .filter-settings-window button,.filter-settings-entry-window button{margin-top:5px;margin-right:5px;background-color:#669CB9;color:#fff;font-size:11px;border:1px solid #000;}.entry-filtered .card-content *, .entry-filtered .collapsed *{color:#BCBCBC!important;} .entry-filtered:hover .card-content *, .entry-filtered:hover .collapsed *{color:#6A6A6A!important;} .entry-highlighted .card-content, .entry-highlighted .collapsed{background-color:#E6EFCF!important;} .entry-highlighted .card-content *, .entry-highlighted .collapsed *{color:#000!important;background-color:#E6EFCF;} .entry-duplicate *{color:#C7D0D8!important;} .filter-configure-entry{background-color:#daa;color:#fff;padding:2px;cursor:pointer;position:absolute;top:0;right:90px};.entry-hidden{display:none;}");
        
        var div = document.createElement("div");
        div.innerHTML = SL.settings;
        div.className = "filter-settings-button";
        div.addEventListener("click", openSettings, false);
        document.body.appendChild(div);
    }
    
    function formatListToTextArea(list){
        return list.join("\n").replace(/(\r?\n){2,}/, "");
    }
    
    // ui
    var _settings;
    var _excludeTextarea, _highlightTextarea;
    
    var _hideDuplicatesCheckbox, _hideExcludsCheckbox, _preferHighlightsCheckbox;
    
    function openSettings(){
        if (!_settings) {
            var settings = document.createElement("div");
            settings.className = "filter-settings-window";
            
            settings.innerHTML = "<label class='ta'>" + SL.excludes + "</label><label class='ta'>" + SL.highlights + "</label><div style='clear:both'></div>";
            
            var excludeTextarea = document.createElement("textarea");
            settings.appendChild(excludeTextarea);
            
            var highlightTextarea = document.createElement("textarea");
            settings.appendChild(highlightTextarea);
            
            settings.appendChild(document.createElement("br"));
            
            // hide dups
            var hideDuplicatesCheckbox = document.createElement("input");
            hideDuplicatesCheckbox.type = "checkbox";
            hideDuplicatesCheckbox.id = "grf-hideDuplicatesCheckbox";
            settings.appendChild(hideDuplicatesCheckbox);
            
            var hideDuplicatesLabel = document.createElement("label");
            hideDuplicatesLabel.innerHTML = SL.hideduplicates;
            hideDuplicatesLabel.setAttribute("for", "grf-hideDuplicates");
            settings.appendChild(hideDuplicatesLabel);
            hideDuplicatesLabel.style.paddingRight = "20px;";
            
            // hide excluded
            var hideExcludsCheckbox = document.createElement("input");
            hideExcludsCheckbox.id = "grf-hideExcludsCheckbox";
            hideExcludsCheckbox.type = "checkbox";
            settings.appendChild(hideExcludsCheckbox);
            
            var hideExcludsLabel = document.createElement("label");
            hideExcludsLabel.setAttribute("for", "grf-hideExcluds");
            hideExcludsLabel.innerHTML = SL.hideexcludes;
            settings.appendChild(hideExcludsLabel);
            
            // hide dups
            var preferHighlightsCheckbox = document.createElement("input");
            preferHighlightsCheckbox.type = "checkbox";
            preferHighlightsCheckbox.id = "grf-preferHighlightsCheckbox";
            settings.appendChild(preferHighlightsCheckbox);
            
            var preferHighlightsLabel = document.createElement("label");
            preferHighlightsLabel.innerHTML = SL.preferehighlights;
            preferHighlightsLabel.setAttribute("for", "grf-preferHighlights");
            settings.appendChild(preferHighlightsLabel);
            preferHighlightsLabel.style.paddingRight = "20px;";
            
            settings.appendChild(document.createElement("br"));
            
            // / buttons
            var update = document.createElement("button");
            update.textContent = SL.update;
            update.addEventListener("click", function(){
                saveSettings(excludeTextarea.value, highlightTextarea.value);
                settings.style.display = "none";
            }, false);
            settings.appendChild(update);
            
            var close = document.createElement("button");
            close.textContent = SL.close;
            close.addEventListener("click", function(){
                settings.style.display = "none";
            }, false);
            settings.appendChild(close);
            
            document.body.appendChild(settings);
            
            // globalize elements
            _settings = settings;
            _excludeTextarea = excludeTextarea;
            _highlightTextarea = highlightTextarea;
            _hideDuplicatesCheckbox = hideDuplicatesCheckbox;
            _hideExcludsCheckbox = hideExcludsCheckbox;
            _preferHighlightsCheckbox = preferHighlightsCheckbox;
        }
        _settings.style.display = "";
        _excludeTextarea.value = formatListToTextArea(_excludes);
        _highlightTextarea.value = formatListToTextArea(_highlights);
        
        _hideDuplicatesCheckbox.checked = !!_hideDuplicates;
        _hideExcludsCheckbox.checked = !!_hideExcluds;
        _preferHighlightsCheckbox.checked = !!_preferHighlights;
    }
    
	function createButton(parent, id, text, input, exclude){
		var el = document.createElement("button");
        el.id = id;
        el.name = "btnex";
        el.id = id;
        el.textContent = text;
		el.addEventListener("click", function(){
                var coll = exclude ? _excludes : _highlights;
                coll.push(input.value);
                saveCollections();
                parent.style.display = "none";
            }, false);
			
        parent.appendChild(el);
		return el;
	}
    function createRadio(parent, id, text, value, selected){
        var el = document.createElement("input");
        el.name = "ex";
        el.id = id;
        el.type = "radio";
        el.value = value;
        if (selected) {
            el.checked = true;
        }
        parent.appendChild(el);
        var label = document.createElement("label");
        label.attributes['for'] = 'radio-exclude';
        label.innerText = text;
        parent.appendChild(label);
		return el;
    }
    
    var _settingsForEntry, _settingsForEntryInput;
    
    function openSettingsForEntry(relative, title){
        if (!_settingsForEntry) {
            var settingsForEntry = document.createElement("div");
            settingsForEntry.className = "filter-settings-entry-window";
            settingsForEntry.innerHTML = "<label>" + SL.quickadd + "</label><div style='clear:both'></div>";
            
            var input = document.createElement("input");
            input.type = "text";
            settingsForEntry.appendChild(input);
            
            settingsForEntry.appendChild(document.createElement("br"));
            
            var  excludesButton = createButton(settingsForEntry, 'btn-exclude', SL.exclude, input, true);
			var  highlightButton = createButton(settingsForEntry, 'btn-highlight',SL.highlight, input, false);
			
            var close = document.createElement("button");
            close.textContent = SL.close;
            close.addEventListener("click", function(){
                settingsForEntry.style.display = "none";
            }, false);
            settingsForEntry.appendChild(close);
            
            document.body.appendChild(settingsForEntry);
            
            _settingsForEntry = settingsForEntry;
            _settingsForEntryInput = input;
        }
        _settingsForEntry.style.display = "";
        var point = findPosition(relative);
        _settingsForEntry.style.left = (point.x - 250) + "px";
        
        var y = point.y + 21 - document.getElementById("entries").scrollTop;
        if (y + _settingsForEntry.offsetHeight > document.documentElement.clientHeight) {
            _settingsForEntry.style.top = "auto";
            _settingsForEntry.style.bottom = (document.documentElement.clientHeight -
            y +
            10) +
            "px";
        }
        else {
            _settingsForEntry.style.top = y + "px";
            _settingsForEntry.style.bottom = "auto";
        }
        _settingsForEntryInput.value = title;
    }
    
    var _alreadyPrinted = {};
    
    function saveSettings(excludesString, highlightsString){
        _excludes = excludesString.replace(/\r/, "").split(/\n+/);
        _highlights = highlightsString.replace(/\r/, "").split(/\n+/);
        _hideExcluds = +_hideExcludsCheckbox.checked;
        _hideDuplicates = +_hideDuplicatesCheckbox.checked;
        _preferHighlights = +_preferHighlightsCheckbox.checked;
        /*GM_setValue("hideExcluds", _hideExcluds ? 1 : "");
        GM_setValue("hideDuplicates", _hideDuplicates ? 1 : "");
        GM_setValue("preferHighlights", _preferHighlights ? 1 : "");*/
		
		GM_setValue("filter_settings", {
			hideExcluds:_hideExcluds,
		    hideDuplicates: _hideDuplicates,
		    preferHighlights: _preferHighlights
		});
		
        saveCollections();
    }
    
    function saveCollections(update){
/*		GM_setValue("excludes", JSON.stringify(_excludes));
		GM_setValue("highlights", JSON.stringify(_highlights));
		*/
		GM_setValue("filter_excludes", _excludes);
		GM_setValue("filter_highlights", _highlights);
		
		GM_setValue("filter_items", {
			excludes:_excludes,
			highlights:_highlights
		});
        setRegExps();
        updateFilterEntries();
    }
    
    function updateFilterEntries(){
        forAllEntries(function(entry){
            filterEntries(false, entry, false, true);
        });
    }
    
    function filterEntries(btn, entry, mode, force){
        //var active = isActive(btn, entry, 'filter', locked);
        if (!force && isTagged(entry, 'tfilter')) {
            //stop entry was already scanned
            return;
        }
        
        // reset the dups list when entries inserted again
        /*if (entry.parentNode.id === "entries") {
            var l = entry.parentNode.childNodes.length;
            if (l <= 2) {
                _alreadyPrinted = {};
            }
        }*/
		if (!entry.previousElementSibling) {
			_alreadyPrinted = {};
		}
        
        if (force) {
            //clean before update
            removeClass(entry, 'entry-highlighted');
            removeClass(entry, 'entry-filtered');
            removeClass(entry, 'entry-duplicate');
            removeClass(entry, 'entry-hidden');
        }
        var link = getEntryLink(entry);
        var title = link.title;
        //console.log('>>>>'+active+'--'+title);
        
        var minifiedTitle = minifyTitle(title);
		if (prefs.filter_searchbody) {
			var body = getBody(entry);
			if (body) {
				minifiedTitle += ' ' + body.innerText;
			}
		}
		
        var escapedTitle = encodeURI(minifiedTitle);
        
        var configure = document.createElement("span");
        configure.className = "filter-configure-entry";
        configure.textContent = "#";
        entry.appendChild(configure, entry);
        configure.title = minifiedTitle;
        configure.addEventListener("click", configureCurrent, false);
        
        var b = false;
        if (!force && _alreadyPrinted[escapedTitle]/* || _alreadyPrinted[url] */) {
            addClass(entry, 'entry-duplicate');
            if (_hideDuplicates) {
                addClass(entry, 'entry-hidden');
                //entry.parentNode.removeChild(entry);// entry.style.display="none";
            }
            return;
        }
        
        if (_preferHighlights) {
            if (_highlights.length) {
                b = checkEntry(minifiedTitle, entry, _rxHighlights, "entry-highlighted");
            }
            if (!b && _excludes.length) {
                b = checkEntry(minifiedTitle, entry, _rxExcludes, "entry-filtered");
                if (_hideExcluds && b) {
                    addClass(entry, 'entry-hidden');
                    //entry.parentNode.removeChild(entry);// entry.style.display="none";
                }
            }
        }
        else {
            if (_excludes.length) {
                b = checkEntry(minifiedTitle, entry, _rxExcludes, "entry-filtered");
                if (_hideExcluds && b) {
                    addClass(entry, 'entry-hidden');
                    //entry.parentNode.removeChild(entry);// entry.style.display="none";
                }
            }
            if (!b && _highlights.length) {
                checkEntry(minifiedTitle, entry, _rxHighlights, "entry-highlighted");
            }
        }
        if (!force) {
			_alreadyPrinted[escapedTitle] = /* _alreadyPrinted[url]= */ true;
		}
    }
    function minifyTitle(title){
        return trim(title.replace(_minifyRx, " ").replace(/ +/g, " ").toLowerCase());
    }
    
    function configureCurrent(e){
        openSettingsForEntry(e.target, e.target.title);
        e.preventDefault();
        e.stopPropagation();
    }
    
    function checkEntry(title, element, rx, className){
        if (rx.test(title)) {
            addClass(element, className);
            return true;
        }
        return false;
    }
    
    init();
};
/**
 * Google Reader Unread Count
 * @version  9
 * @date 2009-11-25
 * 
 * Display actual unread count instead of "1000+" in Google Reader
 * 
 * Original author : 
 * Angus http://angusdev.mysinablog.com/
 */

GRP.count = function(prefs, langs, ID, SL, lang){
    var unreadCountElement = null;
    
    // Wait for the dom ready
    function waitForReady(){
        unreadCountElement = document.getElementById('reading-list-unread-count');
        if (unreadCountElement) {
            window.setInterval(calcUnread, 3000);
            calcUnread();
        } else {
            window.setTimeout(waitForReady, 500);
        }
    }
    
    function modifySubtree(){
        if (unreadCountElement.textContent.match(/\d{4}\+?/)) {
            calcUnread();
        }
    }
    
    function findItemUnread(checkDuplicated, item){
        var hasplus = false;
        var count = 0;
        var alreadyCounted = false;
        var countres = item.innerHTML.match(/\((\d*)\+?\)/);
        if (countres) {
            count = parseInt(countres[1], 10);
            if (item.innerHTML.match(/\(1000\+\)/)) {
                hasplus = true;
            }
            var nodeTitle = item.parentNode.getAttribute('title');
            if (nodeTitle) {
                if (checkDuplicated.indexOf(nodeTitle) < 0) {
                    checkDuplicated.push(nodeTitle);
                } else {
                    alreadyCounted = true;
                }
            }
        }
        
        return {
            count: count,
            hasplus: hasplus,
            alreadyCounted: alreadyCounted
        };
    }
    
    function calcUnread(){
        var checkDuplicated = [];
        var total = 0;
        var totalplus = false;
        var res = document.evaluate("//li[contains(@class, 'folder')]//li[contains(@class, 'folder')]", document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
        for (var i = 0; i < res.snapshotLength; i++) {
            var res2 = document.evaluate(".//li[contains(@class, 'unread')]/a/span/span[contains(@class, 'unread-count')]", res.snapshotItem(i), null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
            var subtotal = 0;
            var subtotalplus = false;
            for (var j = 0; j < res2.snapshotLength; j++) {
                var result = findItemUnread(checkDuplicated, res2.snapshotItem(j));
                if (result.hasplus) {
                    totalplus = true;
                    subtotalplus = true;
                }
                subtotal += result.count;
                if (!result.alreadyCounted) {
                    total += result.count;
                }
            }
            if (subtotal > 0) {
                var resfolder = document.evaluate(".//a/span/span[contains(@class, 'unread-count')]", res.snapshotItem(i), null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                if (resfolder) {
                    resfolder.innerHTML = '&nbsp;(' + subtotal + (subtotalplus ? '+' : '') + ')';
                }
            }
        }
        
		//friends unread
		var elfriend = document.getElementById('friends-tree-item-0-unread-count');
		if (elfriend && elfriend.innerText) {
			var friendcount = parseInt(elfriend.innerText.replace(/[\s\(\)]*/g, ''), 10);
			if (friendcount && friendcount > 0) {
				total += friendcount;
			}
		}
		
        // untagged items
        var res3 = document.evaluate("//ul[@id='sub-tree']/li/ul/li[not(contains(@class, 'folder')) and contains(@class, 'unread')]/a/span/span[contains(@class, 'unread-count')]", document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
        for (var k = 0; k < res3.snapshotLength; k++) {
            var res4 = findItemUnread(checkDuplicated, res3.snapshotItem(k));
            if (res4.hasplus) {
                totalplus = true;
            }
            if (!res4.alreadyCounted) {
                total += res4.count;
            }
        }
        
        if (total > 0) {
            var totaltext = total + (totalplus ? '+' : '');
            unreadCountElement.innerHTML = ' (' + totaltext + ')';
            
            //update subtitle (1000+ new items)
            var elnew = document.getElementById('show-new');
            if (elnew && elnew.innerText.indexOf('1000+') >= 0) {
                elnew.innerText = elnew.innerText.replace('1000+', totaltext);
            }
            
            // update windows title as well
            if (totaltext) {
                var newTitle = '(' + totaltext + ') ' +
                document.title.replace(/\s*\(\d+\+?\)$/, '').replace(/^\(\d+\+?\)\s*/, '');
                if (document.title != newTitle) {
                    document.title = newTitle;
                }
            }
        }
    }
    
    waitForReady();
    
};
/**
 * GReader Favicon Alerts
 * @version  1.0.1
 * @date 2009-06-06
 *
 * Display actual unread count instead of "1000+" in Google Reader
 *
 * Original author :
 * Peter Wooley (http://peterwooley.com)
 * Tyler Sticka
 * http://userscripts.org/scripts/show/46615
 */
GRP = GRP || {};
GRP.counticon = function(prefs, langs, ID, SL, lang){
    var self = this;
    
    this.construct = function(){
        this.head = document.getElementsByTagName("head")[0];
        this.pixelMaps = 
        {
            icons: 
            {
                'unread': [['', '', '', '#b9dd93', '#b9dd93', '#b9dd93', '#b9dd93', '#b9dd93', '#b4d98d', '#add484', '#a5ce7c', '#a0ca75', '#a0c973', '', '', ''], ['', '', '#acd383', '#e0fbd9', '#e3fde0', '#e6ffe5', '#e4fde0', '#dffbd9', '#daf7d1', '#d5f4c7', '#cff0bd', '#caebb3', '#c3e7a8', '#acd383', '', ''], ['', '', 'a0c973', '#defad7', '#e2fcde', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', '#cd6b6b', ''], ['', '', '#9fc974', '#dbf7d2', '#cd6b6b', '#f9eded', '#fcf6f6', '#fcf6f6', '#f8ecec', '#f7e7e7', '#f5e3e3', '#f3dddd', '#efd1d1', '#eecece', '#e6b6b6', '#cd6b6b'], ['', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#b9a1a1', '#ebc3c3', '#e6b6b6', '#eac0c0', '#cd6b6b'], ['#2a5699', '#a4bdec', '#c1d3f5', '#c1d3f5', '#9bb8f2', '#90b0ef', '#86a8ed', '#7da0e4', '#6a93db', '#5b88e6', '#4c7eca', '#2a5699', '#ebc3c3', '#e8bcbc', '#e4b2b2', '#cd6b6b'], ['#2a5699', '#b6cbf2', '#ffffff', '#ffffff', '#ffffff', '#c9d7f2', '#7099ee', '#5885e4', '#5381d9', '#4c7eca', '#4f7dd8', '#2a5699', '#beb2b2', '#e4b2b2', '#e8bcbc', '#cd6b6b'], ['#2a5699', '#abc3f5', '#e4eaf5', '#ffffff', '#ffffff', '#ffffff', '#ffffff', '#90b0ef', '#5381d9', '#4676da', '#467aca', '#2a5699', '#c5c5c5', '#edc9c9', '#e2aaaa', '#cd6b6b'], ['#2a5699', '#90b0ef', '#638ee9', '#638ee9', '#9bb8f2', '#edf0f6', '#ffffff', '#ffffff', '#90ade4', '#467aca', '#4676da', '#2a5699', '#c5c5c5', '#fbf3f3', '#dfa3a3', '#cd6b6b'], ['#2a5699', '#a4bdec', '#ffffff', '#ffffff', '#c1d3f5', '#7499e5', '#c1d3f5', '#ffffff', '#ffffff', '#608bd7', '#3c74ca', '#2a5699', '#c5c5c5', '#ffffff', '#dc9898', '#cd6b6b'], ['#2a5699', '#9bb8f2', '#ffffff', '#ffffff', '#ffffff', '#e4eaf5', '#638ee9', '#edf0f6', '#ffffff', '#b6cbf2', '#336cc9', '#2a5699', '#c5c5c5', '#ffffff', '#e7b9b9', '#cd6b6b'], ['#2a5699', '#6a93db', '#5381d9', '#7da0e4', '#f4f7fc', '#ffffff', '#b6cbf2', '#90ade4', '#ffffff', '#ffffff', '#2d69c3', '#2a5699', '#c5c5c5', '#ffffff', '#e6b6b6', '#cd6b6b'], ['#2a5699', '#84a5e7', '#ffffff', '#90ade4', '#7499e5', '#ffffff', '#f4f7fc', '#3c74ca', '#ffffff', '#ffffff', '#5683c6', '#2a5699', '#b28f8f', '#e6b6b6', '#d27c7c', '#cd6b6b'], ['#2a5699', '#6a93db', '#ffffff', '#f4f7fc', '#3c74ca', '#ffffff', '#ffffff', '#3c74ca', '#d9e3f7', '#ffffff', '#4c7eca', '#2a5699', '#a25d5d', '#cd6b6b', '#cd6b6b', ''], ['#2a5699', '#3c74ca', '#608bd7', '#6a93db', '#3c74ca', '#6892d0', '#608bd7', '#2b65c2', '#467aca', '#4c7eca', '#235daf', '#2a5699', '', '', '', ''], ['', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '#2a5699', '', '', '', '', '']]
            },
            numbers: 
            {
                0: [[1, 1, 1], [1, 0, 1], [1, 0, 1], [1, 0, 1], [1, 1, 1]],
                1: [[0, 1, 0], [1, 1, 0], [0, 1, 0], [0, 1, 0], [1, 1, 1]],
                2: [[1, 1, 1], [0, 0, 1], [1, 1, 1], [1, 0, 0], [1, 1, 1]],
                3: [[1, 1, 1], [0, 0, 1], [0, 1, 1], [0, 0, 1], [1, 1, 1]],
                4: [[0, 0, 1], [0, 1, 1], [1, 0, 1], [1, 1, 1], [0, 0, 1]],
                5: [[1, 1, 1], [1, 0, 0], [1, 1, 1], [0, 0, 1], [1, 1, 1]],
                6: [[0, 1, 1], [1, 0, 0], [1, 1, 1], [1, 0, 1], [1, 1, 1]],
                7: [[1, 1, 1], [0, 0, 1], [0, 0, 1], [0, 1, 0], [0, 1, 0]],
                8: [[1, 1, 1], [1, 0, 1], [1, 1, 1], [1, 0, 1], [1, 1, 1]],
                9: [[1, 1, 1], [1, 0, 1], [1, 1, 1], [0, 0, 1], [1, 1, 0]],
                '+': [[0, 0, 0], [0, 1, 0], [1, 1, 1], [0, 1, 0], [0, 0, 0]],
                'k': [[1, 0, 1], [1, 1, 0], [1, 1, 0], [1, 0, 1], [1, 0, 1]]
            }
        };
        
        this.lastUnreadCount = 0;
        this.timer = setInterval(this.poll, 500);
        this.poll();
        
        return true;
    };
    
    this.drawUnreadCount = function(unread){
        if (!self.textedCanvas) {
            self.textedCanvas = [];
        }
        
        if (!self.textedCanvas[unread]) {
            var iconCanvas = self.getUnreadCanvas();
            var textedCanvas = document.createElement('canvas');
            textedCanvas.height = textedCanvas.width = iconCanvas.width;
            var ctx = textedCanvas.getContext('2d');
            ctx.drawImage(iconCanvas, 0, 0);
            
            ctx.fillStyle = "#fef4ac";
            ctx.strokeStyle = "#dabc5c";
            ctx.strokeWidth = 1;
            
            var count = unread.length;
            
            if (count > 3) {
                unread = unread.substring(0, 1) + "k+";
                count = unread.length;
            }
            
            var index, bgHeight = self.pixelMaps.numbers[0].length, bgWidth = 0, padding = count < 4 ? 1 : 0, topMargin = 2;
            
            for (index = 0; index < count; index++) {
                bgWidth += self.pixelMaps.numbers[unread[index]][0].length;
                if (index < count - 1) {
                    bgWidth += padding;
                }
            }
            bgWidth = bgWidth > textedCanvas.width - 4 ? textedCanvas.width - 4 : bgWidth;
            ctx.fillRect(textedCanvas.width - bgWidth - 4, topMargin, bgWidth + 4, bgHeight + 4);
            
            var digit;
            var digitsWidth = bgWidth;
            for (index = 0; index < count; index++) {
                digit = unread[index];
                
                if (self.pixelMaps.numbers[digit]) {
                    var map = self.pixelMaps.numbers[digit];
                    var height = map.length;
                    var width = map[0].length;
                    
                    ctx.fillStyle = "#2c3323";
                    
                    for (var y = 0; y < height; y++) {
                        for (var x = 0; x < width; x++) {
                            if (map[y][x]) {
                                ctx.fillRect(14 - digitsWidth + x, y + topMargin + 2, 1, 1);
                            }
                        }
                    }
                    
                    digitsWidth -= width + padding;
                }
            }
            
            ctx.strokeRect(textedCanvas.width - bgWidth - 3.5, topMargin + 0.5, bgWidth + 3, bgHeight + 3);
            
            self.textedCanvas[unread] = textedCanvas;
        }
        
        return self.textedCanvas[unread];
    };
    this.getIcon = function(){
        return self.getUnreadCanvas().toDataURL('image/png');
    };
    this.getUnreadCanvas = function(){
        if (!self.unreadCanvas) {
            self.unreadCanvas = document.createElement('canvas');
            self.unreadCanvas.height = self.unreadCanvas.width = 16;
            
            var ctx = self.unreadCanvas.getContext('2d');
            
            for (var y = 0; y < self.unreadCanvas.width; y++) {
                for (var x = 0; x < self.unreadCanvas.height; x++) {
                    if (self.pixelMaps.icons.unread[y][x]) {
                        ctx.fillStyle = self.pixelMaps.icons.unread[y][x];
                        ctx.fillRect(x, y, 1, 1);
                    }
                }
            }
        }
        
        return self.unreadCanvas;
    };
    this.getUnreadCount = function(){
        matches = self.getSearchText().match(/\((.*)\)/);
        return matches ? matches[1] : false;
    };
    this.getUnreadCountIcon = function(unreadcount){
        var unread = unreadcount || self.getUnreadCount();
        return self.drawUnreadCount(unread).toDataURL('image/png');
    };
    this.getSearchText = function(){
        return document.title;
    };
    this.poll = function(){
        var unreadcount = self.getUnreadCount();
        if (unreadcount) {
            if (unreadcount !== lastUnreadCount) {
                console.log('poll getUnreadCountIcon de ' + lastUnreadCount + ' a ' + unreadcount);
                self.setIcon(self.getUnreadCountIcon(unreadcount));
                lastUnreadCount = unreadcount;
                self.forceRefresh();
            }
        } else {
            console.log('poll getIcon');
            self.setIcon(self.getIcon());
        }
    };
    this.forceRefresh = function(){
        /*var hash = window.location.hash;
         if (!hash) {
         window.location.hash = "#";
         } else {
         if (/#Stream\//.test(hash)) {
         window.location.hash = hash.replace(/#Stream\//, 'stream/');
         } else {
         window.location.hash = hash.replace(/#stream\//, 'Stream/');
         }
         }*/
    };
    this.setIcon = function(icon){
        var links = self.head.getElementsByTagName("link");
        for (var i = 0; i < links.length; i++) {
            if (links[i].type == "image/x-icon" && (links[i].rel == "shortcut icon" || links[i].rel == "icon") &&
            links[i].href !== icon) {
                self.head.removeChild(links[i]);
            } else if (links[i].href == icon) {
                return;
            }
        }
        var newIcon = document.createElement("link");
        newIcon.type = "image/x-icon";
        newIcon.rel = "shortcut icon";
        newIcon.href = icon;
        return self.head.appendChild(newIcon);
    };
    
    this.toString = function(){
        return '[object GReaderFavIconAlerts]';
    };
    
    return this.construct();
};
/**
 * Google Reader - Read by Mouse
 * @version  1.1
 * @date 2009-02-28
 *
 * Adds a button that toggles Google Reader in and out of a "mouse-only" mode
 * that allows for easy and customizable reading via the mouse buttons
 * (next item, previous item, open in tab/star/share/tag).
 *
 * bug windows middle ckick :
 * http://code.google.com/p/chromium/issues/detail?id=17234
 *
 * Original author :
 * Ryan Williams <ryanbot at gmail>
 * http://userscripts.org/scripts/show/8843
 */
GRP.readbymouse = function(prefs, langs, ID, SL, lang){
    var btn = document.getElementById('btn-readbymouse');
    if (btn) {
        return;
    }
    
    var systemStatus = GM_getValue('rbmStatus', 'Off');
    var ua = navigator.userAgent.toLowerCase();
    var isWindows = /windows|win32/.test(ua);
    
    var isMClick = (!isWindows || (isWindows && isChromeVersionMini('5.0.342.1')));
    
    // Get the element our new button goes by
    var nearNewButton = document.getElementById('entries-down');
    
    // Add the middle click settings droplist and the Mouse Control toggle
    // button
    if (nearNewButton) {
        var mouseCtrlButton = document.createElement("span");
        mouseCtrlButton.id = 'btn-readbymouse';
        var html = '<input type="button" id="___mouseCtrl" value="ReadByMouse ' + systemStatus + '" style="margin-left: 10px;"></input>';
        if (isMClick) {
            html += '<span style="margin-left: 10px;">' + SL.middleclick +
            ':</span><select id="___middleClickSettings" name="midClickSettings" style="margin-left: 5px;">' +
            '<option id="openInTab" value="openInTab">' +
            SL.openintab +
            '</option><option id="openInBackTab" value="openInBackTab">' +
            SL.openinbacktab +
            '</option><option id="share" value="share">' +
            SL.shares +
            '</option><option id="star" value="star">' +
            SL.stars +
            '</option><option id="addTag" value="addTag">' +
            SL.addtag +
            '</option></select><span id="addTagSpan" style="text-align:left; visibility: collapse; margin-left: 10px;">' +
            SL.addtag +
            ':<input type="textbox" id="txtTag" value=""></span>';
        }
        
        mouseCtrlButton.innerHTML += html;
        insertAfter(mouseCtrlButton, nearNewButton);
    }
    
    var currentSettingMidClick = 'openInTab';
    var currentTag = '';
    
	GM_getValue('readbymouse_settings', {}, function(o){
		currentSettingMidClick=o.midClick||'openInTab';
		currentTag=o.tag||'';
		selectvalue(currentSettingMidClick, currentTag);
	});
	
	function saveSettings(){
		GM_setValue('readbymouse_settings', {
			tag:currentTag,
			midClick:currentSettingMidClick
		});
	}
	
	/*
    // Get the current middle click setting out of GM	
	var currentSettingMidClick = GM_getValue('middleClickSetting', 'openInTab');
    // Get the current tag setting out of GM
    var currentTag = GM_getValue('mouseTag', '');
    */
	
    // set the selected value to the setting
	function selectvalue(settingMidClick){
	    var midClickOption = document.getElementById(settingMidClick);
	    if (midClickOption) {
	        midClickOption.selected = true;
	        // Hide or reveal the tag textbox
	        if (midClickOption.value == "addTag") {
	            document.getElementById('addTagSpan').style.visibility = 'visible';
	        } else {
	            document.getElementById('addTagSpan').style.visibility = 'hidden';
	        }
	        document.getElementById('txtTag').value = currentTag;
	    }
	}
    // Add listener for key press (toggles Mouse on and off)
    document.addEventListener('keydown', function(event){
        if (event.ctrlKey && event.which == 90) {
            var myBtn = document.getElementById('___mouseCtrl');
            
            if (!myBtn) {
                return false;
            }
            
            if (systemStatus == 'On') {
                myBtn.value = SL.off;
                systemStatus = 'Off';
            } else {
                myBtn.value = SL.on;
                systemStatus = 'On';
            }
            GM_setValue('rbmStatus', systemStatus);
        }
    }, false);
    
    // Add listener for mouse clicks
    document.addEventListener('click', function(event){
        console.log('event.button:' + event.button);
        // On each left click, check to see if the middle click setting
        // has changed. if so, then set it in GM
        if (event.button === 0) {
        
            // Get the selected option
            var myMiddleSelect = document.getElementById('___middleClickSettings');
            if (!myMiddleSelect) {
                return;
            }
            
            var midClickSelValue = myMiddleSelect.options[myMiddleSelect.selectedIndex].value;
            if (!midClickSelValue) {
                return;
            }
            
            // If the middle click setting has changed, then set it
            // in GM
            if (currentSettingMidClick != midClickSelValue) {
                //GM_setValue('middleClickSetting', midClickSelValue);
                currentSettingMidClick = midClickSelValue;
				saveSettings();
            }
            
            // If the tag has changed, then set it in GM
            var strTag = document.getElementById('txtTag').value;
            if (currentTag != strTag) {
                //GM_setValue('mouseTag', strTag);
                currentTag = strTag;
				saveSettings();
            }
            
            // Hide or reveal the tag textbox
            if (currentSettingMidClick == "addTag") {
                document.getElementById('addTagSpan').style.visibility = 'visible';
            } else {
                document.getElementById('addTagSpan').style.visibility = 'collapse';
            }
            
        } else if (event.button == 1 && systemStatus == 'On') {
            // Middle click
            // If they click on a link, let the link work like
            // normal
            if (event.target.nodeName.toLowerCase() == 'a') {
                return;
            }
            
            // Action here depends on the selection from the
            // droplist
            var mySettingsDL = document.getElementById("___middleClickSettings");
            if (mySettingsDL) {
                switch (mySettingsDL.options[mySettingsDL.selectedIndex].value) {
                    case "addTag":
                        tagItem2();
                        break;
                }
            }
            
            event.stopPropagation();
            event.preventDefault();
        }
        
    }, true);
    
    // Add listener for mousedown
    document.addEventListener('mousedown', function(event){
        var myTarget = event.target;
        if (systemStatus == 'On') {
            // If they click on a link, let the link work like normal
            if (myTarget.nodeName.toLowerCase() == 'a') {
                return;
            }
            var clickType = event.button;
            // Left Click
            if (clickType === 0) {
            
                // turn mouse control off if clicking on the mouse
                // control button
                if (myTarget.id == '___mouseCtrl') {
                    myTarget.value = SL.off;
                    systemStatus = 'Off';
                    GM_setValue('rbmStatus', systemStatus);
                } else if (myTarget.id == '___middleClickSettings' || myTarget.id == 'txtTag') {
                    // Always let clicks work here
                } else {
                    simulateClick(document.getElementById("entries-down"));
                    event.stopPropagation();
                    event.preventDefault();
                }
            }
            
            // Right Click
            if (clickType == 2) {
                simulateClick(document.getElementById("entries-up"));
                event.stopPropagation();
                event.preventDefault();
            }
            
            // Middle click
            if (clickType == 1) {
            
                // Action here depends on the selection from the
                // droplist
                var mySettingsDL = document.getElementById("___middleClickSettings");
                if (mySettingsDL) {
                    switch (mySettingsDL.options[mySettingsDL.selectedIndex].value) {
                        case "openInTab":
                            openInTab(true);
                            break;
                        case "openInBackTab":
                            openInTab(false);
                            break;
                        case "share":
                            shareItem();
                            break;
                        case "star":
                            starItem();
                            break;
                        case "addTag":
                            tagItem1();
                            break;
                    }
                }
                event.stopPropagation();
                event.preventDefault();
            }
            
        } else // Mouse control is off
        {
            // If they clicked on the mouse control button, then turn it
            // on.
            if (myTarget.id == '___mouseCtrl') {
                myTarget.value = SL.on;
                systemStatus = 'On';
                GM_setValue('rbmStatus', systemStatus);
            }
        }
    }, true);
    
    // Go find the "Open original in tab" element and get the URL for original
    function openInTab(selected){
        openEntryInNewTab(false, selected);
    }
    
    // Go find the "share item" button and simulate a click on it
    function shareItem(){
        var current = getCurrentEntry();
        var currentEntry = current.getElementsByTagName("broadcast")[0];
        // var currentEntry = $("#current-entry .entry-actions .broadcast");
        simulateClick(currentEntry);
    }
    
    // Go find the "star item" button and simulate a click on it
    function starItem(){
        var current = getCurrentEntry();
        var currentEntry = current.getElementsByTagName("star")[0];
        // var currentEntry = $("#current-entry .entry-actions .star");
        simulateClick(currentEntry);
    }
    
    // Do the first part of tagging (click the tag button to reveal the tag
    // control)
    function tagItem1(){
        var current = getCurrentEntry();
        var currentEntry = current.getElementsByTagName("entry-tagging-action-title")[0];
        // var currentEntry = $("#current-entry .entry-actions
        // .entry-tagging-action-title");
        simulateClick(currentEntry);
    }
    
    // Do the second part of tagging (add the tag and click the save button)
    function tagItem2(){
        var tagEdit = document.getElementsByTagName("tags-edit");
        var tagEditTags = tagEdit.getElementsByTagName("tags-edit-tags");
        
        tagEditTags.innerHTML += txtTag.innerText;
        /*
         * $(".tags-edit .tags-edit-tags").val( $(".tags-edit
         * .tags-edit-tags").val() + $("#txtTag").val()); //
         * document.getElementById('tags-container-template');
         *
         * var popup = $(".tags-edit .tags-edit-buttons")
         * .find(".goog-button-body"); //
         * document.getElementById('tags-container-template');
         */
        var tagEditButton = tagEdit.getElementsByTagName("tags-edit-buttons")[0];
        var popup = tagEditButton.getElementsByTagName("goog-button-body")[0];
        
        simulateClick(popup);
    }
    
    // Disable the context menu when Mouse Mode is on.
    document.addEventListener('contextmenu', function(event){
        if (systemStatus == 'On') {
            // Let clicks on links open the context menu.
            if (event.target.nodeName.toLowerCase() != 'a') {
                event.stopPropagation();
                event.preventDefault();
            }
        }
    }, true);
    
};
/**
 * Menu
 * @version  0.1
 * @date 2010-01-22
 * @author LudoO
 *
 * Add a menu for each entry about its site
 *
 */
GRP.menu = function(prefs, langs, ID, SL, lang){
    var menu;
	/*
    function jq_xmlhttpRequest(o){
        jQuery.ajax({
            type: o.method || 'GET',
            url: o.url,
            data: o.parameters,
            success: function(m){
				alert(m);
				o.onload();
			},error:function(m){
				alert('error xhr');
			}
        });
    }
    loadjQuery();
    */
    function createButtonMenu(entry){
        var eactions = getFirstElementByClassName(entry, 'entry-actions');
        var ent = entry;
        var el = dh(eactions, 'span', {
            cls: 'item-link grp-item-link-menu link unselectable',
            html: '<wbr><span class="entry-link-action-title">' + (SL.label || 'Extra') + '</span><div class="item-link-drop-down-arrow"></div>'
        }, {
            click: function(e){
                e.stopPropagation();
                var em = get_id('grpm_menu');
                if (!em) {
                    em = createMenu(document.body, [{
                        icon: '',
                        cls: 'read-state-kept-unread',
                        text: 'Mark site as read',
                        fn: function(){
                            markallasread(ent);
                        }
                    }]);
                }
                var p = getPos(el);
                var entries = get_id('entries');
                em.style.left = p.left + 'px';
                em.style.top = (p.top - entries.scrollTop + 15) + 'px';
                show(em);
                window.setTimeout(function(){
                    hide(em);
                }, 8000);
                var listener = function(e){
                    e.stopPropagation();
                    hide(em);
                    document.removeEventListener('click', listener, false);
                };
                var eventMenu = document.addEventListener('click', listener, false);
            }
        });
    }
    function createMenu(root, items){
        var em = dh(root, 'div', {
            id: 'grpm_menu',
            cls: 'goog-menu goog-menu-vertical',
            style: '-webkit-user-select: none; visibility: visible;',
            tabindex: -1
        });
        foreach(items, function(item){
            var eitem = dh(em, 'div', {
                cls: 'goog-menuitem',
                style: '-webkit-user-select:none;'
            });
            var content = dh(eitem, 'div', {
                cls: 'goog-menuitem-content'
            });
            var sp = dh(content, 'span', {
                cls: 'item-link-menuitem ' + item.cls,
                html: '<img src="' + item.icon + '" alt="" class="item-link-menuitem-image">' + item.text
            }, {
                click: function(){
                    item.fn();
                    hide(em);
                }
            });
        });
        root.appendChild(em);
        return em;
    }
    function addJumpButtons(el, entry, mode){
        createButtonMenu(entry);
        /*
         var favicon = getFirstElementByClassName(entry, 'entry-favicon');//div
         var title = getFirstElementByClassName(entry, 'entry-source-title');//a
         if (title) {
         var e = document.createElement('span');
         e.className = 'section-menubutton section-button';
         e.id = "sub-tree-item-165-action";
         e.innerHTML = "&nbsp;&nbsp;&nbsp;";
         e.addEventListener('click', togglemenu, false);
         //insert before favicon or title if not
         insertBefore(favicon || title, e);
         }*/
    }
    /*
     function togglemenu(item){
     if (!menu) {
     createMenu(items);
     }
     toggle(menu);
     }
     */
    
    var css = '.grp-item-link-menu item-link-drop-down-arrow{visibility:visible;}.grp-item-link-menu:hover item-link-drop-down-arrow{visibility:hidden !important;}';
    css += '.goog-menuitem:hover {background-color:#BECDEE;}'
    GM_addStyle(css);
    registerFeature(addJumpButtons, ID);
    //var keycodeDown = getShortcutKey(ID, 'godown', prefs); //66 Shift+B
    //keycodeDown.fn = gotobottom;
    //initKey(keycodeDown);
};
/**
 * Facebook Sharer + Google Reader
 * @version  ?
 * @date 2007-06-01
 *
 * Adds a "Preview button" that allows you to view actual article in a frame. 
 * Clicking again on that button goes back to RSS view. 
 * Does work both in List view and expanded view.
 *
 * Original author :
 * Thadk
 * http://userscripts.org/scripts/show/63997
 * http://userscripts.org/scripts/show/9594
 */

GRP.facebook = function(prefs, langs, ID, SL, lang){
	function addButton(el, entry, mode) {
		var title = SL.text + formatShortcut(ID, 'gofacebook', prefs); //[b]
		var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
		addBottomLink(el,text, title, ID, '', false, facebookShare, false, entry, mode);
	}

	function addKey() {
		onKey('btn-facebook', facebookShare);
	}

	function facebookShare(btn, entry, locked) {
		var active = isActive(btn, entry, 'facebook', locked);
		var iframe, facebookSharer;
		var body = getFirstElementByClassName(entry,  'entry-body');//div
		iframe = getFirstElementByClassName(entry,  'facebookSharer');//iframe
		if (active) {
			// iframe creation/display
			if (iframe) {
				// iframe already in document, display it
				iframe.style.display = 'block';
			} else {
				// iframe not in document, create it
				iframe = document.createElement('iframe');
				iframe.setAttribute('width', '650px');
				iframe.setAttribute('height', '350px');
				iframe.setAttribute('name', 'grpfacebook');
				iframe.setAttribute('target', 'grpfacebook');
				//var shareurl = getFirstElementMatchingClassName(entry, 'a', 'entry-title-link');
				var shareurl = getEntryLink(entry);
				var e = encodeURIComponent;
				var fbsharer = 'http://www.facebook.com/sharer.php?&u=' + e(shareurl.url) + '&t='
						+ e(shareurl.title);
				iframe.setAttribute('src', fbsharer);
				iframe.className = 'facebookSharer';
				body.appendChild(iframe);
			}

			// Scale article container to fullwidth
			body.setAttribute('style', gpeStyles.entryBody);
		} else {
			// hide iframe
			iframe.style.display = 'none';

			// Go back to initial width
			body.removeAttribute('style', '');
		}
		scrollTo(150, active);
	}

	function scrollTo(offset, dir) {
		var view = document.getElementById('viewer-container');
		view.scrollTop += ((dir) ? 1 : -1) * offset;
		// Force scrolling to top of article
		// location.href = 'javascript:void(s.V=-1);';
		// location.href = 'javascript:void(s.pf('+index+'));';
	}

	var gpeStyles = {
		entryBody : 'max-width: 98%'
	};

	registerFeature(addButton, ID);
	var keycode = getShortcutKey(ID, 'gofacebook', prefs); //66 b
	keycode.fn = addKey;
	initKey(keycode);
};/**
 * Google Reader + Twitter
 * @version  0.6
 * @date 2009-07-23
 *
 * Adds reader posts to twitter when clicked
 *
 * Original author :
 * terababy
 * http://userscripts.org/scripts/show/10169
 */

GRP.twitter = function(prefs, langs, ID, SL, lang){
	// Constants
	// NORMALIZE=false leaves the tags alone
	// NORMALIZE=true converts tags to proper case and replaces -'s with spaces,
	// like reader should itself

	var URL_SHORTENER = prefs.twitter_shortener||'tinyurl';// bitly, tinyurl

	// format the message to send, pls type as you like
	function formatSendMsg(labels, title, notes, url) {
		var msg = "";
		if (notes.length > 0) {
			msg = notes + " ";
		}
		if (labels.length > 0) {
			msg = msg + "#" + labels + " ";
		}
		msg = msg + "reading:" + title + ' ' + url;
		return msg;
		// return notes + " reading " + title + ' ' + url;
	}

	var urlShorteners = {
		'bitly' : getTinyAndInsert_BitLy,
		'tinyurl' : getTinyAndInsert_TinyURL
	};

	function getTinyAndInsert_TinyURL(event) {
		var thelongurl = encodeURIComponent(url);
		// urlinput.value = "making url tiny...";
		GM_xmlhttpRequest( {
			method : 'GET',
			url : "http://tinyurl.com/create.php?url=" + thelongurl,
			onload : function(r) {
				if (r.status == 200) {
					var t = r.responseText;
					urlinput.value = t.match(/<blockquote><b>(http\:\/\/tinyurl\.com\/[a-zA-Z0-9]+)<\/b><br>/)[1];
					countWord(event);
				}
			},
			onerror:function(r) {
				var error = formatText(SL.shortfailed, r.status);
				alert(error);
			}
		});
	}

	function getTinyAndInsert_BitLy(event) {
		var thelongurl = encodeURIComponent(url);
		// urlinput.value = "making url tiny...";
		var o ={
			login: prefs.twitter_bitlylogin||'twitthis',
			apiKey:prefs.twitter_bitlykey||'R_f0b6b5e3a4c028b3ec97119e4f3ce16c',
			url:thelongurl
		};
		var tpl = "http://api.bit.ly/shorten?version=2.0.1&login={login}&apiKey={apiKey}&format=xml&longUrl={url}";
		var urlbitly = fillTpl(tpl, o);
		
		GM_xmlhttpRequest( {
			method : 'GET',
			url : urlbitly,
			onload : function(r) {
				var tinydom = new DOMParser().parseFromString(r.responseText, "application/xml");
				urlinput.value = tinydom.getElementsByTagName('shortUrl')[0].textContent;
				countWord(event);
			},
			onerror:function(r) {
				var error = formatText(SL.shortfailed, r.status);
				alert(error);
			}
		});
	}

	// -------------------------- shorturl service end
	// ---------------------------------

	var getTinyAndInsert = urlShorteners[URL_SHORTENER];

	var DEFAULT_LABEL = "";
	var NORMALIZE = true;

	// Variables for editing bookmark details
	var bookmarkField;
	var bookmarkStar;
	var lblinput;
	var notesinput;
	var urlinput;
	var url;
	var titleinput;
	var notesdesc;

	var mode;
	
	function addTwitterButton(el, entry, mode){
		var title = SL.text + formatShortcut(ID, 'tweet', prefs); //[b]
		var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
        addBottomLink(el, text, title, ID, 'item-star star link', false, postBookmark, false, entry, mode);
	}
	function addKey() {
		onKey('btn-twitter', postBookmark);
	}

	function postBookmark(btn, entry, locked){
		var active = isActive(btn, entry, 'twitter', locked);
		
		//bookmarkStar = event.target;
		//var parent = findParentNode(bookmarkStar, 'div', 'entry');
		bookmarkStar=btn;
		var parent=entry;
		
		var header;
		if (mode === "expanded") {
			// parent = bookmarkStar.parentNode.parentNode.parentNode;
			bookmarkStar.parentNode.parentNode.className = "card-actions";
		} else {
			// parent = bookmarkStar.parentNode.parentNode;
			parent.className = "entry read expanded action-area-visible";
		}
		bookmarkStar.className = "item-star star link email-active";

		var link = getEntryLink(entry);
		url = link.url;
		var title = link.title; 
		var addbkmk = getBookmarkField();
		if (mode == "expanded") {
			if (addbkmk.className == "action-area card-bottom") {
				bookmarkStar.className = "item-star star link";
				addbkmk.className = "action-area card-bottom hidden";
				bookmarkStar.parentNode.parentNode.className = "card-actions card-bottom";
				return;
			}
			addbkmk.className = "action-area card-bottom";
		} else {
			if (addbkmk.className == "action-area") {
				bookmarkStar.className = "item-star star link";
				addbkmk.className = "action-area hidden";
				parent.className = "entry read expanded";
				return;
			}
			addbkmk.className = "action-area";
		}
		parent.appendChild(bookmarkField);
		lblinput = document.getElementById("lblinput");
		notesinput = document.getElementById("notesinput");
		urlinput = document.getElementById("urlinput");
		titleinput = document.getElementById("titleinput");
		notesdesc = document.getElementById("notesdesc");
		notesinput.addEventListener('click', function() {
			notesinput.focus();
		}, false);
		notesinput.addEventListener('keypress', countWord, false);
		notesinput.value = "";
		lblinput.value = getTags(parent);
		urlinput.value = url;
		titleinput.value = title;
		btnSend = document.getElementById("btnSend");
		btnTinyURL = document.getElementById("btnTinyURL");
		btnCount = document.getElementById("btnCount");
		btnCancel = document.getElementById("btnCancel");
		btnSend.addEventListener('click', saveBookmark, false);
		btnTinyURL.addEventListener('click', getTinyAndInsert, false);
		btnCount.addEventListener('click', countWord, false);
		if (mode == "expanded") {
			btnCancel.addEventListener("click", function() {
				bookmarkStar.parentNode.parentNode.className = "card-actions card-bottom";
				bookmarkField.className = "action-area card-bottom hidden";
				bookmarkStar.className = "item-star star link";
				notesdesc.innerHTML = SL.notemax;
				notesinput.value = "";
			}, false);
		} else {
			btnCancel.addEventListener("click", function() {
				parent.className = "entry read expanded";
				bookmarkField.className = "action-area hidden";
				bookmarkStar.className = "item-star star link";
				notesdesc.innerHTML = SL.notemax;
				notesinput.value = "";
			}, false);
		}
		countWord(event);
		btnSend.focus();
		notesinput.focus();
	};

	function getBookmarkField() {
		if (!bookmarkField) {
			bookmarkField = document.createElement("div");
			bookmarkField.setAttribute("id", "twitterField");
			var tpl = "<html><body><div class='email-this-area'><iframe id='iftwitter' src='https://twitter.com/statuses/update.xml' width='0' height='0' style='display:block;'></iframe><table class='email-entry-table'><tbody><tr><td class='field-name'>{text_title}:</td><td><input aria-haspopup='true' class='email-this-subject tags-edit-tags label-input' type='text' id='titleinput'></td></tr><tr><td class='field-name'>{text_tag}:</td><td><input aria-haspopup='true' class='email-this-subject tags-edit-tags label-input' type='text' id='lblinput'></td></tr><tr><td class='field-name'>{text_url}:</td><td><input aria-haspopup='true' class='email-this-subject tags-edit-tags label-input' type='text' id='urlinput'></td></tr><tr><td colspan='2'><div id='notesdesc'>{notemax}</div><br/><textarea class='email-this-comment' rows='6' id='notesinput'></textarea><div class='email-this-buttons' tabindex='-1'><div role='wairole:button' tabindex='0' class='goog-button goog-button-base unselectable goog-inline-block goog-button-float-left email-this-send' id='btnSend'><div class='goog-button-base-outer-box goog-inline-block'><div class='goog-button-base-inner-box goog-inline-block'><div class='goog-button-base-pos'><div class='goog-button-base-top-shadow'> &nbsp; </div><div class='goog-button-base-content'><div class='goog-button-body'>{text_send}</div></div></div></div></div></div><div role='wairole:button' tabindex='0' class='goog-button goog-button-base unselectable goog-inline-block goog-button-float-left email-this-cancel' id='btnTinyURL'><div class='goog-button-base-outer-box goog-inline-block'><div class='goog-button-base-inner-box goog-inline-block'><div class='goog-button-base-pos'><div class='goog-button-base-top-shadow'> &nbsp; </div><div class='goog-button-base-content'><div class='goog-button-body'>{text_shortener}</div></div></div></div></div></div><div role='wairole:button' tabindex='0' class='goog-button goog-button-base unselectable goog-inline-block goog-button-float-left email-this-cancel' id='btnCount'><div class='goog-button-base-outer-box goog-inline-block'><div class='goog-button-base-inner-box goog-inline-block'><div class='goog-button-base-pos'><div class='goog-button-base-top-shadow'> &nbsp; </div><div class='goog-button-base-content'><div class='goog-button-body'>{text_count}</div></div></div></div></div></div><div role='wairole:button' tabindex='0' class='goog-button goog-button-base unselectable goog-inline-block goog-button-float-left email-this-cancel' id='btnCancel'><div class='goog-button-base-outer-box goog-inline-block'><div class='goog-button-base-inner-box goog-inline-block'><div class='goog-button-base-pos'><div class='goog-button-base-top-shadow'> &nbsp; </div><div class='goog-button-base-content'><div class='goog-button-body'>{text_cancel}</div></div></div></div></div></div></div></td></tr></tbody></table></div></body></html>";
			var html = fillTpl(tpl, SL);
			bookmarkField.innerHTML = html;
		}
		return bookmarkField;
	}

	function getTags(parent) {
		var taglist = getElementsByClazzName("user-tags-list", "ul", parent)[0];
		var ins = taglist.getElementsByTagName("li");
		var lbls = "";
		for ( var i = 0; i < ins.length; i++) {
			var lbl = ins[i].getElementsByTagName("a")[0].text;
			if (NORMALIZE) {
				lbl = lbl.replace(/-/g, ' ');
				lbl = lbl.toLowerCase().replace(/^(.)|\s(.)/g, function($1) {
					return $1.toUpperCase();
				});
			}
			if (i > 0) {
				lbls += ", ";
			}
			lbls += lbl;
		}
		if (DEFAULT_LABEL.length > 0) {
			if (lbls.length > 0) {
				lbls = DEFAULT_LABEL + ", " + lbls;
			} else {
				lbls = DEFAULT_LABEL;
			}
		}
		return lbls;
	}

	function saveBookmark(event) {

		var title = titleinput.value;
		var labels = lblinput.value;
		var notes = notesinput.value;
		var msg = formatSendMsg(labels, title, notes, urlinput.value);
		var size = 140 - countMsgWord(msg);
		if (size < 0) {
			alert(SL.toolong);
			notesdesc.innerHTML = formatText(SL.notetoolong, size);
			return;
		}

		GM_log("URL: " + url + "\nTitle: " + title + "\nTags: " + labels + "\nNotes: " + notes);
		GM_xmlhttpRequest( {
			method : 'POST',
			url : 'https://twitter.com/statuses/update.xml',
			headers : {
				'Content-type' : 'application/x-www-form-urlencoded'
			},
			data : 'source=GRSharing&status=' + formatSendMsg(labels, title, notes, encodeURIComponent(urlinput.value)),
			onload : function(r) {
				GM_log('onload returned status:' + r.status + ',statusText:' + r.statusText + '\n' + ',responseHeaders:'
						+ r.responseHeaders + '\n' + 'responseText:\n' + r.responseText);
				var v = false;
				if (authenticated){
					activeStar();
				}else{
					
				}
			},
			onerror: function(r){
				GM_log('onerror'+ r.responseText);
				alert(SL.plslogin);
				var iframe = document.getElementById('iftwitter');
				//iframe.src=iframe.src;
				iframe.location.reload(true);
				//update iframe to fire popup login
			}
		});
		
	}
	function activeStar() {
		if (mode == "expanded") {
			getElementsByClazzName("card-actions", "div", bookmarkField.parentNode)[0].className = "card-actions card-bottom";
		} else {
			bookmarkField.parentNode.className = "entry read expanded";
		}
		bookmarkField.className += " hidden";
		bookmarkStar.className = "item-star-active star link";
		notesinput.value = "";
	}

	function countWord(event) {
		var title = titleinput.value;
		var labels = lblinput.value;
		var notes = notesinput.value;
		var msg = formatSendMsg(labels, title, notes, urlinput.value);
		notesdesc.innerHTML = formatText(SL.notetoolong, (140 - countMsgWord(msg)));		
	}

	function countMsgWord(str) {
		var len;
		var i;
		len = 0;
		for (i = 0; i < str.length; i++) {
			if (str.charCodeAt(i) > 255) {
				len++;
			} else {
				len++;
			}
		}
		return len;
	}

	registerFeature(addTwitterButton, ID);
	
	var keycode = getShortcutKey(ID, 'tweet', prefs); //68 d
	keycode.fn = addKey;
	initKey(keycode);
};/**
 * ReadItLater integration
 * @param {Object} prefs
 * @param {Object} langs
 */
GRP.readitlater = function(prefs, langs, ID, SL, lang){
    var api = {
        key:'e6cg2d3cp4431Y55aKT0V06R29AWr21b',
		add: 'https://readitlaterlist.com/v2/add',
        auth: 'https://readitlaterlist.com/v2/auth',
		successCode:200,
		errors: {
	        //400: Invalid request, please make sure you follow the documentation for proper syntax.
	        400: 'badrequest',
	        //401: Username and/or password is incorrect.
	        401: 'wronglogin',
	        //403: Rate limit exceeded, please wait a little bit before resubmitting
	        403: 'rateexceeded',
	        //500: error
	        500: 'error',
	        //503: Read It Later's sync server is down for scheduled maintenance
	        503: 'maintenance'
	    }
    };
    GRP.api_readit(prefs, langs, ID, SL, lang, api);
};/**
 * Instapaper integration
 * @version  ?
 * @date 2009-07-30
 *
 * Integrate an instapaper button
 *
 * Original author :
 * ckolderup
 * http://userscripts.org/scripts/show/54713
 *
 * see API docs: http://www.instapaper.com/api
 */
GRP.instapaper = function(prefs, langs, ID, SL, lang){
    var api = {
        add: 'https://www.instapaper.com/api/add',
        auth: 'https://www.instapaper.com/api/authenticate',
		successCode:201,
		errors: {
	        //400: Bad request. Probably missing a required parameter, such as url.
	        400: 'badrequest',
	        //403: Invalid username or password.
	        403: 'wronglogin',
	        //500: The service encountered an error. Please try again later.
	        500: 'error'
	    }
	};
    GRP.api_readit(prefs, langs, ID, SL, lang, api);
};/**
 * Close entry
 * @version  0.1
 * @date 2010
 * @author LudoO
 *
 * Add a close button on each entry
 *
 */

GRP.closeentry = function(prefs, langs, ID, SL, lang){
	function addLink(el, entry, mode) {
		var title = SL.text + formatShortcut(ID, 'close', prefs); //[x]
		var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
		addBottomLink(el, text, title, ID, '', false, closeEntry, false, entry, mode);
	}
	
	function addKey(e) {
		var entry = getEntry(e);
		closeEntry('btn-'+ID, entry);
	}
	
	function closeEntry(btn, entry, locked, e){
		var nextEntry = entry.nextSibling;
		entry.parentNode.removeChild(entry);
		
		if (hasClass(nextEntry.firstChild, 'collapsed')){
			//mode list
			nextEntry=nextEntry.firstChild;
		}
		
		simulateClick(nextEntry);
	}
	
	//http://images.google.com/images/isr_c.gif
	var css = ".btn-closeentry {margin-left: 4px;padding: 1px 8px 1px 16px;;width:14px;height:14px;background-repeat:no-repeat;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9oBCAkSJ1WKaoEAAABdSURBVCjPYzx0/uN/BnIBuZoPnf/4n4mBAsBErEuwiTNhU4CuEJc4imY7Q35GfBqQ5bE6G5sB2DRi1YxNITaNODXj8jNJoY3LC3hDG1kjXgOIdSJWdQOWPBkpyVUAalJcJ5S4CXgAAAAASUVORK5CYII=);}";
	GM_addStyle(css);
	
	registerFeature(addLink, ID);
	var keycode = getShortcutKey(ID, 'close', prefs); //88//x
	keycode.fn = addKey;
	initKey(keycode);
};/**
 * FitHeight 
 * @version  0.1
 * @date 2009
 * @author LudoO
 *
 * Fit entry height
 *
 */
GRP.fitheight = function(prefs, langs, ID, SL, lang){
	var locked=false;
	if (prefs && prefs.fitheight_locked) {
		locked = prefs.fitheight_locked;
	}

	function fitHeight(btn, entry, locked){
		var active = isActive(btn, entry, ID, locked);
		//TODO: replace 'fit-height-on' with 'fitheight'
		addClassIf(entry, 'fit-height-on', active);
		
		if (!locked) {
			jump(entry, true);
		}
	}	
	
	function addButton(el, entry, mode) {
		var title = SL.text + formatShortcut(ID, 'fit', prefs); //[f]
		//var text = (prefs && prefs.general_icons)?'':(SL.keyword || ID);
		var text = (SL.keyword || ID);//checkbox
		addBottomLink(el,text, title, ID, '', true, fitHeight, false, entry, mode);
		if (locked){
			fitHeight(el, entry, true);
		}
	}

	function fitHeightKey() {
		onKey('btn-fitheight', fitHeight);
	}
	
	var he = getHeightEntries()-2;	

	var css = " .read.fit-height-on .entry-body{ display:block !important; max-height: "+he+"px !important; overflow-y:auto;}";
	css += ".fit-height-on .entry-likers{display:none;}";
	GM_addStyle(css);
	
	registerFeature(addButton, ID);
	var keycode = getShortcutKey(ID, 'fit', prefs); //70 f
	keycode.fn = fitHeightKey;
	initKey(keycode);
};
/*
 * limit (aka limit)
 */
GRP.limit = function(prefs, langs, ID, SL, lang){
    var nent = prefs.limit_mini || 30, lsup = prefs.limit_maxi || 200;
    var c, ent = 0, bor = 0, bsig = 0, nbor = 0, centi = false;
    var entries = get_id("entries");
    entries.addEventListener("DOMNodeInserted", function(e){
        if (hasClass(e.target, 'entry')) {
            try {
                //ent += 1;
                ent = entries.childNodes.length;
                if ((ent > lsup) && (!centi)) {
                    centi = true;
                    //console.log(ent + '>' + lsup);
                    nbor = entries.scrollTop;
                    c = getCurrentEntry();
                    while (bor + bsig <= nbor) {
                        actual = entries.firstChild;
                        bsig = Math.floor(actual.nextSibling.offsetHeight / 2);
                        bor = bor + actual.offsetHeight;
                        console.log('remove ' + actual.className);
                        entries.removeChild(actual);
                    }
                    ent = nent;
                    bor = 0;
                    entries.scrollTop = 0;
                    if (!c) {
                        c = entries.firstChild;
                    }
                    //TODO: why current-entry is removed ?
                    window.setTimeout(function(){
                        selectCurrentEntry(c);
                    }, 300);
                    centi = false;
                }
            } catch (e) {
            }
        }
    }, false);
};
/**
 * TODO make doc
 * @version  0.3
 * @date 2010
 * @author JoLan, LudoO
 * Replace entries with part of the original article
 *
 * +css selector 
 */
GRP.replacer = function(prefs, langs, ID, SL, lang){
    var locked = false, partIndex = 0, gp_data = {}, TPL_NAME = "replacer_result_";
    
    function initVars(){
        gp_data = {};
        parseItems(gp_data, prefs.replacer_items);
        
        if (prefs.replacer_cloud) {
            //get online data from cloud db
            chrome.extension.sendRequest({
                message: "clouddata",
                name: 'LDRFullFeed'
            }, function(selectors){
                parseItems(gp_data, selectors);
                console.log('cloud LDRFullFeed added');
            });
            chrome.extension.sendRequest({
                message: "clouddata",
                name: 'Replacer'
            }, function(selectors){
                parseItems(gp_data, selectors);
                console.log('cloud replacer added');
            });
        }
        
    }
    
    function parseItems(gp_data, items){
        iterate(items, function(title, o){
            if (o.values) {
                //flatten values
                o = apply(o, o.values);
            }
            o.re_url = new RegExp(o.url, "im");
            if (/^xpath\:/.test(o.search)) {
                o.xpath = o.search.replace(/^xpath\:/, '');
                //Ensure relative path
                if (!(/^\./.test(o.xpath))) {
                    if (/^\//.test(o.xpath)) {
                        o.xpath = '.' + o.xpath;
                    } else {
                        o.xpath = './' + o.xpath;
                    }
                }
            }else if (/^css\:/.test(o.search)) {
				o.selector = o.search.replace(/^css\:/, '');
			} else {
                try {
					o.re_search = new RegExp(o.search, "im");
				}catch(e){
					console.error(e);
					console.error(o);
					o=false;
				}
            }
			if (o){
            	gp_data[title] = o;
			}
        });
    }
    
    function replaceItem(html, xml, matches, partIndex){
        var result = '';
        var el = document.getElementById(TPL_NAME + partIndex);
        /*if (item.keeptext){
         var eb = getEntryBody(el.parentNode);
         result = eb.innerHTML+'<br/>';
         }*/
        iterate(matches, function(title, o){
            if (o.xpath || o.selector) {
                if (!xml) {
                    xml = loadXml(html);
                }
                if (xml) {
                    var els;
					if (o.xpath){
						els = getElements(o.xpath, xml);
					}else{
						els = jQuery(o.selector, xml);
					}
					if (els && els.length>0) {
						foreach(els, function(el){
							result += el.outerHTML;
						});
					}
                    //clean xml
                    remove(xml);
                }
            } else {
                var item = gp_data[title];
                if (item.re_search) {
                    var m = item.re_search.exec(html);
                    if (m && m[0]) {
                        result += m[0].replace(item.re_search, item.replace);
                    }
                }
            }
        });
        
        var entryBody = getEntryBody(el.parentNode);
        if (result !== '') {
            el.innerHTML = result;
            show(el);
            hide(entryBody);
        } else {
            el.innerHTML = SL.nomatch;
            //Reset to original
            hide(el);
            show(entryBody);
        }
    }
    
    function doreplacer(el, entry, mode, force){
        var index = -1, regex, link = getEntryLink(entry);
        if (link) {
            var matches = {};
            iterate(gp_data, function(title, o){
                if (o.re_url.test(link.url) || o.re_url.test(link.feed)) {
                    matches[title] = o;
                }
            });
            replacePart(matches, entry, link);
        }
    }
    
    function replacePart(matches, entry, link){
        if (isObjectEmpty(matches)) {
            return false;
        }
        
        var body = getFirstElementByClassName(entry, 'entry-body');//div
        //var entryBody = getEntryBody(body);
        
        //hide(entryBody);
        var el = document.createElement('div');
        /*if (matches[0].keeptext) {
         hide(el);
         }else{
         hide(entryBody);
         }*/
        partIndex++;
        el.id = TPL_NAME + partIndex;
        el.innerHTML = SL.loading;
        hide(el);
        body.appendChild(el);
        //console.log('request '+partIndex+' - '+link.url);
        GM_xmlhttpRequest({
            url: link.url,
            method: "GET",
            partIndex: partIndex,
            matches: JSON.stringify(matches),
            onload: function(res, req){
                var matches = JSON.parse(req.matches);
                var text = res.responseText.replace(/[\r\n]+/g, '');
                replaceItem(text, res.responseXml, matches, req.partIndex);
            }
        });
    }
    
    
    initVars();
    registerFeature(doreplacer, ID);
};
//relook custom theme

GRP.relook = function(prefs, langs, ID, SL, lang){

	if (prefs.relook_css) {
		var css = prefs.relook_css.replace(/\n/g, '').replace(/\t/g, ' ').replace(/\/\*.*?\*\//g, '');
		GM_addStyle(css, 'rps_relook');
		if (prefs.relook_resize){
			fireResize();
		}
	}
};/*
 * Translate entries
 *
 * Samples
 * ro : www.hackersblog.org
 * ru : www.kremlin.ru
 * zh : http://newsrss.bbc.co.uk/rss/chinese/trad/news/rss.xml
 * de : www.spiegel.de
 * fr : www.lemonde.fr
 *
 *
 */
//TODO: 
// - walk inside text nodes ONLY
// - web feeds
// - check compatibility with features (preview, column...)
// - Add a back to original (2 divs like columns,replacer ??)
// - Translate into mylanguage already exist -> Can we be better ?
// - Translate feed title too
GRP.translate = function(prefs, langs, ID, SL, lang){
    var langDest = prefs.translate_lang || lang;
    function translateEntry(entry, active, btn, e){
        var body = getBody(entry), l = getEntryLink(entry);
        var texts = {};
        if (l.eltitle) {
            translate(l.eltitle.firstChild, 'text', l.eltitle, 'text');
            translate(l.eltitle.title, 'direct', l.eltitle, 'title');
        }
        if (body) {
            //var eb = getEntryBody(body);
            translate(body, 'html', body, 'body');
        }
        function setText(el, t, mode){
            if (mode === 'html') {
                el.innerHTML = t;
            } else if (mode === 'direct') {
                el = t;
            } else if (mode === 'text') {
                if (el.innerText) {
                    el.innerText = t;
                } else if (el.textContent) {
                    el.textContent = t;
                } else {
                    el = t;
                }
            }
        }
		
		function cleanQuotes(txt){
			return (txt||'').replace(/«|»|"/g, "'");
		}
		
        function translate(el, mode, p, id){
            mode = mode || 'html';
            var txt;
            if (!active) {
				setText(el, decodeu(p.getAttribute('o_'+id)), mode);
                return;
            }
            if (mode === 'html') {
                txt = el.innerHTML;
            } else if (mode === 'direct') {
                txt = el;
            } else if (mode === 'text') {
                txt = (el.innerText || el.textContent || el);
            }
            addAttr(p, 'o_'+id,  encodeu(txt));
            chrome.extension.sendRequest({
                message: "translate",
                text: cleanQuotes(txt),
                to: langDest
            }, function(a){
                 if (!a.error && a.detectedSourceLanguage !== langDest) {
                    var t = (a.translation || '').replace(/&#39;/g, "'").replace(/&quot;/g, "\"");
                    setText(el, t, mode);
                }
            });
        }
    }
    GRP.api_entry(prefs, langs, ID, SL, lang, {
        action: 'translate',
        cb: translateEntry
    });
};
/**
 * Google Reader Prefetch More
 * @version  0.2.4
 * @date 2010-07-21
 *
 * This script will improve the speed experience.
 * It boosts the number of articles that prefetched on the Google Reader's expanded view.
 *
 * Original author :
 * ucnv
 * http://userscripts.org/scripts/show/26383
 */
GRP.prefetch = function(prefs, langs, ID, SL, lang){
	var js = 'var GRP_prefetch={first:'+(prefs.prefetch_first||25)+','+
	'next:'+(prefs.prefetch_next||15)+','+
	'list:'+(prefs.prefetch_list||60)+'};';
	GM_addjs(js, true, '_grp_prefetch');
	
	GM_addjs(chrome.extension.getURL('res/prefetch.js?'+Math.round(Math.random()*999+1)));
};
// ==UserScript==
// @name           Google Reader: Nested Folders
// @namespace      meta.ironi.st
// @author         sethaurus
// @description    Displays folders (tags) in a nested hierarchy, when (for example) one folder is named category, and another is named category:subcategory. Note that the names must be separated by a colon, and that the outer folder must exist, even if it does not directly contain any feeds. Folders an be nested to an arbitrary depth.
// @include        http://*.google.com/reader*
// @include        https://*.google.com/reader*
// @source         http://userscripts.org/scripts/show/64659
// ==/UserScript==
GRP.nested = function(prefs, langs, ID, SL, lang){
    var sep = prefs.nested_separator || ':';
	setTimeout(function(){
        if (domIsDirty()) {
			nestFolders();
		}
    }, 100);
	
    
    function nestFolders(){
        var folderNodes = document.querySelectorAll('.folder, .tag'), folderMap = {};
        
        var i = 0, folder;
        while ((folder = folderNodes[i++])) {
            var nameNode = folder.querySelector('.name');
            if (nameNode) {
                folderMap[nameNode.title.split(' (')[0]] = folder;
            }
        }
        
        iterate(folderMap, function(name, folder){
            var nameTokens = name.split(sep).reverse();
			var prefix = nameTokens.slice(1).reverse().join(sep);
			console.log(name +' -- '+ prefix);
            
            if (name !== prefix && (prefix in folderMap)) {
                var parent = folderMap[prefix].querySelector('ul');
                
                if (!parent) {
                    parent = folderMap[prefix].appendChild(document.createElement('ul'));
                }
                var wrapper = parseNode('<div style="position:relative;left:16px;"/>');
                wrapper.appendChild(folder);
                wrapper.querySelector('.name-text').innerHTML = nameTokens[0];
                wrapper.querySelector('.link').style.cssText = 'margin-left:-16px';
                parent.insertBefore(wrapper, parent.firstChild);
            }
        });
    }
    
    function domIsDirty(){
        var isDirty = !document.querySelector('#clean-flag');
        if (isDirty) {
            document.querySelector('#sub-tree').appendChild(parseNode('<div id="clean-flag" />'));
        }
        return isDirty;
    }
    
    function parseNode(html){
        if (!parseNode.element) {
            parseNode.element = document.createElement('div');
        }
        parseNode.element.innerHTML = html;
        return parseNode.element.firstChild;
    }
};
// Theme
GRP.theme = function(prefs, langs, scop){
	if (prefs.theme_noborder) {
        var css = '.card-common,.entry-main{margin:0 !important;}';
        css += '.entry,.card-content,.entry-actions,.entry-container{padding:0 !important;}';
        css += '.entry-title{margin-left:20px !important;font-size:120% !important;}';
        css += '.entry .entry-body{max-width:100% !important;}';
        css += '.entry-author{display:none;}';
        css += '.entry,.entry .card, #no-entries-msg{border-width:0 !important;}';
        css += '.collapsed{background-color:transparent !important;}';
        css += '.entry:nth-child(odd) .card-common, .entry:nth-child(odd) .card-actions {background-color:#EFEFEF;}';
        css += '.entry:nth-child(even) .card-actions {background-color:transparent;}';
        GM_addStyle(css, 'rps_noborder');
    }
	
	var skin = GRP.skins[prefs.theme_skin];
    if (!skin) {
        console.log('Error with skin '+prefs.theme_skin);
		return;
    }
    skin.id = prefs.theme_skin;
    if (skin.url) {
        //Run remote skin
        remoteSkin(skin);
    } else {
        scop.run(skin.id, langs);
    }
    function remoteSkin(skin){
        var c = GM_getValue('cache_theme_' + skin.id);
        if (c) {
            GM_addStyle(c, 'rps_' + skin.id);
        } else {
            GM_xmlhttpRequest({
                method: 'get',
                url: skin.url,
                onload: function(r){
                    var css = r.responseText;
					//unescape
                    css = css.replace(/\\n/g, ' ').replace(/\\"/g, '"');
                    //Filter userscripts userjs
                    if (/^http\:\/\/userstyles\.org/.test(skin.url)) {
                        var m = /var\s+css\s+=\s+"(.*?)";\n/.exec(css);
                        if (m && m[1]) {
                            css = m[1];
                        }else{
							//not better?
							m = /css\s+\+=\s+"body(.*?)";\n/.exec(css);
							if (m && m[1]) {
								css = 'body'+m[1];
							}
						}
                    }
                    if (css) {
                        css = css.replace(/\n/g, ' ');
						css = css.replace(/\-moz\-/g, '-webkit-');
						if (skin.fix){
							css+=skin.fix;
						}
						GM_addStyle(css, 'rps_' + skin.id);
                        //cache css 
						//param3 = false : force local storage in webpage
						GM_setValue('theme_' + skin.id, css, false);
                    }
                }
            });
        }
    }
    	
	/*
	if (prefs.theme_hidenav) {
		addClass(document.body, 'lhn-hidden');
	}*/
	if (skin.resize) {
		fireResize();
	}
};
//My theme
//Customizable theme with background picture
/*
 to get theme from gmail (desk is a good omplete example):
 - Open gmail
 - selet theme
 - open all css
 - copy paste 2nd line into notepad2 (html,body...)
 - replace } with }\n (transform backslash on)
 - line 5 is the background color .cP{overflow:visible;background-color:#fff}
 - line 9 is the font color : .aB,.e,.cg{color:#0065cc;
 - line 17 : the tiled piture .cP{background:url(...)}
 - line 20-39 5 groups of 4 css classes
 -.wp=hl header left
 -.wq=hr header right
 -.wn=fl footer let
 -.wo=fr footer right
 */
GRP.mytheme = function(prefs){
    var daycodes = ['mon', 'tue', 'thu', 'wed', 'fri', 'sat', 'sun'];
    var fulldaycodes = ['monday', 'tuesday', 'thursday', 'wednesday', 'friday', 'saturday', 'sunday'];
    var daytimes = {
        0: 'midnight',
        2: '2am',
        4: '4am',
        6: '6am',
        8: '8am',
        10: '10am',
        12: 'noon',
        14: '2pm',
        16: '4pm',
        18: '6pm',
        20: '8pm',
        22: '10pm'
    };
    
    var css = ''; //GM_getValue('theme_mytheme');
    if (css) {
        GM_addStyle(css, 'rps_mytheme');
    }
    else {
        loadCss('skin/css/mytheme.css', function(css){
            stylish(css);
        }, {
            compact: true,
            clean: false
        });
    }
    
    function stylish(tplCss){
        //rbg : Repeated image background
        //sbg : Single image background
        //hr : header right
        //h: header
        //rh : repeated header
        //f: footer
        //fr: footer right
        //fl: footer left
        //rf: repeated footer
        var items = ['rbg', 'sbg', 'rh', 'h', 'hr', 'hl', 'rf', 'f', 'fr', 'fl'];
        
        var o = {};
        
		var externalthemes = GRP.getExternalThemes();
		
        if (prefs.theme_externaltheme && externalthemes && externalthemes[prefs.theme_externaltheme]) {
            o = externalthemes[prefs.theme_externaltheme];
			track('theme_externaltheme', prefs.theme_externaltheme);
            o.bg2 = o.bg2 || o.bg;
            if (o.rbg) {
                //repeated image background
                o.bg2 = 'transparent';
            }
            if (typeof o === 'string') {
                o = {
	                color: prefs.theme_color || '#000',
	                bg: prefs.theme_bg || '#fff',
                    hl: o
                };
            }
            
            //current_time
            var current_time = (new Date()).getHours();
            current_time = current_time - current_time % 2;//pair number
            daytime = daytimes[current_time];
            //day
            var day = (new Date()).getDay();
            
            //placeholders replacement
            var holders = {
                day: daycodes[day - 1],
                fullday: fulldaycodes[day - 1],
                time: current_time,
                daytime: daytime,
                daynight: ((current_time < 8 || current_time > 20) ? 'night' : 'day')
            };
            if (o.vars) {
                iterate(o.vars, function(varname, varvalues){
                    var variable = false;
                    //random choice
                    variable = randomselect(varvalues);
                    holders[varname] = variable;
                });
            }
            
            
            //choose random image if multiples...
            iterate(o, function(key, a){
                if (key !== 'vars') {
                    if (isArray(a)) {
                        o[key] = randomselect(a);
                    }
                    else if (typeof a === 'object') {
                        var k = holders[a.selector]; //selector specific (day...)
                        if (k && k !== 'random') {
                            o[key] = o[key][k];
                        }
                        else {
                            delete a.selector;
                            //multiple images per day possible
                            o[key] = randomselect(a);
                        }
                    }
                }
            });
            
            //placeholders replacement
            if (holders) {
                iterate(holders, function(name, value){
                    iterate(o, function(key, a){
                        if (typeof a === 'string') {
                            o[key] = a.replace('{' + name + '}', value);
                        }
                    });
                });
            }
            
        }
        else {
            //custom
            o = {
                color: prefs.theme_color || '#aaa',
                bg: prefs.theme_bg || '#ffc'
            };
			
			foreach(items, function(itm){
	            if (prefs['theme_img'+itm]) {
	                o[itm]=prefs['theme_'+itm];
	            }
	        });
		
        }
        
        var css = fillTpl(tplCss, o);
        
        
        var html = '';
        
        foreach(items, function(itm){
            html += '<div id="rp-' + itm + '"></div>';
            if (o[itm]) {
                css = cleancss(css, itm);
            }
        });
        
        var c = dh(document.body, 'div', {
            id: 'rp-cs',
            html: html
        });
        
        GM_addStyle(css, 'rps_mytheme');
        //cache css
        GM_setValue('theme_mytheme', css, false);
        
        if (o.resize) {
            fireResize();
        }
    }
    
    function cleancss(css, id){
        return css.replace('/*--' + id + '>--*//*', '').replace('*//*--<' + id + '--*/', '');
    }
};

GRP.getExternalThemes = function(){
     var urlgmail = window.location.protocol + '//mail.google.com/mail/';
	 return {
        gmail_chrome: {
            bg: '#fff',
            color: '#2a5db0'
        },
        gmail_c: {
            bg: '#fff',
            color: '#00c'
        },
        gmail_newblue: {
            bg: '#79b',
            color: '#fff'
        },
        gmail_coldshower: {
            bg: '#99b1c3',
            color: '#333944',
            rbg: urlgmail + 'images/2/5/coldshower/blue-tile.png'
        },
        gmail_steel: {
            bg: '#fff',
            color: '#4263ab',
            rh: urlgmail + 'images/2/5/steel/bg-main.png'
        },
        gmail_lightbright: {
            bg: '#fff',
            color: '#222',
            rh: urlgmail + 'images/2/5/lightbright/bg-main.png'
        },
        gmail_greensky: {
            bg: '#fff',
            color: '#33c'
        },
        gmail_lightsoft: {
            bg: '#fff',
            color: '#0065cc'
        },
        gmail_cherry: {
            bg: '#fff',
            color: '#942e06',
            rbg: urlgmail + 'images/2/5/cherry/bg-main.png'
        },
        gmail_nightshade: {
            bg: '#55688a',
            color: '#fff',
            rh: urlgmail + 'images/2/5/nightshade/ns_bg.gif'
        },
        gmail_medsoft: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/medsoft/bg-main.gif'
        },
        gmail_medred: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/medred/bg-main.gif'
        },
        gmail_darkwarm: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/darkwarm/bg-main.png'
        },
        gmail_greyrain: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/darkwarm/bg-main.png'
        },
        gmail_contrastblack: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/darkwarm/bg-main.png'
        },
        gmail_shiny: {
            bg: '#000',
            color: '#fff',
            rh: urlgmail + 'images/2/5/shiny/canvastile_bg2.jpg'
        },
        gmail_desk: {
            bg: '#000',
            sbg: urlgmail + 'images/2/5/desk/canvas_bg.jpg',
            hl: [ /* .wp */urlgmail + 'images/2/5/desk/logo_splatter.png', urlgmail + 'images/2/5/desk/logo_splatter_pencil.png'],
            hr: [ /* .wq */urlgmail + 'images/2/5/desk/header_bg_padpins.png', urlgmail + 'images/2/5/desk/header_bg_sharpenerenvelope.png', urlgmail + 'images/2/5/desk/header_bg_ruler.png', urlgmail + 'images/2/5/desk/header_bg_tape.png', urlgmail + 'images/2/5/desk/header_bg_vase.png'],
            fl: [ /* .wn */urlgmail + 'images/2/5/desk/footer_bg_paperclips.png', urlgmail + 'images/2/5/desk/footer_bg_applecalendar1.png', urlgmail + 'images/2/5/desk/footer_bg_postcard.png', urlgmail + 'images/2/5/desk/footer_bg_envelopebusstop1.png', urlgmail + 'images/2/5/desk/footer_bg_photos1.png'],
            fr: [ /* .wo */urlgmail + 'images/2/5/desk/footer_bg_cupring.png', urlgmail + 'images/2/5/desk/footer_bg_cdclips1.png', urlgmail + 'images/2/5/desk/footer_bg_teacookie.png', urlgmail + 'images/2/5/desk/footer_bg_pencilladybug.png', urlgmail + 'images/2/5/desk/footer_bg_calculatorclips1.png']
        },
        gmail_tree: {
            bg: '#cde4f3',
            color: '#074D8F',
            rh: urlgmail + 'images/2/5/tree/mostlycloudy/header_tile.jpg',
            rf: urlgmail + 'images/2/5/tree/mostlycloudy/footer_tile.jpg',
            fl: urlgmail + 'images/2/5/tree/mostlycloudy/footer_bg.jpg'
        },
        gmail_beach: {
            bg: '#fff',
            color: '#fff',
            rh: urlgmail + 'images/2/5/beach/{daytime}/headertile_bg.jpg',
            h: urlgmail + 'images/2/5/beach/{daytime}/header_bg.jpg',
            f: urlgmail + 'images/2/5/beach/{daytime}/footer_bg.jpg',
            rbg: urlgmail + 'images/2/5/beach/{daytime}/canvastile_bg.jpg'
        },
        gmail_mountains: {
            bg: '#6D6C68',
            color: '#fff',
            hl: {
                selector: 'day',
                mon: urlgmail + 'images/2/5/mountains/mon/monday1.jpg',
                tue: [urlgmail + 'images/2/5/mountains/tue/tuesday1.jpg', urlgmail + 'images/2/5/mountains/tue/tuesday3.jpg'],
                thu: urlgmail + 'images/2/5/mountains/thu/thursday1.jpg',
                wed: urlgmail + 'images/2/5/mountains/wed/wednesday.jpg',
                fri: urlgmail + 'images/2/5/mountains/fri/friday1.jpg',
                sat: urlgmail + 'images/2/5/mountains/sat/saturday1.jpg',
                sun: urlgmail + 'images/2/5/mountains/sun/sunday.jpg'
            }
        },
        gmail_pebbles: {
            bg: '#6d6c68',
            color: '#fff',
            hl: urlgmail + 'images/2/5/pebbles/rocks_tile.jpg'
        },
        gmail_ocean: {
            bg: '#af947f',
            color: '#fff',
            hl: urlgmail + 'images/2/5/ocean/weekdays/weekday_header.jpg',
            hr: urlgmail + 'images/2/5/ocean/weekdays/header_tile.jpg'
        },
        gmail_phantasea: {
            bg: '#003142',
            color: '#fff',
            hl: urlgmail + 'images/2/5/phantasea/night_header_bg1.jpg',
            hr: urlgmail + 'images/2/5/phantasea/night_header_tile1.jpg'
        },
        gmail_graffiti: {
            bg: '#000',
            color: '#fff',
            hl: {
                selector: 'day',
                mon: urlgmail + 'images/2/5/graffiti/monday_bg1.jpg',
                tue: urlgmail + 'images/2/5/graffiti/tuesday_bg1.jpg',
                thu: urlgmail + 'images/2/5/graffiti/thursday_bg1.jpg',
                wed: urlgmail + 'images/2/5/graffiti/wednesday_bg1.jpg',
                fri: urlgmail + 'images/2/5/graffiti/friday_bg1.jpg',
                sat: urlgmail + 'images/2/5/graffiti/saturday_bg.jpg',
                sun: urlgmail + 'images/2/5/graffiti/sunday_bg.jpg'
            },
            fl: urlgmail + 'images/2/5/graffiti/footer_bg1.jpg'
        },
        gmail_planets: {
            bg: '#0c1319',
            color: '#fff',
            hl: [urlgmail + 'images/2/5/planets/sun/sun.jpg', urlgmail + 'images/2/5/planets/moon/moon.jpg', urlgmail + 'images/2/5/planets/mercury/mercury.jpg', urlgmail + 'images/2/5/planets/venus/venus.jpg', urlgmail + 'images/2/5/planets/mars/mars.jpg', urlgmail + 'images/2/5/planets/jupiter/jupiter.jpg', urlgmail + 'images/2/5/planets/saturn/saturn.jpg', urlgmail + 'images/2/5/planets/uranus/uranus.jpg', urlgmail + 'images/2/5/planets/neptune/neptune.jpg'],
            rbg: urlgmail + 'images/2/5/planets/base/star_tile.gif'
        },
        gmail_gizmos: {
            bg: '#fff',
            color: '#0065cc',
            fl: urlgmail + 'images/2/5/gizmos/footer.png'
        },
        gmail_candy: {
            bg: '#fff',
            color: '#603913',
            hl: urlgmail + 'images/2/5/candy/header_bg.gif',
            hr: urlgmail + 'images/2/5/candy/headertile_bg.gif',
            fl: urlgmail + 'images/2/5/candy/footer_bg.gif',
            rbg: urlgmail + 'images/2/5/candy/canvastile_bg.gif'
        },
        gmail_busstop: {
            bg: '#78726b',
            bg2: {
                selector: 'weather',
                sunny: '#AFDBE5',
                windy: '#AEDAE3',
                rainy: '#7495A8'
            },
            color: '#196b7b',
            /*Snowy? / Rainy / Sunny / Windy*/
            vars: {
                weather: ['sunny', 'windy', 'rainy']
            },
            rh: urlgmail + 'images/2/5/busstop/{weather}/header_bg.jpg',
            fl: urlgmail + 'images/2/5/busstop/{weather}/footer_bg.gif',
            rf: urlgmail + 'images/2/5/busstop/{weather}/footertile_bg.jpg'
        },
        gmail_ninja: {
            bg: '#006f8a',
            color: '#fff',
            rh: urlgmail + 'images/2/5/ninja/header_bg.gif',
            rf: urlgmail + 'images/2/5/ninja/footer_bg.gif'
        },
        gmail_teahouse: {
            bg: '#8ba451',
            color: '#5c4520',
            hl: urlgmail + 'images/2/5/teahouse/{daytime}/headertile_bg.jpg',
            rh: urlgmail + 'images/2/5/teahouse/{daytime}/headertile_bg.jpg',
            fl: urlgmail + 'images/2/5/teahouse/{daytime}/footer_bg.jpg',
            rf: urlgmail + 'images/2/5/teahouse/{daytime}/footertile_bg.jpg',
            rbg: urlgmail + 'images/2/5/teahouse/{daytime}/canvastile_bg.jpg'
        },
        gmail_terminal: {
            bg: '#000',
            color: '#0c0'
        },
        gmail_orcasisland: {
            bg: '#5e7056',
            color: '#000',
            hl: [urlgmail + 'images/2/5/orcasisland/{fullday}_01.jpg', urlgmail + 'images/2/5/orcasisland/{fullday}_02.jpg']
        },
        gmail_highscore: {
            bg: '#090',
            bg2: '#47B3DA',
            color: '#fff',
            hl: urlgmail + 'images/2/5/highscore/{daynight}_background.png',
            rf: urlgmail + 'images/2/5/highscore/{daynight}_hills_footer.png'
        },
        gmail_turf: {
            bg: '#254a14',
            color: '#fff',
            hl: urlgmail + 'images/2/5/turf/header_tile.jpg'
        },
        gmail_lapinscretins: {
            vars: {
                numero: [1, 2, 3]
            },
            bg: {
                selector: 'numero',
                1: '#3275AC',
                2: '#31669A',
                3: '#B7E0E4'
            },
            color: '#fff',
            sbg: urlgmail + 'images/2/5/lapinscretins/rabbids_header{numero}_final.png'
        },
        gmail_assasinscreed2: {
			bg: '#3C4844',
            color: '#fff',
            sbg: [urlgmail + 'images/2/5/assassinscreed2/ac2_header1_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header2_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header3_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header4_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header5_final.png', urlgmail + 'images/2/5/assassinscreed2/ac2_header6_final.png']
        },
        
/* editors_picks */
"editor_5478752472500006610":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhwWJen7tI/AAAAAAAAAIY/QNQcTiWN9l8/","editor_5478752827007585634":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhwqyH0TWI/AAAAAAAAAI8/APTtF3_y2cI/","editor_5478752842710333378":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhwrsnpN8I/AAAAAAAAAJE/ym-TNB-ipDU/","editor_5478753114195988130":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhw7f-3jqI/AAAAAAAAAJc/YGO5_ldyj-Y/","editor_5478753075316627266":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhw5PJTl0I/AAAAAAAAAJU/rS6YK1WW8-A/","editor_5478753460334726146":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhxPpcxjAI/AAAAAAAAAJs/URghLUy99YA/","editor_5478752501519603442":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhwX1lb1vI/AAAAAAAAAIk/Ksf6-SnvVPo/","editor_5478753089633816370":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhw6EeyjzI/AAAAAAAAAJY/BDvPIiaoi2U/","editor_5478752819223180210":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhwqVH3s7I/AAAAAAAAAI0/xhmZlouBW6Q/","editor_5478753117486370930":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhw7sPW0HI/AAAAAAAAAJg/wiRaz9nNtUw/","editor_5478752835087677362":"http://lh6.ggpht.com/_fxkujw2mA9U/TAhwrQOQt7I/AAAAAAAAAJA/H6GQMElt9Jg/","editor_5478752493997894098":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhwXZkHqdI/AAAAAAAAAIg/PR_JvDoSUUo/","editor_5478752822146891810":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhwqgA8ACI/AAAAAAAAAI4/mBFPhy-c3Dg/","editor_5478753058608504226":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhw4Q5x3aI/AAAAAAAAAJQ/CnTyXr3Q8uQ/","editor_5480987905094465154":"http://lh4.ggpht.com/_fxkujw2mA9U/TBBhdc1eNoI/AAAAAAAAAPg/VL7O_YocFWY/","editor_5480987906200029490":"http://lh6.ggpht.com/_fxkujw2mA9U/TBBhdg9DyTI/AAAAAAAAAPk/1jXNNml5Fvs/","editor_5480998621006856338":"http://lh6.ggpht.com/_fxkujw2mA9U/TBBrNMuFAJI/AAAAAAAAARU/52PQOquzhC8/","editor_5480987916726984130":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBheIK4XcI/AAAAAAAAAPo/BR4cS1ib3xM/","editor_5480987917979934498":"http://lh3.ggpht.com/_fxkujw2mA9U/TBBheM1m3yI/AAAAAAAAAPs/uKFlfn704Q8/","editor_5480987925727076290":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBhepsq38I/AAAAAAAAAPw/Ida0LeDX0fE/","editor_5480988005113749330":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBhjRb7X1I/AAAAAAAAAP4/TUTmK3R2KAE/","editor_5480988012864676114":"http://lh4.ggpht.com/_fxkujw2mA9U/TBBhjuT5IRI/AAAAAAAAAP8/3zSixI6EFwM/","editor_5478753466167683746":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhxP_LdaqI/AAAAAAAAAJw/D3WLPN6-uhk/","editor_5478753483552159554":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhxQ_8Pd0I/AAAAAAAAAJ0/IuvA0kBkziw/","editor_5478755559461692018":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhzJ1TpInI/AAAAAAAAAL4/SRH8g8xRsRE/","editor_5478755572322259650":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhzKlN10sI/AAAAAAAAAL8/B-akepWsw9Q/","editor_5478753799989312658":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhxjawvPJI/AAAAAAAAAKE/Uo0oCE22FnM/","editor_5478753813630017442":"http://lh4.ggpht.com/_fxkujw2mA9U/TAhxkNk736I/AAAAAAAAAKI/cbq956vqL7o/","editor_5478753819961634386":"http://lh3.ggpht.com/_fxkujw2mA9U/TAhxklKgrlI/AAAAAAAAAKM/a95O10f-NEg/","editor_5478752511525657170":"http://lh6.ggpht.com/_fxkujw2mA9U/TAhwYa3EGlI/AAAAAAAAAIo/Wi7XY2Bxgrc/","editor_5478753832267149810":"http://lh5.ggpht.com/_fxkujw2mA9U/TAhxlTAX8fI/AAAAAAAAAKQ/pfQT3foJPRs/","editor_5480997862386069170":"http://lh3.ggpht.com/_fxkujw2mA9U/TBBqhCoybrI/AAAAAAAAAQs/IRrOw-q56ig/","editor_5480997893054118498":"http://lh3.ggpht.com/_fxkujw2mA9U/TBBqi04numI/AAAAAAAAAQw/dEVESx_pvBs/","editor_5480998186992651026":"http://lh5.ggpht.com/_fxkujw2mA9U/TBBqz75ByxI/AAAAAAAAARE/CAq1-arltkE/","editor_5478769425598313058":"http://lh6.ggpht.com/_fxkujw2mA9U/TAh_w8sO8mI/AAAAAAAAAMs/E5kjeXUIQOc/","editor_5478769428183578882":"http://lh3.ggpht.com/_fxkujw2mA9U/TAh_xGUm-QI/AAAAAAAAAMw/TlYQUgOsAOs/","editor_5478769428473291154":"http://lh4.ggpht.com/_fxkujw2mA9U/TAh_xHZroZI/AAAAAAAAAM0/fZ8ZGI4gEHs/","editor_5478769530404012082":"http://lh4.ggpht.com/_fxkujw2mA9U/TAh_3DH3ADI/AAAAAAAAAM4/09PbIsWavv4/","editor_5478769535168997586":"http://lh4.ggpht.com/_fxkujw2mA9U/TAh_3U366NI/AAAAAAAAAM8/fUctF4T897M/","editor_5480596593254567266":"http://lh6.ggpht.com/_fxkujw2mA9U/TA79kGonjWI/AAAAAAAAAO8/wgt1U7ogm0k/",
/* public_gallery */
"public_5468005866288280370":"http://lh5.ggpht.com/_W6mjt7mDgno/S-JCXVndczI/AAAAAAAA3y0/fQWo9r8k0ks/","public_5480525382039743330":"http://lh4.ggpht.com/_3rqotzCU1sY/TA68zEL9q2I/AAAAAAAAA80/cZhz0pxQSM0/","public_5469661666160577106":"http://lh5.ggpht.com/_Z4rK3Ss0bFg/S-gkTk0SilI/AAAAAAAAADw/DDTeQLjTfWA/","public_5464847589870262818":"http://lh6.ggpht.com/_rfAz5DWHZYs/S9cJ7dHd2iI/AAAAAAAAcg8/kx3xyB7P6fc/","public_5468620555541748930":"http://lh3.ggpht.com/_0YSlK3HfZDQ/S-Rxa9h3HMI/AAAAAAAAXiI/fStJVANexYc/","public_5465726438613138322":"http://lh6.ggpht.com/_W6mjt7mDgno/S9opPLz_O5I/AAAAAAAA3yw/yYZekAKroI4/","public_5480525372525642866":"http://lh5.ggpht.com/_3rqotzCU1sY/TA68ygvoBHI/AAAAAAAAA9c/k7jhmLYmw78/","public_5468095309182211138":"http://lh6.ggpht.com/__75Y1wEu2H0/S-KTtmXJFEI/AAAAAAAAAFA/JzlqhzF7Vt4/","public_5467968585789456354":"http://lh5.ggpht.com/_aIZoxdfNfNk/S-IgdU75v-I/AAAAAAAAB7A/jL1VMOt7DgM/","public_5467968606322662898":"http://lh6.ggpht.com/_aIZoxdfNfNk/S-IgehbZnfI/AAAAAAAAB7E/v_h-Pq9AqeU/","public_5394978350593597026":"http://lh5.ggpht.com/_A5ssqXnsoMw/St7QOd4N3mI/AAAAAAAAE98/xKvtFXjUN_U/","public_5468030760630111442":"http://lh4.ggpht.com/_daORpSs2nxc/S-JZAYRETNI/AAAAAAAAAFA/kuOmpgEENNU/","public_5461268259373019506":"http://lh5.ggpht.com/_KFSyWTTuLjA/S8pSi_8LcXI/AAAAAAAAWTA/Ne49ieWVSV8/","public_5418083111186176690":"http://lh6.ggpht.com/_unJLPNmBC1U/SzDl4iXLmrI/AAAAAAABWv4/kkFFBMpXvdM/","public_5465064542962429986":"http://lh6.ggpht.com/_3UYvaY5uN7E/S9fPPyXbsCI/AAAAAAAAAbc/w9YyUMXol5k/","public_5465267981519769410":"http://lh3.ggpht.com/_Z6STI8lIz68/S9iIReDNT0I/AAAAAAAAVn8/1VWscVg0VHI/","public_5464637264209516562":"http://lh4.ggpht.com/_yjAEkPM8eKE/S9ZKo4-SGBI/AAAAAAAAExM/Yolg3yv48ZE/","public_5469816275349772930":"http://lh4.ggpht.com/_aIZoxdfNfNk/S-iw7A7fmoI/AAAAAAAAB7I/uX8etH_Zh8s/","public_5405276903498929458":"http://lh5.ggpht.com/_KFSyWTTuLjA/SwNmtJGtVTI/AAAAAAAAWS8/m3yzK6SE-9k/","public_5464602659331416274":"http://lh3.ggpht.com/_mlwpgEPyjKM/S9YrKnwaoNI/AAAAAAAAL8o/qERJYeK9SOY/","public_5468081125425097026":"http://lh5.ggpht.com/_LgRsf0mgy_M/S-KGz_v7KUI/AAAAAAAABNU/GYTn-LSj3lw/","public_5480525380508846738":"http://lh4.ggpht.com/_3rqotzCU1sY/TA68y-e-CpI/AAAAAAAAA8g/Fb18jqd2T18/","public_5465064395281172466":"http://lh6.ggpht.com/_3UYvaY5uN7E/S9fPHMNeh_I/AAAAAAAAAbY/teuqnGf7uT8/","public_5427875955486466754":"http://lh3.ggpht.com/_K29ox9DWiaM/S1OwbGOnosI/AAAAAAAASqs/Wg5OAoix0tk/","public_5480525385832476034":"http://lh6.ggpht.com/_3rqotzCU1sY/TA68zSUOLYI/AAAAAAAAA9I/JpGyEL5lx9s/","public_5464721817854022450":"http://lh5.ggpht.com/_7V85eCJY_fg/S9aXij2EEzI/AAAAAAAAMsc/rUXq7chzQZo/","public_5468499236979512002":"http://lh6.ggpht.com/_RXIvzqFA_h8/S-QDFSqoksI/AAAAAAAABss/q8Hs_Y6Ojco/","public_5465811371224046274":"http://lh3.ggpht.com/_7SB5-VS6jYo/S9p2e6cZmsI/AAAAAAAAAPk/CdITAmRcDNU/","public_5468499251879550482":"http://lh6.ggpht.com/_RXIvzqFA_h8/S-QDGKLFHhI/AAAAAAAABso/mMXhQIO_rIY/","public_5468011240643552594":"http://lh5.ggpht.com/_q82cg6OMtCs/S-JHQKpm5VI/AAAAAAAAQDs/eQKsBn336_w/","public_5464721917635140242":"http://lh3.ggpht.com/_7V85eCJY_fg/S9aXoXjvGpI/AAAAAAAAMsg/8LweEHXvC8E/","public_5465963404565598994":"http://lh3.ggpht.com/_4HzkBj4VmKw/S9sAwaxq0xI/AAAAAAAAy3s/595Du9f3xbQ/","public_5464886839716494226":"http://lh6.ggpht.com/_as1xi-WX02U/S9ctoGMCO5I/AAAAAAAAC2o/G348G26qKR0/","public_5464644514748019778":"http://lh5.ggpht.com/_dAaguGcsRfA/S9ZRO7VXtEI/AAAAAAAAENA/jQ1y0m7u7FE/","public_5465825398133839090":"http://lh3.ggpht.com/_7SB5-VS6jYo/S9qDPYwTVPI/AAAAAAAAANo/39f76y32uiA/","public_5467921205742594898":"http://lh3.ggpht.com/_aDwLqnCx5xE/S-H1Xcgc61I/AAAAAAAACAQ/zmy2_wM2j4Y/","public_5436863789388960962":"http://lh5.ggpht.com/_uqT1DECwpD8/S3Oez4q2lMI/AAAAAAAAO6c/aGrJoPQEzbY/","public_5464721845849026242":"http://lh4.ggpht.com/_7V85eCJY_fg/S9aXkMIl7sI/AAAAAAAAMsY/hbwwd2lB1ns/","public_5467928286294729906":"http://lh4.ggpht.com/_6NwUsKnkxdc/S-H7zlnoZLI/AAAAAAAAJ2Y/qYD_7yeqVOw/","public_5469782237294118322":"http://lh3.ggpht.com/_iGI-XCxGLew/S-iR9vSoRbI/AAAAAAAABLQ/n5Ix1uZx1qc/","public_5463830940035733394":"http://lh4.ggpht.com/_1rL3G0Y32aQ/S9NtSpWeV5I/AAAAAAAAJd4/wJdXRCWA-_c/","public_5470258900410180098":"http://lh5.ggpht.com/_n8uHgnu6KsU/S-pDfLxeIgI/AAAAAAAAAZY/uPP45av8Tls/","public_5467976005541355106":"http://lh5.ggpht.com/_loGyjar4MMI/S-InNNqm3mI/AAAAAAAAB9s/XKcK0UhQhHk/","public_5467975931636282290":"http://lh6.ggpht.com/_loGyjar4MMI/S-InI6WQ87I/AAAAAAAACEs/WaRxi6D4WCs/","public_5467936023478442338":"http://lh4.ggpht.com/_aDwLqnCx5xE/S-IC183-mWI/AAAAAAAACAU/x5M3XSm-z38/","public_5468630655462131890":"http://lh5.ggpht.com/_vegCfczOoKA/S-R6m2qhyLI/AAAAAAAAIJg/VbgtlWc1YVs/","public_5468499216650860930":"http://lh6.ggpht.com/_RXIvzqFA_h8/S-QDEG75-YI/AAAAAAAABsw/qbL5p3ubU8U/","public_5464708695072547106":"http://lh6.ggpht.com/_s60pF2QNbck/S9aLmtrJoSI/AAAAAAAAeOo/cPMni36CmMk/","public_5464721937652197202":"http://lh4.ggpht.com/_7V85eCJY_fg/S9aXpiILJ1I/AAAAAAAAMsU/m2f6UsfQfEA/","public_5464593346215231826":"http://lh4.ggpht.com/_4HzkBj4VmKw/S9YishsfQVI/AAAAAAAAy3w/2Hg6_XEPri4/"
    };
    
}
/**
 * Use iGoogle Theme for Reader
 *
 */
//http://www.google.com/ig/directory?type=themes
//http://code.google.com/apis/themes/docs/dev_guide.html
GRP.ig = function(prefs, langs, ID, SL, lang){
    var skin_url = prefs.ig_skin_url;
    var skin_name = prefs.ig_skin_name||'';
    var ig_debug = prefs.ig_debug;
    var menu_item;
    var css = GM_getValue('cache_ig_'+skin_name);
    fixMenu();
    if (prefs.ig_userandomthemes) {
        var t = parseInt(prefs.ig_randomthemes, 10) || 5;
        window.setInterval(function(){
            rndskin();
        }, t * 60000);
        rndskin();
    } else {
        setcss(css, skin_url);
    }
    function fixMenu(){
        menu_item = dh('gbg', 'a', {
            href: '#',
            id: 'grp_ch_theme',
            cls: 'gb2',
            html: (getText(lang, 'ig', 'menu_randomtheme') || 'Change theme :') + ' <span id="th_cur">' + skin_name + '</span>'
        }, {
            click: function(){
                rndskin();
            }
        });
    }
    function rndskin(){
        var data = {
            message: 'igtheme',
            type: 'random',
			current:skin_name
        };
        chrome.extension.sendRequest(data, function(entry){
				setcss('', entry.link);
				var item = get_id('th_cur');
				if (item) {
					item.innerHTML = entry.title;
				}
        });
    }
    function setcss(css, xml, entry){
        if (css) {
            GM_addStyle(css, 'theme_ig');
        } else {
            loadCss('skin/css/ig.css', function(css){
                var tplCss = css.replace(/_a_/g, '{').replace(/_z_/g, '}');
                stylish(tplCss, xml, entry);
            });
        }
    }
    function igurl(url){
        return 'http://skins.gmodules.com/ig/skin_fetch?fp=&type=2&sfkey=' + encodeURIComponent(url.replace(/&amp;/g, '&'));
    }
    function convertHours(h){
        var t = 0;
        if (/am$/.test(h)) {
            //am
            t = 12;
        } else {
            //pm
            t = 0;
        }
        t += parseInt(h.replace('/[apm]/g', ''), 10);
        return t;
    }
    function stylish(tplCss, xml, entry){
        GM_xmlhttpRequest({
            method: 'GET',
            url: xml,
            onload: function(r){
                var text = compact(r.responseText);
                var colors = {};
                var skin, skins = [], metadata, ms, reSkins = /<ConfigMap\s+type="Skin">(.*?)<\/ConfigMap>/g;
                var f = 0;
                while ((ms = reSkins.exec(text)) !== null) {
                    if (f > 0) {
                        skins.push(ms[0]);
                    } else {
                        //first is metadata
                        metadata = ms[0];
                    }
                    f++;
                }
				if (skins.length===0){
					console.error('Not XML valid for iGoogle Theme:'+ xml);
					return;
				}
				
                if (prefs.ig_randomtime) {
                    var index = Math.floor(Math.random() * skins.length);
                    skin = skins[index];
                } else {
                    var hc = (new Date()).getHours();
                    var i = 0;
                    var reTrait = /<Trait\s+name="TimeOfDay">([^<]+)<\/Trait>/g;
                    function checkTime(skin){
                        var mt;
                        while ((mt = reTrait.exec(skin)) !== null) {
                            if (mt && mt[1]) {
                                var h = mt[1].split('-');
                                var a = convertHours(h[0]);
                                var b = convertHours(h[1]);
                                if (hc >= a && hc <= b) {
                                    return true;
                                }
                            }
                        }
                    }
                    for (var i = 0, len = skins.length; i < len; i++) {
                        skin = skins[i];
                        if (checkTime(skin)) {
                            break;
                        }
                    }
                }
				if (entry) {
					skin_name = entry.title;
					skin_url = entry.link;
				}
				
				var debug = '', reAttrs = /<Attribute\s+name="([^"]+)">([^<]+)<\/Attribute>/g;
				if (ig_debug) {
					debug += '<a href="http://www.google.com/ig/directory?q=' + encodeURIComponent(skin_name) + '&type=themes" target="igtheme">' + skin_name + '</a><br/>';
				}
                while ((m = reAttrs.exec(skin)) !== null) {
                    colors[m[1]] = m[2];
                    if (ig_debug) {
						debug += '<input size="50" value="' + m[1] + '" style="background-color:' + m[2] + '"/><br/>';
                    }
                }
                if (ig_debug) {
                    var eldbg = get_id('debug');
					if (eldbg) {
						eldbg.innerHTML=debug;
					} else {
						GM_addStyle('#debug{position:absolute;top:200px;right:400px;z-index:9999;height:600px;overflow:auto;background-color:white;}', 'rps_debug');
						var e = dh('', 'div', {
							id: 'debug',
							html: debug
						});
					}
                }
                //tiled
                var header_tile = colors['header.tile_image.url'] || '';
                addClassIf(document.body.parentNode, 'ig_tiled', header_tile);//html
                
                //fixed
                var header_fixe = colors['header.center_image.url'] || '';
                addClassIf(document.body, 'ig_fixed', header_fixe);
                apply(colors, {
                    header_tile: igurl(header_tile),
                    header_fixe: igurl(header_fixe),
					header_link_color: colors['header.link_color'],
					body_bg_color: (header_tile && header_fixe)?'transparent':colors['header.background_color'],
					header_bg_color: colors['header.background_color'],

                    header_text_color: colors['header.text_color'],
					//text_color: colors['gadget_area.tab.unselected.text_color']||colors['gadget_area.tab.selected.text_color'],
					text_color: colors['gadget_area.gadget.body.link_color'],
					link_color: colors['gadget_area.gadget.body.link_color'],

					nav_bg_color: colors['navbar.background_color'],
					nav_text_color:colors['navbar.tab.unselected.link_color']||colors['navbar.tab.selected.link_color'],
					
					nav_bg_color_hover: colors['gadget_area.tab.selected.background_color']||colors['gadget_area.tab.unselected.background_color'],
					nav_text_color_hover: colors['gadget_area.tab.selected.text_color']||colors['gadget_area.tab.unselected.text_color'],
					nav_border_color_hover: colors['gadget_area.gadget.hover.border_color'],
					
					border_color: colors['gadget_area.border_color']||colors['gadget_area.gadget.border_color'],
					bg_action: colors['gadget_area.gadget.header.background_color'],
                    txt_action: colors['gadget_area.gadget.header.text_color'],
					
                    entry_color: '#fff'
                });
                css = '/* '+skin_name+' */'+fillTpl(tplCss, colors);
                GM_addStyle(css, 'rps_ig');
                //cache css
                GM_setValue('cache_ig_'+skin_name, css, false);
            }
        });
    }
	
    var keycode = getShortcutKey(ID, 'random', prefs); //shift+r
    keycode.fn = rndskin;
    initKey(keycode);
	
};
//http://essence-ig-themes.googlecode.com/svn/trunk/lopes/xml/lopes.xml
//http://igcdn.googlecode.com/svn/trunk/xml/travel_lpspain.xml
//Google Aero!
//http://userstyles.org/styles/4096
//Oct 21 2009

//Google Aero! - Icon Pack
//http://userstyles.org/styles/11993
//Oct 21 2009.

GRP.aero = function() {	
	var css= '#ghead,#sbl,#fctr{opacity:1!important}#gbar{display:block!important;position:fixed!important;top:0!important;left:0!important;right:0!important;height:25px!important;z-index:1001!important;background:#F6F6FF!important;border-bottom:solid 1px #99C!important;cursor:default!important;overflow:hidden!important;margin:0!important;padding:0!important}#gbi{display:block!important;visibility:visible!important;position:relative!important;top:0!important;left:0!important;border:none!important}#gbar .gb1,#gbi .gb2{float:left!important;height:inherit!important;font:menu!important;color:#000!important;text-decoration:none!important;cursor:inherit!important;margin:3px 3px 0 5px !important;padding:2px 2px 2px 6px !important}#gbar .gb1:after,#gbi .gb2:after{content:""!important;margin:0 -6px 0 2px !important;padding:2px 4px 2px 0 !important}#gbar .gb1:hover,#gbi .gb2:hover{background:left no-repeat url(data:image/gif;base64,R0lGODlhyAATANUAAPv7/Pr6+/Pz9KOlqfr7/bi6vaKlqa2wtM3S2Ovw9uvx+O3z+auvs+nu86Omqefr7+Xp7eXo6/r8/vn7/fHz9e/x8/r7/Pn6+/j5+vX298zS1+Xp7MrR1vj7/e3w8q2ytbe7vfz9/fLz8/////7+/v39/f///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACYALAAAAADIABMAAAb/QBPiMygaj8ikcslsOp/QqHRKrVqVmoJoxO16v+CweEwum8/otHrNbocPAlJpTq/b7/i8fs/v+/+AgYKDhHgOJAGJiouMjY6PkJGSk5SVlpeYmZqPhxien6ChoqOkpaanqKmqq6ytrq+kDiEZtLW2t7i5uru8vb6/wMHCw8TFug4AFMrLzM3Oz9DR0tPU1dbX2Nna29DIFd/g4eLj5OXm5+jp6uvs7e7v8OUOFh719vf4+fr7/P3+/wADChxIsKDBfQ4uRFjIsKHDhxAjSpxIsaLFixgzatzIMWLCDSBDihxJsqTJkyhTqlzJsqXLlzBjmkwIoabNmzhz6tzJs6fPup9AgwodSrSo0Z0JHyhdyrSp06dQo0qdSrWq1atYs2rdCtUBgQZgw4odS7as2bNo06pdy7at27dw45r1mqCu3bt48+rdy7ev37+AAwseTLiw4b0OJihYzLix48eQI0ueTLmy5cuYM2vezDnygQodFogeTbq06dOoU6tezbq169ewY8uefVoDCAoScuvezbu379/AgwsfTry48ePIkyv3bYIDAwPQo0ufTr269evYs2vfzr279+/gw1cPAgA7)!important}#gbar .gb1:hover:after,#gbi .gb2:hover:after{background:right no-repeat url(data:image/gif;base64,R0lGODlhBAATANUAAPv7/Pr6+/Pz9PLy86Olqfr7/ayvtLi6vfj6/aKlqevw9uvx+O3z+evx96ywtKuvs+nu8+jt8ufr7+Xp7eXo6/r8/vHz9e/x8/r7/Pn6+/j5+vX298zS18vR1srQ1erw9ebr762xtOXp7Li7ve3w8vn7/Pj6+/T29/Hz9O/x8vz9/f////7+/v39/f///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAC4ALAAAAAAEABMAAAZCQEKI41oNDp0WS2AIBFgJjYZF2JxUBAsKQLhcuCQShkChZAgi0XkyOUtAJgIkUiAoPvVFo0RgIFIOFSgjHQkPHi5BADs=)!important}#gbar .gb1:focus,#gbar b.gb1,#gbi .gb2:focus,#gbi b.gb2{background:left no-repeat url(data:image/gif;base64,R0lGODlhyAATAOYAAJWxyCxiizpoikNzmUV1mkh3mpWyyJOwxpezyS9kijxujkR1k2aAkHiSok2LrkFzkVydwUh4lGKixWelyFB9mFOAmleCm3ix0G+On3KPoHWRoX6Von+VonqPm32RnLHM24aZpLXO3M7p+JGkr77S3bLEzsjX4Nrp8mOs02iz22223W213HK533i94m2qyn/C5YzK63600YK305PO7ZjR76jI2azK2sTl9snn99Ps+b7R27XGz93w+uHy++Dx+uX0/P///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEAALAAAAADIABMAAAf/gEAIBQGFhoeIiYqLjI2Oj5CRkpOUlZaKAAIMHiCdnp+goaKjpKWmp6ipqqusra6hBAwjOya1tre4ubq7vL2+v8DBwsPExca5AR0lJz/Nzs/Q0dLT1NXW19jZ2tvc3d7RARw6Pj3l5ufo6err7O3u7/Dx8vP09fbpARskPPz9/v8AAwocSLCgwYMIEypcyLBhwAANQuSYSLGixYsYM2rcyLGjx48gQ4ocSRJjAA0fRKhcybKly5cwY8qcSbOmzZs4c+rc+TJABhs4ggodSrSo0aNIkypdyrSp06dQo0o1GgBDjRtYs2rdyrWr169gw4odS7as2bNo03YNYEEGjbdw4OPKnUu3rt27ePPq3cu3r9+/gOkGqBBjhuHDiBMrXsy4sePHkCNLnky5suXLiwNQuACjs+fPoEOLHk26tOnTqFOrXs26tWvRASK4eEG7tu3buHPr3s27t+/fwIMLH068eO4ACya0WM68ufPn0KNLn069uvXr2LNr384deoAHEliIH0++vPnz6NOrX8++vfv38OPLn3+egAIIK1To38+/v///AAYo4IAEFmjggQgmqOCC/hmQgAMopCDhhBRWaOGFGGao4YYcdujhhyCGKOKIFgJxwACXpKjiiiy26OKLjAQCADs=)!important}#gbar .gb1:focus:after,#gbar b.gb1:after,#gbi .gb2:focus:after,#gbi b.gb2:after{background:right no-repeat url(data:image/gif;base64,R0lGODlhBAATANUAAJWxyJezyixii0NzmT9tj0V1mkh3m5e0ypq2yzp0nXiQoGGp0WWq0oaZpKO5xs7p+MjX4Nrp8miz22223XK533i94n/C5YzK65PO7ZjR78Tl9snn99Ps+d3w+sXV3eHy++Dx+uX0/OTz+////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACMALAAAAAAEABMAAAY7QIEBMWooCAeIx1EIiSKCzwck6FgFnKzgwRVsvgKNWJApCzBowWUtsLgFlbiAQhdMJoyCZJEICAYAI0EAOw==)!important}#gbar .gb1:active,#gbar b.gb1:hover,#gbi .gb2:active,#gbi b.gb2:hover{background:left no-repeat url(data:image/gif;base64,R0lGODlhyAATAOYAAEJxl5Ktwyxiiztpi0RzmEZ1mY+swo2qwJCswjVojWyCkdLb4V+GnmaKoGmLoYSXo4aYo8fV3snW3r/K0VJ/mVqEnW+hv12FnYS302SJn5PK6Ii61prS8Yy814++2JbB2ZrD2q/d9p7F27Pf92uDkbjh+IKTnYiapIeZo4mapIycpZinsMTU3ej0+8/a4M3Y3uv1+5zU8ZvT8J/V8qPX86fZ9IKXooOUncvY377K0OXz+u33/PL6/vH5/ejw9PT7/v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEAALAAAAADIABMAAAf/gEABBQKFhoeIiYqLjI2Oj5CRkpOUlZaKCAMkNyqdnp+goaKjpKWmp6ipqqusra6hBAorEwu1tre4ubq7vL2+v8DBwsPExca5AiY5Pj/Nzs/Q0dLT1NXW19jZ2tvc3d7RAicvPTzl5ufo6err7O3u7/Dx8vP09fbpAikuPfz9/v8AAwocSLCgwYMIEypcyLBhQAEocOyYSLGixYsYM2rcyLGjx48gQ4ocSRKjAAgSYKhcybKly5cwY8qcSbOmzZs4c+rc+VLAgwgtggodSrSo0aNIkypdyrSp06dQo0o1KsAGCx1Ys2rdyrWr169gw4odS7as2bNo03YV4EBEibdw4OPKnUu3rt27ePPq3cu3r9+/gOkKaABihOHDiBMrXsy4sePHkCNLnky5suXLiwVk+BCis+fPoEOLHk26tOnTqFOrXs26tWvRAhh4qEG7tu3buHPr3s27t+/fwIMLH068eG4BFzrQWM68ufPn0KNLn069uvXr2LNr384duoAKG2aIH0++vPnz6NOrX8++vfv38OPLn3+eAAUMMmLo38+/v///AAYo4IAEFmjggQgmqOCC/hmQgAUacCDhhBRWaOGFGGao4YYcdujhhyCGKOKIFgJxAACXpKjiiiy26OKLjAQCADs=)!important}#gbar .gb1:active:after,#gbar b.gb1:hover:after,#gbi .gb2:active:after,#gbi b.gb2:hover:after{background:right no-repeat url(data:image/gif;base64,R0lGODlhBAATANUAACxii0Fxl0NzmEZ1mYuov42qwY2qwI+rwUV8okBuj9Lb4ay9yIzE5I3E45rS8a/d9rPf97jh+H6UoIycpej0+8/Z3+v1+5zU8Z/V8qPX86fZ9OXz+u33/PL6/vH5/ejw9PT7/vP6/f///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAACIALAAAAAAEABMAAAY7QMDgIJpIEgZFZSEAhT6ATscD8FgBnCzAwgVQvoCNGBApAyBowGMN0LgBmTgAQwdcLg2Bg4EoAAIEIkEAOw==)!important}#guser,div.gaiaNav,div.sites-account,#sft .xsm,#ap,p.gseaopt,td.bN.bR {display:block!important;position:fixed!important;top:26px!important;right:0!important;z-index:1002!important;height:0!important;cursor:default!important;margin:0!important;padding:30px 6px 0!important}#guser,div.gaiaNav,div.sites-account{left:0!important;border-bottom:solid 1px #0C3942!important}div.gaiaNav{overflow:hidden!important}#guser nobr{position:relative!important;top:15px!important}#ap{right:-9px!important}p.gseaopt{width:auto!important}#guser nobr > a,div.gaiaNav a,#sft .xsm a,#ap a,p.gseaopt a,td.bN.bR span.toxOdd,#guser nobr .gb4, #guser nobr .offline-status, #offline-status-marker{float:left!important;position:relative!important;font:small-caption!important;color:#FFF!important;text-decoration:none!important;text-shadow:1px 1px 3px #000!important;cursor:inherit!important;margin:0 4px 0 0 !important;padding:4px 4px 5px 8px !important}#guser nobr > a,div.gaiaNav a{top:-43px!important}#sft .xsm a,p.gseaopt a,td.bN.bR span.toxOdd{top:-27px!important}#ap a{top:-40px!important}#guser nobr > a:before,div.sites-account a:before,div.gaiaNav a:before,#sft .xsm a:before,#ap a:before,p.gseaopt a:before,td.bN.bR span.toxOdd:before{display:inline-block!important;vertical-align:top!important;margin:0 6px -4px -2px !important}#guser nobr > a:after,div.sites-account a:after,div.gaiaNav a:after,#sft .xsm a:after,#ap a:after,p.gseaopt a:after,td.bN.bR span.toxOdd:after{content:""!important;margin:0 -8px 0 4px !important;padding:4px 4px 5px 0 !important}#guser nobr > a:active,div.sites-account a:active,div.gaiaNav a:active,#sft .xsm a:active,#ap a:active,p.gseaopt a:active,td.bN.bR span.toxOdd:active{background:left no-repeat url(data:image/gif;base64,R0lGODlhQAEYAOYAABhjcAklKgsmKx5hbCBjbipqdR89QkyOmRw0OB01OR82OiE3O1Z+hWOQmDRLT1+Hjll9gzpPUy4/Ql15fhdjbxdjbhhkcBpmcQomKhxocx5pdB1hayJrdiJsdiFlbw0nKyZueSZveSNmcA4oLCdochAqLixyfSxzfTF3gRY1OidcZC9veChdZSpgaCpfZyldZDRyfCxhaTp+iC9iajJkbDhveEiMl0iNlzZnb0yPmTVjakmGj1CRm0yIkVSTnE+Kk1eTnFOMlUp6gVuUnVuVnUx7giM5PFeMlE99hF6UnFqNlSU6PVuMlFJ+hGGTmic7PlR+hGORmF+Mkik8P1h+hFp9gl2AhVx+g1p6fzdKTVRvc116flVvcxdkbh5qdDF4gSddZDp/iB09QRgyNTBjaRs0N1SUnFeUnGCHjP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAGkALAAAAABAARgAAAf/gGlWERKFhoeIiYqLjI2Oj5CRkpOUlZaXmJmam5QQWVwToaKjpKWmp6RbqKsTqqynrq+tsqm0sbSit7iouri9vLuhv6bDr8Wsx6sOWldozs/Q0dLT1NXW19jZ2tvc3d7f4OHi4+TdU1gPDerr7O3u7/DtUfH0DfP18Pf49vvy/fr91gEMGG9gQIMFCapD+I4hPof1INJ7UkWKk4sYM2rcyLGjx48gQ4ocSbKkyZMoU6pcybKlySVUmCSZSbOmzZs4c+rcybOnz59AgwodSrSo0aNIkwo1wkDJkKdQo0qdSrWqVCJWsw7BqrUq165bwV4V+1Us1LJmraI1u1Zt2qdt/6nG7TpXa92sC6AcAcK3r9+/gAML/ntmsGEghQ8LTqwYcWPCjxk/7it58uDKkzFftsxXc2DPikEfFm1YQZMgPlKrXs26tevXrM3Anu1DNu3Xtm/X1h2bd27eqn8Dhy0ceHHiw1Mfd738dnPaz2cnQPKDh/Xr2LNr3869u/fv4MOLH0++vPnz6NOrX8++PIIiPQ7In0+/vv37+OvnyM//wP7++P0HoH8D6leggAXOh2CC+S2YoIMNMigfhPdRCKCF/WHIXxlC7GDDhyCGKOKIJJYo4g0mpmgDiiqWyGKLK8J4oowvyghijTaaiKONO+qY44c9khhki0OqWGSKAYCxQf8FTDbp5JNQRinlk11MaWUFVV4pZZZaYtkllV9y+WWTYo45ZZljonmmmUyqGaWbWsJ5pZxWBqDCBhTkqeeefPbp55+ABirooIQWauihiCaq6KKMNuroo4gGwMIAAFRq6aWYZqrppphawOmnAHgK6qaijhqqqZ2iWiqqlq7KKqeushorrK9WOqumt46aK6i7foqBCwRcIOywxBZr7LHIJqvsssw26+yz0EYr7bTUVmvttdhGi0ELHmTg7bfghivuuOSWa+656Kar7rrstuvuu/DGK++89LYrQAwiaKDvvvz26++/APfrRcAEazBwwQAfjLDBCwvcsMIN7wtxxAFPHLH/xRVTrC/G/3KMsMcFg0zwBzOQwMHJKKes8sost6xyBy7HzAHMMrdMc80z4/yyzjfrjHLPPrsMtM9DCx30yUWznHTNS8vcdMwj0FAACFRXbfXVWGet9dUhbO01CF1/rXXYYoNdNtdnk3121WqvvXXba8P9tttUy5213WLj/bXeXpeAwwomBC744IQXbvjhhJ+A+OImKM744Y4/3rjkiVMeOeWCX4454ppj3jnnmwf+ueGjP14646cvnoIOMKDg+uuwxy777LTH/kXtuKNwe+6078677r/bHrzvwb9OfPG1H1+88skj7zrzs0PPu/S5U4/7CwbUIMP23Hfv/ffgh+99Uhjily8D+eaHj37657M/vvvru899/PKLT7/899tf//b5g99/+v8zXwDLlwYyiGEMCEygAhfIwAY68IEQjKAEJ0jBClrwghjMoAY3yMEOevCCgQAAOw==)!important;padding:5px 3px 4px 9px !important}#guser nobr > a:active:after,div.sites-account a:active:after,div.gaiaNav a:active:after,#sft .xsm a:active:after,#ap a:active:after,p.gseaopt a:active:after,td.bN.bR span.toxOdd:active:after{background:right no-repeat url(data:image/gif;base64,R0lGODlhBAAYAOYAAAklKh01OSE3OzpPUy4/QhdjbxdkbxhkcAkmKhhjbxpmcRpkbwomKhtlcBxocwsnKx5ociJsdiJqdQ0nKyZveSZueA4oLCtyfBAqLixzfTF3gSldZDR0fR1BRkiNl0yPmVCRm1uVnSM5PF6UnCU6PWGUm2KUm2GTmic7PmSTmmORmCk8P1l+g12AhV16flVvcxdkbh5qdDF4gRY2Ojp/iB09QRgyNTBjaRs0Nxw1OB83OlSUnFeUnDRMT2CIjWCHjDNFR1Jucf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEIALAAAAAAEABgAAAdagAQDLUIuL0AsPz5BPSopKisnJiUoI5YkIZkiPJwCO586IKIBH6U5Hqg4MAYGCAWvAAcJCQAKCwsMDg0NDDEQEA8REhITFBUVFhkXFxgyGhozNBwdGzY1N0KBADs=)!important;margin:0 -7px 0 3px !important;padding:5px 3px 4px 1px !important}#gbs{display:none}#guser #gbg{left:200px!important;top:57px!important;right:auto!important;border:solid 1px #979797!important;background:#F0F0F0 repeat-y 28px url(data:image/gif;base64,R0lGODlhAgABAIAAAOLj4////ywAAAAAAgABAAACAkQKADs=)!important;-moz-box-shadow:4px 4px 2px -2px #8F8F8F!important;padding:1px 2px!important}#guser #gbg .gb2{font:menu!important;color:#000!important;margin:0 4px 0 0 !important;padding:3px 4px 4px 36px !important}#guser #gbg .gb2:before{margin:0 15px -1px -31px !important}#guser #gbg .gb2:after{display:inline-block!important;width:4px!important;height:15px!important;float:right!important;content:""!important;margin:-3px -8px -4px 0 !important;padding:3px 0 4px!important}#gb,#guser,div.sites-account,div.gaiaNav{background:teal repeat-x url(data:image/gif;base64,R0lGODlhAQAeAMQAAGmlr7fU2RhqdxhrdxlqdxtseB1teR9ueiNwfCdzfy14gzN8hzuEj0uUn0+WoVOZo1mcpl2eqGOirG6psXSstXmvt36yuoO1vIe4v4u6wUSOl02ZoVelq5rMzwAAAAAAACwAAAAAAQAeAAAFGGCQYZdVURMgRdDjNINAFMaBJMrCaBvXhQA7)!important}#guser nobr > a:focus,div.sites-account a:focus,div.gaiaNav a:focus,#sft .xsm a:focus,#ap a:focus,p.gseaopt a:focus,td.bN.bR span.toxOdd:focus{background:left no-repeat url(data:image/gif;base64,R0lGODlhQAEYAOYAABlOVxxQWSZbZEyHkU6IkkRze2mlr0lzeniut3iWm6DEyqXJzxFKUxFLUxlqdxlrdxpqdxprdxJKUxxseBRLVBRMVB1teRZNVSBueiBveiRwfCRxfChzfyh0fy54gy55gyBUWzN8hzN9hzNye0yUn0yVnzVnb1CWoVCXoThpcFSZoztrckyIkD5tdFmcplKNllCKk16eqF6fqFWOl0JudVmRmmSirGSjrFyWnkZxeFyUnV2VnWmmr2CYoGObpE12fG+psWuiqnWstXWttVJ4flmBh3mvt32xuW6aoIK0vFt+g2GGi3Kdo4e4v426wZO+xZnCyKbKz6XHzK7O0xlsdzt6gjNobzBjaVmdpmujqnmwt5/Gy67P0zBkaf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAF4ALAAAAABAARgAAAf/gF5MS0qFhoeIiYqLjI2Oj5CRkpOUlZaXmJmam5RICVJToaKjpKRcXKWppaiqrVOsrqmwsbS1tq+3o7O0u7a9tb+5wr7DuMPBRQpRRszNzs/PWlrQ1NDT1dhG19nU29zf4OHa4s7e3+bh6ODq5O3p7uPu7EQLQvb3+Pn6Q0P6/vv/AtrrJ/AfwYIIEyocuBDfwYQPF0ZUOLGhRYkXhVREuPHHFiAgQ4ocSbKkyZMoU6pcybKly5cwY8qcSbOmTZgHoBjYybOnz588ePwcCpSo0Z1CjxJNqrSp06dIofZk6pQqVKtPsUrdepWrAa1NweZ4YqOs2bNo0964kbatWrdw/8uyjet2Lt27ePPK1XvWLl6/egHnFcy3cGDDNgjfVUzDSYzHkCNLnixDxuTLlDFrfmx5M+bOnkOLHs2ZdGTQolGTVj2atenXq2HHcB2adosmLnLr3s27NxYsvYP7Fk48N/Diwo8jX868uXHnu5Uzl+6cenPr0LNX1+4C+3LvK5KoGE++vPnz6NOrX8++vfv38OPLn0+/vv37+PPPT3HkhP//AAYoIAooCGjggAcm6F+BCh7IYIMQRijhghMC+GCEF06YoYQbVuihhh+e0CGEI5qAAAkopqjiiiyWUAKLMLYY44wovkhjjDbeqOOOPNbYo4o57hhkj0PyWOSPSBKZJP8JR+rYZAMsPCDllFRWaSUVVFip5ZVbdillll5uCWaYZJZp5pdnUjlmmWue2aaZb6Ypp5tzPhAnmXcyMIADfPbp55+ASgnooIESaiifDxxqaKKKNuroo30yCimik0pa6aSRYqrpppZC2umjn/IpAQEQlGrqqaimGkEEqbaqqquwlspqrK7OSuutuOYqq66n2oqrr7oCm6uwvBYbrLEQEHurshTAMMGz0EYr7bTUVmvttdhmq+223Hbr7bfghivuuOSW+20FL1ig7rrstuvuu/DGK++89NZr77345qvvvvz26++/AOt7wQwYFGzwwQgnnEEGCTessMMQF8xwxA5PTPH/xRhnLLHGB1uMsccag5yxyByXHLLJGJB8scoA1KDByzDHLPPMG2ww880046zzyzbvjHPPPgct9NA8Ex0z0EIjTbTSQzNt9NNLQ62B00FTHYAOHGSt9dZcd91BB12H7bXYZGcNdtlin4322my3bbbbW6vNttxu09223XDnXbfeHOC9tt8g9ODB4IQXbvjhH3xw+OKIM+744Io/znjkkldu+eWQY1445ZZzjrnnl4Ou+eifk+6B6JWjLsAOOITg+uuwxx67CCLIbrvstd+uewi57257774HL/zwvBMPO/DBIz+88sIzb/zzy0NfPPTOj1CAD0Fkr/323HOfRRbdh989Yfjilx8E+eaHj3767Lfv/vnvb78++/O7X3/798evv/37w79//l6oghWuQMACGvCAB+xCFxDIQAQusIEQvMIDI8jACVLwghjMoAQ1aEALXtCDGQQhBkXIwRKG0IQbNCEJAwEAOw==)!important}#guser nobr > a:focus:after,div.sites-account a:focus:after,div.gaiaNav a:focus:after,#sft .xsm a:focus:after,#ap a:focus:after,p.gseaopt a:focus:after,td.bN.bR span.toxOdd:focus:after{background:right no-repeat url(data:image/gif;base64,R0lGODlhBAAYAOYAAKXJzxFLUxlrdxprdxJLUxxseBRLVBRMVB1teRZNVSBvehlPVyRxfCh0fxxRWS55gyBUWzN9hyZcZEyVnzVob1CXoThpcFSZoztrckyIkUyIkE6JklKNllCKk0R0e16fqFWPl0JvdVmSmmSjrEZyeFyUnWmmr0l0emOcpE12fG+psXWttXivt26aoIK0vFt+g2GGi3Kdo4e4v5O/xZnCyKDFyqbKz6XHzBlsdzNzezt7gjNpbz5udFmdplyXnl2WnWCZoGujqlJ5flmCh3mwt32yuY27wXiXm5/Gy67P0zBkaf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEsALAAAAAAEABgAAAdigC8wMUtJN0ctRDY1QysrAEIqKkgpJiY0JyMjMyQfH0YhPT0yPBcXLhgVFUUWExMsFDg4GgECAhkBAwMbBAUFHQYICBwHCgogCQwMIgsNDSUODw9AEBE+PxJBKB45Sjs6S4EAOw==)!important}#guser nobr > a:hover,div.sites-account a:hover,div.gaiaNav a:hover,#sft .xsm a:hover,#ap a:hover,p.gseaopt a:hover,td.bN.bR span.toxOdd:hover{background:left no-repeat url(data:image/gif;base64,R0lGODlhQAEYAPcAABlOVxxQWSZbZERze0lzepG6wY2xt3iWm6TIzqzL0cLa3sje4tLk58na3dTl6BFKUxFLUxJKUxRLVBRMVBZNVSdrdidsdidrdSlteClueCBUWyxxey1zfTF2gTF3gTR4gzR5gzh8hzh9hzNyezyAikCEjjVnbzhpcDtrcj5tdEJudUZxeGOepmefqGegqE12fGqiqm6krFJ4flmBh3mqsnmrsm6aoFt+g2GGi3Kdo4azuoSvtn+lq5G7wYeutIGmrIarsYSpr420upC1u5O4vp/DyKnM0azM0a/P1LXT17bT17vW2s7i5dzq7CdsdTyBikCFjjt6gjNobzBjaW6lrH6kqYmvtJrAxcfa3DBkaf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAFoALAAAAABAARgAAAj/ALXkwHGjoMGDCBMqXMiwocOHECNKnEixosWLGDNq3EjRxoEGTUKKHEmypMmTKFOqXMmypcuXMGPKnEmzps2bMGdgYaCkp8+fQIMKHUq0qNGjSJMqXcq0qdOnUKNKncpUhoMEWLNq3cr1yBGuYLuGHYv1K9mwZs+qVZt2bdu1ZeHKfQuXrty7dsfmPbuXbN+tL5gUGUy4sOHDiBMrXsy4sePHkCNLnky5suXLmDNPJrCggOfPoEOL7tFDtOnRp1N7Lq36NOvWsGG/jj079mrbuGvb1o27N+/Uv1sHVz089AoFOpIrX868ufPn0KNLn069uvXr2LNr3869u/fv2VUs/6FBvrz58+hr1EDPPn379+TXw28vf759+/Xv578fn7///fwB6N+AAr5X4HwHwpfgeSkkEcODEEYo4YRUUDHhhRRiqOGDFm6IYYcehhgiiCKSKCKHJ6Zo4okrpuhiixrC6KGMG9IoIQpIwKDjjjz26OOPQAYp5JBEFmnkkUgmqeSSTDbp5JNQKnmCES1UaeWVWGbpggtZdqmll2BWyWWYXo5J5plnmommmmiK2eabbLYZ55t0zgmmnWTiGaaeWJqAAAuABirooIQWauihiCaq6KKMNuroo5BGKumklFZqKaQQVHHBppx26umnTjjx6aigkmrqpqKeSmqqqrbaKquuwv/qKqqz1irrrLfWqmuupvKqqq+nAuvpAzxUYOyxyCarrAUWKOvsss9Ga2yz0j5LbbXYYntttttmO6234HbrrbjglktutOdWm6606yYbwQ8YxCvvvPTWm0EG9eZrr778xotvv/r+C/DAAwtMsMEE+5vwwggn3PDCED/Mr8QAU9yvxfRKEMQGHHfs8ccghyzyyCSXbPLJKKes8sost+zyyzDHLDPLEwDBwc0456zzzjz37PPPQAct9NBEF2300UgnrfTSTDd9NAVWdCD11FRXbbUHHlit9dVbdy111l5vDXbYZJM9dtlnl/212mynrbbbbMcNd9dzh12313dXDYABH/T/7fffgAcOAgiBFy644Yj3TXjihi/O+OOPOw655JArXvnllFee+eWcb46454yDnrjogAcwRAiop6766qyLIALrsLce++yov0577Lbfrrvuue/e++61Ay/878ATL/zxxs+e/O3L09786hoQQcL01Fdv/fVPPHH99thz7/302n/Pffjil18++eajbz7467ev/vrvty9//N7TL7793+NvvQA+7FDC/wAMoAAFCAUoDPCAAzQgAhdYAgUy8IAOfKAEHxhBCVZwgg3EoAYvOEEOanCDH/QgBT8IQBEOcAQDEMIVVsjCFrrwhTCMoQxnSMMa2vCGOMyhDnfIwx768IdADKIOPrUQBSlM4YhITKISlZiFLCzxiUt0IhSnOAUpUvGJVryiFq+YRS12cYtVBKMYv7hFMopxjGc0IxfPiEQ1LjEgADs=)!important}#guser nobr > a:hover:after,div.sites-account a:hover:after,div.gaiaNav a:hover:after,#sft .xsm a:hover:after,#ap a:hover:after,p.gseaopt a:hover:after,td.bN.bR span.toxOdd:hover:after{background:right no-repeat url(data:image/gif;base64,R0lGODlhBAAYAOYAANLk5xFLUxJLUxRLVBRMVBZNVRlPVxxRWSdsdilueCBUWyxxey1zfTF3gSZcZDR5gzh9hzVobzhpcDtrckR0e0JvdUZyeGOepkl0emegqE12fGqiqnmrsm6aoFt+g2GGi3Kdo4azuoSwtn+lq5G7wYGmrIarsYSpr420upC1u42yt6TJzp/DyKnM0azM0a/P1LXT17bT17vW2s7i5dzq7CdsdTNzezyBikCFjjt7gjNpbz5udG6lrFJ5flmCh36kqYevtImvtJO5vniXm5rAxcLb3sjf4sfa3Mnb3dTm6DBkaf///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEsALAAAAAAEABgAAAdigB4fIEs0SEMdMQBHPi4uST0sLDMaJCRGGCEhRRYcHDIVPDwwOxsbLxMZGS0SFxcrETU1PwEICCMBCQklAgsLJwMMDCYEDQ1BBQ8PKgYQECkHNzdCCjgiQA5EKBQ2Sjo5S4EAOw==)!important}#guser #gbg .gb2:hover{background:no-repeat url(data:image/gif;base64,R0lGODlhkAEWAOYAAOv3/+Lu9uHt9e74/+Xv9uTu9dzs9tvr9eX1/9jl7dvm7e34/+Tv9uPu9dHj7drs9tnr9dLj7eP1/9vs9trr9eT1/93t9tzs9eb2/+n3/+Du9t/t9drm7ez4/+Pv9uLu9dzn7e/5/+bw9uXv9fP6/urx9enw9Nbq9NDj7dLk7dPk7dzt9tvs9eX2/93t9ef3/97u9tbl7er4/+Hv9uDu9dnm7eDo7NTl7dfm7ePu86jY67Db7L3f7crj7d3t9ODu9Lvf7crk7v///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEIALAAAAACQARYAAAf/gEJBOzqFhoeIiYqLjI2Oj5CRkpOUlZaXmJmam5ydnpY9PDklJqWmp6ipJjYkqq6vsLGys7S1tre4ubq7vL2+v8DBtTs/IiIjyMnKy8wjICHN0dLT1NXW19jZ2tvc3d7f4OHi4+TYOsbH3s/l7O3u7/Dx8vP09dI6BPkF+/z9/v8FFAwASLCgwYMIEypcyLChw4cQI0qcSLGixYsL8emLKBCjx48gQ4ocSbKkyZMFdTBY2aCly5cwYzbgsECmzZs4c+rcybOnz59AgwodSrSo0aNIk/bU4aHph6dQo0qd+qFGB6pYs2rdyrWr169gw4odS7as2bNo06pd+1VHgLcC/+LKnUu3roAEAOzq3cu3r9+/gAMLHky4sOHDiBMrXsy4cWAdMyLTmEy5suXLNHDIwMy5s+fPoEOLHk26tOnTqFOrXs26tevXo3VomL2htu3buHNviJFBt+/fwIMLH068uPHjyJMrX868ufPn0KMXl017OW/p2LNr3869u/fv4MP/pq6B+XXx6NOrX8++vXvtOmDId0G/vv37+F3ceJG/v///AAYo4IAEFmjggQgmqOCCDDbo4IMQEqiDBRReYOGFGGao4QUqYLDhhyCGKOKIJJZo4okopqjiiiy26OKLMMYoo4k6rGAjCzjmqOOOPLKQQgs9BinkkEQWaeSRSCap5M2STDbp5JNQRinllFQiqYMBWB6g5ZZcdunlAREg8OWYZJZp5plopqnmmmy26eabcMYp55x01mmnmjpMoCcFfPbp55+AUuBABYEWauihiCaq6KKMNuroo5BGKumklFZq6aWYMprnnpIOmumnoIYq6qiklmrqqagausMJDzwAwauwxirrrBCgIAGtuOaq66689urrr8AGK+ywxBZr7LHIJqvssr/2AIQPHphlFVvUVmvttdhmq+223HablRA9EPLJuOSWa+656Kar7rrsnhsIADs=)!important}#guser #gbg .gb2:hover:after{background:no-repeat url(data:image/gif;base64,R0lGODlhBAAWAMQAAOHt9eTu9dvr9ePu9dnr9drr9dzs9d/t9eLu9eXv9enw9Nbq9Nvs9d3t9eDu9ePu86jY66/a67zf7crj7d3t9ODu9Lrf7f///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABcALAAAAAAEABYAAAU2IBRNl/JIU5JUkZpAQQzLQw0hOATskONDhyBQGDxAGkiIYQlhOCGCKKRAnVYJhEUEQbFMRKQQADs=)!important}body[onload=sf()]{padding-top:80px!important}body[onload=rpv();]{padding-top:40px!important}body#editpage{padding-top:0!important}.gbh,#gbar a.gb3,#gbi div.gb2,#sft .xsm br,#ap br,p.gseaopt br,td.bN.bR br{display:none!important}#gbar a:focus,#guser a:focus,div.sites-account a:focus,#sft .xsm a:focus,#ap a:focus,p.gseaopt a:focus,td.bN.bR span.toxOdd:focus{outline:none!important}td.bN.bR span[role=link],#guser u{text-decoration:none!important}body[topmargin=3],#doc3,body > div > div > div.nH,body{padding-top:56px!important}';
	//pack icons
	css += 'a:before{display:inline-block!important;width:16px!important;height:16px!important;vertical-align:top!important;margin-right:2px!important;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAAQCAYAAACRBXRYAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAF2FJREFUeNrEmnl0VFX27z/31q15SCrzTIAkEGYEZBIBARVttNV2RFQER9RGbaduFXFuBxwY3q8VcWBQftoiIMgkgmFKIJAASSCBhIQkJJVKVSWV1HSn9weD7dPf763+vfUWe6277rDOOffsfb/nu/fZ+wojhg/n/xRBFFIVRXleVbXxbrfbZrNaS/0B/8L0JNeuEYPziEaVC22Pvf2REGfhjuxeTLOkoljsorGp0RhoqFTKFVVb4u5vpjsSM+uCxaojBvKzXfSIlxHQ0HTwjFhJVnZvSvfvIs5unxSXYL6qouJgwrjRV1xqdWmdW7dt/OeGDf/c0NxcW33+nU6nnXA4iqIoLP1kHW67hNlomuYzJT+mu9wjLTYTejQcMXe0rRGCvr+HVL1W1XQEQfiNrtOnX83vybJlyzIcTmcvORbTq6trTs6f/1LL77X76AHhnM1AiUKXn2RbHG0mC1dmFBR83On1bQ20eGeHu7ALIDgS6dK1X/rf/w+d/xexzG7Vr7/pXjrxYw5noZkChIx2EuRWIpoFJDd+OkkyRAkLToxyB/UGI3GaBEDRNVsFLqIII4YP+9UDURQtkWisuLm5eVA4EiUzqwdjxoxGVTUa6qrfSU9yPK8jRM+37/rnhsxJg1l9xwLG1pdDw0kYfvsl/PiJsW35p8UpYyYnj8joe9l9Jpvkqj14cGvU1/zJgFw7BgNomk7r8OVIoo2UlPhlQycVzEzNtqIBZSVVhOs9TJw8nnZfgA0b1u0sKvpxbUnJ9g0NDY0XwLhi2bdoovmlttSB8wxZ2dicgA6SCDZRRq+u6ZBrj08WzOYDgiii67/+4HfeOfVX9/v27bs8Oytrjs0kDhNFIUVRFD0Y7Gpt9vhKqmtOLLrnnrv3/R4AlRi4km1v5QzMferA+sqbdU1Mf/KbHz48uGH1meVPLZs4ceaINRZnXOrJkm2TRImy82vh3wXgxo0bdVmWUVUVWZZnvLF+yPK9nyZiNSahhCIYbF7aySQegdYwqK3tuHMT0TqiWJ1mTFFAikJYoHRcIcPKT15UAEr/ygpnL/VxoVBoUEZmFsOHXUJHWyMtjSfJyswi0e2c0djifV+SpKbzfTJg7NBhDE65AravtB1auUwov2nRoHumSNbkqiOdGx/9X59NTcu7FKgnWLv71nXvLri5+UjZNQmpbk3TRRITU0CJPdF/bObMw5XbmZB9LU4gcWghNV0qm75fw20zbuCxx+4aP2PGbeNXr968oKRk784fflj2WktL69bu7siV3uyh85IHZFOQAhLQHVLp7NYw2o3YxvWLa+kObumorsk12G2d/5UhTGYLlRUV7w8o7PPnmKpT3RajqUND00TSHA5X71x7frzTOn3FypVv3Dl9+l9/8RYgRyDYDun5jjGXz3iA5B67Voc6VA3i6Dl0Yur1TzUfHX/3V1Jj5S6ObN3WUzJTZnGAKMLhw4d1AF3XUVUVTdN+dVYUBUVRLlzn5OTQr18/fD4fW7ZsebZZyEE0WokCIZuF1mAWX37j4UTJHkoOi4QiyXikNgb2M3P5H0byx0sERvQ0YNeCiJFaLrZIkkH8FQA1nWxdMCBj5tYrChk/6hpamrxEIjH8wdDHTZ6OJslguNCnpGr3lT3zcOCByfeZ+g+bnlAALkxWC9fNuvUc+ELg8+LMSGX64zOv+mr+/D9HfIH3rHYLQdkipfZyPVWQn8iOzSdZWP4OPfvkUV3VxL1Pz2HfqpOcOFZNXt8CiooOEYmYePTR18ePGDFh/MMPXzWoRU94JT4vl7xk6G0CC1AZEbAlSURjGvFGEeO4Qe6SyuOz1Xb/AoPR+LuGOFZVuSgrLWnOkcYuNtcZaYk4iCoawbBMR0Qm0xJl1pB4LhnY97n/+MdH4oMP3P8sgCqDxS69osQUX3tjZ40S6xpbePnDIuSJYMSdMVScMPNOEcBzqiwY6SIhPd3+iRKLLNFUtVTXdQYOHIiqqhdCBF0/Gy6cZ2tBEJBlmc2bNzf36tUro7GxkaKiolOyLC/BfHyxiUL8aBwNWXnt5f2U/hSgZNMfcSRBIuAF6o/BTTPfZUukhd3b38ZudGDwmC8+AJ1204Ubg0HE1xGuSXQ7mTauDwNybJiMAjkZblBVGs+05xkFDcO/ALBYQNQ1oBuSRgVMSagmsGJPyqTLV4nadgiDpEPEA+3N6HYn/Qdk3NCyq+09i0WmqK3anZLXJ82PwD2PPMab8+azdskSZr77KYIIutFILNxFJNKt/fTTAbFPnwKGDgWvtw9AvjklZZDTDZqiIUoiEUXHIAkkmgVks4ARsMdbsaW4r2iqOLnA6rL/xgglBw5cWZiXO6e8Icj3DW4y4gzcOEAk1WEkEtUoOx3k83KNv+0UmTfGRWFej2defHHe2pdfnr+3y88V1z111fO9hw2i7VQnkmkwIHKiZInedqqh02hxW/JHzjLHpQ6h/8S7nJl9s5am9Ezm6/n3pjVVtd6t6zqnT5/GarXi8XhITk6mubmZtLQ0Tp8+TUZGBqdOnSInJweXy5XR2tpKbW0tsizPnjlz5o8vb9+/GNqwk8WK949zcuchqvbcT5KpEUV3YNBcxAsiqfmwdsUDqKF6rO4uiIGQZrn4ADQYzZxbZxhFDUkS9uVlJR1/5E8j+5hMRiLedhAEIjEZORZJdlpFRPEXt93eyqGgl5kkgdYGWpwByeRED3fhsqgYpEYIBEGLoAJ+TyNC8Fgg0wGSBT5Y/GDHe31W+zrVfgmnozD5rscY/af7SchOR5EhHPCQmTOCo0ePdy9c+MjzU6b8cYSitN60dOkHO4FtklE0W0zQFdQ4HNaxWAWy7SISYD53SGdZxNHu68TFb0Oe5AT3k90Rha31ZmxOG9lmLxYlxp6jXWQnupg6IA2XAZ7Y5ufjMiNPX5JEWlrqX4CbjGYqqnbu391j0ISxaflTgTCbFv2l/tDG/XerGjsFcBZ/s+i1657+8tHsAbeRljeBY7tew9fUut5kpX3IkCHC/v37dYvFQmdn50hZlov9fv9IWZaL29vbR0aj0WKv1zsyGo0Wt7a2joxGo8XhcBhZlpsAVEc2YSWNd5adYt3GrWxbcT9OE8QwEBEsWAyN6MRDxMWgHAeS2J8QnWimCLLYcfEBOCbfdQ5+Oj4ljkxZlV3G6Lu19c0f5WQkYDGbEEUBORpFiUX9ktEAoogoSUh2O+1Qsu0nDucfY5DUA2JNJiTnTn78+HQoEuwJYp0N0YqsqiidVdRsWaOt3Zn914h9OEJQx9O2Orb84w8/WjRlwrNBB1gz3bgkcBrg5M9ldJ45RVxiMmVrNoZVlYWbNn2nb9r03evAKSDc1njG19M0ODEaErFYwW0Tz+kDcYDjLDlTf6y20hsyEcCCSdIwGEAywJdffVU4cezIoRWtMTr0eNIFleMdEsWnYzRFEnCebOH1jBSSHRJ2IUSVP46aDiMJTsuIUaNGZU/Po618i2ftwMlNY3sNy+LAulcpWbP/huRcDklnvX3Q38JjmxY/Gj97sWOGIKqUbdp6pK2OHSm9sABhRVGw2WzIslyclpZGLBYrzsjIIBaLFWdlZSHLcnFubi7RaLQ4Ly+PoqIiZFluBJACAqIEPsGGUe3FgCwTqDK6wYVZNtNhzEEALGo3WOzodCOiIMqJaB7XxQfgIwP9COc+WJveRochEU8k5WN/sHu2xStc6nbZMIgC7Z0RVI0vJFFBVyMond10FJUiQ/Hacu4a9w1lw+aBzS2y9KHK0rmfzPnx0VeGPtRr/X9isQRR1W5OH6+lQp0tfMqcazx744+SoHDNNZ3s+KnoubunXpHyt7ffuteSnk040k39qeOU7tjKbbffBkBd3ckAZ0O8MFB1XoFTxcXL+0+dODc5x0zIpxJ1gRWwnTtMwM5d5ezZV/vF5X3C5LqKaQuaCIUhFNGRpFsKNF1LOh0wIKsQDMUwSHYEh410qYvrhvbCKgmsPViHJjkIhzXqOwxkCiQlJibmD5oyuuLyux5wCkIa4Kex8uiPtriz4Du/4XYlQVe798v6I5tn5A6ezK2vvD+wpaaxau/Xi7cBU0aPHi3s2LFDHzVqFGVlZfh8vgvMF4lELjBfc3PzBQacM2dOF4BJ9hEmmfVHy6CXgmbzIGpxCLIdVIg7H+ILJgwaaKKIigq6ToIkXXQAihZJx2QASRToZT/CUOd++qRrV3aERXdVTS21pz3UNbbjbz211G5W1scboyQ1fIW6bSHt27bjOOvmyn9czw48gBjAbxyc+ujrz93x5PNXOzuGv8mJFe3UzvuZM2M2MHnui8K2zxP/ntXn+MM0HeaVVxa4S/aXvpaT17fk8ZkPzt/+yeKu2h0bOV6yj8lXXsOwEZcCEAj4PefA9yvpPNP8UtHS5S0i0CPdgFk463Jt59Bac7qFzev2MmnSCPOf+h1llH0bA41F5MZ+JqFjJ9FIVJBjshBTdboiMsGwgr9bRgm289xlbnIdGk99WcrmZhNGyYisqCiqRjgSERRFMZxdulbADSQAhv+LyZPPcbPh3LI/K6qqvlBbW0tmZiZOp7O4R48euFyu4p49e+J2u4vz8vJITEwsLiwsJBaLXcjdtLvs6IhI7Qng1xGjbghq6MZugkYNZNANUbCAKuoYNCtWdNBriVqyLz4DypqArgtoqowhauphTB3095zE9FtNOb041ZCD0H6EjPR0bPmDc11a7UpFSlujauFviEaQ4k2IxLAB5VUs9u5jQlJqjMFD7FnywBgmTEzsm4KncBJtDRoTJ/cmAVDdcNuMuA+WtAVb/X7D9ZMm5cxYtWoJO3eW7a09WY8oCkwZPoHc3Bza2rpJSrLT2trq/T0FHInujtP7S8Z89ZfQF+PvuvKyPoPzsJgkzgRDbNhWrOzffaS+96AJGYPcxz+3VNRWNnQnPNmlu6oiooIiabS3e0+FQt2+ZKsxIdCkIOogiDqhcJR9lQ0caQ5R2p2E2WImGIogCgbcYhBvu8/v8XhOHt5alrLziz2P3vnWe2/1GjaXrH6TJh3euneo3X3BBdPpBXe64/YeAy8DnKx+YcbR6j3lN6b0ov68HpMmTXr1+++/f+V82qWpqQlFUWhsbESWZerr69F1nYSEBBTll0KAWQ1gIoesxHi2791P1BDD7LQS7RRxuqDbAF1onKhtwxSXgkU1EfFaGTYAOgzlFx+A27c2kpvlIjutPd1UMOwnTGN6Cr4AGdZyMqbOouL0lWyqjXLPkMzJ0sHXkJr33iEr3idFq2OBKMgYzgX57jgKxQTAYMAfiNHaLpLaCbod0uUAyVaFk41RtpqCaB1OevRNkHr2PXN9Y2NtlseTTyTSxvjxQ0aPGTOEiorjBAJdNDY2kZSUhqoaOHOmuev3OVzElZxY11pVOW71305MS81Nu8xhtyb52wMNtSc93xQMGFDlaPzi6fz8+DeSJ07sEd6wdkRTu3mshrFaQOPp5549MmDd2or8dOs4sxbC22XCaFCIEyROeGIoWJBECEdlvCGdvEQdd6yR8qbW8kOHDtV+cIeQOvjKgddnFt4AwPDrXsHbULzm0MatFzYh8Sm8dvWcOTMEcRSQyZCr7+rvP/PkJCXGR/+qyh/+8If/Nim8YMECU3FxcVRV1fYLABQtiHgZdanM9h/68OqiIzwxdzB2lxUUsElhDh6y8OeHDtIYjBJvdTDzzgwu6dcHu5B+8QEYDCho8X5EY/Knqtqnp1xZDLoCYS8Wbz2Ng75jswLTO49DyRai1ZVIDt5FtB7WELadH0iDjlg3GgKiYDBwJiJQGQC8OhkHdmPZs5f6ihoaCvoQ8xtQBR1FU9zz5899KhZ7b9OAAUOSPJ4zxMUJDBnShz17Slm9egOXXDKIwsICfD6f73c10HV0wJGYgCrL672nW9d7dB2DyUxaWhz57EIr+3ZDV+GNr6Xf8Lw4VDAldX355Z5ddVljFN1cHQ2F1aVLly2Mc1jH/bGXgcWH49DQcZq7GVaQQGuXzDfVfgKqDZPRzE0ZtVQfrqC2rv5DADlK/8Lx946VjGZaaopIyx/H1Y8s75F36Vs/tZ0q7TRabJb8kdeZ41InEemuJXCmlILRdwvlW/4xramq+hvAu379+j6KojyhKMr95xlQluUL53NVDxRF4ZlnnhHmz59/YTGqoRxsWHj0T0msesvPwleOMeHqUYztq6BLEkJ3mHGDrOzbdR1VHpgyZj7ZGdMQRS9KgIsPwC5do9YXu7qXnnqVp6YeXZbRYhFiLV7Mew5ScP+nXJ41k0hNGW0/VxJRwWoGjx7+oLFbHKlDlxk408EOTz1CmlFDsJqpx4AT0CICTe58ggXdVIkJWAQjrgL4/oMGTh04WRr1HSu9//6p/a+66uYXr7329jn9+w+ntbWO3btLkaQsamo8RCId+Hze/zZtr+s6oiRhdUoIgoAimLHoneSou5Bt6UdWLf5hwjUhw44R058Rx0tiYvcnX+3ZeSz5MuDYfffN+vqzzz77trC3fOPsvjFWn0yguN3Ktm8bUAURkz2RXgkCt6TXEqwp4mh13effr1/3A4DDzfZdK154ddPCx322uMRB97y/8R7JlE7epXcJeZdOiIPeQDZgpeKnxcFNCz94PD3fOUaJhZbY4/ECyLJ884033vjAqlWrqhRFmSvL8vuzZs16/1/1e/PNN+cqijL35Zdfnquq6oVAM2ZtRCedJLOXHZtGcvWEPVw/fiUvPjeCux4uINluIkgXGg7q2mXauioxO684W0e2d118AO6u9QiD01yPh/0G2nwB5A4vkeY6lGCIeBmOfbqcZy3XkimuIq8BAmaIl6ApRL/ysJauQU0ISDAzZcAYBLByfFtDcEvbjjPds4cUxKe4qHv0c2QBDBrE9nRxqrRO3fcfe5/XQtEPz83Ds3nz14/s3Lnuo8mTb/rr6NGTbrXZ3CQnSyQlZVNTsw+Pp+3gv1XkRkfTBSJCPHZrBJMrpWjp39dMCEW0HeNnPSde45ASm1/+tghI1nWdfv363/nQQw+uyM1MvvGhHonUprppkR3omkai0EBKrJ66skqqahtWrlyx4r4Vy784m7w3QqS764VwELL7p+2STE6qfp6vhToatWHT5kn+5oNa+ea52vi7v5ZScqc6LY4PfEFfcJbFAeI5GCmKwsqVK/W0tLTzCej3Fi1a9N55NlQUhby8PAoKCjh27Nh7ZWVlJ87rqTjCdGDHrNlJSYUfy57giRd+4oMlG3nrk71gzMfgihFpcxCX1sq9j9/EmAnDEbAiE3/xAWgRDODptrVVNHLGH6CjvhZUECUI6uArLWeQexFez2ac0tn65QkVrTzGS+44TrYCLsAXZemSJ4VrL7lam7j/u8or2tl8YN3uyhtM8WJPMd4eJxgkQe8IhiL+0BnUwC6IP4ktHkK/TCYSiR7+/vtVt+3c+e2yKVNueHnUqFtGhsNh1q1b8SOw53+qpKbpOOwStoSMomVvr5sgSqaduYVDhLY0Z9L5NpWVFWHgpmeffe7OhHjngy6bqX8GxMdiMYLBoO/nlvbDTc0tS9avX/f1iuXLf2FeDSQTOBOhO3Bmz8/LHxh7YH3Rrbompg+b9o8P6w5917r27a0TO73T1liccam2OOpE6WzZ83ya5pZbbnkVeHXp0qV6dXU1qqo+/sgjj/yKAV966aW55eXl7ymKwhtvvJF//nmvgER8EHRnIwJZWK0iX70zCd6Z9Bs7hGUNqyiCAoTD2EzqRQeg8PqIdErrfalp4ehjQ4xcj0a2ZvjFOIIg6JLJEDNElWirTsVxhWLBxH/2cFGR74bNB0EEIoCKMCpVYmq9Ypy3kXmc3aL4z0aIZ3cM57YsDpASwGSC0Mz/cnJpaSm3y7LSu73d9zlw+vfa3Hzzs79VShBQBRNGrYsr4jZjFcO0d0m0BcDrjRJn6nwsZdh1046rY8s/Wjj7L7837rXXXjvSbLHkRMIRPRDw1+/Zs2f/v/871siPO71NWwMtjf/ffscat3HK/3iAz+7bRu8m/aL+DfO/BwBgLfmnAZ7z2gAAAABJRU5ErkJggg==)!important}a[href*=.google.][href*=/accounts/Login]:before,a[href*=.google.][href*=/accounts/ClearSID]:before,a[href*=.google.][href*=/groups/signout]:before,a[href*=.google.][href*=/Logout]:before,a[href*=.google.][href*=/logout]:before,a[href*=.google.][href*=?logout]:before{background-position:-16px 0!important;content:""!important}a[href*=.google.][href*=/history/]:before{background-position:-32px 0!important;content:""!important}a[href^=/maps/user?],a[href*=.google.][href*=/accounts/ManageAccount]:before{background-position:0 0!important;content:""!important}a[href*=.google.][href*=/support]:before{background-position:-64px 0!important;content:""!important}a[href*=/advanced_search?]:before{background-position:-48px 0!important;content:""!important}a[href*=.google.][href*=#settings]:before,a[href*=/preferences?]:before{background-position:-80px 0!important;content:""!important}a[href*=/shoppinglist?]:before{background-position:-96px 0!important;content:""!important}a[href*=.google.][href*=pref=ig]:before{background-position:-112px 0!important;content:""!important}';
	//hide logo / Show search box
	css+='#logo-container{ display: none !important; }#search{left:500px!important;top:30px!important;z-index:2000!important;}';
	//Show user information
	css+='#guser nobr .gb4, #guser nobr .offline-status, #offline-status-marker{top:-43px!important;}';
	
	css+='.gbm{position:fixed!important;}';
//TODO: give offline span a hover button 
//make .offline-status same behavior as #guser nobr > a (:hover active...)
	GM_addStyle(css, 'rps_aero');
	//fireResize();
};// ==UserScript==
// @name           Google Reader Air Skin
// @namespace      http://userscripts.org
// @description    A skin for Google Reader
// @homepage       http://userscripts.org
// @include        http://www.google.*/reader/view/*
// @include        https://www.google.*/reader/view/*
// ==/UserScript==
//http://userscripts.org/scripts/show/10573

GRP.air = function() {
	var css = "* { font-family: tahoma, verdana, lucida sans, helvetica, arial !important; } /* buttons */ button { font-size: 13px !important } /* search bar, actions menus */ form#s input, div.tbc select, div.tbc button, div.cd button, div.chc button, div.chc select, td#st_compose button { margin-bottom: 0px !important; } /* Refresh link */ span#rfr { font-size: 13px !important; } /* selection menus */ div.tbc { font-size: 13px !important; } /* contacts sidebar */ div#nav div.nl span#comp { font-size: 13px !important; } /* compose message sidebar: list item (current) */ div#nav table.cv tr.an td b.lk { font-size: 15px !important; font-weight: normal !important; text-decoration: none !important; display: block !important; padding: 4px 0 4px 0 !important; } /* folders sidebar: list item (current) */ div#nds table.cv tr.an td b.lk { font-size: 15px !important; font-weight: normal !important; text-decoration: none !important; display: block !important; padding: 6px 0 6px 0 !important; } /* folders sidebar: list item */ div#nds div.nl { font-size: 13px !important; margin-left: 10px !important; padding-left: 6px !important; padding-top: 3px !important; padding-bottom: 3px !important; } /* folders sidebar: list item (hover) */ div#nds div.nl:hover { background-color: #e3ebfe !important; } /* invite a friend sidebar */ div#nvi { display: none !important; } /* labels appearing in the subject line */ table.tlc span.ct {color: red !important; font-size: 8pt !important; font-weight: bold !important} /* messages */ table.tlc tr td { font-size: 13px !important; padding-top: 3px !important; padding-bottom: 3px !important; } /* cursor */ #ar { margin-top: 2px !important; } /* messages (unread) */ table.tlc tr.ur td { font-size: 13px !important; } /* messages (unread - snippet) */ table.tlc tr.ur td span.p { font-size: 13px !important} /* block (all width active) */ div#nav table.cv tr.an td b[id], div#nds span.lk { display: block !important; } /* remove underline */ div#nds span.lk, div#nds b.lk { text-decoration: none !important; } /*round corners*/ div#nds div.nl { -moz-border-radius-topleft: 4px !important; -moz-border-radius-bottomleft: 4px !important; } /* selected round corners */ div#nav table.cv b.rnd { background-color: transparent !important; } div#nav table.cv { -moz-border-radius-topleft: 5px !important; -moz-border-radius-bottomleft: 5px !important; } div#nav table.cv td:first-child { -moz-border-radius-topleft: 5px !important; -moz-border-radius-bottomleft: 5px !important; } /* border lines */ div#nds div.nl:first-child { border-top: 1px solid #C3D9FF !important; } div#nds div.nl { border-bottom: 1px solid #C3D9FF !important; } div#nds div.nl { border-left: 1px solid #C3D9FF !important; } /*selected border lines*/ div#nds table.cv:first-child { border-top: 1px solid #C3D9FF !important; } div#nds table.cv { border-bottom: 1px solid #C3D9FF !important; } div#nds table.cv { border-left: 1px solid #C3D9FF !important; } /* bk */ div#nds div.nl { background-color: #FFFFFF !important; } /* selected: remove not(tr.an) and resize tr.an to compensate*/ div#nds table.cv tr.an { height: 15px !important; } div#nds table.cv tr:not([class='an']) td { display: none !important; } /* compose and contacts */ div#nav > div.nl { border-top: 1px solid #C3D9FF !important; border-bottom: 1px solid #C3D9FF !important; border-left: 1px solid #C3D9FF !important; -moz-border-radius-topleft: 5px !important; -moz-border-radius-bottomleft: 5px !important; background: white !important; padding-top: 3px !important; padding-bottom: 3px !important; } div#nav > div.nl:hover { background: #e3ebfe !important; } /* selected border lines */ div#nav > table.cv { border-top: 1px solid #C3D9FF !important; border-bottom: 1px solid #C3D9FF !important; border-left: 1px solid #C3D9FF !important; } div#nav > div.nl span#cont, div#nav > div.nl span#comp { display: block !important; text-decoration: none !important; } div#nav > table.cv tr.an b.lk { text-decoration: none !important; }  /* remove left round so that the tab 'compose mail' will connect to div#co' */ div#co > div#tct > table > tbody > tr > td > b.rnd > b.rnd1, div#co > div#tct > table > tbody > tr > td > b.rnd > b.rnd2, div#co > table > tbody > tr > td > b.rnd > b.rnd1, div#co > table > tbody > tr > td > b.rnd > b.rnd2 { margin-left: 0px !important; } .lk { font-weight: normal !important; } /* labels box labels sidebar: header */ div#nvl td.s { padding: 6px 0px 6px 0px !important; font-size: 15px !important; } div#nb_0 { margin-top: 10px !important; margin-bottom: 1.5em !important; } /* label box color div#nb_0 div.nb, div#prf_l, div#nvl b.rnd b.rnd1, div#nvl b.rnd b.rnd2 { background-color: rgb(0, 217, 255) !important; } */ /* item color */ div#nb_0 table.nc div.lk[id^=\"sc\"] { background-color: #FFFFFF !important; border-top:1px solid transparent; border-bottom: thin solid #EFEFEF !important; text-decoration: none !important; padding: 2px 1px 3px 3px !important; } /* item over color */ div#nb_0 table.nc div.lk[id^=\"sc\"]:hover { background-color: rgb(226,250,234) !important; } /* remove edit label link */ div#prf_l { display: none !important; } /* remove table extra border */ div#nb_0 table.nc { border-spacing: 0px !important; padding-right: 4px !important; } div#nb_0 table.nc tr, div#nb_0 table.nc td { padding: 0 !important; } /* spam not bold */ #ds_spam b { font-weight: lighter !important; }";
	GM_addStyle(css, 'rps_air');
	//fireResize();
};// ==UserScript==
// @name           Google Air Skin Comic Sans
// @namespace      http://userscripts.org
// @description    A skin for Google
// @homepage       http://hebbet.blogspot.com
// @include        http://www.google.com/calendar/*
// @include        https://www.google.com/calendar/*
// @include        https://www.google.com/reader/*
// @include        http://www.google.com/reader/*
// @include        https://mail.google.com/mail/*
// @include        http://mail.google.com/mail/*
// @include        http*://*.google.*/*
// @include        http*://groups.google.*/*
// @include        http*://spreadsheets.google.com/*
// @include        http*://docs.google.com/*
// @exclude        http*://docs.google.com/View?*
// @exclude        http*://spreadsheets.google.com/ar*
// @exclude        http*://spreadsheets.google.com/fm*
// @exclude        http*://docs.google.com/Misc*
// @exclude        http*://spreadsheets.google.com/pub*
// ==/UserScript==
//http://userscripts.org/scripts/show/9692

GRP.aircomic = function() {
	var css = "* { font-family: comic sans ms !important; } /* buttons */ button { font-size: 13px !important } /* search bar, actions menus */ form#s input, div.tbc select, div.tbc button, div.cd button, div.chc button, div.chc select, td#st_compose button { margin-bottom: 0px !important; } /* Refresh link */ span#rfr { font-size: 13px !important; } /* selection menus */ div.tbc { font-size: 13px !important; } /* contacts sidebar */ div#nav div.nl span#comp { font-size: 13px !important; } /* compose message sidebar: list item (current) */ div#nav table.cv tr.an td b.lk { font-size: 15px !important; font-weight: normal !important; text-decoration: none !important; display: block !important; padding: 4px 0 4px 0 !important; } /* folders sidebar: list item (current) */ div#nds table.cv tr.an td b.lk { font-size: 15px !important; font-weight: normal !important; text-decoration: none !important; display: block !important; padding: 6px 0 6px 0 !important; } /* folders sidebar: list item */ div#nds div.nl { font-size: 13px !important; margin-left: 10px !important; padding-left: 6px !important; padding-top: 3px !important; padding-bottom: 3px !important; } /* folders sidebar: list item (hover) */ div#nds div.nl:hover { background-color: #e3ebfe !important; } /* invite a friend sidebar */ div#nvi { display: none !important; } /* labels appearing in the subject line */ table.tlc span.ct {color: red !important; font-size: 8pt !important; font-weight: bold !important} /* messages */ table.tlc tr td { font-size: 13px !important; padding-top: 3px !important; padding-bottom: 3px !important; } /* cursor */ #ar { margin-top: 2px !important; } /* messages (unread) */ table.tlc tr.ur td { font-size: 13px !important; } /* messages (unread - snippet) */ table.tlc tr.ur td span.p { font-size: 13px !important} /* block (all width active) */ div#nav table.cv tr.an td b[id], div#nds span.lk { display: block !important; } /* remove underline */ div#nds span.lk, div#nds b.lk { text-decoration: none !important; } /*round corners*/ div#nds div.nl { -moz-border-radius-topleft: 4px !important; -moz-border-radius-bottomleft: 4px !important; } /* selected round corners */ div#nav table.cv b.rnd { background-color: transparent !important; } div#nav table.cv { -moz-border-radius-topleft: 5px !important; -moz-border-radius-bottomleft: 5px !important; } div#nav table.cv td:first-child { -moz-border-radius-topleft: 5px !important; -moz-border-radius-bottomleft: 5px !important; } /* border lines */ div#nds div.nl:first-child { border-top: 1px solid #C3D9FF !important; } div#nds div.nl { border-bottom: 1px solid #C3D9FF !important; } div#nds div.nl { border-left: 1px solid #C3D9FF !important; } /*selected border lines*/ div#nds table.cv:first-child { border-top: 1px solid #C3D9FF !important; } div#nds table.cv { border-bottom: 1px solid #C3D9FF !important; } div#nds table.cv { border-left: 1px solid #C3D9FF !important; } /* bk */ div#nds div.nl { background-color: #FFFFFF !important; } /* selected: remove not(tr.an) and resize tr.an to compensate*/ div#nds table.cv tr.an { height: 15px !important; } div#nds table.cv tr:not([class='an']) td { display: none !important; } /* compose and contacts */ div#nav > div.nl { border-top: 1px solid #C3D9FF !important; border-bottom: 1px solid #C3D9FF !important; border-left: 1px solid #C3D9FF !important; -moz-border-radius-topleft: 5px !important; -moz-border-radius-bottomleft: 5px !important; background: white !important; padding-top: 3px !important; padding-bottom: 3px !important; } div#nav > div.nl:hover { background: #e3ebfe !important; } /* selected border lines */ div#nav > table.cv { border-top: 1px solid #C3D9FF !important; border-bottom: 1px solid #C3D9FF !important; border-left: 1px solid #C3D9FF !important; } div#nav > div.nl span#cont, div#nav > div.nl span#comp { display: block !important; text-decoration: none !important; } div#nav > table.cv tr.an b.lk { text-decoration: none !important; }  /* remove left round so that the tab 'compose mail' will connect to div#co' */ div#co > div#tct > table > tbody > tr > td > b.rnd > b.rnd1, div#co > div#tct > table > tbody > tr > td > b.rnd > b.rnd2, div#co > table > tbody > tr > td > b.rnd > b.rnd1, div#co > table > tbody > tr > td > b.rnd > b.rnd2 { margin-left: 0px !important; } .lk { font-weight: normal !important; } /* labels box labels sidebar: header */ div#nvl td.s { padding: 6px 0px 6px 0px !important; font-size: 15px !important; } div#nb_0 { margin-top: 10px !important; margin-bottom: 1.5em !important; } /* label box color div#nb_0 div.nb, div#prf_l, div#nvl b.rnd b.rnd1, div#nvl b.rnd b.rnd2 { background-color: rgb(0, 217, 255) !important; } */ /* item color */ div#nb_0 table.nc div.lk[id^=\"sc\"] { background-color: #FFFFFF !important; border-top:1px solid transparent; border-bottom: thin solid #EFEFEF !important; text-decoration: none !important; padding: 2px 1px 3px 3px !important; } /* item over color */ div#nb_0 table.nc div.lk[id^=\"sc\"]:hover { background-color: rgb(226,250,234) !important; } /* remove edit label link */ div#prf_l { display: none !important; } /* remove table extra border */ div#nb_0 table.nc { border-spacing: 0px !important; padding-right: 4px !important; } div#nb_0 table.nc tr, div#nb_0 table.nc td { padding: 0 !important; } /* spam not bold */ #ds_spam b { font-weight: lighter !important; }";
	GM_addStyle(css, 'rps_aircomic');
	//fireResize();
};// ==UserScript==
// @name		google Enhanced BLACK
// @description		This Google Black script enhances all Google service pages with an inverted color-scheme for reduced eye fatigue; it also removes ads & clutter and improves page layout and readability by widening search results
// @version		2.9.9
// @date		2009-11-21
// @source		http://userscripts.org/scripts/show/12917
// @identifier		http://userscripts.org/scripts/source/12917.user.js
// @author		gabedibble <gdibble@gmail.com>
// @namespace		http://userscripts.org/people/24894
// @include		htt*://*.google.*
// @include		htt*://www.google.*/accounts*
// @include		htt*://services.google.*
// @include		htt*://www.google.*/voice*
// @include		htt*://www.google.*/reader*
// @include		htt*://*.googlelabs.*
// @exclude		htt*://*.google.*/custom*
// ==/UserScript==

// GENUINE FREEWARE <3
// (CC) BY-NC-SA: This work is licensed under a Creative Commons Attribution-Noncommercial-Share Alike 3.0 United States License. <http://creativecommons.org/licenses/by-nc-sa/3.0/us/>

// Change Log & To-Do Lists available @source (URI above)
// Feel free to leave suggestions/criticism on the UserScript Page or via email; THANX! =)


GRP.black = function(){

    var scriptVersion = 1258854468202; //alert(Date.now());
    var scriptFileURL = "http://userscripts.org/scripts/source/12917.user.js";
    var scriptHomepageURL = "http://userscripts.org/scripts/show/12917";
    
    
    var googleEnhancedBLACK;
    
    function enhanceGoogle(){
        // General Google Page enhancements	
        googleEnhancedBLACK =        /* Global font override */
        "*   {font-family:Trebuchet MS, Verdna;}" +
        /* page bg */
        "BODY   {background:#000 none !important; color:#fff;}" +
        /* link color */
        "A, #gbar A.gb1, #gbar A.gb2, #gbar A.gb3, #guser A.gb3, #guser A.gb4, SPAN.i, .linkon, #codesiteContent A, TABLE.mmhdr TBODY TR TD.mmttlinactive SPAN, TABLE TBODY TR TD TABLE TBODY TR TD A, .lk, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#related TABLE.gf-table TH.sortable, SPAN.linkbtn, DIV#ss-status A.gb3, SPAN#rptgl SPAN, A SPAN.b, .mmttl SPAN, A > SPAN.navlink, SPAN > SPAN.link, DIV#rptgl > SPAN, DIV#tbt-expander DIV, #guser SPAN > SPAN, DIV#ss-bar DIV#ss-box > A, DIV#rpsp.rpop DIV.tl B, SPAN#zippyspan, .actbar-btn   {color:#6495ed !important;}" +
        /* visited linx */
        "A:visited   {color:#406b80 !important;}" +
        /* results visited linx */
        "DIV#res A:visited   {font-size:0.8em !important;}" +
        /* google bar txt */
        "#gbar SPAN   {color:#999;}" +
        /* google bar txt */
        "#gbar DIV.gb1   {background-color:#c9d7f1 !important;}" +
        /* google bar txt */
        "#gbar DIV.gb2   {padding-top:0; padding-bottom:0; background-color:#c9d7f1 !important;}" +
        /* google bar linx */
        "#gbar A.gb1, #gbar B.gb1, #gbar A.gb3   {position:relative; bottom:0.2em; font-weight:bold !important; font-size:1.15em !important;}" +
        /* google bar b-line */
        "#gbh, .gbh   {border-color:#777;}" +
        /* top logos */
        "#logo SPAN, DIV#regular_logo, TABLE[align='center'] TBODY TR TD DIV#logo, #search .logo, TABLE[width='100%'][cellpadding='2'] TBODY TR TD[width='1%'][valign='top'], #gc-header #logo, #header #logo, TABLE[style='margin: 0px 0px -6px 0pt; padding: 0px; width: 100%;'] TD[style='width: 153px;'], TABLE[align='center'] TBODY TR TD[width='155'][rowspan='2'], TABLE[align='center'] TBODY TR[valign='middle'] TD[width='135'], BODY[bgcolor='#ffffff'][topmargin='3'] CENTER TABLE[width='725'] TBODY TR TD TABLE[cellspacing='1'] TBODY TR TD[height='1'][bgcolor='#666666'], BODY > TABLE[width='100%'][style='direction: ltr;'] > TBODY > TR > TD, BODY > TABLE[width='100%'] > TBODY > TR > TD[width='100%'][style='padding-left: 15px;'], BODY.siteowners > TABLE[width='96%'] > TBODY > TR > TD[width='1%'], BODY > CENTER > DIV > TABLE[width='739'] > TBODY > TR > TD[width='100%'], BODY[bgcolor='#ffffff'] > TABLE[cellpadding='5'][align='center'] > TBODY > TR[valign='middle'] > TD[width='1%'], TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='1%'][valign='top'], BODY.search > TABLE[width='95%'] > TBODY > tr[valign='top'] > TD[width='1%'], BODY > DIV#container > DIV#header > DIV[style='float: left; width: 155px;'], BODY > TABLE[width='100%'][height='100%'][style='margin-bottom: 1px;'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'][cellspacing='2'] > TBODY > TR > TD[width='1%'], BODY[onload='sf()'] > CENTER > FORM > TABLE#frame > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD[width='100%'] > TABLE > TBODY > TR > TD[width='100%'] > TABLE > TBODY > TR > TD > DIV[style='margin: 5px 0pt 4px 4px; background: transparent url(/images/firefox/sprite.png) no-repeat scroll 0pt -95px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; height: 23px; width: 80px;'], A#logo, A#glogo, BODY.answer_page TABLE.header_table > TBODY > TR > TD.header_logo_td, CENTER > H1#ps-logo, BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > CENTER > TABLE > TBODY TR > TD[align='left'] > TABLE > TBODY > TR > TD[valign='top'] > DIV, BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[valign='top'] > DIV, BODY > TABLE[width='100%'][cellspacing='2'][cellpadding='0'][border='0'][style='margin-top: 1em;'] > TBODY > TR > TD[width='1%'], BODY > DIV#wrapper > DIV#header_logo, BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#browse-header > TABLE > TBODY > TR:first-child > TD:first-child, BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#search-header, BODY.sp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#browse-header > TABLE > TBODY > TR:first-child > TD:first-child, BODY > CENTER > DIV#videoheader > TABLE.table-header > TBODY > TR > TD.td-logo, BODY#search-results-body > DIV#videoheader > TABLE.table-header > TBODY > TR > TD.td-logo, BODY > DIV > DIV#videoheader > TABLE > TBODY > TR > TD:first-child, BODY > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#page-header > TABLE > TBODY > TR > TD:first-child, BODY > FORM[name='f'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'][style='clear: left;'] > TBODY > TR > TD:first-child, BODY > DIV#whole > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD, BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD, DIV[style='background: transparent url(/intl/en_com/images/logo_plain.png) no-repeat scroll 0% 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; height: 110px; width: 276px;'], BODY > FORM > TABLE#sft > TBODY > TR > TD.tc, BODY > DIV[style='clear: both;'] > CENTER > TABLE[cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[style='padding-bottom: 8px; padding-top: 2px;'], BODY > DIV#top_search_bar > DIV[style='padding: 1px 10px 0px 6px; float: left;'], BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='clear: both;'] > TBODY > TR > TD[valign='top'][rowspan='2'], BODY#search-results-body > DIV#videoheader > TABLE.table-header > TBODY > TR > TD:first-child, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section > DIV.g-unit > DIV.sfe-logo > A > DIV.SP_logo, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section > DIV.g-unit > DIV.sfe-logo > A > DIV.SP_logo, BODY > DIV.g-doc > DIV.g-section > DIV.g-unit > DIV.sfe-logo > A > DIV.SP_logo, BODY DIV.g-doc DIV.g-section > DIV.g-unit > DIV.sfe-logo, BODY > DIV#hp-cont > H1#hp-logo, BODY > FORM > DIV#advd-search-header > TABLE:first-child > TBODY > TR > TD[width='1%']:first-child, BODY > SPAN#main > DIV#header > DIV#sform > FORM#tsf > TABLE#sft > TBODY > TR > TD:first-child > H1, BODY[vlink='#551a8b'] > CENTER > TABLE[cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR:first-child > TD:first-child, BODY > FORM[name='f'] > TABLE[width='99%'] > TBODY > TR:first-child > TD[width='1%'], BODY > DIV > TABLE#srch_box_t > TBODY > TR > TD:first-child, BODY[bgcolor='#ffffff'] > TABLE[width='100%'] > TBODY > TR:first-child > TD[width='143']:first-child, BODY > TABLE[style='margin: 7px 3px; clear: both;'] > TBODY > TR:first-child > TD:first-child, BODY > DIV#srp-header > FORM[name='f'] > TABLE > TBODY > TR > TD:first-child, BODY > TABLE#sft > TBODY > TR > TD.tc, BODY[bgcolor='#ffffff'] > TABLE > TBODY > TR > TD[valign='top'][rowspan='2'], BODY > DIV#h > TABLE:first-child > TBODY > TR > TD:first-child, BODY > DIV#headerdiv > TABLE[width='100%']:first-child > TBODY > TR:first-child > TD[width='1%'][valign='top'], BODY > DIV#masthead > TABLE.searchbar > TBODY > TR#logo-section > TD.searchbar-logo, BODY > DIV[style='clear: both;'] > CENTER > TABLE[cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[style='padding-bottom: 8px; padding-top: 2px;'], BODY.e > DIV.h TABLE#gn_ph > TBODY > TR:first-child > TD[align='right']:first-child, BODY > SPAN#main > CENTER > SPAN#body > CENTER > DIV#logo, BODY > FORM[name='gs'] > TABLE#scife_hdr > TBODY > TR:first-child > TD[valign='top']:first-child, BODY > DIV#whole > DIV[style='margin: 10px 0pt 5px;'], BODY[marginheight='3'][topmargin='3'] > DIV[style='margin: 10px 0pt 5px;']   {width:150px !important; height:55px !important; background:transparent url('" +
        googleLogoBLACK +
        "') no-repeat scroll 0% !important; font-size:0;}" +
        /* intl home logoHeight o.r. */
        "BODY > SPAN#main > CENTER > SPAN#body > CENTER > DIV#logo   {height:110px !important;}" +
        
        /* CONDITIONAL-EVALUATION related to Homepage Special Logo [exception for g.Images-homepage] */
        (((getEl('logo') && getEl('logo').alt == 'Google') || location.href.indexOf('images.google.') > -1) ?        /* insert logo img */
        "BODY[vlink='#551a8b'] > DIV#xjsd, BODY > SPAN#main > CENTER > DIV#xjsd   {width:150px !important; height:55px !important; background:transparent url('" + googleLogoBLACK + "') no-repeat scroll 0% !important; font-size:0;}" +
        /* intl logo mover */
        "BODY[vlink='#551a8b'] > DIV#xjsd, BODY > SPAN#main > CENTER > DIV#xjsd   {position:absolute; top:100px; left:0; width:100% !important; background-position:center !important;}" : "") +
        ((getEl('logo') && getEl('logo').alt != 'Google' && location.href.indexOf('images.google.') == -1) ? "" :        /* large logo hide */
        "BODY > CENTER IMG[onload='window.lol&&lol()']#logo, BODY > CENTER DIV[onload='window.lol&&lol()']#logo, BODY > SPAN#main > CENTER > SPAN#body > CENTER > IMG#logo, BODY > SPAN#main > CENTER > SPAN#body > CENTER DIV#logo   {visibility:hidden; min-height:110px;}") +
        
        /* search input */
        "INPUT[type='text'], INPUT[type='password'], INPUT[name='q']   {background:#333 none !important; color:#fff; padding:2px; border:solid 1px #ccc; font-weight:bold; color:#ff0 !important;}" +
        /* submit btns */
        "INPUT[type='submit'], INPUT[value='Cancel'], INPUT[value='Save'], BUTTON, INPUT#stxemailsend, INPUT[value='Discard'], BUTTON[type='submit'], INPUT[value='Download'], INPUT[value='Add it now']   {background-color:#333; border:solid 1px #ccc; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#fff !important; cursor:pointer;}" +
        /* submit btn hover */
        "INPUT[type='submit']:hover, BUTTON[type='submit']:hover   {background-color:#36f; color:#fff;}" +
        /* div btn outer */
        ".goog-button-base-outer-box   {border-top-color:#555; border-bottom-color:#333;}" +
        /* div btn inner */
        ".goog-button-base-inner-box   {border-left-color:#555; border-right-color:#333; background-color:#555;}" +
        /* div btn inner txt */
        ".goog-button-base-content   {color:#bbb !important;}" +
        /* div btn inner txtH */
        ".goog-button-base-content:hover   {color:#fff !important;}" +
        /* div btn T-shadow */
        ".goog-button-base-top-shadow   {background-color:#777; border-bottom-color:#555;}" +
        /* div btn restrict */
        "#search-restrict   {border-bottom-color:#000;}" +
        /* menu dropd folder */
        "DIV.goog-menu > DIV.goog-menuitem > DIV.goog-menuitem-content   {color:#ccc !important;}" +
        /* menu dropd item */
        "DIV.goog-menu > DIV.goog-menuitem   {background-color:#222; color:#999 !important;}" +
        /* menu dropd itemHov*/
        "DIV.goog-menu > DIV.goog-menuitem:hover   {background-color:#333; color:#ccc !important;}" +
        /* home international txt */
        "DIV[style='background: transparent url(/intl/en_com/images/logo_plain.png) no-repeat scroll 0% 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; height: 110px; width: 276px;'] > DIV[style='color: rgb(102, 102, 102); font-size: 16px; font-weight: bold; left: 208px; position: relative; top: 78px;']   {top:-18px !important; left:180px !important; color:#fff !important;}" +
        /* more pop layer */
        "SPAN#more, #gbar .gb2   {background-color:#333 !important; border-right:solid 1px #a2bae7; border-bottom:solid 1px #a2bae7; color:#333 !important;}" +
        /* google alerts txt */
        "P[style='margin-left: 9px;'], SPAN[style='font-size: medium;']   {color:#999;}" +
        /* mainbody txt */
        "DIV.mainbody, TD.j, DIV.empty, DIV.empty DIV, BODY#gsr DIV, BODY#gsr TD   {color:#999 !important;}" +
        /* remove footers */
        "#footer, #footer_promos, #footerwrap, P FONT[size='-2'], TABLE[class='t n bt'][width='100%'][cellpadding='2'], DIV[align='center'][style='white-space: nowrap;'], FONT[class='p'][size='-1'], FONT[size='-1'][color='#6f6f6f'], DIV.div-copyright, SPAN.copyr, DIV.content DIV.footer, DIV#footarea, TABLE[width='99%'][cellpadding='3'][bgcolor='#c3d9ff'][align='center'][style='margin-bottom: 5px;'], CENTER > DIV[style='padding: 2px;'] > FONT[size='-1'], CENTER > CENTER > P > FONT[size='-1'], BODY.search > DIV[align='center'] > SMALL > FONT[size='-1'][face='Arial, sans-serif'], BODY > TABLE[width='100%'][height='100%'][style='margin-bottom: 1px;'] > TBODY > TR > TD[valign='top'] > CENTER > FONT[size='-1'], BODY > CENTER > TABLE[width='100%'][cellspacing='0'][cellpadding='2'][border='0'] *, DIV[class='padt10 padb10'] > TABLE[width='100%'] > TBODY > TR > TD[class='fontsize1 padt5'][align='center'], BODY[marginheight='3'][bgcolor='#ffffff'][dir='ltr'][topmargin='3'] > CENTER > FONT[size='-1'], BODY > DIV[style='width: 100%; clear: both;'] > FORM[name='langform'] > DIV[align='center'] > FONT[size='-1']   {display:none;}" +
        
        // Preferences
        /* pre title line */
        "BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM > TABLE TBODY TR TD[bgcolor='#3366cc'], BODY> DIV[style='width: 100%; clear: both;'] > FORM > TABLE TBODY TR TD[bgcolor='#3366cc']   {display:none;}" +
        /* title header txt */
        "BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM > TABLE TBODY TR TD[bgcolor='#e5ecf9'] FONT B   {color:#999 !important;}" +
        /* headers */
        "BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM > TABLE TBODY TR TD[bgcolor='#e5ecf9'], TABLE TBODY TR[bgcolor='#e5ecf9'], TABLE > TBODY > TR > TD[bgcolor='#e5ecf9']   {background-color:#000;}" +
        /* global borders */
        "BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM > TABLE > TBODY > TR > TD[bgcolor='#cbdced']   {display:none;}" +
        /* page txt */
        "BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM H1, BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM H2, BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM LABEL, TABLE#gsea_table > TBODY > TR > TD DIV   {color:#ccc !important;}" +
        /* subscribed links */
        "BODY[vlink='#551a8b'][text='#000000'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > DIV[style='width: 100%; clear: both;'] > FORM > TABLE > TBODY > TR > TD[valign='top'] > IFRAME[src='http://www.google.com/coop/sl/pref']   {padding-left:9px; background-color:#fff; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        
        
        // iGoogle Homepage enhancements
        /* header */
        "#guser, #guser *, #gbar, #gbar *   {background-color:transparent !important; font-family:Trebuchet MS, Verdna !important; color:#ccc;}" +
        /* header Themed BG */
        "#nhdrwrap   {background-color:transparent;}" +
        /* search btn spacing */
        ".gseain INPUT[type='submit'], INPUT[name='btnG'], INPUT[name='btnI']   {margin-top:5px; margin-right:30px; margin-left:30px;}" +
        /* go btns hover */
        "INPUT#btnI:hover, INPUT[name='btnI']:hover, INPUT[value='Save']:hover, SPAN#button_0 BUTTON:hover, INPUT#stxemailsend:hover, INPUT[value='Submit Issue']:hover, INPUT[value='Download']:hover, INPUT[value='Add it now']:hover, INPUT[value='Add it now'], INPUT[value='Save Preferences']:hover, INPUT[value='Save Preferences ']:hover   {background-color:#090; color:#fff;}" +
        /* setup block */
        "DIV.setup_div   {background-color:#333; border:solid 1px #ccc; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* setup title txt */
        "DIV.setup_title_welcome, DIV.setup_promo, DIV.setup_promo_subtext, DIV#promo   {color:#999 !important;}" +
        /* create cntnr */
        "FORM#_setup > DIV#box   {border:0 none;}" +
        /* create heading */
        "FORM#_setup > DIV#box > DIV#box_heading   {background-color:#222; color:#fff !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* create body */
        "FORM#_setup > DIV#box > DIV#box_body   {background-color:#333; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* create body txt */
        "FORM#_setup > DIV#box > DIV#box_body DIV, FORM#_setup > DIV#box > DIV#box_body TD   {color:#ccc !important;}" +
        /* nav top gradient 1 */
        "#nhdrwrapinner > .gradient > B   {background-color:#171717 !important;}" +
        /* nav top gradient 2 */
        "#nhdrwrapinner > .gradient > B > B   {background-color:#252525 !important;}" +
        /* nav top gradient 3 */
        "#nhdrwrapinner > .gradient > B > B > B   {background-color:#333 !important;}" +
        /* nav container */
        "TABLE > TBODY > TR > TD#col1   {width:134px; background-color:#333; border-color:#333;}" +
        /* nav bg */
        "#full_nav   {background-color:#333;}" +
        /* nav tab color */
        "#full_nav H2   {color:#6495ed;}" +
        /* nav separators */
        "#full_nav .topline, #full_nav .bottomline   {visibility:hidden;}" +
        /* nav first tab */
        "#full_nav #section0_contents.selected_section_contents   {margin-top:20px;}" +
        /* nav selected tab */
        "#full_nav .leftselectedtab   {background-color:#000; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* nav non selected tab */
        "#full_nav .leftunselectedtab   {background-color:#333;}" +
        /* nav non selected tab */
        "#full_nav .leftselectedtab, #full_nav .leftunselectedtab, #full_nav .bottom_nav, #col1_contents .leftborder   {border:0 none;}" +
        /* nav chat separator */
        "DIV#chat_nav > DIV#tab_separator_bot   {visibility:hidden;}" +
        /* remove nav selection rnds */
        "#full_nav B[class='rnd_tab left_rounded_only']   {visibility:hidden;}" +
        /* alert / promo box */
        "DIV#undel_box, .header_promo   {background-color:#333; border:1px solid #ff0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#ff0 !important;}" +
        /* alert / promo box link */
        "DIV#undel_box A, .header_promo A   {color:#f00 !important;}" +
        /* skins box title */
        "H2.modtitle_s   {background-color:#feffc5; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* skins box title txt */
        "H2.modtitle_s B   {color:#000 !important;}" +
        /* skins box body */
        "DIV#skinbox_b   {background-color:#000; border:solid 1px #feffc5 !important;}" +
        /* skins box themes */
        "DIV.skinthsel B, DIV.skinth B   {color:#000 !important;}" +
        /* dialog box */
        "DIV#IG_PU_box > TABLE.dialog TBODY TR TD DIV   {background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;;}" +
        /* dialog box txt */
        "LABEL[for='share_userprefs'], TABLE#email TBODY TR TD, TABLE#email TBODY TR TD DIV   {color:#999 !important;}" +
        /* dialog box btns */
        "DIV#IG_PU_box > TABLE.dialog TBODY TR TD DIV#buttons   {padding-bottom:10px;}" +
        /* add tab dialog */
        "BODY.mozilla> DIV#IG_PU_box TABLE.dialog TBODY TR TD DIV.outerborder DIV   {color:#999 !important;}" +
        /* new tab txt */
        "#modules > TABLE[width='98%'][cellspacing='10'][align='center'] > TBODY > TR > TD > DIV[align='center'][style='padding-bottom: 100px;']   {color:#999 !important;}" +
        /* module border */
        ".modbox, .modbox_e   {background-color:#000; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* module bg */
        ".modboxin, .modboxin IFRAME HTML BODY   {background-color:#fff !important;}" +
        /* module border */
        ".modboxin, .modboxin_s, .modtitle   {border:0 none !important;}" +
        /* module area container */
        "TABLE > TBODY > TR > TD#col2   {background-color:#333; border:0 none;}" +
        /* module area header rndng */
        "TABLE > TBODY > TR > TD#col2 > #rcbg   {display:none;}" +
        /* module area bg */
        "#modules   {background-color:#000; -moz-border-radius-topleft:20px;}" +
        /* module area btm spacing */
        "#modules > .yui-b   {margin-bottom:-0.3em; padding-top:0.2em;}" +
        /* module title rndng */
        "B.rnd_modtitle   {display:none;}" +
        /* module title bg */
        ".modtitle   {-moz-border-radius-topleft:14px; -moz-border-radius-topright:14px; background-color:#333 !important;}" +
        /* module title txt */
        ".modtitle_text,.mtlink   {position:relative; top:1px; left:1px; color:#999 !important;}" +
        /* module options buttons */
        ".modtitle .v2enlargebox, .modtitle .v2ddbox, .modtitle .v2dragbox   {position:relative; top:2px; right:3px;}" +
        /* module settings line */
        "DIV.meditbox   {margin-top:0; border:0;}" +
        /* module settings txt */
        "DIV.meditbox DIV, DIV.meditbox TD, DIV.meditbox SPAN, DIV.meditbox NOBR   {color:#999 !important;}" +
        /* module inner detail txt */
        ".modboxin FONT   {color:#000 !important;}" +
        /* cancel btn hover */
        "INPUT[value='Cancel']:hover, SPAN#button_1 BUTTON:hover, INPUT[value='Discard']:hover, INPUT[value='Delete Group']:hover   {background-color:#990000 !important; color:#fff !important;}" +
        
        // Theme Selection Box
        /* outer box & hdr */
        "DIV#indi, DIV#indi_top   {border:0 none; background-color:#333; color:#999 !important;}" +
        /* headline & selctn */
        "DIV#indi H1, DIV#indi DIV SPAN.indi_current_item   {color:#fff !important;}" +
        /* inner desc txt */
        "DIV#indi DIV SPAN   {color:#777 !important;}" +
        /* inner txt */
        "DIV#indi DIV   {color:#ccc !important;}" +
        /* theme select indc */
        "DIV#indi DIV DIV.indi_undo   {background-color:#333 !important; border:0 none !important; color:#ffaa1c !important; -moz-border-radius-topright:8px; -moz-border-radius-topleft:8px; -moz-border-radius-bottomright:8px; -moz-border-radius-bottomleft:8px;}" +
        
        // Module-specific Requests
        /* gmail */
        "HTML > BODY > DIV > #modules A B   {color:#36a !important;}" +
        /* youtube video */
        "HTML > BODY > DIV > DIV#middle, HTML > BODY > DIV > DIV#uppernav, HTML > BODY > DIV > DIV#searchFooter   {background-color:#fff;}" +
        /* confucius quotes */
        "DIV#modules DIV#remote_56 > IFRAME#remote_iframe_56   {overflow:hidden !important; height:11.6em !important;}" +
        /* quotes of the day */
        "DIV.modboxin > DIV[style='padding-top: 4px; padding-bottom: 4px;']   {color:#000;}" +
        /* weather */
        "DIV#modules DIV.w_box, DIV#modules DIV.w_box DIV   {height:8em; overflow:visible; font-size:11px;}" +
        
        // Add Stuff / Themes Directory
        /* logo img */
        "BODY > DIV#wrapper > DIV#header_logo > A > IMG.backlink_logo, TD[width='1%'] > A > IMG[src='http://img0.gmodules.com/ig/images/igoogle_logo_sm.gif']   {display:none;}" +
        /* header tabs */
        "BODY > DIV#wrapper > DIV#header > UL.header_tab   {margin-left:170px; border:0 none; background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header selectdTab */
        "BODY > DIV#wrapper > DIV#header > UL.header_tab > LI.selected, BODY > DIV#wrapper > DIV#header > UL.header_tab > LI.selected > A   {border:0 none; background-color:#333; font-weight:bold; text-decoration:none; color:#fff !important;}" +
        /* body txt */
        "BODY > DIV#wrapper *   {color:#ccc;}" +
        /* body header */
        "BODY > DIV#wrapper > DIV.page_table > DIV.main_content > TABLE[width='99%'][cellspacing='0'] TD, DIV.main_content > DIV#promo > TABLE[width='99%'] > TBODY > TR > TD   {background:none #000 !important; color:#999 !important;}" +
        /* body header line */
        "BODY > DIV#wrapper > DIV.page_table > DIV.main_content > TABLE[width='99%'][cellspacing='0']   {border-bottom:6px solid #333;}" +
        /* r-module top */
        "BODY > DIV#wrapper > DIV.page_table > DIV.right_sidebar .module > H3, BODY > DIV#wrapper > DIV#sidebar > DIV.module > H3   {background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; color:#ccc !important;}" +
        /* r-module bottom */
        "BODY > DIV#wrapper > DIV.page_table > DIV.right_sidebar .module, BODY > DIV#wrapper > DIV#sidebar DIV.module   {min-height:34px; padding-bottom:5px; background-color:#333; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#000 !important;}" +
        /* r-module feat */
        "BODY > DIV#wrapper > DIV#sidebar DIV#featured.module   {padding:0 7px 7px 7px;}" +
        /* makeyourown head */
        "BODY > DIV#gm_blue_bar > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD > DIV#bluebar   {background-color:#333; border:0 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* makeyourown title */
        "BODY > CENTER > DIV#gm_sign_in > TABLE > TBODY > TR > TD#gm_sign_in_steps > DIV:first-child, BODY > CENTER > DIV#gm_desc   {color:#fff !important;}" +
        /* makeyourown txt */
        "BODY > CENTER > DIV#gm_sign_in > TABLE > TBODY > TR > TD#gm_sign_in_steps > DIV, BODY > CENTER > DIV#gm_sign_in > TABLE > TBODY > TR > TD#gm_sign_in_steps > DIV.gm_step, BODY > CENTER > DIV#gm_choices DIV, BODY > CENTER > DIV#gm_wizard DIV, BODY > CENTER > DIV#gm_wizard TD, BODY > CENTER > DIV#gm_send DIV, BODY > CENTER > DIV#gm_publish TD, BODY > CENTER > DIV#gm_publish DIV    {color:#999 !important;}" +
        /* makeyourown num */
        "BODY > CENTER > DIV#gm_sign_in > TABLE > TBODY > TR > TD#gm_sign_in_steps > DIV.gm_step > SPAN.gm_num   {background:none #333; color:#fff;}" +
        /* makeyourown start */
        "BODY > CENTER > DIV#gm_sign_in > TABLE > TBODY > TR > TD > DIV#gm_sign_in_box   {background-color:#333 !important; border:0 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        
        
        // Google Search Results Page enhancements
        /* logo */
        "BODY#gsr > DIV#header > FORM#tsf > TABLE#sft > TBODY > TR > TD > H1 > A#logo > IMG, BODY > SPAN#main > DIV#header > DIV#sform > FORM#tsf > TABLE#sft > TBODY > TR > TD:first-child > H1 > A#logo > IMG, BODY > SPAN#main > DIV DIV#sform > FORM#tsf > TABLE#sft > TBODY > TR[valign='top'] > TD[style='padding-right: 8px;'] > H1 > A#logo > IMG, BODY#gsr > DIV#cnt > FORM#tsf > TABLE#sft > TBODY > TR[valign='top']:first-child > TD:first-child > H1 > A#logo > IMG, BODY > SPAN#main > DIV >  DIV#cnt > DIV#sform > FORM#tsf > TABLE#sft > TBODY > TR[valign='top']:first-child > TD:first-child > H1 > A#logo > IMG   {display:none;}" +
        /* search container */
        "BODY#gsr > DIV#header > FORM#tsf > TABLE#sft > TBODY > TR > TD#sff > TABLE.ts, BODY#gsr > DIV#header > FORM#tsf > TABLE#sft > TBODY > TR > TD#sff > TABLE.ts > TBODY > TR > TD:first-child, BODY#gsr > DIV#header > FORM#tsf > TABLE#sft > TBODY > TR > TD#sff > TABLE.ts > TBODY > TR > TD > INPUT[name='q']   {width:80%;}" +
        /* search suggest bg */
        ".gac_m, .gac_m *, .google-ac-a, .google-ac-a *   {background-color:#222 !important; color:#999 !important;}" +
        /* search suggest hover */
        ".gac_b .gac_c, .gac_b .gac_c *, .google-ac-b, .google-ac-b *, .google-ac-e, .google-ac-e *   {background-color:#444 !important; color:#fff !important;}" +
        /* search within logo */
        "TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > A > IMG[width='200'][height='78'][alt='Google'], A#logo IMG[src='/images/experimental_sm.gif'], A#logo > IMG[width='150'][height='105'], A#logo > IMG[src='/images/nav_logo4.png']   {display:none;}" +
        /* search within txt */
        "TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > CENTER > FONT > b   {position:relative; top:68px;}" +
        /* search header bar */
        "TABLE[class='t bt'], DIV#ssb   {padding-right:0.4em; padding-left:0.7em; background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header bar experiment dd */
        "DIV#cnt > DIV.std > SPAN   {background-color:#000 !important;}" +
        /* search header bar */
        "TABLE[class='ft t bb bt']   {border:0; border-top:1px}" +
        /* outer result cntnr */
        "BODY#gsr > DIV#cnt   {max-width:100%;}" +
        /* result-area width [DYNMC] */
        "DIV#res   {width:" +
        resW +
        "% !important;}" +
        /* remove sponsored linx */
        "DIV#tads   {display:none;}" +
        /* refine results txt */
        "TABLE#po TBODY TR TD, TD#sff > DIV#bsb   {color:#999 !important;}" +
        /* sponsored linx */
        "DIV#res DIV.ta, BODY#gsr > TABLE#mbEnd   {display:none;}" +
        /* result-area txt */
        "DIV#res P, DIV#res .j, DIV.sml, DIV.std, DIV#res OL LI, DIV#res OL LI DIV ,BODY > SPAN#main > DIV#cnt > DIV#res > SPAN#topstuff > DIV.e > DIV.std TD   {color:#999 !important;}" +
        /* description width */
        "TD.j, OL > LI.g > DIV.s   {width:100% !important; max-width:100% !important;}" +
        /* description color */
        "FONT   {color:#999;}" +
        /* result spacing */
        ".g   {margin:0.5em 0; padding-bottom:1em; border-bottom:1px dotted #222;}" +
        /* bottom related txt */
        ".r, BODY > SPAN#main DIV#cnt > DIV#res > SPAN#botstuff > DIV.e > TABLE#brs > CAPTION   {color:#aaa;}" +
        /* bottom related selection */
        "TABLE#brs.ts > TBODY > TR > TD > A > B   {color:#aaa !important;}" +
        /* nav bar */
        "#navbar   {position:relative; left:33%; width:400px;}" +
        /* options L-sidebar cntnr */
        "DIV#tbd.med   {background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* options L-sidebar title */
        "DIV#tbd.med DIV.tbos   {color:#fff !important;}" +
        /* r-side ads */
        "#rhscol, #mbEnd   {display:none;}" +
        /* footer logo(s) */
        "#navbar DIV,#navbar IMG, TABLE#nav SPAN#nf, TABLE#nav SPAN#nc, TABLE#nav SPAN.nr, TABLE#nav SPAN#nn, DIV#np, TABLE#nav > TBODY > TR[valign='top'] > TD.b > SPAN, TABLE#nav > TBODY > TR[valign='top'] > TD.cur > SPAN, TABLE#nav > TBODY > TR[valign='top'] > TD > A > SPAN.csb   {height:0px; background:none;}" +
        /* footer bg */
        "TABLE[class='ft t bb bt'], DIV.clr > DIV#bsf, DIV.clr > P.blk, BODY#gsr > DIV > DIV#bsf   {background-color:#000 !important; border-top:0 none; border-bottom:0 none;}" +
        
        // Advanced Search
        /* header bar line */
        "BODY > TABLE[width='100%'][cellspacing='2'][cellpadding='0'][border='0'][style='margin-top: 1em;'] > TBODY > TR > TD > TABLE[width='100%'][style='border-top: 1px solid rgb(51, 102, 204);']   {border-top:0 none !important;}" +
        /* header bar L */
        "BODY > TABLE[width='100%'][cellspacing='2'][cellpadding='0'][border='0'][style='margin-top: 1em;'] > TBODY > TR > TD > TABLE[width='100%'][style='border-top: 1px solid rgb(51, 102, 204);'] > TBODY > TR > TD.page-title   {background-color:#333; border:0; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header bar R */
        "TABLE[width='100%'][cellspacing='2'][cellpadding='0'][border='0'][style='margin-top: 1em;'] > TBODY > TR > TD > TABLE[width='100%'][style='border-top: 1px solid rgb(51, 102, 204);'] > TBODY > TR > TD[bgcolor='#d5ddf3'][align='right']   {background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-bottomright:14px;}" +
        /* title top */
        "BODY > TABLE[width='100%'][cellspacing='0'][cellpadding='0'] > TBODY > TR > TD[align='center'] > TABLE[cellspacing='0'][cellpadding='0'][style='margin-top: 1em; width: 80%;'] > TBODY > TR > TD[align='left'] > DIV.outer-box > DIV.qbuilder-env, BODY > TABLE[width='100%'][cellspacing='0'][cellpadding='0'] > TBODY > TR > TD[align='center'] > TABLE[cellspacing='0'][cellpadding='0'][style='margin-top: 1em; width: 80%;'] > TBODY > TR > TD[align='left'] > DIV.outer-box > DIV.qbuilder-env *   {border-color:#333; background-color:#000 !important; font-weight:bold; color:#fff !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* lower form */
        "BODY > TABLE[width='100%'][cellspacing='0'][cellpadding='0'] > TBODY > TR > TD[align='center'] > TABLE[cellspacing='0'][cellpadding='0'][style='margin-top: 1em; width: 80%;'] > TBODY > TR > TD[align='left'] > DIV.outer-box > FORM[name='f'].block   {border-color:#333; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* related box */
        "BODY > TABLE[width='100%'][cellspacing='0'][cellpadding='0'] > TBODY > TR > TD[align='center'] > TABLE[cellspacing='0'][cellpadding='0'][style='width: 80%;'] > TBODY > TR > TD[align='left'] > DIV#related.block   {border-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* form & page txt */
        "DIV.outer-box > FORM.block H3, DIV.outer-box > FORM.block LABEL, DIV.spec-engines > H3   {color:#999;}" +
        /* footer */
        "BODY > CENTER:last-child > FONT[size='-1'], BODY > CENTER:nth-last-child(2) > FONT[size='-1']   {display:none;}" +
        
        // Quality Form
        /* header bar */
        "BODY[marginheight='3'][bgcolor='#ffffff'][topmargin='3'] > FORM > TABLE[width='100%'][cellpadding='2'] > TBODY > TR > TD[class='t bt']   {padding-left:10px; background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* form box bg */
        "BODY[marginheight='3'][bgcolor='#ffffff'][topmargin='3'] > FORM > BLOCKQUOTE > P > TABLE[cellpadding='10'][bgcolor='#cbdced']   {background-color:#000 !important;}" +
        /* bottom line */
        "BODY[marginheight='3'][bgcolor='#ffffff'][topmargin='3'] > CENTER > DIV[class='t n bt'][style='padding: 2px;']   {display:none;}" +
        
        // Language Tools
        /* top line */
        "BODY[vlink='#551a8b'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'][onload='ht();'] TABLE.header TD, BODY[vlink='#551a8b'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > TABLE > TBODY > TR > TD > TABLE.header > TBODY > TR > TD[bgcolor='#e5ecf9']   {border-top:0 none;}" +
        /* header bars */
        "BODY[vlink='#551a8b'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'][onload='ht();'] H4, BODY[vlink='#551a8b'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] H4   {background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* search across box */
        "BODY[vlink='#551a8b'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'][onload='ht();'] > TABLE[width='100%'][cellpadding='3'] > TBODY > TR[bgcolor='#ffffff'] > TD, BODY[vlink='#551a8b'][link='#0000cc'][bgcolor='#ffffff'][alink='#ff0000'] > TABLE[width='100%'][cellpadding='3'] > TBODY > TR[bgcolor='#ffffff'] > TD   {background-color:#000;}" +
        
        // Search Within expanded below in brute force enhancements
        
        // Feedback
        /* header bar */
        "BODY > FORM > TABLE.qftbb > TBODY > TR > TD   {background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* form txt */
        "BODY > FORM > TABLE.ts > TBODY > TR > TD > TABLE.qflhs > TBODY > TR > TD   {color:#ccc !important;}" +
        /* answers box */
        " BODY > FORM > TABLE.ts > TBODY > TR > TD > TABLE.qfrhs   {background-color:#555; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        
        // Help Central
        /* logo img */
        "BODY.search > TABLE[width='95%'] > TBODY > tr[valign='top'] > TD[width='1%'] > A > IMG[width='143'][vspace='10'][height='59'][align='left']   {visibility:hidden;}" +
        /* header bg */
        "BODY.search > TABLE[width='95%'] > TBODY > tr[valign='top'] > TD[width='99%'][valign='top'][bgcolor='#ffffff'], BODY.search > TABLE[width='95%'] > TBODY > tr[valign='top'] > TD[width='99%'][valign='top'][bgcolor='#ffffff'] > TABLE > TBODY > TR   {background-color:#000;}" +
        
        
        // Custom Seach iFrame-edition
        /* iframe bgs */
        "BODY[marginheight='2'][text='#000000'], BODY[marginheight='2'][text='#000000'] TABLE[width='1%']   {background-color:inherit !important;}" +
        /* iframe txt & linx */
        "BODY[marginheight='2'][text='#000000'] A, BODY[marginheight='2'][text='#000000'] A B, BODY[marginheight='2'][text='#000000'] B   {color:inherit !important;}" +
        
        
        // Images Results enhancements
        /* logo img */
        "BODY > FORM[name='gs'] > TABLE#sft > TBODY > TR > TD.tc > A > IMG   {visibility:hidden; width:150px;}" +
        /* options L-sidebar */
        "DIV#rpsp.rpop   {margin-left:10px; padding-top:7px !important; padding-left:2px !important; background-color:#181818; border:0 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* options L-sidebar txt */
        "DIV#rpsp.rpop DIV   {color:#fff;}" +
        /* safe search block */
        "DIV#ss-bar   {position:inherit !important;}" +
        /* safe search txt */
        "DIV#ss-bar DIV   {color:#777 !important;}" +
        /* safe search dropdown */
        "DIV#ss-bar DIV#ss-box   {background-color:#222; color:#fff;}" +
        /* safe search dd link */
        "DIV#ss-bar DIV#ss-box > A *   {display:inline; margin:0;}" +
        /* safe search link selected */
        "DIV#ss-bar DIV#ss-box A.ss-selected   {color:#fff !important;}" +
        /* safe search dd hover */
        "DIV#ss-bar DIV#ss-box > A:hover   {color:#fff !important;}" +
        /* safe search dd selected */
        "DIV#ss-bar DIV#ss-box > A.ss-selected, BODY > FORM > TABLE#sft > TBODY > TR > TD > TABLE.tb > TBODY > TR > TD.tc > FONT > DIV#ss-bar > DIV#ss-box > A.ss-selected > SPAN:nth-child(2)   {background-color:#444; color:#fff !important;}" +
        /* sizes alert */
        "DIV[style='padding: 16px 0pt;'] CENTER SPAN[style='padding: 4px; background-color: rgb(255, 255, 153);'], BODY > DIV#ImgCont > DIV#rstc > CENTER > SPAN   {padding:2px 7px 2px 7px !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* sizes alert txt */
        "DIV[style='padding: 16px 0pt;'] CENTER SPAN[style='padding: 4px; background-color: rgb(255, 255, 153);'] FONT, BODY > DIV#ImgCont > DIV#rstc > CENTER > SPAN > FONT   {color:#777;}" +
        /* sizes alert highlight */
        "DIV[style='padding: 16px 0pt;'] CENTER SPAN[style='padding: 4px; background-color: rgb(255, 255, 153);'] FONT B, BODY > DIV#ImgCont > DIV#rstc > CENTER > SPAN > FONT > B   {color:#000 !important;}" +
        /* ad bar */
        "DIV#ImgCont > TABLE[width='100%'][style='padding: 8px; background: rgb(255, 248, 221) none repeat scroll 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; margin-top: 10px;']   {display:none;}" +
        /* img size txt */
        "DIV.std > .f, DIV.std > .m   {color:#999 !important;}" +
        /* img source txt */
        "DIV.std > .a   {color:#090 !important;}" +
        /* g.image labeler */
        "CENTER TABLE[cellpadding='10'][style='text-align: center;'] TBODY TR TD   {background-color:#000;}" +
        /* Advanced Image Search expanded below in brute force enhancements */
        
        
        // Video Results enhancements
        /* logo img */
        "A#logoimg IMG, BODY > DIV#headerdiv > TABLE[width='100%']:first-child > TBODY > TR:first-child > TD[width='1%'][valign='top'] > A > IMG[height='40']   {display:none;}" +
        /* logo container */
        "TD.td-logo   {height:65px; background:transparent url('" +
        googleLogoBLACK +
        "') no-repeat scroll 0% !important;}" +
        /* header/footer bgs */
        "#videoheader, BODY#search-results-body DIV.div-footer   {background-color:#000 !important;}" +
        /* body txt */
        "#main-container DIV, #slideout-player DIV   {color:#999 !important;}" +
        /* filter option txt */
        "TD[style='padding: 0pt;'] SPAN.filter-prefix, TD[style='padding: 0pt;'] LABEL.filter-option   {color:#999;}" +
        /* section header bg */
        "BODY > DIV#headerdiv > TABLE > TBODY > TR > TD > TABLE > TBODY > TR[bgcolor='#ebeff9']   {background-color:#000;}" +
        /* section header */
        "DIV.div-section-header, BODY > DIV#hotstuff > DIV.hot_videos_container > TABLE.hot_videos_title_bar, DIV.container DIV.mod_titlebar, DIV.container DIV.mod-header, BODY > DIV#headerdiv > TABLE > TBODY > TR > TD > TABLE > TBODY > TR[bgcolor='#ebeff9'] > TD[style='border-width: 1px 0pt 0pt; border-top: 1px solid rgb(107, 144, 218); padding-left: 4px; padding-bottom: 3px; padding-top: 2px; font-family: arial,sans-serif;']   {padding:0.1em 0 0.2em 0.4em !important; background-color:#333; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* section borders */
        "BODY > DIV#hotstuff > DIV.hot_videos_container > TABLE.hot_videos_body > TBODY > TR > TD.embedded_player_container, BODY > CENTER > DIV.container > DIV > DIV.mod_content   {border:0 none;}" +
        /* section header txt */
        "TD.td-section-header-left B   {color:#000 !important;}" +
        /* home video time */
        "DIV.div-video-text   {color:#090 !important;}" +
        /* search type */
        "TABLE.table-header TABLE[bgcolor='white'], DIV.menu-normalsb   {border:0; background-color:#000;}" +
        /* results toolbelt */
        "DIV#main-container > DIV#search-results-toolbelt   {background-color:#222; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* results toolbelt heading */
        "DIV#main-container > DIV#search-results-toolbelt .tbos   {color:#fff !important;}" +
        /* results header */
        "TABLE#resultsheadertable, DIV#results-bar   {padding-right:0.4em; padding-left:0.7em; background-color:#333 !important; border-top:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* results header title */
        "TABLE#resultsheadertable TD[valign='baseline'] B   {position:relative; top:1px; left:2px; color:#000 !important;}" +
        /* result item */
        "DIV.SearchResultItem   {width:100%; margin:2em 0pt;}" +
        /* result W */
        ".rl-res .rl-metadata   {max-width:none;}" +
        /* result item txt */
        "DIV#search-results DIV.rl-snippet   {color:#ccc !important;}" +
        /* result item domain */
        "DIV#search-results DIV.rl-domain-below   {color:green !important;}" +
        /* result selection */
        "DIV#search-results DIV.rl-highlight   {background-color:#222; border:0 none !important; color:#fff !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* result item border */
        "TD#search-results-td > DIV#search-results DIV.tv-res, TD#search-results-td > DIV#search-results DIV.rl-res   {border:0 none;}" +
        /* result item details */
        "TD.MetaData DIV.Details, DIV.rl-metadata > DIV.rl-details   {color:#999 !important;}" +
        /* result item description */
        "TD.MetaData DIV.Snippet, DIV.rl-metadata > DIV.rl-snippet, DIV.rl-metadata > DIV.rl-short-snippet   {color:#aaa !important;}" +
        /* result item uri */
        "TD.MetaData DIV.URL, DIV.rl-metadata > SPAN.rl-domain   {color:#090 !important;}" +
        /* results message */
        "TD#search-results-td > DIV#search-results > DIV.message   {color:#999 !important;}" +
        /* sidebar */
        "DIV#main-container > DIV#slideout-player   {margin-top:1em;}" +
        /* video related border */
        "BODY#search-results-body > DIV#tv-table > TABLE > TBODY > TR > TD#tv-player-td > DIV#tv-player > DIV#tv-related   {border:0 none;}" +
        /* video data */
        "BODY#search-results-body > DIV#tv-table > TABLE > TBODY > TR > TD#tv-player-td > DIV#tv-player > DIV#video-data-spacer > DIV#video-data   {background-color:#000;}" +
        /* footer nav table */
        "TABLE#pagenavigatortable   {width:400px !important;}" +
        /* footer logo(s) */
        "TABLE#pagenavigatortable TD IMG, TABLE#pagenavigatortable TD A.imglink, TABLE#pagenavigatortable TD BR, DIV#search-results > DIV#pagi > DIV > TABLE.gooooogle > TBODY > TR > TD.prev > A > DIV.nav_previous, DIV#search-results > DIV#pagi > DIV > TABLE.gooooogle > TBODY > TR > TD.prev > DIV.nav_first, DIV#search-results > DIV#pagi > DIV > TABLE.gooooogle > TBODY > TR > TD#current-page > DIV.nav_current, DIV#search-results > DIV#pagi > DIV > TABLE.gooooogle > TBODY > TR > TD.abs-page > A > DIV.nav_page, DIV#search-results > DIV#pagi > DIV > TABLE.gooooogle > TBODY > TR > TD.next > A > DIV.nav_next   {display:none;}" +
        /* search again */
        "DIV#searchagain   {border:0; background-color:#000;}" +
        /* advanced search bgs */
        "BODY > CENTER > FORM#as_form TABLE[style='border: 3px solid rgb(213, 221, 243);'], BODY > CENTER > FORM#as_form > TABLE[style='border: 3px solid rgb(213, 221, 243);'] > TBODY > TR[bgcolor='#d5ddf3'], BODY > DIV.div-footer, BODY > DIV.div-footer > DIV.div-footer   {border-color:#000 !important; border-width:20px !important; background-color:#000;}" +
        
        
        // News Results enhancements
        /* header Google links */
        "BODY.hp > DIV#gbar > NOBR, BODY.serp > DIV#gbar > NOBR, BODY.sp > DIV#gbar > NOBR   {position:relative; top:0.2em;}" +
        /* header iGoogle link */
        "BODY.hp > DIV#gbar > NOBR > A.gb1:last-child, BODY.serp > DIV#gbar > NOBR > A.gb1:last-child, BODY.sp > DIV#gbar > NOBR > A.gb1:last-child   {top:-1.3em !important;}" +
        /* search table */
        "TABLE[width='1%']   {position:relative; top:1px; background-color:#000; width:100% !important;}" +
        /* search form input */
        "BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#search-header > FORM.search-form > *   {float:none;}" +
        /* logo imgs */
        "IMG[src='/images/logo_sm.gif'], IMG[src='images/news.gif'], IMG[src='/images/news.gif'], IMG[width='150'][height='58'][alt='Go to Google News Home'], BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#browse-header > TABLE > TBODY > TR > TD > A > IMG[width='205'][height='85'], BODY.sp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#browse-header > TABLE > TBODY > TR > TD > A > IMG[width='205'][height='85'], BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#search-header > A > IMG[width='150'][height='58'], BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#search-header > A > IMG[width='150'][height='55'], BODY > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#page-header > TABLE > TBODY > TR > TD:first-child > A > IMG    {visibility:hidden;}" +
        /* search logo adjustment */
        "BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#search-header   {height:65px !important; background-position:0 10px !important;}" +
        /* logo img link */
        "TABLE[width='1%'] TBODY TR TD[valign='top'],TABLE[align='center'] TBODY TR TD TABLE TBODY TR TD[valign='bottom']   {height:65px; background:transparent url('" +
        googleLogoBLACK +
        "') no-repeat scroll 0% !important;}" +
        /* news sources txt */
        "BODY[marginwidth='0'][marginheight='3'][bgcolor='white'][rightmargin='0'][leftmargin='0'][topmargin='3'] > TABLE[cellspacing='0'][cellpadding='0'][border='0'][align='center'][style='clear: both;'] > TBODY > TR > TD[valign='top'][nowrap=''] > FORM[name='f'] > B > FONT[size='-1'][color='#aa0033'], BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search > DIV#browse-header > TABLE > TBODY > TR > TD > FORM.search-form > DIV.search-label   {position:relative; top:5px; font-weight:normal; font-style:italic; color:#333 !important;}" +
        /* header bars */
        "BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > DIV.main > DIV#headline-wrapper > DIV.basic-title, BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.bt-border, BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > DIV.main > DIV#headline-wrapper TD, BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search-sub-header > DIV#_h, BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > DIV.search-sub-header > DIV#_h DIV, BODY.sp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > DIV.main DIV#_h, DIV.blended-section2 > TABLE.blended-section2 > TBODY > TR > TD DIV.basic-title   {padding-right:0.4em; padding-left:0.4em; background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* top red line */
        "BODY[marginwidth='0'][marginheight='3'][bgcolor='white'][rightmargin='0'][leftmargin='0'][topmargin='3'] > TABLE#topSection > TBODY > TR > TD[valign='top'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='100%'][bgcolor='#aa0033'][colspan='2'], BODY[marginheight='2'][bgcolor='#ffffff'][topmargin='2'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='100%'][bgcolor='#aa0033'][colspan='2'], BODY[marginheight='0'][bgcolor='#ffffff'][topmargin='0'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='100%'][bgcolor='#aa0033'][colspan='2']   {display:none;}" +
        /* notify box */
        "DIV#notifybox   {color:#000; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* top stories dropdown */
        "BODY[marginwidth='0'][marginheight='3'][bgcolor='white'][rightmargin='0'][leftmargin='0'][topmargin='3'] > TABLE#topSection > TBODY > TR > TD[valign='top'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='60%'][nowrap=''][bgcolor='#efefef'][style='padding-bottom: 0pt;'] > FONT.ks > FONT[size='-1'] > SELECT[name='ned']   {height:1.7em; background-color:#333; border: 1px solid #fff;}" +
        /* top stories headlines */
        "TABLE#main-table > TBODY > TR > TD > DIV.main > DIV#headline-wrapper > DIV.blended-section2 > TABLE > TBODY > TR > TD   {background-color:#000 !important;}" +
        /* right alert box */
        "BODY[marginwidth='0'][marginheight='3'][bgcolor='white'][rightmargin='0'][leftmargin='0'][topmargin='3'] > TABLE#topSection > TBODY > TR > TD[valign='top'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'][valign='top'] > TBODY > TR > TD[width='42%'][valign='top'] > DIV#cust_result > TABLE[width='100%'][cellspacing='5'][cellpadding='4'][border='0'][bgcolor='#ffff99'][align='center'][style='border: 1px solid rgb(204, 204, 204);']   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* more pop layer */
        "SPAN#more, #gbar .gbard, #gbar .gb2   {background-color:#333 !important; border-right:solid 1px #a2bae7; border-bottom:solid 1px #a2bae7; color:#333 !important;}" +
        /* more pop layer link */
        "DIV#gbar B.gb2   {color:#fff !important;}" +
        /* top stories txt */
        "TABLE[width='100%'] .ks   {color:#999 !important;}" +
        /* left nav bg */
        ".leftnav TABLE TABLE TBODY TR TD[nowrap=''], DIV.browse-sidebar > DIV.wrapper > DIV#left-nav-sections TABLE.nav, DIV.browse-sidebar > DIV.wrapper > DIV#left-nav-sections TABLE.nav-items, DIV.browse-sidebar > DIV.wrapper > DIV#left-nav-sections > TABLE.nav-items > TBODY > TR > TD.clickable, DIV.browse-sidebar > DIV.wrapper > DIV#left-nav-sections > TABLE.nav-items > TBODY > TR.item > TD   {background-color:#000 !important;}" +
        /* left nav frontpage link */
        "DIV.sidebar > DIV.back-to-frontpage > A   {color:#6495ed !important;}" +
        /* left nav selected bg */
        "BODY > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.browse-sidebar > DIV.wrapper > DIV#left-nav-sections > TABLE.nav-items > TBODY > TR.selected > TD DIV.title   {color:#fff !important;}" +
        /* left nav spacing */
        ".leftnav TABLE TABLE TBODY TR TD[bgcolor='#ffffff']   {display:none;}" +
        /* left nav line */
        "BODY[marginwidth='0'][marginheight='3'][bgcolor='white'][rightmargin='0'][leftmargin='0'][topmargin='3'] > TABLE#topSection > TBODY > TR > TD[width='1'][height='1'][bgcolor='#cccccc']   {width:2px; background-color:#333;}" +
        /* left nav line alternate 1 */
        "BODY[marginwidth='0'][marginheight='2'][bgcolor='#ffffff'][rightmargin='0'][leftmargin='0'][topmargin='2'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD.leftnav > DIV[style='border-right: 1px solid rgb(204, 204, 204);']   {border-right:2px solid #333 !important;}" +
        /* left nav line alternate 2 */
        "BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > DIV.main > DIV#headline-wrapper, BODY.sp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > DIV.main > DIV#headline-wrapper   {border-left-color:#333;}" +
        /* left nav borders (old) */
        "BODY[marginwidth='0'][marginheight='3'][bgcolor='white'][rightmargin='0'][leftmargin='0'][topmargin='3'] > TABLE#topSection > TBODY > TR > TD.leftnav > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD > TABLE[width='100%'][cellspacing='1'][cellpadding='0'][border='0'][bgcolor='#cccccc'], BODY[marginwidth='0'][marginheight='2'][bgcolor='#ffffff'][rightmargin='0'][leftmargin='0'][topmargin='2'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD.leftnav > DIV[style='border-right: 1px solid rgb(204, 204, 204);'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD > TABLE[width='100%'][cellspacing='1'][cellpadding='0'][border='0'][bgcolor='#cccccc'], .leftnav TABLE TABLE TBODY TR TD[nowrap='']   {position:relative; right:-1px; background-color:#333 !important;}" +
        /* left nav borders */
        "DIV.browse-sidebar > DIV.wrapper > DIV#left-nav-sections > TABLE.nav-items > TBODY > TR > TD[height='2'][bgcolor='white'][colspan='2']   {background-color:#333;}" +
        /* left headline */
        "DIV.hd   {background:#333 !important; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header title bg */
        "BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.basic-title   {background-color:#333;}" +
        /* header color bars */
        "BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.ls-wrapper DIV.bar   {display:none;}" +
        /* section headers */
        "DIV#section-header, BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.ls-wrapper DIV.basic-title   {padding-left:0.7em; background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* more fewer linx (old) */
        "TABLE[bgcolor='#efefef'][style='border: 1px solid rgb(0, 0, 153);']   {background-color:#000;}" +
        /* more fewer links new */
        "BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.ls-wrapper DIV.more-link, BODY.hp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV.ls-wrapper DIV.fewer-link   {background-color:#222; -moz-border-radius-topright:8px; -moz-border-radius-topleft:8px; -moz-border-radius-bottomright:8px; -moz-border-radius-bottomleft:8px;}" +
        /* search header r1col1 */
        "TABLE[width='1%'] TBODY TR TD[valign='top'] TABLE TBODY TR TD,TABLE[width='100%'] TBODY TR TD[bgcolor='#efefef']    {background:#000 none !important;}" +
        /* search header r1col2 */
        "TABLE[width='1%'] TBODY TR TD[valign='top'] TABLE TBODY TR TD A   {position:relative; top:12px;}" +
        /* search header barL */
        "TABLE TBODY TR TD[width='60%']   {background-color:#333; border:0; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* search header barL txt*/
        "TABLE TBODY TR TD[width='60%'] FONT   {color:#000;}" +
        /* search header barR */
        "TABLE TBODY TR TD[width='40%']   {background-color:#333; border:0; -moz-border-radius-topright:14px; -moz-border-radius-bottomright:14px;}" +
        /* results top ad */
        "TABLE#main-table DIV.top-ads   {display:none;}" +
        /* results area width */
        "BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > TABLE.left > TBODY > TR > TD.search-middle   {width:100%;}" +
        /* results area R-nav */
        "BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD > TABLE.left > TBODY > TR > TD.right-nav   {display:none;}" +
        /* results nav r-side line */
        "BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD.nav > DIV.sidebar   {border-color:#333;}" +
        /* results nav headline */
        "BODY.serp > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered > TABLE#main-table > TBODY > TR > TD.nav > DIV.sidebar DIV.filter-label   {background-color:#333; padding-left:0.5em; color:#ccc !important; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* quote box */
        "DIV.qdetails DIV.qsnippet, DIV.quote-story DIV.quotesnippet   {padding-right:1.2em !important; padding-left:1.2em !important; -moz-border-radius-topright:8px; -moz-border-radius-topleft:8px; -moz-border-radius-bottomright:8px; -moz-border-radius-bottomleft:8px; text-align:justify; font-weight:bold;}" +
        /* quote arrow */
        "DIV.qdetails DIV.qarrow   {border-right-color:#000; border-left-color:#000;}" +
        /* results txt */
        "TABLE TBODY TR TD DIV[style='margin: 60px 22px;'], BODY > DIV#main-wrapper > DIV#main > DIV.background > DIV.centered DIV   {color:#999 !important;}" +
        /* result spacing */
        "DIV.mainbody TABLE TBODY TR TD[align='left'] TABLE[cellspacing='7'][cellpadding='2']   {margin:0.5em 0pt;}" +
        /* footer search borders */
        "CENTER > CENTER > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[bgcolor='#3366cc'] IMG   {display:none;}" +
        /* footer search bg */
        "CENTER > CENTER > TABLE[width='100%'][cellspacing='0'][cellpadding='3'][border='0'] > TBODY > TR > TD[bgcolor='#e5ecf9'][align='center'], BODY > DIV#main-wrapper > DIV.footer > DIV.bottom-search, BODY > DIV#main-wrapper > DIV.footer > DIV.bottom, BODY.serp > DIV#main-wrapper > DIV#pagination > TABLE > TBODY > TR > TD > A > DIV#start-prev, BODY.serp > DIV#main-wrapper > DIV#pagination > TABLE > TBODY > TR > TD > DIV#start, BODY.serp > DIV#main-wrapper > DIV#pagination > TABLE > TBODY > TR > TD > DIV#current, BODY.serp > DIV#main-wrapper > DIV#pagination > TABLE > TBODY > TR > TD > A > DIV.o, BODY.serp > DIV#main-wrapper > DIV#pagination > TABLE > TBODY > TR > TD > A > DIV#end-next   {border:0 none; background:#000 none;}" +
        /* footer seach borders */
        "CENTER > CENTER > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[bgcolor='#aa0033']   {display:none;}" +
        /* footer disclaimer */
        "BODY.hp > DIV#main-wrapper > DIV.footer > DIV.footer-disclaimer   {color:#333 !important;}" +
        /* personalize header */
        "#cust_link_tbl {background-color:#333; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* personalize button */
        "DIV.blended-section2 > DIV.column2 > SPAN > DIV#personalize   {background-color:#223; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* in the news top line */
        "DIV.t-IN_THE_NEWS   {border-top-color:#333 !important;}" +
        /* in the news headline */
        "DIV.t-IN_THE_NEWS > DIV.basic-title   {color:#ccc !important;}" +
        /* Finance R-sidebar Header */
        "DIV.sp-b DIV.basic-title   {background-color:#333; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        
        // Image Version
        /* cell container */
        "TD#ImageSection TABLE TBODY TR TD   {padding:5px;}" +
        /* cells */
        "TD#ImageSection TABLE TBODY TR TD DIV[style='border: 1px solid rgb(255, 255, 255); padding: 7px 7px 4px; white-space: nowrap; width: 104px;']   {background-color:#333; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* img container */
        "DIV.divnohighlightnoie   {border:0 none !important;}" +
        /* img container */
        "DIV.divnohighlightnoie IMG.centerimagenonie   {position:relative; left:-5px;}" +
        /* rightBar */
        "DIV#RightBarContent DIV   {background-color:#000 !important;}" +
        
        
        // AP/AFP.google News enhancements
        /* body txt */
        "DIV DIV#hn-content DIV   {color:#999 !important;}" +
        /* article title */
        "DIV DIV#hn-content DIV H1   {color:#fff;}" +
        /* footer */
        "DIV DIV#hn-footer   {display:none;}" +
        /* /hostednews/ expanded below in brute force enhancements */
        
        
        // Maps enhancements
        /* logo img */
        "IMG[alt='Go to Google Maps Home'], BODY > DIV#header > DIV#search > FORM#q_form > DIV#logo IMG   {display:none;}" +
        /* help linx */
        "DIV.helplinks DIV   {background-color:#000 !important; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header txt */
        "DIV#header SPAN   {color:#999;}" +
        /* mapping tabs */
        "TABLE#paneltabs TBODY TR TD   {background-color:#000 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* mapping tab txt */
        "TABLE#paneltabs TBODY TR TD.tabOff A DIV, TABLE#paneltabs TBODY TR TD.tabOn A DIV   {font-weight:bold; color:#999 !important;}" +
        /* map popup txt */
        "DIV.iw #basics DIV, DIV.gmnoprint DIV DIV DIV B  {color:#000 !important;}" +
        /* send panel container */
        "DIV.sdb   {margin:5px; background-color:#000 !important; border:3px solid #f90 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* send panel inner */
        "DIV.sdb DIV.c, DIV.sdb DIV.c DIV DIV   {border:0 none !important; background-color:#000 !important; color:#999 !important;}" +
        /* link to this page panel */
        "DIV#le   {background-color:#000 !important; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* link to panel txt */
        "DIV#le TABLE.letbl TBODY TR TD   {color:#999 !important;}" +
        /* panel selection */
        "DIV#page DIV#panel DIV.selected   {background-color:#222 !important; color:#333; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* results area */
        "DIV#hp DIV, DIV#hp TABLE TR TD, DIV#panel DIV DIV, DIV#panel DIV TABLE TBODY TR TD, DIV#page DIV, DIV#page TABLE TBODY TR TD   {color:#777 !important;}" +
        /* sponsored linx */
        "TABLE > TBODY > TR > TD > TABLE.geoads, TABLE > TBODY > TR > TD > DIV.adsmessage, #panel .ads, #contentads, #rhsads   {display:none;}" +
        /* searched term in title */
        "TABLE.res TBODY TR TD DIV.name SPAN A SPAN B   {color:#aaa !important;}" +
        /* phone numbers */
        "TABLE.res TBODY TR TD DIV SPAN.tel   {color:#090;}" +
        /* highlight */
        "FONT[color='red']   {color:#f00;}" +
        /* map points */
        "TABLE.ddwpt_table TD   {background-color:#333;}" +
        /* my maps content */
        "DIV#mmheaderpane DIV.mmboxheaderinactive   {background-color:#181818;}" +
        /* search logo(s) */
        "DIV.n DIV.imgn IMG   {display:none;}" +
        /* legal & navtech blocks */
        "DIV.legal, DIV.cprt   {display:none;}" +
        /* headers */
        "TABLE#titlebar, DIV#pp-maincol DIV.bar, DIV#pp-sidecol DIV.bar   {border:0; background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* txt-view body width */
        "#contentpanel > TABLE[style='margin-top: 0.2em;'], #contentpanel > TABLE[style='margin-top: 0.2em;'] TBODY TR.lr TD TABLE, #contentpanel > TABLE[style='margin-top: 0.2em;'] TBODY TR.lr TD TABLE TBODY TR TD:nth-child(3)    {width:99%;}" +
        /* txt-view footer block */
        "#localfooter TABLE TBODY TR TD   {border:0; background-color:#000;}" +
        /* mymaps feat cont bg */
        "DIV.mmheaderpane DIV DIV.mmboxheaderinactive, DIV.mmboxbody IFRAME HTML BODY   {background-color:#000 !important;}" +
        /* lowerpanel activeselected */
        "DIV#rv-content > DIV.rvitem > DIV.rvcontrols > SPAN.rvactivetitle   {color:#fff !important;}" +
        /* search results notice */
        "DIV#resultspanel > DIV.local > DIV#localpanelnotices   {display:none;}" +
        /* place page bg */
        "BODY > DIV#page > DIV#wpanel   {background-color:inherit;}" +
        /* place loc action bar */
        "DIV#pp-headline-details DIV.actbar   {background-color:#000 !important;}" +
        /* bottom search bgs */
        "DIV.pp-footer > DIV.pp-footer-links, DIV#localfooter > #bsf   {background-color:#000; border:0 none;}" +
        
        // Print-page
        /*directions txt */
        "DIV.segmentdiv TABLE TBODY TR TD   {background-color:#000;}" +
        /* title width */
        "@media print{ #ph TD.phh   {width:100%;} }" +
        /* save trees msg */
        "@media print{ #pnc.untouched #gmm_msg   {display:none;} }" +
        
        
        // Gmail [basic HTML view] enhancements
        /* view type headers */
        "TABLE.bn > TBODY> TR > TD#bm   {border:0 none; background-color:#181818; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* logo img */
        "BODY[bgcolor='#ffffff'] > TABLE[width='100%'] > TBODY > TR:first-child > TD[width='143'] > H1 > A > IMG   {display:none;}" +
        /* menu selected */
        "BODY > TABLE > TBODY > TR > TD > TABLE[width='100%'].m > TBODY > TR > TD[bgcolor='#c3d9ff'], BODY > TABLE > TBODY > TR > TD > TABLE[width='100%'].m > TBODY > TR > TD[bgcolor='#fad163']   {background-color:#333; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* menu selected txt */
        "BODY > TABLE > TBODY > TR > TD > TABLE[width='100%'].m > TBODY > TR > TD[bgcolor='#c3d9ff'] A, BODY > TABLE > TBODY > TR > TD > TABLE[width='100%'].m > TBODY > TR > TD[bgcolor='#fad163'] A   {color:#fff !important;}" +
        /* upper alert msg box */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[cellspacing='4'][align='center'] > TBODY > TR:first-child > TD:first-child   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* upper alert msg box txt */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[cellspacing='4'][align='center'] > TBODY > TR:first-child > TD:first-child > B   {color:#000 !important;}" +
        /* search options bgs */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#74d982'], BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#b5edbc'], BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#b5edbc'] > TABLE[bgcolor='#74d982']   {background-color:#000 !important;}" +
        /* msg-list L-spacer */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD[width='5'][bgcolor='#c3d9ff'], BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD[width='5'][bgcolor='#74d982'], BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD[width='5'][bgcolor='#fad163']   {background-color:#333;}" +
        /* msg-list bg */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > FORM[name='f'] > TABLE[bgcolor='#c3d9ff'], BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > FORM[name='f'] > TABLE[bgcolor='#74d982'], BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'][bgcolor='#c3d9ff'], BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'][bgcolor='#74d982'], BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'][bgcolor='#fad163']   {background-color:#333;}" +
        /* msg-list row normal */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > FORM[name='f'] > TABLE.th > TBODY > TR[bgcolor='#ffffff']   {background-color:#000;}" +
        /* msg-list row Read */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > FORM[name='f'] > TABLE.th > TBODY > TR[bgcolor='#e8eef7']   {background-color:#222;}" +
        /* msg-list row unread txt */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > FORM[name='f'] > TABLE.th > TBODY > TR[bgcolor='#e8eef7'] > TD   {color:#999 !important;}" +
        /* msg bg */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='98%'][bgcolor='#CCCCCC']   {background-color:#000;}" +
        /* msg header */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'][bgcolor='#e0ecff'], BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'][bgcolor='#b5edbc']   {background-color:#000;}" +
        /* msg body bg */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD TABLE[width='100%'][bgcolor='#efefef']   {border:0 none; -moz-border-radius-topright:8px; -moz-border-radius-topleft:8px;}" +
        /* msg body */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD TABLE[width='100%'][bgcolor='#efefef'] DIV.msg   {color:#000; -moz-border-radius-bottomright:8px; -moz-border-radius-bottomleft:8px;}" +
        /* msg body uppper */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD TABLE[width='100%'][bgcolor='#efefef'] > TBODY > TR:first-child   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* msg lowerReplyBox */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD TABLE[width='100%'].qr TD   {background-color:#000; color:#999 !important;}" +
        /* msg lowerReplyBox logoFix */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD TABLE[width='100%'].qr > TBODY > TR > TD > TABLE > TBODY > TR > TD[colspan='2'] > TABLE[width='100%'] > TBODY > TR > TD[width='1%']   {background-image:none !important;}" +
        /* compose tbl */
        "FORM[name='f'] > TABLE.compose   {background-color:#000;}" +
        /* compose tbl logo fix */
        "FORM[name='f'] > TABLE.compose > TBODY > TR:first-child > TD[width='1%']:first-child   {width:inherit !important; height:inherit !important; font-size:0.8em; background-image:none !important;}" +
        /* contacts list header */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > TABLE[bgcolor='#fad163'] > TBODY > TR:first-child > TD:first-child > DIV.hp > DIV.bg   {background-color:#333;}" +
        /* contacts list bg */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > TABLE[bgcolor='#ffffff'].th, BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#fff7d7']   {background-color:#000;}" +
        /* contacts list tbl txt */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > TABLE[bgcolor='#ffffff'].th > TBODY > TR > TD   {color:#ccc !important;}" +
        /* settings selected tab */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD > TABLE[bgcolor='#ffffff'].th, BODY > TABLE[width='100%'] > TBODY > TR > TD[valign='top'] > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#fff7d7'] DIV.nav > UL > LI.on   {background-color:#333; color:#fff;}" +
        /* header txt */
        "BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'] > TABLE[bgcolor='#fad163']:first-child H2   {color:#fff;}" +
        /* filters bg */
        "BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fad163'], BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'], BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fad163'], BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'], BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'] DIV.middle-container-padded, BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'] > TABLE[bgcolor='#fad163']:last-child   {background-color:#000; color:#999 !important;}" +
        /* filters header */
        "BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'] > TABLE[bgcolor='#fad163']:first-child   {padding-left:0.5em; background-color:#000;}" +
        /* filters tab selected */
        "BODY > TABLE[width='100%'] > TBODY > TR TD[bgcolor='#fff7d7'] > TABLE[bgcolor='#fad163']:first-child DIV.nav > UL > LI.on   {background-color:#333; color:#fff;}" +
        /* page txt */
        "BODY > TABLE > TBODY > TR > TD > TABLE.ft TD, BODY > TABLE > TBODY > TR > TD > TABLE.ft TD DIV, BODY > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD[bgcolor='#fff7d7'] > DIV.prf TD, BODY > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD[bgcolor='#fff7d7'] > DIV.prf DIV   {color:#999 !important;}" +
        /* footer */
        "BODY > TABLE > TBODY > TR > TD > TABLE.ft > TBODY > TR > TD[align='center'] > FONT[size='1']   {display:none;}" +
        /* Gmail expanded below in brute force enhancements */
        
        
        // Docs enhancements
        /* logo img */
        "BODY > DIV#masthead > TABLE.searchbar > TBODY > TR#logo-section > TD.searchbar-logo > DIV > A[href='.'] > IMG   {display:none;}" +
        /* doclist borders */
        "DIV#doclist > DIV.doclistappview   {background:#000 none;}" +
        /* templates header */
        "DIV#templates-header > DIV#templates-header-location   {background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* templates header tabs */
        "DIV#templates-header > DIV#templates-header-tabs   {border:0 none; background-color:#000;}" +
        /* templates header tab sel */
        "DIV#templates-header > DIV#templates-header-tabs .templates-list-selected   {margin-bottom:1em; border:0 none; background-color:#000; font-weight:bold; color:#fff;}" +
        /* settings outer box */
        "FORM.settings-container-form > TABLE.roundedblock   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* settings corner imgs */
        "FORM.settings-container-form > TABLE.roundedblock TD   {background-image:none;}" +
        /* footers */
        "BODY > DIV.footer   {display:none;}" +
        /* Docs expanded below in brute force enhancements */
        
        
        // Shopping/Froogle enhancements
        /* logo img */
        "A#glogo > IMG[width='150'][height='105'], CENTER > H1#ps-logo > IMG, BODY > FORM[name='f'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'][style='clear: left;'] > TBODY > TR > TD:first-child > A#glogo > IMG, BODY > DIV#hp-cont > H1#hp-logo > IMG, BODY > DIV#srp-header > FORM[name='f'] > TABLE:first-child > TBODY > TR > TD:first-child > A#glogo > IMG, BODY > FORM > DIV#advd-search-header > TABLE:first-child > TBODY > TR > TD[width='1%']:first-child > A#advd-logo > IMG, BODY > DIV#srp-header > FORM[name='f'] > TABLE > TBODY > TR > TD > A#srp-logo > IMG   {display:none;}" +
        /* logo adjust */
        "BODY > DIV#hp-cont > H1#hp-logo   {width:100% !important; height:120px !important; background-position:center center !important;}" +
        /* adv search logo adjust */
        "BODY > FORM > DIV#advd-search-header > TABLE:first-child > TBODY > TR > TD[width='1%']:first-child > A   {width:inherit !important;}" +
        /* header bar */
        "TABLE[cellspacing='0'][cellpadding='0'][style='border-top: 1px solid rgb(68, 120, 212); background: rgb(234, 239, 250) none repeat scroll 0% 0%; width: 100%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;'], TABLE#ps-titlebar, BODY > DIV#ps-titlebar, BODY > FORM > DIV#advd-search-header H1   {padding:0 0.3em 0.1em 0.3em; background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* L-menu */
        "BODY > DIV#lhs-ref   {padding-top:0.2em; background-color:#181818; border-right:0 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* sponsored linx */
        "DIV[style='padding-top: 11px;'] > DIV[style='font-size: small; background-color: rgb(255, 249, 221);'], BODY[vlink='#551a8b'][text='#000000'][marginheight='3'][link='#0000cc'][alink='#ff0000'][topmargin='3'] > TABLE[cellspacing='0'][cellpadding='0'][border='0'][bgcolor='#ffffff'][align='right'][style='']   {display:none;}" +
        /* top & bottom ads */
        "BODY > DIV#ads-top, BODY > DIV.list > DIV#ads-bot   {display:none;}" +
        /* results width aleviater */
        "BODY > DIV.rhs, BODY > DIV.list   {max-width:none; margin-right:0;}" +
        /* search txt */
        "TABLE.list FORM, TABLE.list SPAN.prod-detail, TABLE.list > TBODY > TR > TD.ol NOBR, TABLE.list > TBODY > TR > TD.ol SPAN, TD.bo > NOBR, BODY > DIV.list DIV, BODY > DIV.list P, BODY > DIV.grid DIV   {color:#999 !important;}" +
        /* result prices */
        "BODY > DIV.list > OL#results P.result-price, BODY > DIV.list > OL#results P.result-taxship, BODY > DIV.grid P.result-price, BODY > DIV.grid P.result-taxship   {color:#fff !important;}" +
        /* search desc */
        "TABLE.list > TBODY > TR > TD.ol   {color:#fff !important;}" +
        /* vertical ads */
        "TABLE#ps-vertical-ads, DIV#ads-rhs   {display:none;}" +
        /* advanced search box */
        "BODY > FORM > DIV.as-table-cont, BODY > FORM > DIV.as-table-cont TD   {border:0 none; color:#999 !important;}" +
        /* footer search refinement */
        "DIV.main-top > DIV#attr-div > TABLE.attr-table, DIV.main-top > DIV#attr-div > TABLE.attr-table LI   {color:#ccc;}" +
        /* footer logo(s) */
        "TABLE DIV#nf, TABLE DIV#nc, TABLE DIV.nr, TABLE DIV#nn   {height:0px; background:none;}" +
        /* footer disclaimer */
        "TABLE[width='65%'][align='center'] > TBODY > TR > TD[align='center'] > SPAN.disclaimer   {display:none;}" +
        /* footer search */
        "BODY > TABLE[cellspacing='0'][cellpadding='3'][style='border-top: 1px solid rgb(68, 120, 212); border-bottom: 1px solid rgb(68, 120, 212); background: rgb(234, 239, 250) none repeat scroll 0% 0%; width: 100%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;'], BODY > TABLE#ps-footer   {background-color:#000 !important; border:0 none !important;}" +
        /* footer txt */
        "BODY > TABLE[cellspacing='0'][cellpadding='3'][style='border-top: 1px solid rgb(68, 120, 212); border-bottom: 1px solid rgb(68, 120, 212); background: rgb(234, 239, 250) none repeat scroll 0% 0%; width: 100%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;'] > TBODY > TR > TD[align='center'] > FONT[size='-1'], BODY[vlink='#551a8b'][text='#000000'][marginheight='3'][link='#0000cc'][alink='#ff0000'][topmargin='3'] > CENTER > FONT[size='-1'], BODY > TABLE#ps-footer > TBODY > TR > TD[align='center'] > FONT[size='-1'], BODY > P.as-footer   {display:none;}" +
        /* footer pagination imgs */
        "BODY > DIV.n > TABLE > TBODY > TR > TD > DIV#nl   {background-image:none;}" +
        /* footer bg */
        "BODY > DIV#ps-footer > DIV#ps-footer-bg   {background-color:#000 !important;}" +
        /* footer disclaimer */
        "BODY > DIV#ps-footer > P.ps-disclaimer   {color:#777;}" +
        /* footer */
        "BODY > DIV#hp-cont > P:last-child   {display:none;}" +
        
        
        // Finance enhancements
        /* logo img */
        "BODY DIV.g-doc DIV.g-section > DIV.g-unit > DIV.sfe-logo > A > IMG   {display:none;}" +
        /* left nav selected */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section UL#navmenu > LI.nav-selected, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section UL#navmenu > LI.nav-selected, BODY > DIV.g-doc > DIV.g-section UL#navmenu > LI.nav-selected   {background-color:#333;}" +
        /* left nav item */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section UL#navmenu > LI.nav-item, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section UL#navmenu > LI.nav-item, BODY > DIV.g-doc > DIV.g-section UL#navmenu > LI.nav-item   {background-color:#181818;}" +
        /* left nav item link */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section UL#navmenu > LI.nav-item > A *, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section UL#navmenu > LI.nav-item > A *, BODY > DIV.g-doc > DIV.g-section UL#navmenu > LI.nav-item > A *   {color:#999 !important;}" +
        /* left nav sub */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section UL#navmenu > LI.navsub, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section UL#navmenu > LI.navsub, BODY > DIV.g-doc DIV.g-section UL#navmenu > LI.navsub, BODY > DIV.g-doc DIV.g-section UL#navmenu > LI.navsub DIV   {background-color:#000; color:#fff !important;}" +
        /* left Recent box */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section #rq-box, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section .ra-box, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section #rq-box, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section .ra-box, BODY > DIV.g-doc > DIV.g-section #rq-box, BODY > DIV.g-doc > DIV.g-section .ra-box   {margin-top:3em; background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* headers */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV.hdg, BODY > DIV.g-doc > DIV.g-section DIV.hdg, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV.g-wrap > DIV.g-section > DIV.hdg, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#reorder DIV.hdg, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV.g-wrap > DIV.g-section > DIV.g-unit > DIV.g-c > DIV.hdg, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV.hdg   {background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header selection */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV.hdg A.t > B.t, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV.hdg A.t > B.t > B.t   {top:0; left:0; background-color:#333; color:#fff;}" +
        /* header tabs bg */
        "BODY DIV.g-doc DIV.g-section DIV.goog-tab B.t, BODY DIV.g-doc > DIV.g-section TABLE.gf-table TH, BODY DIV.g-doc > DIV.g-section DIV.add_trans_bar_border   {border:0 none !important; background-color:#000 !important; color:#fff;}" +
        /* header tabs */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV.hdg DIV.goog-tab, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV.hdg DIV.goog-tab A.t   {background-color:#333; border:0 none !important;}" +
        /* section option menu */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV.goog-menu   {background-color:#181818; border:0 none; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* create profile box */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV#p0   {padding-bottom:7px; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* stock values */
        "BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#price-panel SPAN.pr SPAN:first-child, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#price-panel SPAN.nwp, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section OL#snap-data > LI > SPAN.val, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#price-panel > DIV, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#price-panel > DIV > DIV, DIV.g-section > DIV.g-unit > DIV.g-c DIV, DIV.g-section > DIV.g-unit > DIV.g-c DIV TD, TABLE#fs-table TD   {color:#fff !important;}" +
        /* price panel keys */
        "BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section OL#snap-data > LI > SPAN.key   {position:relative; top:0; left:0.7em; font-size:0.8em;}" +
        /* right side news item */
        "BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section TD#scrollingListTd DIV.news-item   {background-color:#000;}" +
        /* related header */
        "BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#related DIV.hdg, BODY > DIV.g-doc DIV.g-section DIV.gf-table-control, BODY DIV.g-doc DIV.g-section TABLE#main.results > TBODY > TR > TD.highlight1, BODY DIV.g-doc DIV.g-section TABLE#main.results > TBODY > TR > TD.selected1   {background-color:#000 !important;}" +
        /* related row headers */
        "BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#related TABLE.gf-table TH, BODY > DIV.g-doc > DIV.g-section DIV#related-table TABLE.gf-table TH, BODY > DIV.g-doc DIV.g-section TABLE#fs-table TH, BODY DIV.g-doc DIV.g-section TABLE#main.results > TBODY > TR.hdg > TD.hdg   {border-color:#000; background-color:#333; color:#fff;}" +
        /* related company row */
        "BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#related TABLE.gf-table > TBODY > TR > TD, BODY > DIV.g-doc > DIV.g-section DIV#related-table TABLE.gf-table > TBODY > TR > TD, BODY > DIV.g-doc > DIV.g-section TABLE#company_results > THEAD > TR > TH, BODY > DIV.g-doc > DIV.g-section TABLE#mf_results > THEAD > TR > TH, BODY DIV.g-doc DIV.g-section TABLE#historical_price > TBODY > TR > TH, BODY > DIV.g-doc DIV.g-section TABLE#historical_price > TBODY > TR.tptr > TD[colspan='6'].rgt, BODY > DIV.g-doc DIV.g-section TABLE#fs-table TR.hilite, BODY > DIV.g-doc DIV.g-section TABLE#fs-table TR.hilite > TD, BODY > DIV.g-doc > DIV.g-section TABLE#advanced_search_results TR.hilite > TD, BODY > DIV.g-doc > DIV.g-section TR.tptr, BODY DIV.g-doc DIV.g-section TABLE#main.results > TBODY > TR > TD.highlight2, BODY DIV.g-doc DIV.g-section TABLE#main.results > TBODY > TR > TD.selected2   {border-color:#000; background-color:#222 !important; color:#fff !important;}" +
        /* SscreenerAdd criteriaBx */
        "BODY > DIV.g-doc > DIV.g-section DIV.criteria_wizard, BODY > DIV.g-doc > DIV.g-section DIV.criteria_wizard TABLE.searchtabs TD    {background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* SscreenerAdd criteriaBxIn */
        "BODY > DIV.g-doc > DIV.g-section DIV.criteria_wizard DIV.criteria_list_div, BODY > DIV.g-doc > DIV.g-section DIV.criteria_wizard DIV.criteria_list_div > DIV.criteriadiv   {background-color:#000 !important; border:0 none !important; font-size:0.9em; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* page txt */
        "BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section > DIV#rt-content > DIV, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section > DIV#rt-content TD, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section > DIV#rt-content TD:nth-child(2) > SPAN, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#rq-table DIV, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV#rq-table DIV, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#rq-table TD:nth-child(2) SPAN, BODY > DIV.g-doc > DIV.g-section DIV#rq-table TD:nth-child(2) SPAN, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV#rq-table TD:nth-child(2) SPAN, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section DIV#rq-toggle SPAN, BODY > DIV.g-doc > DIV.g-section DIV#rq-toggle SPAN, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#rq-toggle SPAN, BODY > DIV#body-wrapper > DIV.g-doc > DIV.g-section UL#navmenu > LI.navsub DIV, BODY > DIV.g-doc > DIV.g-section UL#navmenu > LI.navsub DIV, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section UL#navmenu > LI.navsub DIV, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV#price-panel SPAN.dis-large, BODY > DIV.g-doc DIV.g-section TD.price SPAN, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV.g-c DIV, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section DIV.g-c DIV, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section TABLE.quotes TD, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section TABLE#cc-table TD:nth-child(3) SPAN, BODY > DIV.g-doc > DIV.g-section TABLE#cc-table TD:nth-child(3) SPAN, BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section TABLE#cc-table TD:nth-child(7), BODY > DIV.g-doc > DIV.g-section TABLE#cc-table TD:nth-child(7), BODY > DIV.g-doc > DIV#body-wrapper > DIV.g-section TABLE#mgmt-table TD, BODY > DIV.g-doc > DIV.g-section TABLE#company_results > TBODY > TR > TD, BODY > DIV.g-doc > DIV.g-section TABLE#company_results > TBODY > TR > TD SPAN.chb, BODY > DIV.g-doc > DIV.g-section DIV.g-unit, BODY > DIV.g-doc DIV.g-section TABLE#historical_price > TBODY > TR > TD, BODY > DIV.g-doc DIV.g-section TABLE#fs-table TD, BODY > DIV.g-doc DIV.g-section DIV#news-main DIV, BODY > DIV.g-doc DIV.g-section DIV#need-sign-in, BODY > DIV.g-doc > DIV.g-section DIV#criteria TD, BODY DIV.g-doc DIV.g-section DIV.snippet, BODY DIV.g-doc DIV.g-section DIV.byline > SPAN.date, BODY DIV.g-doc DIV.g-section TABLE.quotes TD, BODY DIV.g-doc DIV.g-section TABLE#main.results TD, BODY DIV.g-doc DIV.g-section TABLE.topmovers TD, BODY DIV.g-doc DIV.g-section DIV.event, BODY DIV.g-doc DIV.g-section DIV.event > DIV.date, BODY DIV.g-doc DIV.g-section TABLE.gf-table > TBODY > TR > TD.pf-table-lp > SPAN > SPAN   {color:#999 !important;}" +
        /* ads */
        "DIV#ad-label, DIV#ad-target   {display:none;}" +
        
        
        // Dictionary enhancements
        /* language selector */
        "DIV#gs-box > DIV#gs-view   {color:#fff !important;}" +
        /* language box */
        "DIV#gs-box > UL#gs-opts, DIV#gs-box > UL#gs-opts UL.sub   {background-color:#181818 !important; border:0 none; color:#777;}" +
        /* body cntnr */
        "BODY > DIV#cnt > DIV.dct-srch-otr DIV   {color:#999 !important;}" +
        /* definition txt */
        "BODY > DIV#cnt > DIV.dct-srch-otr H2.wd, BODY > DIV#cnt > DIV.dct-srch-otr DIV.dct-eh SPAN, BODY > DIV#cnt > DIV.dct-srch-otr LI.dct-er SPAN   {color:#fff;}" +
        /* headers */
        "BODY > DIV#cnt > DIV.dct-srch-otr H3   {background-color:#333; border:0 none !important; color:#000; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* footer */
        "BODY > DIV#cnt > CENTER > DIV[style='border-top: 1px solid rgb(204, 204, 240); padding: 15px 2px 2px;']   {display:none;}" +
        
        
        // Calendar enhancements
        /* logo img [hide] */
        "BODY > DIV#calcontent > DIV#topBar > DIV.noprint > TABLE > TBODY > TR > TD.logoparent > IMG#mainlogo   {display:none;}" +
        /* logo img [insert] */
        "BODY > DIV#calcontent > DIV#topBar > DIV.noprint > TABLE > TBODY > TR > TD.logoparent   {width:150px !important; height:55px !important; background:transparent url('" +
        googleLogoBLACK +
        "') no-repeat scroll 0% !important; font-size:0;}" +
        /* alert box */
        "DIV#nt1 > DIV > TABLE.mbox   {background-color:#000 !important;}" +
        /* search options header */
        "DIV#sropt > DIV.logoMargin > TABLE[width='100%'][style='background: rgb(116, 221, 130) none repeat scroll 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;']   {position:relative; right:10px; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* search options box */
        "DIV#sropt > DIV[style='border: 3px solid rgb(116, 221, 130); padding: 6px 5%; background: rgb(181, 237, 188) none repeat scroll 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; margin-bottom: 4px;']   {margin-right:10px; margin-bottom:20px !important; -moz-border-radius-topleft: 14px; -moz-border-radius-bottomright: 14px; -moz-border-radius-bottomleft: 14px;}" +
        /* search options I-override */
        "DIV#sropt > DIV[style='border: 3px solid rgb(116, 221, 130); padding: 6px 5%; background: rgb(181, 237, 188) none repeat scroll 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; margin-bottom: 4px;'] > FORM#advancedSearchForm TD   {background-color:inherit; border:inherit; -moz-border-radius-topright:inherit; -moz-border-radius-bottomleft:inherit;}" +
        /* calendar header */
        "DIV#tc_top > TABLE#chrome_main1   {background-color:#000 !important;}" +
        /* calendar R-side */
        "BODY > DIV#calcontent > TABLE#mothertable > TBODY > TR > TD#rhstogglecell   {background-color:#000;}" +
        /* item bubble */
        "DIV.bubble > TABLE.bubble-table   {background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* item bubble corner bg */
        "DIV.bubble > TABLE.bubble-table > TBODY > TR > TD DIV.bubble-sprite   {background:transparent none !important;}" +
        /* item bubble cell bg */
        "DIV.bubble > TABLE.bubble-table > TBODY > TR > TD.bubble-cell-main > DIV.bubble-top, DIV.bubble > TABLE.bubble-table > TBODY > TR > TD > DIV.bubble-bottom, DIV.bubble > TABLE.bubble-table > TBODY > TR > TD.bubble-mid, DIV.bubble > TABLE.bubble-table > TBODY > TR > TD.bubble-mid TH, DIV.bubble > TABLE.bubble-table > TBODY > TR > TD.bubble-mid TD, DIV.bubble > TABLE.bubble-table > TBODY > TR > TD.bubble-mid DIV   {background-color:#333; border:0 none; color:#ccc !important;}" +
        /* create event page body */
        "FORM#masterForm > DIV.eventpg   {background-color:#000;}" +
        /* Calendar Login expanded below in brute force enhancements */
        /* table txt */
        "DIV#newdirtarget TD, DIV#set H3, DIV#set TD, DIV#set TABLE#svalues DIV   {color:#000;}" +
        
        
        // Groups enhancements
        /* mygroups panel */
        "#myg_popup   {border:0 none !important; background-color:#333 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* logo img */
        "IMG[width='150'][height='55'][alt='Go to Google Groups Home'], IMG[width='150'][height='55'][src='/groups/img/3nb/groups_medium.gif'], IMG[width='132'][height='26'][style='position: relative; top: 1px;'][alt='Google Groups Home'], BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > CENTER > TABLE > TBODY TR > TD[align='left'] > TABLE > TBODY > TR > TD[valign='top'] > DIV > A > IMG, BODY > TABLE#sft > TBODY > TR > TD.tc > A#logo, BODY > TABLE#sft > TBODY > TR > TD.tc > A#logo > IMG   {visibility:hidden}" +
        /* search header */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > CENTER > TABLE > TBODY TR > TD[align='left'] > TABLE > TBODY > TR > TD[valign='top'] > DIV   {margin:20px;}" +
        /* search header options */
        "BODY > TABLE#sft > TBODY > TR > TD > FORM[name='gs'] > TABLE.tb > TBODY > TR > TD > DIV.ss   {color:#777 !important;}" +
        /* top table borders */
        "TABLE[width='100%'] > TBODY > TR[valign='top'] > TD[width='70%'][valign='top'][align='left'] > DIV > TABLE[width='450'][style='border-top: 1px solid rgb(119, 153, 221);'], BODY[bgcolor='white'] > TABLE[width='100%'] > TBODY > TR[valign='bottom'] > TD > TABLE[width='100%'] > TBODY > TR > TD[valign='center'][align='left'] > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#7799dd']   {border:0 none !important; background-color:#000 !important;}" +
        /* header bar bgs */
        "TD[valign='center'][align='left'] > TABLE[width='100%'] > TBODY > TR[bgcolor='#e8eef7']   {background-color:#000;}" +
        /* header top line */
        "BODY > CENTER > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD > DIV > TABLE[style='border-top: 1px solid rgb(119, 153, 221);']   {border:0 none !important;}" +
        /* header bars */
        "TD[class='padt3 padb3 padl3 padr8'][bgcolor='#e8eef7'], TD[valign='center'][align='left'] > TABLE[width='100%'] > TBODY > TR[bgcolor='#e8eef7'] > TD, BODY > TABLE.sb   {padding-left:7px; background-color:#333; border:0 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* right table bg */
        "#GHP_compact_my_groups > TABLE TBODY TR TD   {border:0 none !important; background-color:#000; color:#999 !important;}" +
        /* right headers */
        "TD[class='padt3 padb3 padl7'][style='border-top: 1px solid rgb(119, 153, 221);']   {border:0 none !important; padding-left:7px; background-color:#222 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* number txt & bgs */
        "DIV[class='padl0 padr0'] > DIV, DIV[class='padl0 padr0'] > DIV B   {background-color:#000 !important; color:#369 !important;}" +
        /* number corners */
        "DIV[class='padl0 padr0'] > DIV > TABLE   {display:none;}" +
        /* suggested for you bg */
        "TABLE[width='450'][style='border-top: 1px solid rgb(119, 153, 221);'] > TBODY > TR > TD > TABLE > TBODY TR TD[width='40%'][valign='top']   {background-color:#000;}" +
        /* search page txt */
        "BODY > DIV#res > TABLE#gdr > TBODY > TR > TD DIV   {color:#999 !important;}" +
        /* sponsored links */
        "BODY > TABLE#rhsc   {display:none;}" +
        
        // Advanced Search
        /* logo img */
        "BODY[marginheight='3'][bgcolor='#ffffff'][topmargin='3'] > TABLE[width='100%'][cellpadding='0'][border='0'] > TBODY > TR > TD[valign='middle'].tc > A#logo > IMG   {display:none;}" +
        /* header blue line */
        "TABLE#advsearch-t   {border-top:0 none;}" +
        /* header bar */
        "TABLE#advsearch-t > TBODY > TR > TD.page-title   {padding-left:7px; background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header about */
        "TABLE#advsearch-t > TBODY > TR > TD.page-about   {display:none;}" +
        /* borders */
        "TABLE.advsearch-s > TBODY > TR > TD > DIV.outer-box > DIV.qbuilder-env, TABLE.advsearch-s > TBODY > TR > TD > DIV.outer-box > FORM[name='f'].block, TABLE.advsearch-s > TBODY > TR > TD > FORM[name='msgid'].block   {background-color:#000 !important; border-color:#333;}" +
        /* top borders */
        "TABLE.advsearch-s > TBODY > TR > TD > DIV.outer-box > DIV.qbuilder-env, TABLE.advsearch-s > TBODY > TR > TD > FORM[name='msgid'].block   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* bottom borders */
        "TABLE.advsearch-s > TBODY > TR > TD > DIV.outer-box > FORM[name='f'].block, TABLE.advsearch-s > TBODY > TR > TD > FORM[name='msgid'].block   {-moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* highlighted bgs */
        "TABLE.advsearch-s > TBODY > TR > TD > DIV.outer-box > DIV.qbuilder-env > DIV#gen-query, TABLE.advsearch-s > TBODY > TR > TD > DIV.outer-box > FORM[name='f'].block > DIV > TABLE > TBODY > TR[bgcolor='#ffffff'], TABLE.advsearch-s > TBODY > TR > TD > FORM[name='msgid'].block > DIV > TABLE > TBODY > TR[bgcolor='#ffffff']   {background-color:#000; color:#fff !important;}" +
        
        // Browse Groups
        /* logo img */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[valign='top'] > DIV > A > IMG   {display:none;}" +
        /* top line */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][bgcolor='#e8eef7'].tsh   {display:none;}" +
        /* search bars */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'][bgcolor='#e8eef7']   {padding-left:7px; background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* result txt */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex   {color:#ccc !important;}" +
        /* result item */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > P   {padding-top:10px; border-top:1px solid #555;}" +
        /* pagination */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE#bottom_marker > TBODY > TR[valign='bottom'] > TD[width='100%'] > DIV[dir='ltr'] > TABLE > TBODY > TR > TD IMG   {display:none;}" +
        /* pagination bg fix */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE#bottom_marker > TBODY > TR[valign='bottom'] > TD[width='100%'] > DIV[dir='ltr'] > TABLE > TBODY > TR > TD   {background-image:none !important;}" +
        /* bottom search bg */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'][bgcolor='#e8eef7'][style='margin-right: -5px;']   {background-color:#000;}" +
        /* bottom line */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV[style='border-bottom: 1px solid rgb(119, 153, 221);']   {display:none;}" +
        
        // My Profile
        /* header bar */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][bgcolor='#e8eef7'][style='padding: 1px 0px 2px;']   {background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* recent activity */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE.padt10 > TBODY > TR > TD> TABLE > TBODY > TR#stats > TD[width='500'] *   {color:#000 !important;}" +
        /* activity box */
        "BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE.padt10 > TBODY > TR > TD> TABLE > TBODY > TR#stats > TD[width='500'] TD[bgcolor='#e8eef7'], BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE.padt10 > TBODY > TR > TD> TABLE > TBODY > TR#stats > TD[width='500'] TD[bgcolor='#e8eef7'] > DIV, BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE.padt10 > TBODY > TR > TD> TABLE > TBODY > TR#stats > TD[width='500'] > DIV.wdth100 > DIV[style='border-top: 15px solid white; border-bottom: 10px solid white;'], BODY[marginheight='3'][bgcolor='white'][topmargin='3'] > DIV.padl1ex > TABLE.padt10 > TBODY > TR > TD> TABLE > TBODY > TR#stats > TD[width='500'] TABLE#stat_ftr > TBODY > TR > TD   {border-color:#000 !important; background-color:#000; color:#fff !important;}" +
        
        // Create
        /* step num */
        "DIV[style='padding: 10px 158px;'] > TABLE > TBODY > TR > TD[width='16'][height='18'][align='center']   {color:#999 !important;}" +
        /* page txt */
        "TABLE.content > TBODY > TR > TD, DIV[style='padding: 10px 158px;'] > FORM[name='cr'] > DIV.boxttl, BODY[bgcolor='white'] > DIV[style='padding: 10px 158px;'], BODY[bgcolor='white'] > DIV[style='padding: 10px 158px;'] > DIV, BODY[bgcolor='white'] > DIV[style='padding: 10px 158px;'] > TABLE > TBODY > TR > TD, BODY[bgcolor='white'] > DIV[style='padding: 10px 158px;'] > TABLE > TBODY > TR > TD > DIV   {color:#999 !important;}" +
        /* submit bar bg */
        "TABLE.content > TBODY > TR > TD[valign='middle'][align='right'][style='background-color: rgb(232, 238, 247);']   {background-color:#000 !important;}" +
        /* footer bar bg */
        "BODY[bgcolor='white'] > DIV[style='background-color: rgb(232, 238, 247);']   {background-color:#000 !important;}" +
        
        // Admin
        /* group name bar */
        "BODY[bgcolor='white'] > DIV[style='border-top: 1px solid rgb(119, 153, 221);'], BODY[bgcolor='white'] > DIV[style='padding: 4px 10px; background-color: rgb(232, 238, 247);'], BODY[bgcolor='white'] > DIV[style='border-top: 1px solid rgb(119, 153, 221);']   {border:0 none !important; background-color:#000 !important;}" +
        /* title bar */
        "DIV.maincontheaderbox > DIV.secttlbarwrap > DIV.secttlbar   {background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* spacers */
        "DIV.maincontheaderbox > DIV.secttlbarwrap > DIV > TABLE[width='100%'] > TBODY > TR, DIV.maincontheaderboxatt > DIV > TABLE[width='100%'] > TBODY > TR > TD[width='100%'][height='4'][bgcolor='#e8eeff'], DIV.maincontheaderboxatt > DIV > TABLE[width='100%'] > TBODY > TR > TD[width='100%'][height='4'][bgcolor='#c3d9ff'], DIV.maincontheaderboxatt DIV[style='background: transparent url(/groups/roundedcorners?c=c3d9ff&bc=white&w=4&h=4&a=af) repeat scroll 0px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; width: 4px; height: 4px;'], DIV.maincontheaderboxatt DIV[style='background: transparent url(/groups/roundedcorners?c=c3d9ff&bc=white&w=4&h=4&a=af) repeat scroll 0px 4px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; width: 4px; height: 4px;'], DIV.maincontheaderboxatt DIV[style='background: transparent url(/groups/roundedcorners?c=e8eeff&bc=white&w=4&h=4&a=af) repeat scroll 0px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; width: 4px; height: 4px;'], DIV.maincontheaderboxatt DIV[style='background: transparent url(/groups/roundedcorners?c=e8eeff&bc=white&w=4&h=4&a=af) repeat scroll 0px 4px; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; width: 4px; height: 4px;']   {display:none;}" +
        /* section headers */
        "DIV.maincontheaderboxatt > DIV.sshdr   {padding:5px; background-color:#333 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* right panel */
        "BODY[bgcolor='white'] > DIV.rf DIV   {background-color:#333 !important;}" +
        /* right panel bttm */
        "TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] > TD[style='background-color: rgb(232, 238, 247);']   {background-color:#000 !important;}" +
        /* content border */
        "TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] >  TD.overflow-hide   {border:0 none !important;}" +
        /* page txt */
        "TD.overflow-hide > DIV.maincontheaderboxatt TABLE TBODY TR TD, TD.overflow-hide > DIV[style='text-align: center;'], DIV.mngcontentbox TABLE > TBODY > TR > TD, DIV.mngcontentbox DIV, BODY > DIV.padl1ex SPAN, TD.padt8 TD, TD > DIV#banner    {color:#999 !important;}" +
        /* settings bgs */
        "TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] >  TD.overflow-hide DIV.mnghdrttl, TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] >  TD.overflow-hide DIV.mngbottombox DIV, TD.padall6 > TABLE > TBODY > TR > TD > TABLE[width='500'][bgcolor='#ffffff']   {background-color:#000 !important;}" +
        /* settings spacers */
        "TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] >  TD.overflow-hide > DIV.mngtabbox > DIV:first-child > TABLE[width='100%']   {display:none;}" +
        /* settings actv itm */
        "DIV.mngbottombox > DIV.mnghdrbtm > DIV > SPAN   {color:#fff;}" +
        /* settings o-border */
        "TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] >  TD.overflow-hide > DIV.mngbottombox   {border:0 none !important;}" +
        /* settings i-border */
        "TABLE[class='wdth100 overflow-hide'] > TBODY > TR[valign='top'] >  TD.overflow-hide > DIV.mngbottombox > DIV.mngcontentbox   {border:3px solid #333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        
        /* Groups additionally expanded below in brute force enhancements */
        
        
        // Books enhancements
        /* logo img */
        "BODY > DIV > CENTER > TABLE#top_search_box > TBODY > TR > TD[style='padding-bottom: 8px; padding-top: 2px;'] > A > IMG[height='40'], BODY[bgcolor='#ffffff'] > TABLE > TBODY > TR > TD[valign='top'][rowspan='2'] > A > IMG   {display:none;}" +
        /* announcement */
        "BODY > DIV > CENTER > SPAN.announcement   {color:#999;}" +
        /* headers */
        "BODY > DIV > CENTER > TABLE#hp_table > TBODY > TR > TD > DIV.sbr > DIV.sub_cat_section > DIV.sub_cat_title, BODY > DIV > CENTER > TABLE#hp_table > TBODY > TR > TD DIV.hpm_title, BODY > DIV#results_bar   {background-color:#333 !important; border:0 none !important; font-weight:bold; color:#000 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* menu txt */
        "TABLE#viewport_table > TBODY > TR > TD#menu_td > DIV#menu_container > DIV#menu TD, TABLE#viewport_table > TBODY > TR > TD#menu_td > DIV#menu_container > DIV#menu H3, TABLE#viewport_table > TBODY > TR > TD#menu_td > DIV#menu_container > DIV#menu SPAN   {color:#999 !important;}" +
        /* goog-tooltip */
        "BODY > DIV.goog-tooltip   {background-color:#333 !important; border:0 none !important; color:#000 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* page txt */
        "TABLE#viewport_table > TBODY > TR > TD#viewport_td DIV, TABLE#viewport_table > TBODY > TR > TD#viewport_td H2, BODY > DIV.scontentarea > DIV > DIV.rsiwrapper> TABLE.rsi > TBODY > TR > TD DIV   {color:#999 !important;}" +
        /* buy alternate row */
        "DIV#summary_content > TABLE > TBODY > TR.seller-row-alt   {background-color:#181818;}" +
        /* view block */
        "BODY > DIV#rhswrapper > TABLE#rhssection, BODY > DIV#rhswrapper > TABLE#rhssection TD   {border:0 none; background-color:#000;}" +
        /* rate book block */
        "BODY > DIV[style='border: 1px solid rgb(167, 167, 114); margin: 20px; padding: 20px; background-color: rgb(255, 255, 217); width: 50%;'], BODY > FORM[name='edit_annotations'] DIV   {border:0 none !important; background-color:#000 !important; color:#999 !important;}" +
        /* right-side ads */
        "DIV#rhswrapper > TABLE#rhssection > TBODY > TR > TD   {display:none;}" +
        /* right-side viewToggleCell */
        "DIV#rhswrapper > TABLE#rhssection > TBODY > TR > TD#viewmodetogglecell   {display:inherit;}" +
        /* bottom search bg */
        "BODY > DIV > DIV[style='border-top: 1px solid rgb(107, 144, 218); border-bottom: 1px solid rgb(107, 144, 218); padding: 16px; background: rgb(229, 236, 249) none repeat scroll 0%; font-size: 83%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial;']   {background-color:#000 !important; border:0 none !important;}" +
        /* Books expanded below in brute force enhancements */
        
        
        // Scholar enhancements
        /* logo imgs */
        "BODY[vlink='#551a8b'] > CENTER > TABLE[cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR:first-child > TD:first-child > IMG, BODY > FORM[name='f'] > TABLE[width='99%'] > TBODY > TR:first-child > TD[width='1%'] > A > IMG, BODY > FORM[name='prefform'] > CENTER > TABLE[width='100%'] > TBODY > TR:first-child > TD:first-child > A > IMG[height='40'], BODY > TABLE[style='margin: 7px 3px; clear: both;'] > TBODY > TR:first-child > TD:first-child > A > IMG[height='40'], BODY > FORM[name='gs'] > TABLE#scife_hdr > TBODY > TR:first-child > TD[valign='top']:first-child > A > IMG   {display:none;}" +
        /* pre header line */
        "BODY > FORM[name='f'] > TABLE[width='99%'] > TBODY > TR:first-child > TD > TABLE[width='100%'] > TBODY > TR:first-child > TD[bgcolor='#008000'], BODY > FORM[name='prefform'] > CENTER > TABLE > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR:first-child > TD[bgcolor='#008000'], BODY > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#008000']   {display:none;}" +
        /* header bg */
        "BODY > TABLE[width='100%'][bgcolor='#dcf6db'], BODY > FORM[name='gs'] > TABLE[width='100%'][bgcolor='#dcf6db'], BODY > FORM[name='gs'] > TABLE[width='100%'][bgcolor='#dcf6db'] TD   {background-color:#000;}" +
        /* header R */
        "BODY > FORM[name='f'] > TABLE[width='99%'] > TBODY > TR:first-child > TD > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#dcf6db'][align='right'], BODY > FORM[name='prefform'] > CENTER > TABLE > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR:first-child > TD[bgcolor='#dcf6db'][align='right'], BODY > TABLE[width='100%'][bgcolor='#dcf6db'] > TBODY > TR > TD[bgcolor='#dcf6db'][align='right']   {padding-right:0.5em; background-color:#333 !important; -moz-border-radius-topright:14px; -moz-border-radius-bottomright:14px;}" +
        /* header L */
        "BODY > FORM[name='f'] > TABLE[width='99%'] > TBODY > TR:first-child > TD > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#dcf6db']:first-child, BODY > FORM[name='prefform'] > CENTER > TABLE > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR:first-child > TD[bgcolor='#dcf6db']:first-child, BODY > TABLE[width='100%'][bgcolor='#dcf6db'] > TBODY > TR > TD[bgcolor='#dcf6db']:first-child   {padding-left:0.5em; background-color:#333 !important; -moz-border-radius-topleft:14px; -moz-border-radius-bottomleft:14px;}" +
        /* box bgs */
        "BODY > FORM[name='f'] > TABLE[width='99%'] TD, BODY > FORM[name='prefform'] > CENTER > TABLE[width='100%'] > TBODY > TR[bgcolor='#dcf6db']   {background-color:#000 !important;}" +
        /* table cell override */
        "BODY > FORM[name='f'] > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD[width='40%']   {-moz-border-radius-topright:0; -moz-border-radius-topleft:0; -moz-border-radius-bottomright:0; -moz-border-radius-bottomleft:0;}" +
        /* bottom search box */
        "BODY > CENTER > TABLE[width='100%'] > TBODY > TR > TD.k, BODY > CENTER > TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#dcf6db']   {background-color:#000;}" +
        /* bottom search page nums W */
        "BODY > DIV.n > TABLE[width='1%']   {width:inherit !important; border-spacing:1em;}" +
        /* bottom search page nums */
        "BODY > DIV.n > TABLE[width='1%'] > TBODY > TR > TD IMG   {display:none;}" +
        /* footer */
        "BODY > FORM[name='f'] > CENTER:last-child > FONT[size='-1'], BODY > FORM[name='prefform'] > CENTER > P:last-child > FONT[size='-1']   {display:none;}" +
        /* Scholar: Support expanded below in brute force enhancements */
        
        
        // Blogs enhancements
        /* logo imgs */
        "BODY > DIV > TABLE#srch_box_t > TBODY > TR > TD:first-child > A > IMG[height='40'], BODY > DIV#h > TABLE:first-child > TBODY > TR > TD:first-child > A > IMG   {display:none;}" +
        /* pre header line */
        "BODY TABLE[width='100%'] > TBODY > TR > TD.tpb   {display:none;}" +
        /* headers */
        "BODY > DIV#canvas > DIV.heading, DIV#rightHandContainer DIV.heading, BODY TABLE.ttt, BODY TABLE.ttt TD   {padding-left:0.7em; background-color:#333; border:0 none !important; color:#ccc!important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* menu divider */
        "DIV#main > DIV#sideBarContainer > DIV#sideBarWrap   {border-color:#333;}" +
        /* menu r-line */
        "BODY > DIV#m > DIV.ln   {border-right-color:#333;}" +
        /* menu highlights */
        "UL#sideLinksList > LI.selected, DIV#sideBarWrap > DIV#feedsContainer > DIV > DIV.sbiTitle   {background-color:#222 !important; color:#fff !important;}" +
        /* page txt */
        "TABLE#buzzlistTable TR.clusterGroup DIV.entryText SPAN, TABLE#buzzlistTable TR.clusterGroup DIV.entryText DIV   {color:#999 !important;}" +
        /* bottom search bg */
        "BODY > DIV#f > CENTER > TABLE > TBODY > TR > TD.bts   {background-color:#000;}" +
        /* bottom search borders */
        "BODY > DIV#f > CENTER > TABLE > TBODY > TR > TD.btb   {display:none;}" +
        /* footer */
        "BODY > CENTER > CENTER > FONT[size='-2']:last-child, BODY > DIV#f > CENTER:last-child > FONT[size='-2']   {display:none;}" +
        /* Blogs: Advanced Search expanded below in brute force enhancements */
        
        
        // Code enhancements
        /* logo imgs */
        "#logo IMG[src='/images/code_sm.png'], TABLE[style='margin: 0px 0px -6px 0pt; padding: 0px; width: 100%;'] TD[style='width: 153px;'] IMG[src='/hosting/images/code_sm.png'], #logo IMG[src='http://code.google.com/images/code_sm.png']   {display:none;}" +
        /* search button bg */
        ".gsc-search-box .gsc-search-button   {background-color:#000;}" +
        /* search suggest */
        ".gsc-search-box .greytext   {background-color:#000 !important; color:#999 !important;}" +
        /* header bars */
        "#gc-topnav, #gc-topnav H1, #header #title, TABLE.mainhdr, #issueheader, #issueheader TABLE TBODY TR TD, #makechanges DIV.h4   {padding-right:10px; background-color:#333; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#000 !important;}" +
        /* page txt */
        "#gc-home DIV, #codesiteContent DIV, #body, #body DIV, #body TABLE TBODY TR TD DIV, #maincol DIV, #maincol DIV TABLE TBODY TR TD, #maincol P, #maincol H4, #issuemeta, #issuemeta TD, TABLE.issuepage TBODY TR TD[class='vt issuedescription'], DIV.content DIV, DIV.content DIV DIV DIV H2, DIV.content DIV DIV TABLE TBODY TR TD   {color:#999 !important;}" +
        /* section headers */
        "DIV.g-unit H2, .g-c .column-title, #gc-toc UL.treelist LI H1, #gc-toc UL.treelist LI H2, #gc-pagecontent H1   {margin-top:10px; padding-top:2px; padding-left:4px; border:0; background-color:#333; -moz-border-radius-topleft:14px;-moz-border-radius-topright:14px;  color:#fff;}" +
        /* labels tables */
        ".g-c .labels-table DIV   {background-color:#333;}" +
        /* box bgs */
        "#products-list, #preview-box   {border:0; background-color:#000 !important;}" +
        /* project tabs */
        "TABLE#mt TBODY TR TH   {background:#333 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* project tab round bg */
        "TABLE#mt TBODY TR TH DIV   {background-image:none !important;}" +
        /* project details */
        "#codesiteContent TABLE.columns TBODY TR TD   {background-color:#000; color:#999 !important;}" +
        /* docs toc bg */
        "#gc-toc UL.treelist LI UL LI   {background-color:inherit;}" +
        /* docs sidebar bg */
        "#maincol .pmeta_bubble_bg, .rounded_ul, .rounded_ur, .rounded_ll, .rounded_lr, DIV[style='background: rgb(221, 248, 204) none repeat scroll 0%; -moz-background-clip: -moz-initial; -moz-background-origin: -moz-initial; -moz-background-inline-policy: -moz-initial; margin-bottom: 5px; table-layout: fixed;'], .vt DIV.tip   {background:#333 none !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* docs code bg */
        "PRE   {background-color:#ccc;}" +
        /* downloads search bar */
        "TABLE.st TBODY TR TD, TABLE.st TBODY TR TD DIV, TABLE.st TBODY TR TD DIV DIV SPAN   {background:#000 none !important; color:#999 !important;}" +
        /* downloads results table */
        ".bubble_bg, TABLE#resultstable TBODY TR TH, TABLE#resultstable TBODY TR TD   {border-bottom-color:#333; border-left-color:#333; background:#000;}" +
        /* org info block */
        "#body TABLE TBODY TR TD DIV.extern_app   {background:#333 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* org info app list */
        "#body DIV TABLE.applist   {background:#333 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* org info app details */
        "#body DIV TABLE.applist TBODY TR TD   {color:#fff !important;}" +
        /* org info app text */
        "#body DIV TABLE.applist TBODY TR TD DIV.app_text   {padding:10px; background:#000 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#fff !important;}" +
        /* alerts & messages */
        "#codesiteContent P.note, #codesiteContent P.caution, #codesiteContent P.warning, #codesiteContent DIV.noticebox, #nowShowingDiv, DIV[class='bottom clearfix'] DIV.blog   {padding-top:4px; padding-bottom:5px; border:0; background:#333 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#fff;}" +
        /* collapsible bg */
        "#gc-collapsible   {border:2px solid #333; background:#333 none !important;}" +
        /* footer bg */
        "DIV#gc-footer   {background:#000 none;}" +
        /* Code expanded below in brute force enhancements */
        
        
        // Experimental enhancements
        /*   These two maintained for older G.versions, expanded below and in brute force enhancements: */
        /* logo img */
        "BODY > DIV#container > DIV#header > DIV[style='float: left; width: 155px;'] IMG[width='150'][height='55']   {display:none;}" +
        /* content */
        "BODY > DIV#container > DIV#content   {color:#999 !important;}" +
        
        /*   New web search results implementations: */
        /* right side drop menu */
        "BODY#gsr > DIV#header > DIV.std > SPAN[style='background: rgb(255, 255, 255) none repeat scroll 0% 0%; float: right; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; position: relative;']   {background-color:#555 !important; padding-right:0.25em; padding-left:0.25em; color:#fff !important; text-decoration:none; -moz-border-radius-topright:7px; -moz-border-radius-topleft:7px; -moz-border-radius-bottomright:7px; -moz-border-radius-bottomleft:7px;}" +
        /* right side drop menuLink */
        "BODY#gsr > DIV#header > DIV.std > SPAN[style='background: rgb(255, 255, 255) none repeat scroll 0% 0%; float: right; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; position: relative;'] A, BODY#gsr > DIV#header > DIV.std > SPAN[style='background: rgb(255, 255, 255) none repeat scroll 0% 0%; float: right; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; position: relative;'] A U   {color:#fff !important; text-decoration:none !important;}" +
        /* right side drop menu drop */
        "BODY#gsr > DIV#header > DIV.std > SPAN[style='background: rgb(255, 255, 255) none repeat scroll 0% 0%; float: right; -moz-background-clip: border; -moz-background-origin: padding; -moz-background-inline-policy: continuous; position: relative;'] > DIV#exp_info   {background-color:#333 !important;}" +
        /* keyboard legend bg */
        "BODY DIV#cnt TABLE.mbEnd, BODY DIV#cnt TABLE.mbEnd TD   {border:0 none !important; background-color:#000 !important;}" +
        /* keyboard chevron */
        "BODY DIV#res > DIV > OL > LI.g > IMG[src='/images/chevron.gif']   {padding:1px; background-color:#fff;}" +
        /* keyboard exp Key title */
        "BODY TABLE.mbEnd > TBODY > TR > TD.std > CENTER.f   {font-weight:bold; color:#fff;}" +
        
        
        // Support enhancements
        /* logo img */
        "TABLE[align='center'] TBODY TR TD[width='155'][rowspan='2'] A IMG, TABLE[align='center'] TBODY TR[valign='middle'] TD[width='135'] IMG, BODY.answer_page TABLE.header_table > TBODY > TR > TD.header_logo_td > A[href='/'] > IMG[alt='Google']   {display:none;}" +
        /* header */
        "TABLE[style='border-bottom: 1px solid rgb(37, 71, 157);'] TBODY TR TD, DIV#baseDiv > DIV.header_wrapper > TABLE.header_table *   {background-color:#000; color:#fff !important;}" +
        /* page title */
        "TABLE[style='border-bottom: 1px solid rgb(37, 71, 157);'] TBODY TR TD.header H1   {color:#fff !important;}" +
        /* headline color */
        "BODY.answer_page H2, BODY.answer_page H3, BODY.answer_page H4   {color:#ccc;}" +
        /* page txt */
        "TABLE[style='border-bottom: 1px solid rgb(37, 71, 157);'] TBODY TR TD, TABLE TBODY TR TD P, #content, BODY.answer_page OL, BODY.answer_page FORM   {color:#999 !important;}" +
        /* head tabs */
        "#tabs TABLE TBODY TR TD DIV   {border:0; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* head tabs */
        "#tabs TABLE TBODY TR TD DIV DIV.link A   {color:#000 !important;}" +
        /* answer name */
        "TABLE TBODY TR TD H3.answername   {color:#fff !important;}" +
        /* info boxes */
        "BODY.answer_page DIV.lightbulb, BODY.answer_page DIV.module   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* info box module title bg */
        "BODY.answer_page DIV.module > H2   {background-color:transparent; color:#ccc;}" +
        /* side bar headers */
        "TABLE.smfont TBODY TR TD.module_hdr   {border:0; background:#333 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* side bar header txt */
        "TABLE.smfont TBODY TR TD.module_hdr H4, TABLE.smfont TBODY TR TD.module_hdr H4 LABEL, TABLE.smfont TBODY TR TD.module_hdr B   {color:#000 !important;}" +
        /* side bar block bg */
        "TABLE.smfont TBODY TR TD   {border:0 none #000 !important; background-color:#000;}" +
        /* bottom tools */
        "TABLE TBODY TBODY TR TD[style='border-bottom: 1px solid rgb(204, 204, 204);'] B   {color:#fff !important;}" +
        /* bottom help box */
        "TABLE.answerfooter   {border:0 none; background:#333 none; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* bottom help txt */
        "TABLE.answerfooter TBODY TR TD DIV FONT, TABLE.answerfooter TBODY TR TD DIV FONT B, TABLE.answerfooter TBODY TR TD DIV FONT NOBR   {color:#fff !important;}" +
        
        
        // Patents enhancements
        /* logo img */
        "BODY > DIV[style='clear: both;'] > CENTER > TABLE[cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD > IMG, BODY > DIV#top_search_bar > DIV[style='padding: 1px 10px 0px 6px; float: left;'] > A > IMG#logo, BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='clear: both;'] > TBODY > TR > TD[valign='top'][rowspan='2'] > A > IMG   {display:none;}" +
        /* titlebar */
        "BODY > DIV#titlebar, BODY > TABLE#results_bar   {padding-left:0.5em; border:0 none !important; background-color:#333 !important; font-weight:bold; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* titlebar txt */
        "BODY > DIV#titlebar H1, BODY > DIV#titlebar SPAN   {color:#fff !important;}" +
        /* menu active */
        "BODY > TABLE#viewport_table > TBODY > TR > TD#menu_td > DIV#menu_container > DIV#menu DIV.menu_content > DIV > DIV.sidebarnav > SPAN.nolink   {color:#fff;}" +
        /* headers */
        "BODY > TABLE#viewport_table > TBODY > TR > TD#viewport_td H3   {border:0; background-color:#222 !important; color:#ccc; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* page txt */
        "BODY > TABLE#viewport_table > TBODY > TR > TD#viewport_td > DIV.vertical_module_list_row TD, BODY > TABLE#viewport_table > TBODY > TR > TD#viewport_td DD, BODY > DIV.scontentarea DIV P, BODY > DIV.scontentarea > SPAN.big   {color:#ccc !important;}" +
        /* footer */
        "BODY > DIV#footer_table > SPAN, BODY > DIV > DIV#footer_table > SPAN, BODY > DIV[align='center'] > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD.k   {display:none;}" +
        /* Advanced Search expanded below in brute force enhancements */
        
        
        // Toolbar enhancements
        /* logo imgs */
        "BODY[bgcolor='#ffffff'][topmargin='3'] CENTER TABLE[width='725'] TBODY TR TD IMG[width='143'][height='59'][src='../../../../common/toolbar_sm.gif'], TABLE[width='100%'][style='direction: ltr;'] TBODY TR TD A[href='http://toolbar.google.com'] IMG, BODY > TABLE[width='100%'] > TBODY > TR > TD > A[href='../../T4/'] IMG[width='143'][height='59'], BODY.siteowners > TABLE[width='96%'] > TBODY > TR > TD[width='1%'] > A > IMG, BODY.siteowners IMG[src='http://www.google.com/images/art.gif']   {display:none;}" +
        /* page title */
        "BODY > TABLE[width='100%'][style='direction: ltr;'] > TBODY > TR > TD[width='100%'], BODY > TABLE[width='100%'][style='direction: ltr;'] > TBODY > TR > TD[width='100%'] TABLE TBODY TR TD   {background-image:none !important; color:#fff !important;}" +
        /* download box */
        "BODY[bgcolor='#ffffff'][topmargin='3'] CENTER TABLE TBODY TR TD TABLE#download TBODY TR TD   {background-color:#000; border:0 !important;}" +
        /* bottom logo(s) */
        "TABLE TBODY TR TD[nowrap='nowrap'] IMG[src='http://www.google.com/nav_first.gif'], TABLE TBODY TR TD[nowrap='nowrap'] IMG[src='http://www.google.com/nav_current.gif'], TABLE TBODY TR TD[nowrap='nowrap'] IMG[src='http://www.google.com/nav_page.gif'], TABLE TBODY TR TD[nowrap='nowrap'] IMG[src='http://www.google.com/nav_next.gif']   {display:none;}" +
        
        /* Toolbar expanded below in brute force enhancements */
        
        // API
        /* page title */
        "BODY > TABLE[width='100%'] > TBODY > TR > TD[width='100%'][style='padding-left: 15px;'] TABLE TBODY TR TD FONT STRONG   {padding-left:131px; color:#fff !important;}" +
        /* start making btn */
        "TABLE TBODY TR TD#content DIV#start_box   {border:1px solid #fff; background-color:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* header bars */
        "TABLE TBODY TR TD#content H2.header   {border:0; background:#333; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* page-code */
        "TABLE TBODY TR TD#content PRE   {color:#000;}" +
        /* page block bgs */
        "TABLE TBODY TR TD#content DIV, BODY.siteowners TABLE TBODY TR TD   {background-color:#000 !important;}" +
        
        
        // Firefox Tools enhancements
        /* logo img */
        "BODY > CENTER > DIV > TABLE[width='739'] > TBODY > TR > TD[width='1%'] A IMG   {display:none;}" +
        /* page titlebar */
        "BODY > CENTER > DIV > TABLE[width='739'] > TBODY > TR > TD[width='100%']   {width:100%; padding-left:151px; color:#fff;}" +
        /* page txt */
        "BODY > CENTER > DIV > TABLE[width='100%'] > TBODY > TR > TD, BODY > CENTER > DIV > TABLE[width='100%'] > TBODY > TR > TD TABLE TBODY TR TD, BODY > CENTER > DIV[style='margin: 20px 30px; text-align: left; width: 740px;'] *   {color:#999 !important;}" +
        /* more header */
        "BODY > CENTER > DIV > TABLE[width='100%'] > TBODY > TR > TD H3[style='border-bottom: 1px solid rgb(37, 71, 157); font-size: 17px; background-color: rgb(255, 255, 255); padding-bottom: 4px;']   {padding-left:7px; border:0 none !important; background-color:#333 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px; color:#000;}" +
        /* right col block */
        "BODY > CENTER > DIV > TABLE[width='100%'] > TBODY > TR > TD DIV.rightcol   {background-color:#333 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* install extension */
        "BODY > CENTER > DIV[style='margin: 20px 30px; text-align: left; width: 740px;'] DIV.extension  {background-color:#333 !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* extension whitelist */
        "BODY > CENTER > DIV[style='margin: 20px 30px; text-align: left; width: 740px;'] DIV.whitelist  {border:2px solid #fff; background-color:#000; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        
        
        // MonkeyBarrel Google enhancements
        /* shift down slightly */
        "DIV[style='position: fixed; top: 10px; left: 10px; margin-bottom: 10px; background-color: transparent; z-index: 99999;']   {top:28px !important; left:2px !important;}" +
        
        
        // Notebook enhancements
        /* logo img */
        "BODY.e > DIV.h TABLE#gn_ph > TBODY > TR:first-child > TD[align='right']:first-child > A > IMG   {visibility:hidden;}" +
        /* left menu border */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR[valign='top'] > TD[align='left'] > DIV.jc > DIV > DIV.wb   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* left menu header */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR[valign='top'] > TD[align='left'] > DIV.jc DIV.vb   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* left menu lower-block */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR[valign='top'] > TD[align='left'] > DIV.jc TABLE.vb, BODY.e > DIV.h > TABLE.p > TBODY > TR > TD > DIV.jc > DIV.rc > DIV TABLE.rb  {display:none;}" +
        /* left menu C-footer */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR[valign='top'] > TD[align='left'] > DIV.jc > DIV.bf   {display:none;}" +
        /* labels block header */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR > TD > DIV.jc > DIV.rc > DIV[class='sc rb']   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px;}" +
        /* labels lower block */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR > TD > DIV.jc > DIV.rc > DIV[class='wc sb']   {border-bottom:2px solid #b5edbc; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* tip bar */
        "BODY.e TD.cb > SPAN.eb   {-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* page txt */
        "BODY.e > DIV.h > TABLE.p > TBODY > TR > TD > DIV > DIV.m > DIV.oa > DIV.zg > DIV.dh > DIV.hh > DIV:first-child   {color:#000;}" +
        /* faq logo img */
        "BODY[bgcolor='#ffffff'] > TABLE[cellpadding='5'][align='center'] > TBODY > TR[valign='middle'] > TD[width='1%'] > A[href='http://www.google.com/notebook'] > IMG   {display:none;}" +
        /* faq title block */
        "BODY[bgcolor='#ffffff'] > TABLE[cellpadding='5'][align='center'] > TBODY > TR[valign='middle'] > TD > TABLE[width='100%'][bgcolor='#c3d9ff'][align='center'][style='margin-bottom: 5px;'] TBODY TR TD   {background-color:#000;}" +
        /* faq title block corners */
        "BODY[bgcolor='#ffffff'] > TABLE[cellpadding='5'][align='center'] > TBODY > TR[valign='middle'] > TD > TABLE[width='100%'][bgcolor='#c3d9ff'][align='center'][style='margin-bottom: 5px;'] TBODY TR TD IMG   {display:none;}" +
        /* faq list txt */
        "OL.answers LI UL.response LI, OL.response LI   {color:#999 !important;}" +
        /* Notebook expanded below in brute force enhancements */
        
        
        // Translate enhancements
        /* logo img */
        "BODY > DIV#whole > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD[width='1%'][height='40'] > A > IMG, BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD[width='1%'][height='40'] > A > IMG, BODY > DIV#whole > DIV[style='margin: 10px 0pt 5px;'] > A > IMG[height='40'], BODY[marginheight='3'][topmargin='3'] > DIV[style='margin: 10px 0pt 5px;'] > A > IMG[height='40']   {display:none;}" +
        /* logo-bar 2nd remove */
        "BODY > DIV#whole > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD[width='100%'][valign='top'][align='right'], BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD[width='100%'][valign='top'][align='right']   {background-image:none !important;}" +
        /* head menu */
        "BODY > DIV#whole > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD > DIV[style='margin: 4px 0pt; padding: 0pt;'] > TABLE > TBODY > TR > TD, BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD > DIV[style='margin: 4px 0pt; padding: 0pt;'] > TABLE > TBODY > TR > TD   {background-color:#000; border:0 none;}" +
        /* head menu active */
        "BODY > DIV#whole > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD > DIV[style='margin: 4px 0pt; padding: 0pt;'] > TABLE > TBODY > TR > TD.active, BODY > TABLE[cellspacing='0'][cellpadding='0'][border='0'][style='font-size: medium;'] > TBODY > TR > TD > DIV[style='margin: 4px 0pt; padding: 0pt;'] > TABLE > TBODY > TR > TD.active   {color:#fff !important;}" +
        /* header bg */
        "BODY > DIV#content > DIV.resulthd   {background-color:#000;}" +
        /* headers */
        "BODY > DIV#whole H1, BODY > DIV#whole H2, BODY > DIV#content H1, BODY[marginheight='3'][topmargin='3'] > H1, BODY > DIV#whole > DIV#middle_body > DIV#autotrans, BODY > DIV#whole > DIV#middle_body > DIV#dict > P#dict_head   {background-color:#333 !important; color:#fff; padding-left:0.7em; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* middle body L-border */
        "BODY > DIV#whole > DIV#middle_body   {border-color:#333;}" +
        /* page txt */
        "BODY > DIV#whole > DIV#main > DIV, BODY > DIV#whole > DIV#main > DIV DIV, BODY > DIV#whole > FORM#text_form TD, BODY > DIV#content DIV, BODY > DIV#content TABLE > TBODY > TR > TD, BODY[marginheight='3'][topmargin='3'] > DIV.section, BODY[marginheight='3'][topmargin='3'] > DIV.section LI   {color:#ccc !important;}" +
        /* result txt */
        "BODY > DIV#whole > FORM#text_form > TABLE#texttable > TBODY > TR > TD.almost_half_cell > DIV#result_box   {color:#fff !important;}" +
        /* boxes */
        "BODY > DIV#whole > DIV#main >  DIV#alang, BODY[marginheight='3'][topmargin='3'] > DIV.section > TABLE > TBODY > TR > TD.main, BODY[marginheight='3'][topmargin='3'] > DIV.section > DIV#toolbar_float, BODY > DIV#content > DIV.section > TABLE > TBODY > TR > TD.main   {padding-top:0.7em; padding-bottom:0.5em; background-color:#191919; border:0 none; color:#ccc !important;padding-left:1em; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* footer */
        "BODY > DIV#whole > DIV#foot, BODY > DIV#whole > DIV.footer, BODY DIV.tab_footer, BODY > DIV.tab_footer   {display:none;}" +
        /* Translate Top Frame expanded below in brute force enhancements */
        
        
        // Profile enhancements
        /* page txt */
        "DIV.vcard DIV, UL.g-section > LI > B   {color:#999 !important;}" +
        /* about box */
        "DIV.g-section > UL.g-section   {background-color:#000;}" +
        /* about tab */
        "DIV.g-section > UL.g-section LI#about_tab   {background-color:#000; -moz-border-radius-topright:8px; -moz-border-radius-topleft:8px;}" +
        /* footer logo */
        "DIV.ll_footer IMG.logo   {display:none;}" +
        /* search logo img [hide] */
        "BODY.ll_page_body > DIV > DIV.profile-results-header-search > FORM[name='profilesearch'] > IMG.logo   {display:none;}" +
        /* search logo img [insert] */
        "BODY.ll_page_body > DIV > DIV.profile-results-header-search > FORM[name='profilesearch']   {padding:0px 0 17px 150px; background:transparent url('" +
        googleLogoBLACK +
        "') no-repeat scroll 0% !important;}" +
        /* search header */
        "BODY.ll_page_body > DIV > TABLE.profile-results-header-ribbon   {border:0 none; background-color:#333 !important; color:#fff; padding-left:0.7em;-moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* search B-pagination W */
        "BODY.ll_page_body > DIV > DIV.profile-results-paginator > DIV.p > TABLE[width='1%']   {width:33% !important;}" +
        /* search B-pagination */
        "BODY.ll_page_body > DIV > DIV.profile-results-paginator > DIV.p > TABLE[width='1%'] > TBODY > TR[valign='top'][align='center'] > TD IMG   {display:none;}" +
        /* search B-searchForm */
        "BODY.ll_page_body > DIV > TABLE.profile-results-footer-ribbon   {border:0 none; background-color:#000;}" +
        /* Profiles Main-page expanded below in brute force enhancements */
        
        
        // Firefox Start enhancements
        /* search outer */
        "FORM[name='f'] > TABLE#frame   {margin-top:50px; padding-left:20px; background-color:#fff; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* search inner */
        "FORM[name='f'] > TABLE#frame > TBODY > TR > TD > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='100%'] > TABLE[cellspacing='0'][cellpadding='0']   {margin:20px; padding: 0 13px 13px 20px; background-color:#000; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}" +
        /* search inner left-col */
        "FORM[name='f'] > TABLE#frame > TBODY > TR > TD > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='100%'] > TABLE[cellspacing='0'][cellpadding='0'] > TBODY > TR > TD > IMG[width='40'][height='1']   {display:none;}" +
        /* Google logo removal */
        "BODY > CENTER > FORM > TABLE#frame > TBODY > TR > TD > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD > TABLE > TBODY > TR > TD > DIV[title='Google']   {visibility:hidden;}" +
        /* orange search button */
        "FORM[name='f'] > TABLE#frame > TBODY > TR > TD > TABLE[width='100%'][cellspacing='0'][cellpadding='0'][border='0'] > TBODY > TR > TD[width='100%'] > TABLE[cellspacing='0'][cellpadding='0'] > TBODY > TR > TD INPUT[type='submit']:hover   {background-color:#f60;}" +
        /* bottom tables */
        "BODY[onload='sf()'] > CENTER > FORM > TABLE#frame > TBODY > TR > TD > TABLE[width='100%'] > TBODY > TR > TD > TABLE[width='100%'][cellpadding='4']   {display:none;}" +
        
        
        // Gm-Script Google Search Sidebar enhancements - http://userscripts.org/scripts/show/11888
        /* sidebar width */
        "#searchPlus   {width:26% !important; float:right !important;}" +
        /* sidebar txt */
        "#searchPlus DIV P, .luna-Ent td   {color:#fff !important;}" +
        /* sidebar header */
        "#searchPlus H1, DIV#gSearchSidebar H1   {margin-top:1em; background-color:#333 !important; border:0 none !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; color:#fff;}" +
        /* sidebar header link */
        "#searchPlus H1 A, DIV#gSearchSidebar H1 A   {color:#000 !important;}" +
        
        
        // Script Update Message Box
        /* layout */
        "#gsscriptVersionMessage   {position:fixed; top:0px; right:1px; width:470px; height:76px; z-index:99; overflow:auto; padding:10px; background-color:#C00040; outline:#aaa solid 1px; font-family:Trebuchet MS, Verdna; font-weight:bold; font-size:14px; color:#fff !important; text-align:center; cursor:default;}";
        
        
        
        // BRUTE-FORCE for "less cooperative" sites (each URI validated)
        var style = document.createElement('style');
        style.setAttribute('id', 'bruteForce');
        document.getElementsByTagName('head')[0].appendChild(style);
        //stylesheet insert rule shortcut-func
        function sIR(style){
            getEl('bruteForce').sheet.insertRule(style, 0);
        }
        
        // Global B.F. enhancements
        function gBFenh(){
            /* Global font */
            sIR("*   {font-family:Trebuchet MS, Verdna;}");
            /* page bg */
            sIR("HTML,BODY   {background:#000 none !important; color:#fff;}");
            /* link color */
            sIR("A, #gbar A.gb1, #gbar A.gb2, #gbar A.gb3, #gbar A.gb4, SPAN.i, .linkon, #codesiteContent A, TABLE.mmhdr TBODY TR TD.mmttlinactive SPAN, TABLE TBODY TR TD TABLE TBODY TR TD A, SPAN#show-new, SPAN#show-all, SPAN.link, SPAN[dir='ltr'] > FONT[color='blue'], FONT[color='blue'][dir='ltr'], .gc-control, .goog-flat-menu-button, .gsc-tabHeader.gsc-tabhInactive, .goog-tab-bar-top .goog-tab, DIV.search-options-header-link   {color:#6495ed !important;}");
            /* visited linx */
            sIR("A:visited   {color:#406b80 !important;}");
            /* resultsvisitedlnx */
            sIR("DIV#res A:visited   {font-size:0.8em !important;}");
            /* header */
            sIR("#guser, #guser *, #gbar, #gbar *   {background-color:transparent !important; font-family:Trebuchet MS, Verdna !important; color:#ccc;}");
            /* google bar txt */
            sIR("#gbar SPAN   {color:#999;}");
            /* google bar txt */
            sIR("#gbar DIV.gb1   {background-color:#c9d7f1 !important;}");
            /* google bar txt */
            sIR("#gbar DIV.gb2   {padding-top:0; padding-bottom:0; background-color:#c9d7f1 !important;}");
            /* google bar linx */
            sIR("#gbar A.gb1, #gbar B.gb1, #gbar A.gb3   {font-weight:bold !important; font-size:1.15em !important;}");
            /* google bar b-line */
            sIR("#gbh, .gbh   {border-color:#777;}");
            /* search input */
            sIR("INPUT[type='text'], INPUT[type='password'], INPUT[name='q']   {background:#333 none !important; color:#fff; padding:2px; border:solid 1px #ccc; font-weight:bold; color:#ff0 !important;}");
            /* submit button */
            sIR("INPUT[type='submit'], INPUT[type='button'], .yt-button-primary   {background:#333 none !important; border:solid 1px #ccc !important; -moz-border-radius-topright:14px !important; -moz-border-radius-topleft:14px !important; -moz-border-radius-bottomright:14px !important; -moz-border-radius-bottomleft:14px !important; color:#fff !important; cursor:pointer;}");
            /* submit btn hover */
            sIR("INPUT[type='submit']:hover, BUTTON[type='submit']:hover, INPUT[type='button']:hover   {background-color:#36f; color:#fff;}");
            /* div btn outer */
            sIR(".goog-button-base-outer-box   {border-top-color:#555; border-bottom-color:#333;}");
            /* div btn inner */
            sIR(".goog-button-base-inner-box   {border-left-color:#555; border-right-color:#333; background-color:#555;}");
            /* div btn inner txt */
            sIR(".goog-button-base-content   {color:#bbb !important;}");
            /* div btn inner txtH*/
            sIR(".goog-button-base-content:hover   {color:#fff !important;}");
            /* div btn T-shadow */
            sIR(".goog-button-base-top-shadow   {background-color:#777; border-bottom-color:#555;}");
            /* div btn restrict */
            sIR("#search-restrict   {border-bottom-color:#000;}");
            /* menu dropd folder */
            sIR("DIV.goog-menu > DIV.goog-menuitem > DIV.goog-menuitem-content   {color:#ccc !important;}");
            /* menu dropd item */
            sIR("DIV.goog-menu > DIV.goog-menuitem   {background-color:#222; color:#999 !important;}");
            /* menu dropd itemHov*/
            sIR("DIV.goog-menu > DIV.goog-menuitem:hover   {background-color:#333; color:#ccc !important;}");
            /* more pop layer */
            sIR("SPAN#more, #gbar .gb2   {background-color:#333 !important; border-right:solid 1px #a2bae7; border-bottom:solid 1px #a2bae7; color:#333 !important;}");
            /* 404 error header */
            sIR("BODY[text='#000000'][bgcolor='#ffffff'] TABLE[width='100%'] > TBODY > TR > TD[bgcolor='#3366cc']:first-child   {background-color:#000;}");
        }
        
        
        
        // Reader enhancements
        if (location.href.indexOf('.google.') > -1 && (location.href.indexOf('/reader/') > -1 || location.href.indexOf('/reader/view/') > -1)) {
            /* Global BF Styles */
            gBFenh();
            
            /* top linx */
            sIR("DIV#gbar > NOBR   {top:-2px;}");
            /* logo img [replac] */
            sIR("A#logo-container > H1#logo   {z-index:1000; width:145px !important; height:50px !important; background:transparent url('" + googleLogoBLACK + "') no-repeat scroll 0 -10px !important; font-size:0;}");
            /* addSub btn */
            sIR("DIV#lhn-add-subscription   {position:relative; top:15px; left:0;}");
            /* addSub box */
            sIR("DIV#quick-add-bubble-holder   {background-color:#000; border:1px solid #777; color:#ccc !important; -moz-border-radius-topright:8px; -moz-border-radius-bottomright:8px; -moz-border-radius-bottomleft:8px;}");
            /* border */
            sIR("DIV#chrome   {border:0 none;}");
            /* hdr */
			/* #555-> black*/
            sIR("DIV#chrome-header   {background-color:#000; border:0; color:#fff !important; -moz-border-radius-topleft:14px;}");
            /* hdr v-Linx */
            sIR("DIV#chrome-header > SPAN#chrome-view-links   {background-color:#555;}");
            /* menu txt */
            sIR(".lhn-section a, .lhn-section a .text, .lhn-section .link, UL#your-items-tree LI, SPAN.name > SPAN, UL#friends-tree *, UL#sub-tree LI   {color:#888 !important;}");
            /* menu sel/h */
            sIR(".scroll-tree LI A:hover, .scroll-tree LI .tree-link-selected, .scroll-tree LI .tree-link-selected SPAN, .scroll-tree LI .tree-link-selected:hover, #lhn-selectors .selector:hover, #lhn-selectors .selected, #lhn-selectors .selected SPAN, #lhn-selectors .selected:hover   {background-color:#555; color:#fff !important;}");
            /* menu spcng */
            sIR("DIV#lhn-selectors, DIV#your-items-tree-container, DIV.lhn-section, DIV.friends-tree-notification-info   {margin-top:1.5em;}");
            /* light grey */
            sIR("TABLE#chrome-viewer-container > TBODY > TR > TD#chrome-lhn-toggle, TABLE#chrome-viewer-container > TBODY > TR > TD#chrome-viewer, DIV.setting-body, #settings #settings-navigation .selected   {background-color:#555 !important;}");
            /* dark grey */
            sIR("TABLE#chrome-viewer-container > TBODY > TR > TD#chrome-viewer > DIV#viewer-header, TABLE#chrome-viewer-container > TBODY > TR > TD#chrome-viewer > DIV#viewer-footer, DIV.tab-group > DIV.tab-header-selected, DIV.card-actions   {background-color:#333 !important;}");
            /* black bg */
            sIR("DIV#lhn-selectors, DIV#lhn-friends, DIV#lhn-subscriptions, DIV#lhn-recommendations, TABLE#chrome-viewer-container > TBODY > TR > TD#chrome-viewer > DIV#viewer-container, DIV#entries > DIV.entry, UL#your-items-tree LI, UL#friends-tree *, DIV#viewer-page-container, DIV#friends-manager, UL#sub-tree LI, DIV.preview-interruption, DIV.friend-interruption, DIV.interruption, DIV#settings > TABLE TD, DIV.tab-group, DIV.tab-group-contents, DIV#discover-container, DIV.tab-group > DIV.tab-header, DIV#directory-search-container, DIV#recommendations-tab-contents, DIV.card-common, DIV.entry-likers, DIV.fr-modal-dialog DIV, DIV.entry-comments, DIV.entry > DIV.comment-entry, .scroll-tree LI   {background:#000 none !important;}");
            /* no borders */
            sIR("DIV#lhn-selectors, DIV#viewer-top-controls, DIV.friends-tree-following-info, DIV.friends-tree-notification-info, DIV.entry > DIV.comment-entry   {border:0 none !important;}");
            /* Vwr header */
            sIR("TABLE#chrome-viewer-container > TBODY > TR > TD#chrome-viewer > DIV#viewer-header   {-moz-border-radius-topleft:14px;}");
            /* Vwr cntrls */
            sIR("DIV#viewer-all-new-links, DIV#entries-status   {padding-left:0.5em !important; color:#ccc !important;}");
            /* note box */
            sIR("DIV#overview > DIV#featured-bundles-promo   {background-color:#333; color:#fff !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}");
            /* page txt #999->#BBB */
            sIR("DIV#friends-manager DIV, DIV.results DIV, DIV#quick-add-helptext, .unselectable, DIV#viewer-container DIV, DIV#viewer-container LI, DIV#viewer-container SPAN, DIV.subscription-title, TR.data-row TD, TABLE#homepage-table TD, DIV#viewer-comments-all-links, DIV.fr-modal-dialog DIV {color:#999 !important;}");
            /* card box */
            sIR("DIV.card   {border-color:#333 !important; -moz-box-shadow:none !important;}");
            /* R boxes */
            sIR("DIV#rec-preview, DIV#tips   {background-color:#222; border:0 none; color:#ccc !important; -moz-border-radius-topright:14px; -moz-border-radius-topleft:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}");
            /* R bx title */
            sIR("TD#right-section DIV.section-header   {color:#fff !important;}");
            /* subMenu */
            sIR("DIV#settings-navigation H3.selected, DIV.tab-group > DIV.tab-header   {margin:0.2em; -moz-border-radius-topright:8px; -moz-border-radius-topleft:8px;}");
            /* rndBoxes */
            sIR("DIV.setting-body, DIV.fr-modal-dialog   {color:#000; -moz-border-radius-topright:14px; -moz-border-radius-bottomright:14px; -moz-border-radius-bottomleft:14px;}");
            /* browse top */
            sIR("DIV.tab-group-contents   {padding:0;}");
            /* cmodial dlg */
            sIR("DIV.fr-modal-dialog   {-moz-border-radius-topleft:14px;}");
            /* footer */
            sIR("DIV#footer > DIV.copyright   {display:none;}");
        }
        
        
        // Modify Google Header Bar
        var cGtld = location.host.substring(location.host.indexOf('.google.') + 8, location.host.length); //current Google Top Level Domain
        gHeaderBarCntnr = getEl("gbar");
        gHdrUsrBarCntnr = getEl("guser");
        gHeaderBarCntnrVoice = getEl("gc-gaia-bar");
        //shift header-menu right for 'iGoogle' link insertion
        gHeaderBar = gHeaderBarCntnr.getElementsByTagName('nobr')[0];
        gHeaderBar.style.position = "relative";
        gHeaderBar.style.left = "4.8em";
        //header-menu left-side 'iGoogle'/'Web' link insertion
        if (location.href.indexOf('.google.' + cGtld + '/ig') > -1) {
            //create new 'iGoogle' B-tag
            iGheaderInsert = document.createElement('b');
            
            //create new 'Web' A-tag
            WEBheaderInsert = document.createElement('a');
            WEBheaderInsert.href = "http://www.google." + cGtld + "/url?sa=p&pref=ig&pval=1&q=/webhp%3Frls%3Dig";
            WEBheaderInsert.innerHTML = "Web";
            WEBheaderInsert.className = "gb1";
            WEBheaderInsert.setAttribute('style', 'float:left; position:relative; top:-1.6em; padding-left:0.15em;');
            
            //hide old 'Web' B-tag
            if (gHeaderBarCntnr.getElementsByTagName('nobr')[0].getElementsByTagName('b')[0]) 
                gHeaderBarCntnr.getElementsByTagName('nobr')[0].getElementsByTagName('b')[0].setAttribute('style', 'visibility:hidden;');
            
            //hide old right-side 'Classic Home' A-tag
            if (gHdrUsrBarCntnr.getElementsByTagName('nobr')[0].getElementsByTagName('a')[0]) 
                gHdrUsrBarCntnr.getElementsByTagName('nobr')[0].getElementsByTagName('a')[0].setAttribute('style', 'display:none;');
            
            //shift 'account' slightly-right
            if (gHdrUsrBarCntnr.getElementsByTagName('nobr')[0].getElementsByTagName('b')[0]) 
                gHdrUsrBarCntnr.getElementsByTagName('nobr')[0].getElementsByTagName('b')[0].setAttribute('style', 'position:relative; left:1em;');
        } else {
            //create new 'iGoogle' A-tag
            iGheaderInsert = document.createElement('a');
            iGheaderInsert.href = "http://www.google." + cGtld + "/ig";
        }
        iGheaderInsert.innerHTML = "iGoogle";
        iGheaderInsert.className = "gb1";
        iGheaderInsert.setAttribute('style', 'float:left; position:relative; top:-1.55em;');
        gHeaderBar.insertBefore(iGheaderInsert, parent.firstChild);
        if (location.href.indexOf('.google.' + cGtld + '/ig') > -1) 
            gHeaderBar.insertBefore(WEBheaderInsert, parent.firstChild);
        //header-menu 'Sign in' link adjustments
        if (gHdrUsrBarCntnr || gHeaderBarCntnrVoice) 
            gHdrUsrBar = gHdrUsrBarCntnr.getElementsByTagName('nobr')[0];
        if (((!gHdrUsrBarCntnr) || (gHdrUsrBarCntnr && typeof gHdrUsrBar == "undefined")) && (!gHdrUsrBarCntnr && gHdrUsrBarCntnr.getElementsByTagName('a')[2])) {
            signInLink = document.createElement('a');
            signInLink.innerHTML = "Sign in";
            signInLink.href = "https://www.google." + cGtld + "/accounts/ServiceLogin?continue=http://www.google." + cGtld + "/ig&followup=http://www.google." + cGtld + "/ig&service=ig&passive=true";
            signInLink.setAttribute('style', 'position:absolute; top:4px; right:8px; font-family:Trebuchet MS,Verdna;');
            //adds Sign in link to right-side of Firefox start page (when signed out), or not News (body.hp, body.serp & body.sp)
            if (document.body.className != "hp" && document.body.className != "serp" && document.body.className != "sp" && document.body.className != "gecko loading loaded") 
                gHeaderBarCntnr.appendChild(signInLink);
        }
        //header-menu right-side adjustments
        if (gHdrUsrBarCntnr && typeof gHdrUsrBar == "object" && gHdrUsrBar.hasChildNodes()) 
            for (iA = 0; iA < gHdrUsrBar.getElementsByTagName('a').length; iA++) 
                if (gHdrUsrBar.getElementsByTagName('a')[iA].innerHTML == "iGoogle") {
                    //removes iGoogle link from right-side (when signed in)
                    gHdrUsrBar.getElementsByTagName('a')[iA].style.display = "none";
                    //if exists, shift Account name over (when signed in)
                    if (gHdrUsrBar.getElementsByTagName('b')[0]) 
                        gHdrUsrBar.getElementsByTagName('b')[0].setAttribute('style', 'position:relative; left:0.8em; background-color:#000 !important;');
                }
        
        //DIV#tads
        
        // Remove Search-Tracking Links
        var arLinks = document.getElementsByTagName("a");
        for (var i = 0; i < arLinks.length; i++) {
            var elmLink = arLinks[i];
            if (elmLink.getAttribute("class") == "l") {
                elmLink.removeAttribute("onmousedown");
            }
        }
        
        // Remove Right-side Ads
        iframe = document.getElementsByTagName("iframe");
        for (var iB = 0; iB < iframe.length; iB++) {
            if (iframe[iB].src.indexOf("pagead2.googlesyndication.com/pagead/ads") != -1) {
                iframe[iB].height = 0;
                iframe[iB].width = 0;
            };
                    };
        
        GM_addStyle(googleEnhancedBLACK, 'rps_black');
        
        //fireResize();
    
    };
    
    var googleLogoBLACK = "data:image/gif;base64," +
    "R0lGODlhlgBBAOZJAAoQHi4JBAsbPAgMFxI1gRhJtE0MAxdEqKQXA7YZAxoGAwJjBxAubhQ8kG4QAxlNvsYcBIsTAwsWLQ4lWANEBgSSDBtSyQ0gSBVAnQQmBh" +
    "wXAyojBAa1D+YhBtceBQcKEZB0Ax1X1QoDAUE1A6SEA7CNAhAOAidm6R5b4PcoCuq+BeC1BHpjA1hIBAMUBCNg3yBa1mxYAwUHDfjMBdetBLyWA86mBP7qDCps" +
    "7wcHB8WeBCdgui515iFSqClm06mcCzB59jo5OhxRvi9z9kdHSDJ+8MG4Dx9OmAMDBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +
    "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAEkALAAAAACWAEEAQAf/gEmCg4SFhoeIiYqLjI2Oj5CRkpOUlZaXmIkCPC8EEgMAAI8EExISma" +
    "iZHBULFBkuqYs+JwUMF6KxSREpCAEiCgqFDhDECYhGMyAaJhrNJs8aJCs0NiSHPjAEoR8fMhIYDwUYEwMDhBSrrRmFCCkRCr/BgxAeCRGTFygW4tqODTAhQrw4" +
    "cUJfAwFJDHTwgCCCAXmJ2iVwYCBAEhAzaJBgscHEIhUqSrAYoSEJgRAPDvQz1ONBKVyCFqRzNShBB3sPRfzKRWhCAwwHCjywcGCCIgIWGjCYIADmIAMRECDAaQ" +
    "AqBAQPA1hEFAMEiRoiR4yIUYIGiA0aNmxoZCGc0AaH/yqwWkCXbiGoUqcSK/aOp9+/hibgSHqrUYiDTgErXhzrQ7lyocoxnky5suXLmDNrHtTAAtGlAkJfYNCg" +
    "QAgUBhFu/itXHSzKPYYUKHVqte1zM9dRPl2gwYTElyDwcqBVkYMOVx0OujGDRAu0ikqoqAZikA8U44ALshACA4PaMXMPkkicUAQIEwMo0LpV0oS2BeIzgCTgRH" +
    "cGTeehR+BgEXLixSXRwgo21OCcIi3MUMJzaxUiwASkwTAELRfIEIohMrFC0yAReLBff5ZBFsqIjz12GyIM8JCNBDk45lg5HwDAgFAHHHTijX4RcEBQDxCgWiEN" +
    "PMAAZDgWaeSRSCap5P+STE4S2o9NWkJBBau0ttkOJ2BwwQAxAvAYNy8OIECQKSkV5SO5vUbZEUDMZop2i4BypiPoaKjbZAwAYQEBF0gA5yUGJACBQ1oZgIAHHX" +
    "SAACMsUDPSBmPpoMIMK1SnyARBHfAACifgUFCZ8w1SpzqHDDNRVcMkCoEBgwRBhCMCvICCSoXF0oE77CXiYQL8EdLCDSvEoFYiLKhAg4EjDJKnS3ICiZJ3H+Bm" +
    "JyGJRhAgO6eyGkkBKDyAgY+pGJCCosRBhAgENyl30Q1mCetRIiNQWgIII3j0QggqgQfkC77pmyGpgiB6qgMREKcTMOZOwgBKBdQIiQw5CIACvt+Zk0T/AvXw1x" +
    "4i7WBV3AgqrGBgCyUpAhIIz5UswI5AhTqIEBg0pW8S/26YEHINafsXAfHF1yOsOMDgnQAWCxJBArwuikg9FV0rSAk61FADC4i0oAK9wyrCrTgMwFnznYIEirSg" +
    "9ywmwQUQEvBTUPEdgIFSfYLyZtGGsKcVPL+o10haaqFlQg7MNIPIBWTyM8EEOvqMwSEuNO64moTYfTfCc062Aw5aXqgIBkmRU3nlnrl9ASOl3fLn50pKgDgGBX" +
    "gWztAQS4b67LTXbvvtuOeu++689+7778A/4hPbPQ+VEp++U7AAlTOt1sALexItA5hcgiIAAwdwpw8BvaeJ2QWceAKK/+aJSNDAAUvNfLv3ls2CmJ+PXOCJKbyz" +
    "P5kARWTT1OmJRMv7qDabDCf6xT9LQAVp9PCQuhoRAxLowAYrAIkNLOWItBHgghhkwFJEJR5EOAAB9FgIBEAkiCC46hE9wEGPapWL4yTAAAdD2DA8wLRE/CAZGk" +
    "DCM56xARCs4IfWQEQP9gSA6a0sBG3pGpekBTBCIKAD79CJTgJwqBpK4gUvoFUBIyGuVa2HY7sqGyF+cIMSoAU6hoBggahGCCxpIzECEAJRDiIDJgbQASlIgHoS" +
    "loRD8UdnsJqYFmOBxxE6zRCHSg4hjFBGBinihzogQQwGcbkD3IJughAAEr3jFADeqf+L5REGrwC0MUdYAAW96VosxqUxPhaChjgRRAyAhTI0ciUj8xqBCJJwAq" +
    "Gp8hAHwM53CPG1eQzHIoa6Sk4oNwkC6KNGE/AfrJ70pKekgCEUcSUhbBLLJJCAXZLsyEdCMpKSPCAEvRndIf7hI391MAnowgne4qHNSBjPbUZhBANIcQH5nQB6" +
    "WhrEQuS5CPJUJAkxkBe93pWISUmSJIKgEfoMocl2OqWYRsOZA+p5idaFQyWRuMC9hoaL4yQHkIewCaG2UoPpzKtBicjIo0qWBAGorTQqIcARYHAACXSpEBgVBD" +
    "14JUaeEMAt8nlEfXxJtEGYilcoJcRxVkoIEtAgahT/PMQPVDDTQ0TmACd4QAM+gcnwTGub6EEaCY26o/gQRZ2LCCsp8iNVqfAqpS/MlSFAUIIS1CCrghgQCUag" +
    "FpoiAgMn2MdED7G8uYBNEB+ciqAGpTOoRHUSEtjn2u5JgKWk7QBCWGFo4Fc3AxAsLzkDxiENMYIWsICvfd1IvUxgy8FpcEc88hYiMsDb3h7CtA4gWAQK9hCOTk" +
    "JuEqCmAPwEgA/kYHrjK+sh9shMSDTjuoIb3A5eUItPQEwGA5BA4hrGvUqshz3GDZ4iLpA/bYBCuklgQDh8o97VbEJ/BZzAYVhY38tMILGcZMQFLPCdLfY3R4q1" +
    "5KVcQr4DZ4Y0QLlnIQPU9hYBgNfADlaM9Q43gQs0BbrwzbCIR0ziEpv4xIgIBAA7";
    
    
    // Adaptive Resolution Support from 800x600 to 2560x1600 for Search Results
    var resW;
    var dW = document.all ? document.body.clientWidth : window.innerWidth;
    if (getEl('gSearchSidebar') == null) 
        resW = 96;
    else if (dW >= 2532) 
        resW = 73;
    else if (dW >= 1699) 
        resW = 72;
    else if (dW >= 1308) 
        resW = 71;
    else if (dW >= 1266) 
        resW = 70;
    else if (dW >= 1226) 
        resW = 69;
    else if (dW >= 1189) 
        resW = 68;
    else if (dW >= 1154) 
        resW = 67;
    else if (dW >= 1121) 
        resW = 66;
    else if (dW >= 1090) 
        resW = 65;
    else if (dW >= 1060) 
        resW = 64;
    else if (dW >= 1032) 
        resW = 63;
    else if (dW >= 1006) 
        resW = 62;
    else if (dW >= 981) 
        resW = 61;
    else if (dW < 981) 
        resW = 60;
    
    // Shortcut!
    function getEl(id){
        return document.getElementById(id);
    }
    
    // Creates a new node with the given attributes and properties (be careful with XPCNativeWrapper limitations)
    function createNode(type, attributes, props){
        var node = document.createElement(type);
        if (attributes) {
            for (var attr in attributes) {
                node.setAttribute(attr, attributes[attr]);
            }
        }
        if (props) {
            for (var prop in props) {
                if (prop in node) {
                    node[prop] = props[prop];
                }
            }
        }
        return node;
    }
    
    // RUN!!!
    enhanceGoogle();
    
};
// ==UserScript==
// @name           Google Skin
// @namespace      Bloody_Angel - www.myspace.com/stojshic
// @description    Black Skin for Google search - RC1
// @include        http://www.google.tld/*
// @include        http://www.google.tld/ig*
// @include        http://images.google.tld/*
// @include        http://images.google.rs/*
// @include        http://www.google.rs/*
// @exclude        http://www.google.com/reader/*
// @exclude        http://www.google.com/firefox*
// ==/UserScript==
//Black Skin for Google search 
//http://userscripts.org/scripts/show/24736

GRP.darkgray = function() {

	var css = "img[src*='/logos/'][width='276'], img[src$='images_hp.gif'], img[src$='logo.gif'], img[src$='hp0.gif'], div[style*='logo_plain.png'], img[src$='logo_google_suggest.gif'] { margin-top: 5em !important; width: 0 !important; height: 103px !important; padding-left: 281px !important; background:transparent url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARkAAABnCAYAAAA0TzYSAABxzklEQVR4Xuyce3AV1R3Hv2df95Wb3CQ3BBJBERBtcWo7iGM7Y219ztgROkVFq+1oKwqtMvXBw2oVraKiBYIUHZWp2pliyyMojhTUShEsLaJShEQFEhIS8rw397nPc3rGXGZ3die3YiLiZD+Z75zd3H/O7GY+9/fbczaEMYYvBx8fn6UN902WItYLokxq4IExcCizYEBHjuVozkqyrKX1lPbUXPXg5JV7MQCMg68JXzvJLFvX/CPKEIIDgdG350wf24WTBB+fJz9aEBGC9MVohTRVFAVRhAiAwIbBYDpyLI0+2otu2okeqwtKqmx/eF/NpU9NW30UNsx7DDYI2fiSWbLm0PmCJF1LAvJ5UkCoEYNShRwOhMEABoBSh2AEgBBARD+5PjUBy8obmtVOdXO/lc//7a5rJ25EP+xL/0bw8QXTOPd2lGUf1gLpEnCipAwxqQpjQ5NACnYwoCKDJBKsA28nX0eb3o7KvtrdDQtSF+7esN9wFy5F8nlE40tm2ZpDVZCl2VJYuVopC4yDKAd0i0E1KQ+DQQGDnx+bqsX6xSLwyAKBLAJSYQyKAhSRgA8AQf9NNSwz25dvN7P6HlNVN3UcPviXJ+dennRJhw1WPD4+jzfccVs2kPhpnuUoOGESESJyZFRFNDqmNjQOcaUWFnSk0INutGFH6k3sTe9DLFvZ2nqPcO6utXtzA8iFOkbq/MyXTBGWrG2+SikJ3BuJl3xTBxHTuoW0xpBSKXIGg2YCpslgMUCwTDVErZRAADBYACNEJIJEQIxwsEoiBAEJCMoEQYmgukRBmB8bFgUDg0AAAcckxZDqyhzSE6nn5s2YuNi+YUNbjvr4EM7j++fOq64JL4rKMYwOTUQWSbSjCX3oxJtdm5DQ+zB215RfPDut/hVPT2VLxXKOdk7+akbCV8Cy9c1zgpWR+ZXj4yMzOkNr1kJKA472mcjzc5iWVmZpH5dD36EYuc2NOze+Vb/qtyr6ERw3ghzLb57YfGEgVn2xFS2/ojcaGZvMq0SRCMpDEmqiMuIRCYZpQTUpMrqFaFV0LKqiD6/c0Xt/ujO9LdfZ8cgDM6e84y5HCWcwwvHxIY4fDigoDKiwGEXWyCNIg3T97VvfAhB0SsYhFR4IPKZLQMRxDF8yhcolMiLydMW4qoqMTtGZBQ/FwS4DWY0hbqkNpyK7avdrK1asqX/KdAhFKMyVDBAsuevSdwBs51l4zaxHTzntnEtuIuXxK/tQelpOt9CeETEmpmB0aRAAQyJvIq2ZyCiKUlpbcVGkJvbDx9Y3vdv8wbs3/HHhtW0AKLzCOa52ysevYjAAAgSAARIRIUExuw8nJACKSxxWISaP4apuCL4mSCfqmYsYDW+unlB1Tt5iSKhAVxZoaM8jlaeIWlr72eibs/iWs+sBCIXIDsEIxQTjHl9eOb8DmL8IwKLbHqm/omzCt3+Xi5eN+bQ7j7RmYXxFEBURGVUlMnI6RVfOQFfGIMFRld8dF7+s4aHx+57dVr9i4ea1KzKuspQep2x8fAgoisPAQYBH5BFcVYzhOhdcgvEls3Rt00XR2tiGYCQQSWoMJhPx3uEcOlIWJMvMT0Rm+fJbzrjXUa0I9sW2BeMYOV7BDHS8/J5pmwFsuXvZP+aUTpr0q0SOBPaZFGfEQ4hIAoKygJElASiShIM9GrpVIucqR84+5bqFt95+3tTpdXMvfcNxg8nQy8bHxyUZu1oxeVgRufiSWbqhZVH89PjdTBREjRIEZAWv70kgk2eoEfJ7So/sumz5wukJp1zsuATjkYuXIrIhi+f84Kkrr5+3acrVs17U4uUjG7py+EZVGJIgoE8DsoYIWQ5gf0cOqs5Q03d4DRfMjsLNt1whjgoHhJDBisbHRyqEoB/LHl2CcS1UDEvJPPNKs6LLypYRp1deYFEGxgSYkLBuNxeMSnGmkK1/fua4axzVi+iOp0WyYcVGb/tk88qfHzuwd9eWS258aPWa8lNHTWxKqhgTCyFtEDQnLWz7OAHVoBiVPbJ91R2TFwAIHuuJHSGOPwA4REMGIRofH7uCt6H2+cAb8xhn2EnGVALvxGtLzzUpQ1CRkdYFrH+/XzBnkczLz80a//OCSCTHKHnaJO/Fpa6xmNEJOK5qiB1s2J19ctb3p933wrtvydXxUU1JDSZVsP3TBDSDIq52NL724GW/BhByCcbgEYpKz4uPD4PwOSVjB0WqFzvDtV1atrFtXdWpsXMpA6pKguhVBWzal4BqMEwg2S3PzeaCccvFKxniurC0EKuIaDyScUUoREx2t9MDO7cuPOfKnzzdmTXx39Yc8hpFhdbdtLPu+ptTyS7B0SZJPKZnXvacyBAKxseH8LDigrHDGV7t0tJ1zTdVjY//GJx4iYKcIeKNT1LoTpuIQ21p3/rMjIJMZMfoFAwphDliFduIZMfLAJKxeMRcJtGatxiauvXP5lepdX/677rrbmw5sEd1yFd09MRwC6aYaHx8GIdwcHww7xesM17BDBvJ1K09VBsbXb6CEIISRQSDhD0dGpo7VUiEGTWJj6fWvfy4DkApSEVxVzCei2u3K5Yj1E6xdql4NTNh8sU3t/aZOJqyUJNuev2lO8+7yyE9uB42w55PsedFXnx80TzRMB+fA+oVDFix3w27dkkoCW9UQkowLIuIhQI4kgH2t+XBwQSr99m6eZd8AkAuRHFVMQQct1zseCVT/KIXF82MWYuqM7ERlydak03VLR8+8vz9ny1zK04ZFREVjkcuPj4iIewLVDI4SVeTtjsq9xU8WZ65PFfzJHku4pnHM4OnBRxpqNqkEXyjHQEQD8voVYEP21V0pXVEYfS88fSsex1yURyykYrvcLRFc3yCKS6a1SsXtGHlgkoAoj2XAVenmCfeOQweHx+vSLzHXy3jeG7jWc6zmec9nkno53qex3hOK0hooi2ZIViuLqku+QMBUB6WYVABSQ041KWCg9FmzzMbPtzKACiOyI42Ca5nLoYrxQTzfzfD2e8e2bIp0nJhgOVDyzsP0BP07eLjw3BycAA2Ok8jzxie3TwX8KzkCRXmKw1Zu6RR4ffx0lBZUBZQHpLRlgaa+gz0pnVEqNH3Wt0vl7iqGMUhGOIQh+kQi15cMF6xePEKqN83YN4KxcZVVYl25eKV3jCuZHx8LEe1/0+e7xTapFd5pvKMtiUzyComUl06mwAoDUjIG0BaBw505cDBKJra8mrjfxiAgKtNEl1b9M1C3BWMOZSvtDOOSzae9miAl9Coa37WMBeNj8+YwngWz06eD3iqeP7Fk+AZa0tmkFVMtCQQiSgiyoISOnOAagGdSR2CwJh2+L06h1hkRxUjeJ/BFBcMh30JS4vM9V6S4apkBO9KF4wi8hsO+Ph8r1CphHiWoZ99PCn0cytPzZBIJlwVnkkARAMidBNI6cDRjAkOYtA6Xnj0hsbC1nzZ/RzGFsgJFIxXNHBKBTbUW23BcueL7lfIPXDn+QTsKsLoFC7jGoDF4IBS0gxBtCilBykjf9/f0vbSlD/91TjZ/qG0eXDxt4hIpjFCayCQGBFxOjjMRCOALKHsiKrS1SVnLvjkxM/bJ7fw7pkCtaYTQkcTgmrHY0aNMrRSio8oyLboQ0tXfYF/WN7iOk+5PmsZtGSWrTv8sxET4mUhWUAsKKFXBTQT6EprYAwo1dLvOzbcKa42ybNUPSjBDL6ioa6PqFs67l3HxyuY/3H3HWCWFFXbb1V1unnizuZIDBIEQVRA8VMxfAqSMQAKCqIEyYJEAzkKIpJEooDAJ0EQRRBEsoCEZdkcZyfd3Kmqzr/bPbt3nhtmWJaVX4/PefreWZw51VX11qkTK2edOJ1DnSWY/IKlgm5Uq4DnAjIEiADOAdMCHAfCSbRHnwW2BxP7fnjWhOvc07/fGxJ7sLfqnbXxpb9ehpgi+f9deSxywS8sMPdEZosDmM025uOYDe2BUQiwNaFDBhhP7MCYFX1PAmer/kvKygvekFV9bXKTH91Uk3tDlz5tLEIPzrYH4xONhLE957xN2KITzYhA8QQD1BzcIQnkSSI3ICpVVTXlFr97zsGbPYI6uvDNk9m/DVh+csokHgY3GqbezQpdK1pngQ8oDRgCsGzAtiFsezxsYwcAB4dn/eAaGaj5PjN/2vbTy29BjaJ5Wo/5WT+QMdL2iQCQMgUkAa4EAgXkK2Fc6rK49NEmGgxv1GJae5FW07/Rcq9HfOctyiDSugJM5awTUpzRdbZQ+yA/aGDlCtDAYAwwSiEixgHTBCwTSCWBdAasvQNswiSQ0oBXhWmyHpP0t6anxcHlU498LS/ZaZMvvPpPALChK/nJ+RdtyUycz9vMz4ArC9QP6AIQVADyYwFUymUGS4DZAGVALAVmdoG0BLONtOFYOxo5vaPsu+BSv+Df9cYbAz/+yJcv6xshOzaE/Jffv/hM7phfNXP2ZuaUTksRwBlgrGbBoieLmIGPOAElEaohoRJo+DIWQ/AYK5QmBAQUPI3BioZRrS4e7w7sd84R270IQHxQHiH37ONvt7jaB9UhAyuWgwYGANeNJREcsCwgmQBLpkDpLNiMmWCcAWHZME1sbCjvJveU755X0sY54y646noA9H6sL+O9FqHq2qh7SwBoSxiQOgYZDURFoRgHFv3z0afrAu5aajH1gXYfoItQ12QcHYhW07tQV79pmeyXrJRPYtF80NKloKECVFfnXDVpxoN+ruOPXVf99k8A2C8+u2vqK9OnfdYhvU2imj/IWrpkOhscAMtkwbf5MGDaoIE+YLBf2Fxv22PoBwonHv7sI0sH99/vtntW1gDw/avkJ+dd1M4c/nvRnfok6SFALQDCXkCXoIP0Uu13/F36PX9IbXHx7QDYsYd+1Dr1+7t+KZ1je9q5ob2hiyZYEnA2QgQ+qgrmyIzjsG9t2zbuoKHXz/55+5ZnXtAiDgnvVf5L7pqXErZ1id2Z/DrGtycHXYVygeCpEADgCAbbYkgIROVZx6dNdCYNiGHAIQLWFFd7fWUJxaqKAEmwYeEIEfCUq0qPd/O3X3vkpoc17qfaeEgSwwak6rmn7GAg/IMpK+Mxby5oyRJQPg+yEnk5a6MHw7bOJ0JhLtWMJQ0tt3MC9wtWtbIN5s1haGsH33p7UCEPDA3AcKvj25V/dfWkw87ul/yUqZdcezsAPdb8vO8gwwzjRC44S1sCBmeoBrEWUw0VlNJIUVi5686L+4YNQ2adFtMIMPFTr4uWsCGMwPW1U9ej1010qtgm25/6ljN643XQ4mXQmewS7yMfO6X9ht/fAbzOALA17+b7jz4ZfP9RPATgYQDnv/Cdg3bfmKvzktXKpur5Z8Bnbgy+1XYgzwMtXQi9ZBFLKvnRL3cn3px3zGEnzLz8upsB0PtVyU8uvPAE3p48F2bgkHwHUItAaiXI6/6XV9rqxMxWF0fgOGIM7LIb/0Gr+AEAD/7653ufut/em/4q3U2fIX8hY9YksMTGgBwEwj5wc8jJTmZnu4vP/vqLz6086BN7X/VGnVfvPYHlFfcu+k5uWscVHgx7QVFiRTGA5yqdDf03Uwj/mebySShlwbK2r6aSewRtifFDrsTErI1ZHTZMzmIhJNBflRHA5ILKfLtvwekUSwGtQSAgUx5Y9Ksz934NgDVK+L8mIrbh7C7Hf860+P0sP2TT7LdA8+dDm06/95Fdjmu//q7b8cL8+pSahwGc99DX995sV9O+265Upqrn/w6xw0fBp28MvWgeqHcZzFKhewLouv4fHvalrkuu+2Z9UvAYYLP+IGOm7S9j2OCrEQOM1IhKWTIATuj312kw9VqMHi0fqU7YDxJo6L0YK/1zjn/BsrE9LV2MCGAWLoHcdPN7Uw/9Yx88N5cDGI0j8Nnh2tueArDL4qMPubQnrBykly9l4Ax8i23BNtoCrHsC9NuvQwz2JSfrylWLjz70Q1OuuPFUAHp9K/mppZf8WXS17U5qCAwDoPA1kKooWdrmHGeTX/50JDi2KpF6+Kn3FA4/FQfOffqkQ6dtkTwfQb8ADDBnOmC0A2IZKFgMK0sb7/iJjiee+78f7LPjl698uon9i95tcbArHlz+QNvMji/2VzVm9wdYMqjQFbovz9JDB//su9u+UZc2ch0Afub1/zyCzZxyXl8lMD2psXGnA0twUBS9LtCV5kiw1OTq4hK/7JQvPYJGssZoX8JIbRCQiTVly7gepUEDC+aC3p4DOWHii39sm/Txva+/Szasrdo+FF+45Z55ALbvPeZbt3ew4H/UKy9CbLsj+LSZwJRp0G++Br10McuFxb0Gj/raM5+797FPP7+s16uzS460Z1Krmkr8vcTGZLuSmwBA2hax6jgMMl6oIlQzlVsPMrzudFIt85E+IKJG0lRHGJvgnf3DJ4yksQpgliBWXZch3HTT/1sFMPvWTbYBwKxjo+6zMeWKm056QdnHEze17uuDfuctgAEsm4XYegfw8RPBSLHx/tCR84/8xqUA7LrI6voqg2CrqJVhVy2/5GXelosBxihAV5+Dlq7nDey45yqA+dmIQmNGszHUyz/r4xfc8q/nBo4hYkSyHxQORGIwayJ4amswIwthU3K7j2Xv/ecfj92/JnfTQ4qtofrr0S//0rewfUruiysrGm/2SsxbKTE1KF5/8+HTdlgFMG/Wvfe1fPa3t71+6RN/+qwuVfo9pTF3wIUmgiOAnM0wo9OB7Rhmxw47XXfYKdd9CkBimJ2Y4/dd40Y7JOH9p9KZPzzaSho3saBisEIe+rU3oTK5BRHA/P5htea91c2TUSej2XP5DQevZM5jYBx69utAGAJcgG+6FcTmWwGhXK2xbfXgl3a7v26sTWpAxfOz3iBTDfEVLjhLmBwGY9AUAUxEoSRwDhihO9hoi4mpXpP5r4k3iQHmYTPt7Er9A2BuBfqd+ZAdHfN/qxP714NLa26sFPixa2+5518+u4hMk3Rfb2SbiUjEi4FvtDEQhJhc7j301e987TgAdpMFz1svhhhgWFK+wbNt2wJlsEQGuvw0oMsU5Lf7fnqryx6p36St5K8HiG0/d8l9S2bnbwIA8ueDtIuImAmW2BzM6gI3yN5yB+eqx+884vNNFrOIuAVQJtrTr+S6UlPLAUWxWosHFaapyoPXfGej79bG3Fr2q8864PU7zjr0I37v0EKpCYsLPkwOJAxgq+4EulMWyDDtiR///HUf/dQ+0wEkY64Bzsh3Xi8zhZrjfaS+0479upOyLmFaMqYV1HPPAb5P1W0/ckgEMHXjbZ2YHPOkS677dgHWPDBAL54LGCbAGVhbB8Rqe2AQoG1oxUef+9b+3xsxTrseTEceBOsFMtwSXwQA2+CQCvADoOrFTz8kcAaQ9CqtilCNWRfmP5Tcs47/lZl29oBXhejqhHr+ZUBKKn1oh28d+ccnVMOktwYWVuOaGv7hq266anGF7gcAveCdGrIrAu/oAZ8+EwCwqdt/yu37fHm3uoU/5mJglv8nnsrOAiOwRBeo+iRAVcjylnektrjy5gaAbJ2LJppVEJy+08/PGFpSfglgQLCkNtXR35sJZrWDG8r82G6p63989GdmxfKPrZFd8cCy23M96VmhBgxm4Y2lPqxQlmjBPw5sBPbWAP/Ks4+Ef//dlQfIqueVA4mlRR98eLVOzyaQtkzoVCqz27fOvTGSrcZ23YYzWr0DAkFBIkAIHwF8+FhXWnDiUZ9vy1rXMs4YM0xgaAgoVyCnTn2j69o7/l4PLmPPUUzXvj73W9q0NJVKsUcqCIFSAYwIfMIkwPexZX75iVNymcw6rq11BxnTNrZCJC2P5HB9oOLFcoUhxVIr32+2KADQKOBC/8FBT582U9bhIA2WaQO99gpQqUBOmDBn/K/vfLo28aNuTl4PxPX8md/87vhKSP3wXOgFcwClASJASvCeieBd48CV5Hsk5C8mZdO1xTDGqSMXXnAyz7XvChBgp0D6HZC/EKRs7+V/Gj8EIFqMwWw9hsZxnH3+Xw5VHnzIChCuGDFMHywxGcxIwbClfdxRW9wMwBkLKC++c86unZNz+xMBFrfwxsog0qaniOrvb/j5QV7zDdcauP5w64VLFz779x8LBpQCibKvoDUgJTA+4UTiqu7xM484566jW14dWjsNQNAIEUbw4kb/87AudPuBe02d0J64jQlhsGQaPJ2FfvstQBOCSdPuBcCbjNcce51B/+jBx+YWPHoHgoOG+oHVvHghsGAeeCIJRhpmf2/qlj12Pbw1wDZqm+9NkzFENwBoxRAEgOtFQIpKBQglhjUZKVugOdW4RdLjfyAZhr4tOlnsBHi1Cv32OwAAf+YmN45hfzHq7FV6tFSLeUMF9/Hl+aPIMInyA0CpOAw0AKpeBDQwDKRKQ133fuUzJwNwxtAIkH/tp908lzk71maSYGII5L0OkIaqTP/Lzvten6/d5RvYHAUgZT1fedOTvfPfXHkpwEBhAYA/IlyqCpbsABiQ6/Y2evKuw75TB5I1+WPmdlv6F1wwZjIBt2JgeT6A4AxpWbpzHYCdjQTFS0/5yp39cxY+wRgw5IbQIaAkIAOOnJGAIoK9+Y77JtNtTh24tKqeSMzkGgAUKNJePHJRoSoqcLEu9IVNpt0hLNNm6dUA0xaBAPUNAkJg0En/qSZPs0Ng7EDYkGgJAFDfCmDRImDJYui33oD882PQ8xdFf2t8Kb9jbV5qh0ArDe69gYzJ0gRASQbPj69KlTJQKQFasjiwSRjpZipZC3Ah/AeTe/YJZwrHHgfDBBc2MG8e9OAgyDDVvYPVG1pcMczRASae9GaJo3vd/Lsnhlz1KjiD7l8BKImIwgAoFsETGUArbF5auf+mXZ1t9Yuh3kaTbLNvYWYUAgqYGsBCwB8AmIG+/rZfjnJFMsYGmEb5N931/Eu8grsCJEHBwIjoBQ9gLpiTjL5vvyP7Xk93JtVwYsYszr72H9u2TchsRQC0b2L5AKESSlic9AVHbvd4M1tEw3uPieo33NP3//p4HUgZkEIl1CAF+B7APAtCm/DtdPqAY678ZvPrR+NByhATaQ0/8OH6LkrVCirVMt4t3X/w/tun0vYWYCwGmOVLgaXLQEEAGIKOfuLZVwEYrQ+C1uNdwylLbI5yGax3JfRzf4d8/gXI2W9D9w9EG31ZV8+/Tpm/8vyaTSbiMa9NBtaROOcCAIJAAUrDcwnVskbFBZQpwUwGCCNZh2gtiz79p4ONYbLjo4k3TGDZEuiFCwDGocb3LPr2g3+utNBgOGLSLTZno7etNnHGSyvzp/xPetzD5FYAzwM0DWszLrgwQYYFu1J2fvnpnb67+50PXdGqKPVTd3+/y2jL7g4gjvz0lwFqBUiFILLlYac88nTdJrXqFlF9I3jZshRGzXWsl84fumTWdpkLIH2AWfHQSQJUBSMGcA4n7WZuvvSrB3/u67+5qVmHiHRn90kcDEJzlMoKA8U4YC6pZRmAaOapq8+qb3BAxMQeuuPyxZ/c53vP92w0aWdXBTBCAzIkFEsEBQZpAOb0bf4HwBpblRpFa9dMMAIARRpe4MOVLiphFRVy8W5px4njvg8uwJxUtOGjiN6+PkSHjeX4D762gFpoa2geOhLP01V7fr5zny02Pj1r8b2NoJKlxYsg57wTR6WDENqOu3DS9Keuz/s3XPK3lxYMj8+sA2rdgmm90gqCIISWgOdruG6ISpmgUwC3AWbYOQB8rKZU/w0JaHbGyjBhgAUaiCJ6hwDOEbR1vNP8NK1t0BYZ3mqYaQSzEaz3uPH2Z/I/PnpeOslmUrkAZibif5IKyBfBNAOkxBZecQ8A17S4rtK220w6D0wIQMQpAuEykOwHIKD83MpHnvwLNVG9RV18hB4VZBqBkm+8y3m/8pdffIqZSXQgqMY/VgzQAaALa7Fqu+2crwK4rRlAJtpTuwKA8jSGigHyBQmzDTA0BfXvvQHYG090VQfqIr9syU3jN568s4ZGGATQoUa5IlHxNIJuAk+Pm5BM54xquaCbxDmh2eGplYYvPVSli4pXQUlXAQfvirIp5+OxnUNEGisG+mMbBeMg2w7qNeW6bpSyDlzla8cevuvUbOqkpNAfQbloYPlK0LJloN4+oFpFZVzP3Pnjp93xv48+fduy154RIzRJ0VD7ugbi4ftyXVIq9j+GMkQQ+AhXceB5qJYr8MteHJadyPTU/6F6oPlvABzB9Q/Wvsb8ENDXF1vlBYefTM9resWImTcs9Nasml09qqG6N3YJB7ExjDFAa6BUAg919Lm9ODD+fzffeBIAq5lqa2YSnwMAFirAKwDl3lgzYhwqTK6syd/6mtfKflTHjfIX3UcBgJQEojEgzrCtFMFcFyCNjnHlKV/57Ica5J86a8tUtj01DgC8so+hvItSoRKvPc6sOlvM2KktjfIHPzv603eEfhBoAfihD7mK/YqLwb4yfFfD44b1kU/uM3OMHu1r6hdFT601vMBD1XNRrlRRKbl4N3TMrh/rsR0jCwBMKqBYiA4T+PFa04YRNhxmjdck/aFJE8S8E793UuWsY17fPM3vTQ4t35lef8Wg55+FfvkVqJV9bnnajHuf2e4TH+946q2Pbn/3I79cViz7TTRrNnowaY3fE8joQFdAQCAVfD+EDEOEvgevWoWXr0IwQCUzXS2KblNT0PkPpOpFZ1vCtjYDAEiCHhiAGipAkwY4Q1mYy2uTPSrAqFEKp+sWaq784/ylFxMTRFxBhwG0JmjwyLGnKlVAAUxpduhmMz7XzCt0+y8O3tJMZ7pjtdQD3DxQyQOhAoNAGBqVMewZ1Fr2scewfHHpUhAAwaK/iVADAYuNH+USWBiCMc0OO3CrPeqBbo/9jv0IF5yRInh+iErFg1txwTlbzdYoIQKs2XtvYQMLqkPVJRyAZhpKhvA9D8VCBaGnIBWhrXtK50gNbaxOFpo0giCA5/uoVj14ro93Q/ttuclnweJ9rYMAulSCKleggxBgDJy0A8BqNVdnfe6Ts5acfNT1zx++99tTUD3eWvjOeP3SC6Dnnwe9/iZC4m9Vtt7+xMTLS9s673/qa5+88w//anDQtP6OsTq3GlhHUlIPApgVqZGhhJQK0GGE9AgZhOiATiSTW334U+P+9dLjg/hvpXLx6yzrGEQMyvWgh4agymUYIDBwuEReC0+SrsvhUu82A31E6IH61p339R+4xXGDZtLsVDIEBQrEeXRaUsUFFxqCa8wiuQ2A2+vzxnbYbvJXAQxv8BAUFAC3AjLiPROGosGe1Do1pHWdnRby6y3+5/x/BisuXWmkU+MACSgJksPaTFgBmSGQdTBzemKb4SuTuUb+XOf4LeK1KBH6IcIgRLB6zAwIDcOetcWO6blvPFffX5oAoGW7ncaTmoKK/wKAmcxk0WHqez4qpSos2QZDA0pJiZjYaG2WiYitBRmpEIQBAi+AJ0MkMTb1ZJJbI36hUF4APTgEXSwCoYRhc8AUAoBZr8Hce+iB++w8ofPATh5MR74PNG85aGU/qFiCNqx8OHXqg4XuKT+dcs1v5wCvN9NG0LhWa+/n3da85u8BZOYPrxhIKQGtosXMSEGFAfxBNzIpb/epA3arR7QW1yeG/0BiYJFNgBRBeR6CciWyUxEYwBmKGuWaBtHSm6TXJXdr+OdrWGvCQoBFwKJIQzGBgADf9xC4AUgptPuVic2ijbNtqZ0AQIchpPQh/QpCz4MKNcA4GKdUw8Jt7Q1TzersjCl/GC4AOFS0lghKC8iQEPouZLkKQKG9Q02sl50bRjcN2zhCKaFUGGtznoRgjO34P1/7UJO0BN6qaVqL01rpMHwpQg+DQ0oZayAVD5IBUhGKA0v7GjSZ1n8XRBSZGcIwRODLSCN6N5QwxHQA0FJDVooIViyHN5CHV/UAxiBMc63n7ctbbznh2aO/fU7htCMf/1KXfWrn8vnT6aUXQS+8CD1nnqwkU0/3bb3j1xPPz+vJ3vPXQ1cBzNxmUeYtPXCNdbiDFmBN71mTISlfJWA/ZsZzZgiGhM1hmgxSAmHBQ7IzgcSkTT8M4L4mqMjq+D8SaDjHVhje6aQVsJpjgIntqJp4vVuv4TRtZFqXin6aaC6ADzMegz5MM7bjSg2K9Xykq+V2AGwEyCgAhukY44Z/CUCxOCOv20S6PshKNEn+0y0BZmz5tQ71bAA7MiHigTMTYEb8LsNIOGQyfix/DShNzlky/gUAY/EaFAYDuQFE2kRm4qafAPB2vYdlrDCKWO5ahwtGeBMMYGui232CAgDTAAIZPPngjXMAGHXyNbq1NdaLHMvoiuVDrHV6HkAajiXi+eac3XXQXl/eobvtGxN4sLko9nJaXojKitDgIMrJzJK+STPvvXn54JU/e/iFXuCFkUXyeT23AGZdM+w21OYOWhXZf08gw6R6AMBPTMesIa0tYJscvqcQlnxwDrAJ07dq2fvov4EExtd8FcMblTEQYwADLFBXE4OjbgkytYX+roGGNJuDGF9iMniEftB6GDcYLM+zaiBei9y1bLM9ln+kBgxQSNFnw1adTeTHWJHb6yI/0/RajNjDv57xmEkDMj48TTuw6kBGeOVSCQRwHotkmRyWJaBKAczxKRidE3YZdi/ziBvBm5oBTENWvtYrYvmAINTwAwm7KwulCTl3aNGIsbNRNilf31IPgiEJIpDW0fyyTAaipxvmuDS0beuBRMerO+hwX9W/MlwYytco8PVKZs9hqa7grzL1wI//+syLwJvuMBjwETJjFJDhjS7/2vf6BgD1nsX10mSO2WfGKzc+N+QZju3Ep6aEaTAkHIGKqyAr/ioOYaYymS99/aQdH7jlgudHaRfL6pj+g7qiJ0AEggbW7HS+BmQYbNJdjQFrje7N9WnepYCX1oIMX7NJWQwyDIBi4FwaAFC/Ublg8c+JaqJxAabiw822VXsT1Vm1bv6+7qQVZscgMxIDASIdASRIN5V/qG/xYop339pDLpUQCMte9CPZNX6bdK7TLBcG+Hvt+klEdOnv3qE1k1JxJVxXw5qWhtaANTj3T020T7YhWhgLzmwMEzNtiM4uKDDolAlOkncPLN32/5zun+7z+z8+tPZAqAV1enUgWNPsWnuJWJNYLtUqXWSU6xKtJgPvgSr5YEGux9pMJEywQMIyGdJJgVKZR4ivSh4SGQvTdvjClxGDDEYFmA1Il9+76ARwvjHQ2hqkSbNm/i4CSCqQL7XmgX/d6d/c7GUMk/+T4wWAkRs0BhqKNZkk6Qk1gKmfsPXfqEREA2cc/2zNslbbrKR0DDwaIM1VTS0eCTSM11UiA5hYq8lYjpvtak9Z/UMV3hokG3ld5K/MPi+qW8GEqL+TR2ISFDSNlD/mP/7uFy9+6huHE7dMxjiDbXGkkwb68wF0OYCRs62vHX/NYb86Y9+basb2Jlf2MYhxPgUA/IAwWJDQmQSsjhQs5VeeuuPcm5oHHDaaBAjrS7wmq2kC6TSQz8MfqsAMKzBCD5PS4zaqW2tND/Y6uxprASysRZiJbgIyuu5JAPR6F60KKt4fCenNzJQJr+DC4AyphIGEE0Jqgj9YRXZyFmzaFh+ettHW2YXvvJpvGFAj2KBW9Gb96dJ7Fh7kdKcuzczoHBdKgkaNDMZgGdGz4Q6giOBHnRcUBioay0saSbf0+NWHbvbKyDsqWE1OxgW4aUAJEWOMYHB0OKFujM036XpQ17mXLA3PO1EywY0RhVcB0vG4NENoWEGTk5ZrXfeemQlwE9ABKNRgpuCnHLXbh0/4yUOvjXrlWA/yPNmfjKWq3flIx+LwGLNCjzfIv2LpPD/fNzCQ6+nqMhIWhOsi4YgIbMK8i2S7DXOTHfYD8JvamGvPBm5BzDJ3AQFD+QD9RQkxoQtKEcaXF97x8FvPFwEk6zqNEjYAKa0CkABAa8APCHzofB6aFGASxgXuFnXjaQYwokWQJ6/3JrUuwtXIY9m4ON4Dyap7BRHBTlkRyArB4FgcyYQRaTWyHCDI++C2Ye5xyJnfbDJg0XzC158uu2fBrpc93PuGmNx5a4Fb4+YNhJg7JDFvIOb5QxLLShJFn1Ap+3BLHrySFz3LeRcrVlTx5twiXl8h8dqyEHzlwENXHzr98/UWeK3IjzcEDVsfY6Or4pElEunAmzry9NgQbUiJiLTS7kj4gtYxEwFKwzetchOVnoWB8gBau8EZtwFhI05eVADj2G7Lzm03pNbZuc3pg2tFIqqlF2g5vB00/MBsKv/KufOfUgSIjAUA0XUpkzTgrSxBlkOItrb2I86+8zsA2FhA06rYkrCtT4aasGRpFbqnDSxlYhyrLrjxpF3OalbmNOJmxbexfhRKXQCophIJI55jP4BUKpq/nFee3AJAeROg4U3SfvRYAYo1Hr2N9BoCgPcMMid/ffMFpX43uhfbGQexwZ1FE22bHFwAfn8FnAGJLT762QlTNkqPbWBaf6C54J5FlxWd5O9WBKx7wZJK/+Jl1b6BPm9lccBdWRpazdWV7pDbJ4tef1j1XTNpQXoS5ZVl5JeVsGhOHq88vwKz55Swsqgwzss/fsMRm+zfrP6I1tQ/7MpG9HQcwLZATABcIFstjt928oTsuxnb+oybNFViWwwApUBSRSDDKX6WE6neZieXW3XzNU2cA8IC44kIXMiLD+cZ080dWp38GwJ0QBpEAUAU58BBoZw3msp/33Vn/cKv+lI4FoyMDc6BhMNhmgLBYBVCAO07fepr2+z02fEjx13PrcZxxT3zJ2W7Uh8acBVWSg6ZTSCtZZleuferY53y73dn0aoXLoImMBZrqTA4YDuAIUBMRM+MX23bY9NZPWMADWtlwG8VWT5KJLcaC1zWC2SIiIJi5VYQYKZMEMXtIpKOQCppwBAc3mAFQdEHSyScPX9w2VH1hsda3EirimfrTiftPfXYM744bvx5XxnXfcnePd1X7z+h55oDJ4z/1YETJ6ziSb86cNLkX+w/ccpPvjJ+qlzR9yubM1hJAwCinJQlKzwsX8XKMWEYDKkg/0KLrFbDi+KFCAwUb9RUCiyZjCZdMQ5OxE/fadsvNJ3095OIBWvBLoz8rCBNEIgX5DIrMbtZkFQxX10MaDAxLA6zAW7FUxGBjEBnT7jxGCEIWJ9QBDn3/NRIsaB9QHoAKbAEB6CwolfE8tfR6y89kV/08qv3SALMzlT0zokAy2IIh6rQJR+WbZlfOuaKy1bnGLXy/LQs4pV0flchiNnzKijbDmyt3Omlt/a755rjFwHAaDE39RuQsfUzy8wplO6FVmBQgIo9TDydjg82w4BiBhgX7KitNm693mpPGjXavBFUGsGlxtQUXNYfZGJ65e+PnRW4gWckLYhVPOxKjIDGsjg4Ayq9ZRiCIbPFjrt9dPd9Zo6YXKPlZL9PxBgb9W5KpBhY7d0HoUa+FML1JThjMBmgQ1cAcJpVQhv0wuegaW0QBHMSYKl0nEuiOSAEtjXp0/Wb8f0HHe0PIz/I9+IYCq0hoAGl8Yyrnmx2qs6fn38FoEhOkAKiEzENcBMUaFBISGdl9oLT/nenUeTm6xXrxMXEYaAEQCBVBmQ1FtWJ5XrqueLfWlwr2Xnf/9S5+cW9czVjyM7sgN2RjMCWM6C0OA9IhcSk8ZOOufyxK1tF5Tattnff4guccZmPLcxL9MKECGRpE3fhnr846dN/awUwo9at5lgv+p9rf/uHMNA+Jx3bqoQBls2BpdNxnpmOPZtbs3C3Ftoxa+EZkmNoK3KUiPQGcHnfQebmiw8Pyr2lP4AAu80edrUhApmELWAaArroI8x7EI5pfuIbP/5x3UkiWoBNfKK8v8TqNSktw4ax14OxkoEAkGhSz9W69bU3H4CU4DxeRzAN8FQKzDAgiUUgM7nQt9UnN5re2QRo+Pt29WDCHhY+ysqlqgvBKAJ5L5ksnfSXvz+PJnTdbf94lEiCWSKWBgKMp8BEIvYy+THwfPEzPXu2AOv1B0qmtwIAUsO2GFkEqSpYUoDZHL6bLJ3w0z8+D4Ba9cK64bT99iwv6Z+tGENmSg656e3QtgG3KtH/9iBAQNumm2x1zu2v3TJ11lbZ2rprXgj7sj8svicxpf3ERUWF+f0Spuuv2Mxb8NFLj9n5yfox12sFrWNG1p8K1eDZGJcZoqz/dBI8kwETHIriQMzxbnH6kR/bcZNW66oBZFrX/pGjRXKvo3Nm/TC23Lf8hCAIpZmwYWZsEBBrLkmORIJDGAz5+UNQgYY5eerUI86+/TsAxFgT/f4BTWs3HmnFmqaHU/yJAISeawBINKtQf9Yjf+0vuWo+NIFztjZIKr4ycSiKtDn+4x22+norWZpeRdaRGKckAJAMofJ5kO/DErEBeOnEqU+3cjPf89BLK4d6iwsADeZYw8brFGBmo7FQJQRgYOYm6sNbbDwxNXac07rPG+N865qx2gUFg4D0wTpsABpLF3U9PYZHi+a99VL17P1nfcabPft6GSpptjno3GwcUtM74QmB+S+tQNVTSE6dOv3oa/70h5Mu/+Np2bZxI6OZjSN+dP3kC+58+5xfP9k/mJzQvtdqDWZOrwQr+Ytneku3v/Doj81pMWcEQI8BMPF1aT3pmWX9FwCI9hQ44ujudBYslQIZJhQEmGDsmOnd3x/lGkuNMjcmuK6D1rLhQeaM73x0SXnJ0G81Eaw2B0oRGANsS0QajRAAaY3ysiI4A7o+9pn99jrk1I/WwKUF0GwAGktrGInNjMUiyKAcAHBatL8wFhert4EInA1fmRJJ8FwOMExo4oDg2FZVPtOWcIxmQPd+XBW5YbYBgC5VQP39YIEPQwDEoH9dlFeOEteCOa/33h17r0WMrswARBKMWSBfg3wJy4Z95U8+d3ATcFx/+QX7eAyQARAWgGAAzAJ4xgJppq/+zfKrmnttGm0hP//uTqcveeTOL+ply/+uQxmaORv2pDYYG3VjwAeW9PooGQmnc/ud9/nJg2+/fMVjS164/IEFT/367/2Ldj3ggLcnbT7pFJZ2cnOWVvH2Sgm3FBQnluftfMEPduprfs1qzOlp5XVhfP1BZq/f/u5F11PLQIQ1vy4qw5nNggkBqRhgGJghy5sfs+tHt2hxsDUae1sDix4DWDY8yKxBtb/cc+1RbsHNC9tEZmJmbc9gx+aRW9vgDP5AFeGQB9M0+NZ7H3nmjp/ca2qzercb/to0truYMYAZDCwCGU+NlLO+INCev73reim1z6HAMRzyncqAJRyEChHQZPxK5ravfOZbowRG8daawNjtSZnBDVIKNDAQlf20EXuVBmZs9Mylz7y4sAXA6NW89+E3/EZ6vs9MBmYzABqMJwEzA8YEqBoATGDHnazPTZ/cZbcKnW9xyo9NlhlvhtAFBb0gvwgW/RnCwIrJ/7jshqcWtm4X3BgY9puLv/fy+QdvsffTlx61k379uavN3iWvM9eteAGhAIHlJYXessZgAM4zuba2yV0zkulEUmtCvuDh9X8NYN6KEENVjVmy78RLf7hrf4ukR1af1T6KW5fer2Ozz5U3gBQ4FCKyTbB0BrAdaG5AMQvcMNlJM3tOm9bZ7tTNSx3V3t9Y16EPBmRqRA/ffl5QWrTkUKa1TrQl4KxiAsBZlDgZgY1hMBQX5xGWApjZbOrzR1909aZbf6yzLku5dWuF9aZGBOfC1GN7VBWrAWBjS4l5QwU5WA3/iDCEQBir/ckEeCYb2WaU5gAX+BhVvjK9q8OutwutrzbAVHAkiKArFajly2D6LgQHlGH4tyFx9lin/7KVRb9v0dCjgARzhrUZYQEiC3AHVA5AfohkVqdvvOTLh9e1peV1T7YuHkI57/zpPJGaBBCo2g/yVoDn2Cq2oLXwb/5d+ZxmVRUbwaWRn/3L73qvPHGPiy8/bOt9r9l/8ieu26tzp8LDvzx56MFrTvFe/MtvSy8/c9eip5+8MazGBV365+fx9st9eHt2Ab5jog1h/6Xf2+bWsSv+QzdkJscsN0Rv95kX//LSUOoSZwTBKJ7FRCLSZviqpyQDWgiMI3/cA1/59LnNYtNaXc1bgcsHDzIx0Rnf+vCD+XnLryECkuMz4KYAEcA5j6IwTYNDcKCwqICwKmF1d3UcePqNN03beOv2Fk3B+DBj/dzarRcnE4LG1tZ0w6ldB4I44qHHjw0lKpFJw+Fghhlb/RNJSM2giSMp/eTtn9/txBZufLHu2kxcNMuwxL5QEmrpCtCKFTBVAJDGom23v+TEv/x9Tuvs49oG/fZxdx8XukEFlgGWTQ8bgG3AcABmgCpBJOLOu6a+8IXdt+oGwN8XD6HJfwzGIu2F3KWAzoOPsyP5F8ze5LKTznt0bosQd92qIFbjhq/x7399+uN3/eq0v1592t5X3XbJD34xfZsP7ZVIJ+2wGsDzQgwUAkjThG0wdKMyp0Xogtmkup6sK31QV6f5fSUa8uha6GFtRuvYCJzJAE4C4BzSj4NDN+P+hx/55j5H1QCmjtfBaP+BgswI5KMfHbTZ8eWlA88TAenJWcDkw0ADGCICCpBUKC7KQ3sSzsTxPYdddP/du+7x9Rm1iWzRIOu9E7XqAySEodfdeNwoz//9663qwqo8C4wR5wQGCXAenSwwTCgtoueHUfnUBV/8n11abFKxrpuUlYvncUtk9MAQwnfmwqoWAdKozpr5wmb3/Pnymuyju1v/+MQb5cWz82dBg1jCAMwRcTPCAVUJ5AOmLaxrL9n9vPX3EMbxMTyVOgCQoPIykL8EvIcDnMHNT39xk0/99soxPCON9oQayzqQ8Wscg8A3jrvk4LbuzjblhyguLyFUBKUoilbPJjgcIy73WcdWE5CRY16VABKM0ft1zZ94/tVnBxJ9DBqGSYhICDDbiW2B4Ai1iH62exr7PHP4QWc2c7Ssz42hcubxqX+7JjPM+q93XP5Fb7C4jJsCualtYCaHUgDptSnroFCisHAI0g1hdXZ0fP6482//xjEXfar5iVEDmjX0XgCw2SZjTKzLxLPRxr7ZFddfVwzwKKSEyUIwNVwWMeFAmxY0M8AZY4dNSJ+y1YSebN0GXedNWj3r+J3NpPEDVMoIZ8+B2bccIgyg2tv6fknp/Vtt0FbZsxvtct515d7Ko9Aquq5AaETEnRho8i6gCBOmsekvPHTkac3avq4TUFriKmbbSfL6oIbehOj0ouA75bf1nXflwEHraKxUowCN34SDzonTtiUAXjkuW+r5OhZLSmQdBqurbYvdv3z4lPrYqCZlO9S7CbGvK3YGBg4BDkMIGGwVQ6zTXltUDg8jTZpzgHMFSBn/kxEfaAoGJJmAaWCHFD6z7LhDf3/aZz+5ZQsbqFgXG2j1pCO/T8WC8W8GmdoiePjOS0t/u/WKnbyhykphCWSnt0MkTCgCAIqejDHoQKEwPw9ZDZDIZZM77H/YlWfc9PyvZ2yyTa7xDrz+EcFNQYZzGulZUppAVOdPZrxZeDg1484Lr923KtkbkBKWkBCCogmHaSHUBjQTyECl/vSV3W7cZuL4XDMP29hu/NjYa9r8T8yrGvLtOeBLFkB4HlQ2U3h5yx2+cNoT/8g3bPbWhbPVGs5tcuY+ft59A4zAO1NgSSsWgxkgDehCBYDAtjtnP/3QLYcfNhJk1sVwLxdccJBoz32TqAidfx2iowgkCTrIFJ5+auL//vTqJ1vJTzV56+RvBFBZp8l4I9hXmqqKYkTwAg0iRHl3NtcQboBEyk7s+o1T7s62j8vUNcgz6+wxo7l/qRbKhPEcPH6PpEDQMIUFm5twmIOkkRB4txQfan8qKPMyaAWDSXCSICUBNZy3BkBpjlByEBPotvjEs3bc9NblJ3/3gaeO+OaRzfokjXWYV8744Rbe9w58kqrlcvrS6wobEGTGLgn5wK3nD774+1993OsvLhWWQNusDiS7kyACpCL4vl5bTa64II+w6IIJwTo222yXI6546G+Hn/LrzwGw1gdxG41ZjUDDuCBERNFCK5UlwlCBsVGPYRoNwPa9/y+fKDPnVWgF0wJMG7EaJyXCANGEd5Ec98ien7r5w1Mm5lr0BuKNoFprwWIa6m+sWkqp198Ae/st8HweqiO34s3tPrbLJ267f/Yo7TlU6yJDMe9/6B0f94aCVyOgaUuBt6fXFuQiLwS5BMZs9tkvTf7msw8efSoAY12ARs6/8NO8LXMDocSo8Bp4th+wPGi/Y8XLL87Ybfev/fbtmpa0bvK3MAiHzYBmcNnih0JNINNAqCjKu8umjSjBMlhRgCANZ0LX1OOv/8cjO39632kt2ozQGPVUato0pxkaGoEKkA8HMegPQJKECQuWl0bOyolvXPyVz6+DJk3dF/7ytJIy/hhpz1zBYCoGmMAHqlWQ70VmidAlaPDIEdGdMGZ8dHzmRPeMo+YsO/l7d88/4cifvPiDb+3Rao8Vzjh+W/fM487wjj/0NfPVZ15RQfhg6he/vSkSaAzCCGJE9H6F8LORvXgnzfxQ6ts/uev31qTxH1ME+AUfg6tBxZNgHLAERzLJYZsCZtJEoicNJ2VBkKL8vCXPznn+z+f+5tJjngcQNp5a69/adnXoeNeszhPLBQ9zXu/H2/Or6B90oTTQtc0kJDqTsF6+7+LbLjr8D8MTgBEnpAugOsxuTb6IxOKjD7lsnDt0MNdKaDeA9CWkYhDJBKy0BZawUBJ26dGV5csPuOWeO+pO2qBuvDR0xvFbJrj6rWFgW+pfGTXf4osXA8Uygs03e/jp7Phv73HnHwq11iE1Nb+ugHkkf93fi2WvJSCaK1855bKOyTiYCRIIqtCVKqjkAiIB3tEJlkwBEFg0p/rqUSfef+xDj7++HIC7RlOo87AQAJILz7+c59JHEisaVHkTMJYAugRZnvXHhx/DYXsdcUcxkr8me2L4u1FXhMlvkD9m1axlR4sYF3H5n5e/ZWbTOa/gobqihFASKp6ElATDMdE+vR2GIxCWy9WXf3fNKffccO6zI+bfb5ivmHXEdevy6uWnLXGSmLSwtxfzBhair7oSnvZhchOTJrdjYlc7El6nv+R+79pbTr33/mrRWwNc/vB7rYx4v8HItdZ37KG3tpX794TSUKGMKiAoqdZma/NkEizXBubYEBYHNzh4VOfEXFtoDQBUCJ+0qsYQpmCosI3yQ4x6V4BWrpT+9E3Pyv7m/p/jXVENZBtBZv2BhkdcO6HtU6566kfWJpsdxQ3DDKVGpc9FfnEeOiQIgyFhcdh27IHqnpFDpj0BPgyEhWUDC0tLF99wzpGfuLIZ0KwP2Fz58LI/5ybmdl8wv4hXX1iJFQM+KGHDzjmw2xOwO5NI/vO+i29vDTLxxMccABhZXMl89JD9dt/RCH6dKhc6Sanh6gsMipkwO7Lg6SRgGOgnc+EzfcUrv/qbO+8ZuUnnnHDENl2Os5tj4hATchMqFEBLFwPLloH6h6ANo+jtsPMx7Tf+/ta6lid2xHXNuOo2qd8AaDGxNXP3+B3f3X3HnTO/drJ+J0iDwgDwQlBFA4k0eHsXwCyEgRkunpN/4om/zf/VYSff8Y+RRtb+V8/5Ujpr72lm7b0g/AR0L6CWgvRKUIhiUPjQMaktrrgNgFEnuzNCfl7TGlpucNUAMjHxFixOueLxvafu9OFrDSFYubcEN++i6mm4fvwqDEsgMzkXHQqQUs995N4rrv35YbfVNn7t+jXSHlNvh7n4rVN3z4xXf+6nXiwYXIzBcBABBWvFdLiDnJ3GuEw7srwdFkvGk0UBKlTGkO5H+Fb6D1fvct9314y5/lCYc9TBJ0x2B08yPNchJaF9BemFqziIqx3aFmDZ4LYVB4wmbHDHimymjAswDkDFXSuGW9JEtYExMAilURraeof9J/76zsferYOlHmjeb5CpAc2IALavfOOUzbbc45BrWE/P5gQg8BXK/VVUVpQRVMNIXXWcuB5IW4eDdHcSTtKEYRkQHPBLbrWycvBp6fsvucXCk+d+b5e/rJnQdQGbS++aP51bxrfNtHOw2ZacMugpvPVWAUPaADk1W5YmQCog/eJtZ9591bFPjAIy1RETL2sTH2+ajTvaMnd/5bMnTg0LB6SqpU5ICRBFhmCyHIikDZbNAqkMlGWFIbEKQ6TlpZkMjEj1LZZAAyuBlX2gwTzIsob8jTa79W/KPPtL9zxUbNFYfmTYPKtztTZ4W9aAdp1B19pkRlfm3usPPHHqTDogmQ07AQWQAgUKCBlgpcGcdoAlAO5AutrXUrtCcMNIijTpMMZgPQSoFYAehA6NvCxPvuXFl8OzPnHATSUAokH2mK0aQNZpYY3yq5EaRKvk2PqUiPNue+PKcZtPPSRwQ6yYMxiX2PQ1DMGi2C6tgdyUNqQ6HDAQLX/uH/930XF7nAXAG0tzW00Xv3HqdNmef7FoLe/o1/0o6xIU6WZ7BzazI/uMgICGhk8+XN8PnHldz9y7/3NHFnpLxbq/pRFRPPdnfnqXqUfM6LmhvdS/LQ8DjjAEhQo6kNC+hI6ztyNHBIl4WTARx7MxoshZIWQAHvhR/hsFvq7OmPnEfTxz8Lce/MsAAGoNLI3cDGQ2BNCIGtDEC+ewU2/cs/NDH/+h7uqeqnQkANyiD3fAXcVVCKUiA5xhsFVPEx2T0kjlrOgaZQm21l5CksgruUPSDebHvnGQ9IOXGNjaCmvMMCZzwbsBAjN4G7eMbp6yc4ECyr7CQFVjsEpRiQdfEkytg4ysLnLcoTe8FbOfefx35z+16J1X1NrFXjtN/brrUrzQahPPamOvncz3HvDlfT7C5KEdpf4ZRuCbUCrGo6QDOInV8kay03CbGfg+4PpR0qP2Aykzubnu9FlXd//m/mvqguJiUGjdc5uaGkMbg8Yw8spbL/8fbjx4n4/skDy0Y5w3QxihCQprrm7mxCIwDqw10QUAeQC5IFWVqpqc65fHX5390FWR/PXX61E6Veo6LayV/LSaRsvE/+6PfpOeseUOnyetmeEkdiOtzVR3bi+WSbYvfKMfQ30uQkkwhzVsLhgMAWSn5JBsT0ATMPTmW//42WE7HdYEZMJ6Lfunbx59rMtKMyUFpFRsYCZJXCtiKtRCelooTxnS04b2tdCKGGnNw6LOFxd68954bO7L819asnLEOvPqxo26vWb/cJedZh4+c9LJE4srd0tUy5nYGCoBpWuVBwMJkiFAFLPUsRajFKRtu/mpM//yDzN94d73PfJaM+AYLYq8/ucbBmRi4s2BJuZvHHvlHl1bfvzb1DN5MzIMU1Fss5KBgpf3EVR8GFJDkALXOqrAl213kMyakYZj2QKc87Wgo2sF3qLPWmuEGggVrX16EghWPwNCNSQgkOVk4M9JKe8FVur9w2U/3PVvI2RMjkiINEeAjKyp6w335HDEZhVNrjDOms/Xf/mze2yeMD7SKb1pDEC7X5nEQ8kZEXGp4GVz8ziB/ETqtYqVeO7op16459F5iwLUqKHXT4uARjQEjMUcjnLN4C3lj5/WjRft8/mtNsvs0NmJ6WCgto5wEueaM2gIpqhaScwTglFQtf5VKrPnv3Pqn+756z/m+3WnYQ0ka7Jb9fI3uqQb5W8GMJfePX9nZhj7ctvYBYaYyByjnWwroZRGtN6olhDrSYLnSlQLQVRZT3sSdtQBgcEyRdxtJmNHWd4EoLpg0ZuXH/0/+xUGe0dqF0GrrOU6c4JR907jLP/a+uBNCoF7rQGt9cFw5Ee33+R/p47//AwdbJ9QQVtK+rlkpZwxq65FMoRnOW5o25XANIplK/3OAsP522fv+9NtzXKZ1rUk5wYDmRrQNJ5UzdTh8ZM3yn3x4DP2TU3b6nMy1zVZJ1IpPaJLhxqxEAwOCBHX5eV8ZI4dIBVqxeE0IDUhVLE3i0Ll22HYZ6lwoaP9l43Qe7E6sPCpq07/yhLEJOpUdqeF4ZTqrksRj366NNpK6k5qhpiooYdNoweFxjBsGqMk8IWjRKVS080/tvxmk5a1YcPfah1iz8eIt2HNe/vEXC//xb+bmxSWeYpIWl810vasgBt2NdQoh4SqHx86WgOKCCR1aIZhPn75kZcpbSbMhCUYTA7oSoDq8hKUH3fiMI0Y75hjoG1m3Aaquqxv0S0/3vt/57/9ylDt6ta691CLw8epAUzEZt0VMay7IgbNtKZWQFOf0Ft7543Z2C09ZWOzahaFvV7dCtal+VhNiOYu3xVL3tHX//SbNwGIjJef+NzXNtpkhz12tTsnb4Z0W49IZNpDM5kOhWX7a3AdFI9IAZYKKpYKq0SArbwFDFCMdD4R+gtS0v1XYfm8Z2742dfmtGg7Eo+9NjmiZWxJYzMrNZoRulU4ed3Emi3ySUSTxckB6FFAhjds+LHdvtTitKWx5Y+5vrd3vSZUJ6tqVkazIemwtfxBbRw1+S+5a/437Kzzg2RHchsX3BjyNPoLCnk3gBsSUp67IEXylZQOntDFFfddeOxuS5ppbd/98S07JTb58OnoGfexZJstkjkbxSWFqDA5kQZjHMoNMDB7AKlpbeDjuqbu+6NbfnvBIR/ae5SATV33bprZM1RdX6NmSaCof2ctritylIL1uvFd19Z/3Zyopt1NG38uxyozWttoGx5oWmfS1lg99cits1fxOyMGjKaRqq2rdqkmqp3ZqkdvE9sGbwEwNW2j9WlF9eNrBTJ1QMNbbtSYWH3xo3qgqXtXaN0Mv3VEap3RlN6N/PXgXC9//QapAxm0kF+PVqela/w03b9iof7J9c93tk2a/Gj7hOzWriL0VhXmL6tiSHFUPR1OVpUHe4KBH533vY/MqTMAiybf+a/O/fo/ARz4P3sdMWPnvb9/tT1l8oc6prUhyDkoL82vHYRbCVGe3Y/2TceBJk7e+qif3X/0VT/6ypUtKiDK1us/HmOTxmmqpsU1rEFex3pYrFGDRuvmy2hSRLx2wNWINcjRuA5Yk31FGxxkGoGmEWSaJuuNnbfEMZJqiCvqtIrW98ga0Ri9oKjOrVtn22hUWVsCaWstwASgmp/kNbCpW2BUD5CtU/cb1d/WANM4b6PL37hoG/pkN8rMWgAlGrTAGsv6MawGmIvumP3Fjmnj7rCTlpP3Nd54awhDThJDZYZU6C7eQq780gVH7fAmANaqM0aruX/s3muWreL9jrv44VN7tt/p66kOhwujHZWlRWjNIZiCW5FR5nZqSg7GrG2/mW0bd30xv7JV4Fzjad8Iorz2s4aDTo91qNWBN7UAGNkqyrdxDsZOpRmtC2rrXtgbHmioxs2rpLcEmrERl9d5UqgZ0LR6mS2uG6g9a+povb2klaGvfqO2mHjRcqw1Rp2W0HQc9RrAWA3x11kTbX0yimaZ83VzgLpxtACxseU//5bXt+6a2XOn6Zh2/6CHZ5/pRbG7HV6gMEVV/7ri8V994YI7zlON2eGtOy40uyZfevznLzzkh794ffP/PeAnyZxtmkZbXDfYEZGNJ7+kAJ20ITLp3N5HnH/gjecdemsT4Ef9gVU3Rg4gqGnJddfnRlCvAU7rDc5G22OtcuXGABE1Gjfutdo62sAgM/aCbXENMmJuTEsfQxNpvAPHT95io6DF6UI1VTem+slqBTBjjJuahKMLAHK0CR9DbmqmxbS4T4/dEH/d5Zf10bQtNpmuk7NxbGPLv/qK1NUxffzjqwGmUPDw0jPLMWClESiOHua9teDhi7/4+H2/oDrgFq0y6FuvoXhsN13y/Yf2KfYP7XTAkVeksknHnp5DfnEx6paaLwDFfhfppA1n8uafBnBX61O/8cBq8p3XuGWZEtVkfqmOW4GMGh1kYh71tjG2cZhqXHdd+jcDjRoFKcWMzXdKj5u2RcZMtqWVMBzFYCnGjFCTIK0ZRs4MAQZpxeNO5MTDqs+5oUlLRb7r+eUht3/p25XexbO9MdRMtFLj16Uqfetx1ya/DvhEy4ZbNaJWz1Yg0+LaiLEA5n2Wv1ENH7uUJo0mf9vkyY8ls07OdwPMeW0QKyqA6kzAJuVll77wuTtGAMwY4EetrjD13+++7qynk6ns8Tvtf8jlyWzC0N0SoaxEsVxDvWU4k3IIMuNmATBbgkONdYvDVo1SWZDGfE+tgUY30ZzD1lUNYxr7Ct5oGG6a7rP+uUvr36Zk1rafNMZ1TzQ3/sgXxyHb0emCEoFWZuhXjNALhQp9LmXAVRhwrSQHacahGYOuOcrXQj8nJngEZgRO4IZWmhGBadKkRBhKrqRPbqHqF/oqfYvfLC9fPj/QgUsq8HToV3UrDaLFpKpmG3jMcddEZh8Z12lUA5/7SvMUZzxQmisipolYWcciVJSmUihpjPBt3ey5fqkXY8u/03YTjErV536guONwoZRmodRca2LVqqbVz0pVUrka6rEAciz5L7lr3rd6Nu25jjRh4ex+vPRqHvm2HJBLYiMq3P6r727y7VGSNVmzK0iLKx1v0j7FOOnyR07adJePHya9ECveGcL8pVUsWsU9u8wEQPTo97f7zEDfkkotWLAx/aG1h611j6Qx7CHUyI11kGbmMiIrmHCl5A5jIpCSS6W5JIo2jAZYRUciMVdrqkpVm5/1aE/bQpPZ8BrNz29fwBb2zjfaU9kOmcz2VCyRVFJy3w+YqFSxipVUXJNX5twn7hBxphkThs1thzHTBhMCjDFibLhZPmec4lljSoj4MxGD5gLgBjQYERdcwXAUmBNq3p7Z6Qs0Q5EyXdfjYbXqrpxffP1f/yiyoEpMBeQW+lW+b1FD6sK6b+Dav5328R3Y3uMyRv+KFXyzLbdq1+VKVrvlREiakVuxA19ySZpJKVmQSPmh1HBNy+1TzH1oeV9+qL9Pz1eQ7xTKrRYYrT+4tJb/jGM+yfbZc4rRV+jnm0/ZpJ3gZjVzE0FAjLhrB6HiMpSR/KHv+EEgUXWZ29+v3AceW5AfKg7peQs9OWdBfp3lv+aJ/nMZgErBQ3+/j/6hAIlZqUg2teDlM5oF9DXW423UIOpP4FZxSBcc87mfXvHY0r3Tnbn2THcSyX4fDEDgSQhLsE233WXi3/90+/x6U8Dq/9ZIGHCyJqyMyTPjkio3MRXJ4RZ8FlQkAFBYjZ8EgvQV8/IBVfo8Kiwv12Qb8wpd8xA+tc/nRHtpgGPijIQj/Q6rXEqr0DPdatViriuC6iqWIQuFRdI0dMC5rgjb7+VW6a7X3hgYNCz9wlBJAqDmB8HY4PKBaDJn/X65bWrZ4VnWBNfiRhhoBK7HvIIHP++h2p/nQvks4TAmTM0MoXm6w2LClJwxYggDqDAgGQRah6Gqliu6WiiGjAOkgdJQvyeGy2pyJshOZw0nkRJgBDOR4MlMlpvJhGBmwgiICRcmDbmEkgsKiMG2TEppFdrK9+AWS6XeeYW5L/+5MvuFP8pWk/puNnH1uG8bYmCZqdu6O/hQX3c41G8xz0OoiEEIIOkgcBJMCpOBMQRhyEIpGQt9kOsD5TJ01YVKJGW+vav/yddnDyzNtIW/eGtBMNaCw/tAcv6ZBksUTArSHcwqdodUtMB8hH7AwASIJxBIi4WhYCAOGUoWhpqBhyDyAVQBVYFyDVkYSvU//twbA8uW2OHlN746tvxxf/NP92wy7jEtZaRFvPp2GXNWeOjYYSoyFKy849DJGwGw6ou9t6z9UvusazxmeIM449qnTpu147bf9yoB3vpnH954pwh7y8kRiAzcfsrhTzxw/ez6bPGdDvhQcvy2bY7ZCc9qN2Wiy5TCEmTYorZ+EH9UHjHOonEDxCQ87gWDurJ08VL/0eP/6aOBGtegd+QBtk5mHF4cnMAHezOyWGSkNYJQMkgNAkNAmoWhYqtBRhKxtcl6MgSkBBwb5c5x1Xl2ZsWLixdVzp+zzKubm5bg8oGBzHl3LjCZxbOe6UwJM46hfIXqalAZdFHpLTKtJEyumeMItLVZyORMZmUF4wax0PWZdKthaXDQG1q63M33LfHmvvYP75VnHw7GdLU1PimVaWd7fevM3IRZm2SzPd05adn8nXfK6C0qhJZF3LJJODZpxgAzQVuFKxZdcfROK1sDS2uqnH4cQ7WYFl61hxcH2lilCCiCxnAv40QCyjYYpbPQTsYLmA4UIu0VSpEAI9PSSshKxWaFAaCvD+by3ujSWO7uKVVznSv+1J8vH/Pk87JRrvWncO7PGOCmuaN6YFXamOkCajhBUjGA2wiQZMzKgJSlPZ/70DwkpbQfKs5tzi3OjDB0bS6qAuiDJVYSBRrVYqZUKaZXPPq3FeWjznh0VPmvfGDZ77umte3llTwsnlvAy28VMKBMtG85Dj1B8dlfH7bRF5rkPvExK9g1ekYwGtDs/r/f7vzm2Ze8DS7Y68+uwKtvDcHYagqYwbHgyoP2/tcLj/XXJ3Nmu9LBZ0/acUJ2cxhuZymsOiWFNClmEwmTkwqJMc1gcAMZI4mkSMFkFrSOkySrqopUpTNM9vbMvXi3m8ut5rd6yvdMaJ0Wgyun8mKfiVCCQgUVxE8vVIyIAYZAaNqMDAtM8DjljHFI0oxpCREGYL4LKpaiw41NmOAtap+w5Kf/mpO/752F1GoPfKAg89N7lqS5xccHuXSWNMXAMuCi3FcBJ8BJCDgmh+0ImA5jbVMysG3GVCUkv1quFPoHveVvvVa48cLvlAGwdWyIRqOBzhm/fmbapM2ntPcuK+ONfw7S4uUuAiZgpi1kp3aT3Z3Ext7Akgu/86FerCO5Jx7hgFSHUegdz0olaKUhFQeEAVgWzPZ0lHavTdslJkrScAZSZ1/sjiz489ChXxNbd7cnk7aRNQyW4H41y4b6gMWLoeYvAjwPxmZb9hPT/ck/PFPB+0hywTkODOrgyep4iCookKCqDwQaIAsslY3qlCAURIFVoCAswWdD5sanKIygOX892e7szmSs9kSak8pwq2KSXgYK5oKoCkvN6odm/cbM37aU/5q/9C3Kdaem5FcUsXRxBa/MLsJLJpHbuBM9lf4/Xf2dzb9RV97CaEh3aMzbkmN5RZoE7Ymr/7piXqot3fnGK314+bU8+BaTYMjQf+A7kz7VJCXAA+B2TesIDzr/MzOMcUoO0KDMO0PSY1WCCeJMIJfMoDuTQ2eyHemgy2PacM0kxeUeUEYfrWBioM29eOO7ljdfa99JMulPEEN9ORYGUIGK2ZdQUoFZVtQEjtkOuGOuYgciYUNaBoPgEciAAaTjAmsUhoBXBSsWgRXLoQtFeFNmrkxkcr2pG+4JsI5kbFCA+d3CDp5LTqJcQqi8p6srqyitrEBLjVRSwDI4bIMh05mAlXVgtiXAiKDKbqncVyrMfvbRod9efrRuCipjAw2NBTi26bhOIpUZ32MgnEVgwsGyPp+8koJhWbAMC6aT0lhH8o49tI2rYLzhFhwi6JDZ0FpCcQNm2oHpGIAQkMLpUyIxkDr3Es9ufjpIAMXVXDn3FGbYrItNbWvj48an9LjxwOzZYK+93K4mTExXD/p8b/K2h/vxPpBaekYbczCepwKHFDQVFLTnAW4IlsyCd3UBtgWqshCB7hWTju+vnW4no468Ye5TCy7IMtHdiWR3jngOkG+CJWe3a7c7Hc49stec9cum8ptJo5MAaF+vLZFq2wKWwWBABXXXpLoaOq2jn5t531CjppGvshr2og2dWnCIrjQCSWir9L49ImqX1dt1+hcO6vwK15va0SVMM615JUX91KvLKJMBA4mcjVTShlXuKFMlvez4zc+rop460JS8E7+T4dKfYpQHLc24DmFCSYIGA9IOhGlHRe15exbcsSEMBsYJ4EZcXpaJkBh8IeDrkIFMpZFgQLYNonscV5NnmMgPONaypZ26pFKVb++zIHX93d7/FyBz0f1LeqyeXI+2DJR7y7q0ooywEsAwOAzbgCHiREenM4nMpCyMhIlgqCpV2e2najBw2oGbKhy4KW6+7AcAUJdb866LfLc2ZMbV8bRhWkqbhPZcEhMnCBRcQqj8kahEWAeqnvCdTkMHE4VXZEoxLSWDIgFwwEoYMEwCAZBWZnnivF/24V1S6sfnEYC+ytknFoSd7TY23qQTmSxUKgU+f77gA30Tq1/Z1Ure/+Sy9dNgzurkaTYRjmS6GmoqeyA3brUCxwLvSAKmBpW1Sy5fbkw/vYx3SWL6SUU594IyI2cKz22S0xULVHkNzF4umDE0MVzwTcucfnOD/JwzAwC0pnjNWByeknBMBtjW1BYlLnRze0zrJMZmpSLq3fdErEoEuAFFwXiaALHstVsAyBbpFBwAG1pRcqdtNi6ZMhM02Xa0ww29yF1MgfKgklXkJVFHcfOFJ2x1Xoh3SZUfHZ0yoaYI5RmKOzrUAbQCmGmBmwbgJMBtE8I0IGwOYREkMWgyKkxTUUoVEGPhKvatsy9WAo0kALjnnpRgmbYEBgdSnImJlaO+vjx11S3uBwoyF9y3ZDzvzHRyg6vi0gLKq7WXQIMbApwBYtgklxyXRqonHc/28vyQClThhD0nV0YFh0YivHfSABQBEBywLQ7OYzsYvYff7516ZLvJwvGcKR3CggpDkFRgWkEYBIMrEHGEmc5lyQt+NYT3QKkzLwwALPV+cqI0J0/q4oaBMCSIRQtg/PPF9uoXd2bJB59ZivdAavHP2nnOHg8z1FSoQJcrgFIAj18IzyYBU4HKOiQfi1YBjI91JGPWSVrOP3+p5szkmRm29n3ogQp4rgCeeLNdLvwaM6bdOlJ+aKl9IljgLDqcHIfDdwNYBqAy2U0mz9wqvWTevzDCo4RRcrhUjUc3XDaL3hamaPMVUAwAlbSR8yu9t1548O8BJADwFi2RWXXQC8JAOhbZymYJZfOkJq0oKk4lJMIwpBO3Ov9dA0z1jB8aBgWTBCemhKVCCkHcRATHxAHTADc4DAsQXEJJE9I0+5mWrgL3kudeGph4d5T48QVrKg4MekcdmGW2ky4f+y0/fdkN+gMBmYvuXTzOGpdrJw69OvTaH4y7GsJkkAogAjQYchNzSHYl46pd+dIKthpg9p+h8W+lRoPfewWx6unHJE1OPcwQWkoLijEQhSDPAycNIxk52BF2ThyIAGY9yTn9wl7/3BNsY3xPSmy+OYJKFdbKFRD/ejVb3Wd3mbz7L+tkR5Lzfp7kObMHFtNUdEFlNQy/ISDDqLA4S1ggjxEFfKEx/Qwf75GMGSdLOe/8JbDtGTw3E1QpQfe9Bt7tgzlvZ+Xcw6Qx67q18ntV2WumKIOotguLCptV3QBUDmC22/ZXj7zwqCtO/Pyv6gp9N0uu1fW5W+salJjMOJP7PAUvk0RY0ugceOOsmoZUlyxaY8hA6tVEoIg1aR1SSIGSCLSGAiOsA3HtTxRMCQ2upTZiA64iEAWAUuAGg8lCcKkgnZwPYr3O2ZdXsJ7kXHV7sXry90xmGB/Mdemiuxe2ORPb22AJlV8whLDgx5qBIqyphAfOkZmUi65JuuITHyovPWG/6VV8MEQA1PsBMoYKehiPFHoosgBIaN8HVrGIvyLMTvTIcPrwPpGyksuF9GcYUyZC5ovwy1XY5SGIl1/MVb75pWrq5gdKeJfEUqIHjtDkS1BVAYzHAKNcMJuDpQyAJKjcudSYeaaP9SRj5smeXHpxSbS3J3nHRlDVfqjeuRCTAJZ4LSfnfL9qbPyLSH6/5D+U6EodLdIWsLKKTErACwxQyYPV5cDYcrtDPrLbnn94/on7BpqnkTT2fX4vsUKrCmEdJE3TWbi4gqLPMJmKL1x/xpfuBuDUgKy+ZkvMpIm0IrWaGdcKjDTF+LXOwrhnHJu1uHI0cSVDDRCLZQx8IAzAQDA5wJVGmOyuEDdXJi74ZYj3iZLnXx1+IDaZS363wElOauvgttCl3tj+wjmgpIYfaEhFAAEdU3Nw2h2osq9T5fLS4/abXrdg//M0GfeMY7osQUJraOlpkJKgShlYxYIRBAeI26TGTVyeOvcyet8m++RzQu/sHxbNtJM2Z0yBWtELOb8KI/TAX36pa5VK661SacdcEHLReV2iwxIUSE2FMgAN0kEEMNABWCYLMAldypZXAUwF7xf5sg8aU5jTDpaaBhrqg+4fAu8GWOr1LjnnNM/Y+KchZPijwA2OELZpOe2JKBkynRDw8lWgkoDd7th7HHneNYve/uchvcsXeKOlZayPq9/uzly6vCzRJzmSQXVZ/unffNlKpIhzA16lUAOZ5sF+mnMo0qRBjWC3LsAnuOoEM7RWBIKM5opKJcCtAkQwkgKMNEIz65MwVqwCGIUNSxseZH5y8xyWmdQ2DpZBbt5V1YFKbI4nguvpiAGgY3o77A4HygspUSwtP27fGT4+WNLrq8mUTzyC2Wk7DcNUytMgFgJVF7pYiFyBRoIDmiC7JhVXAUz4vg+Am3kwluDZLMTkKQiWLwcrBTCKRdDsf3UAGPXaFL59JhPd7WlAKHI9gAhQPqAKsRaTtsAcCxQahLCtTgtbb23GV/1XBjyREizZA+ZOhB4cAKwQPFsCjPmR/D/cd2blgrsXnJ+a1vVjZ1wafMiL7FuOzeEuKyGTs5CcNGHy96589NZbz/rGYW//69mBRi9kY6rEugDN5Q8ue0y2p8fN75WQlaAwpfjO7jf/6fZSqmO8HXoVsrWC75Z1o8E5fnKDK3AuhcGkJigCvSeNyj3juJxlMWgJpWiNZdaFLhQAJSPngtCAcjJKdY1fljrnUoUPmDjeB0q2JTqcXIIpL9TFZcUIqZUm7flau4HWUpF2ulLa6kxoGSiVGCr3nviBA0zrvAwiaJKkY/PR6CAjEsksNzhpCK3BNbTWVCpoqrraFNCcaU2pjNSJ9CA2ACV/fL5HUismhGbdXZp3dmkfQkMIbcye7ZR/cLCJUYhZySyzbKKQNPmkAa5JVzXCoiZSmqVsDVKa3FzBmHWKwvtNfuAB0LCSmtnjNbNymvp8DeKaJeY64ZxTI/lP3nfGmdVlhaeU0sjMbIdIW+CcQZBC4Z0h6FAhM7Gn5/BL773z8B9du2+rDgXr2o308rvnd1/+8PK/y/b0p99aKTE4FHqbY/BLj91z5cJUbgJnsJgwHRiJFBulnKUGQQrBlJW0pGEJ1byM5djEuU6DCa0hYkDzQ03Foobnaq5CLSjQpKSWXRN66wDmP1eTufyeBWZqSkeCA8ofciE4g5QE11eouApSAsI2kJ6UhdaExFCpcOL+01000AevyYxcckQ6emqNUUkISoIxpYkBUNE1SefzsbHUFIAkyI6JxfRF19AGG4QMpRAW55k0WHc3aPkKhKELkxP4vNk5AP2tbTFmMm7zI+MXoENAlkEURBoMsw1ACkKYymNDkCIXgMUMC2S2AXYXKD8IXfTBczaYsWit/CftOfmTP7938fO6K7tdx6wOVAdc5BfkEQQB9DuDGDcjh3Quk9xurwOPu2DH3Q9Y9uY/77js1H2uqUt21COvNK00msvvmt9OpnG26MkdNqBEYsEKCa/o9X1IlPZ76cm7n09n241KucBBgoMZnBs2Oakc8yoFDQD15VqFyblpGWFklSGmQaB1vS5Vz/yhY1ucxesNEVGpCF3Ig6RE1O02DKE6J3qpn1/lA8B/BciwhJO1LENVCtWoex0DEEiNUkXBdRUY5+iY2QFmMFj5in/aftNKaEkfvOG3BjYMww9qOennnGTYFgcYlNYaUDq6G5Prxq56Bmhhk87kNuiYSUMCEEwYEO3tUI6DwHNhGhxiwXyzfPTBLH3Fb6jRo3SxIXpSADFF3nAsjCwDYRFQCixtAghBbrdrbHQ6bRjZdQBAQQiAJ8CsTpDpgAY8IJsAnCXmKm2GYZhO3WvKR8+5c+59bHzHHonOBJOCo7iigqFBF361H93TcmjrTiA1sWfCFpP3OO6aXfuOKq8cmlstFF9084OP/PzYz95fnwHOGMM5v3zcSnfP+DITfGeWsD7HJnVsUpIwlhc0BgqB7vCrD0/wVhxS4QNlO8UMzqQwBRNcGFzJyHXMDDsFVAqqrpmeAiDtlM24YNKwDAUIbUAQKlgnEiSja60MCVAE+D6oWABVq+CCQxCBYEJ19uQB4L8CZH5+6zuiZ5NuQ68if8gHGCAlIg3G9RWCUCE9KQ2etgA30Enf+/9q8ESkGaDBauBiCg4GNjIfX6MFMSUdJEytw+H/Ogigy6X4VLE5IAl64iQ//fMrCRsWZVSMigxIpcBSSaihAhQRhO8BvmcD8Jq4xByAawpCgHisiakSSLkAA5gtAE3QMlUW2ECkWQhAM8EBZgBGDkykQG4V5CmwpA9ioQ3AB0A9kzfCY7ed87Vdv3DkIWzS9HNE0k6np1ngHSn4RR+Ll1awdGER7T1p5Loc5LKOlZ48YfPslImbc46v3/ByGdFIJVHg+hUr46SlGu5woeOeXHmXkF+pUK3KIO26z8xS+R/87LvbvgGAfe5rx1kQ2iAWCpAyOOeCNOPcMhlLpNBYBD0GGsaY4AZXpmOo0CVqcnjR6FrMCdyyDQGQJkWxc6FYhi4WQZogTIq1mO6JQernv5D/HSAT22JShmWqasEF+SEIgOcrVKoSQajBLQPp8WnIUCNXLJdPOmiWxgamC+5ZZLqJhKgERH6o4a8xsYHWmgBNwdCeEGi3Ta4ISoUqmijH5BjXYaHqhpC+hCcJvkJLYgwCDIrAAQKoWgGVy4DS4PHtCdTWWcEGJx4vasbALBvMcQDBoMAgBAPvX2k1BxkmAK6ghl3WWgKyApAES9hgBoG8lDZnnSmxgciYeaKmyg1qzR5jIg0yk4DHgaoCkjaYGLSGQQY7fXZ/U5iS/nT3hbe6ZXXfZ75x6tnombyXSCbSlmNCUgoAkJcaxSGFlaUq4CswAMmshUTaiD5LDUYw0uFACDck+BLRs+oTkm51doeq3FJ46eErr/3lD6sjawW/8reH2MYf/phBkMK0TW4YBo9jkjmgBRmGpaUMGiooOhkrTGQdoRVFBAbCOhAj7TCDK60AggaUjK5J0XojgmCIk287uqsA8F8DMomOVLTJ/KIPxlkEJmU3ssXEwDKxDdw2YFVcffpBMzz8e4jZYWBywzRSGQdVX8ENNEaW4eECgMnBsg5cL1Q6JFgpC20JgpkykWizsaIKeIJhUWAbh10z37zuiBlhoxEu1mdiDCOgUgFVXTBIcG1AJ5NIXnxtuMEHzGk4CokAUwCWBcY5VCQkAy/mGZoQN8xIflrzcrQHaB+ABhJ8uCVtKsCGJ1WrQGYAwolAT3saAgIwKoyIaI/9jhEf+vgufPHbr7FUKk8D/Uv9639+9JlkBOftuf8PvpCbtPkXeCo3U6ZzPaHpOIHBEY3GEnHgsgdwX8UONEWQFKcqMC90U9Kbkw1L/2f3z7/7mjP2nIMamSO9VCsWzead46eIdEebadqGMExzFduCmSaLYMtylJRBWHddUsIQ3LSFFLZBZDCCi3UizsgAF4rkMNwpHQEM+X48x0qDTAupS2/w/2tA5tJ7FppdG3dpGUhILwQRoniYclXCDzWEIeCMS0EqQrfvVfBvopP2nhqs8giESdswOUKjI2ea5DjwJaCptlxszpCxGUylonwczhFRG4DOacDkisKgApYVDQRlI/G9mxaxqw+ZGmAkCUZgTAN6TTBU7LYWFJ80mTaFfwNxwXVcpStWr5iIDlcQZ4AAWLVCLf6PBDAdiU8apPz4qkQa3I5tpKSSwb/HAE+R7IAAYxaIi+GUQwEIjyIt5jMHGO3j0qw80I+VyTyY7ZKZIc0MV/7hlgsfHlzy5kNrEiV3/OTeU6Zs8uFZhp00s+M33pIJoTg3NOOmZowTSA+G5YHXZ7/wyDNPPnDtQEMbndY5cnzR7H/qLXf+pGnaFjctmwsTjDkJMME141wCqGeV7khyrUhzTQSwdU6PYSYnMGi9RhSpAK2G1WmKQEe35zQA/NeAjHAsAwTtl2Jjb6g0qp5CNfIoEZI9yci7YlddfeqBMyT+jXTMPjMIQLCqwX6Y6EkHLO+bJhgj1IiBIQRBctbYCoABKR0DUJtJyCcBMBjn3T5PnnLgzNpERgATN8slrUDD/YQ5YyCpQE5ig4+7+pNTmW1zIoCopmJFTMOaDAK/BciwkRnugA5iJoBZAiANKLFBxyDnX8TEuI5hlB6eBSYAxkGxKhYlCgNAqr3NBFNMiCRSufHaSgXKIVLgFSm8IkZG+j7313sWruLFiOnROm9PfR6T1bLsQyOxUqGfyUAKzjkzLBvcZMQsB1yY2i3ngyb9wLSTsrSTtpSdTlB+wF/3oE/GCVHWdAzGRBqwbLBsFkK6AIXQbR3hfxXIJNusyJUmKwGIgEASihUJz9fQimC2JxEqQnfgBfiAaFWwHwGQl92zUIFzxprNKGvRbIYAAsFgQKcGPAOArFsIBF37rCNggR7GHc0A09bY0KQVB+NqrWQUf2Ccx4PhbCwXfo0oBLQEM1j8XlQC5ibnEDYkMeIAKVK67udi+Cjgayelc9J4rrXL2tomYqgTzElVgGRCKepXMqjUN/fT9S1GGprm1b6rUUCGmkktQ8mSmTQ3HEEmJYmSKZ2EatlEL9WZ0umOpAwDeq/vSa89BqUEXBfgHFZ3O4RKAsUCKJOT/zUgc/ld81jnJj2aNEGH8biCkFCtKoRSwUzaMDIWEEqccdCMD3zgx+49jQDQBvB/qziii68FGmiKlWEikDA2OMgwUiwOoAOgKQY5IkCI4dsHA4Qxlleqhjlaggwr3iPSJmxoihVJDaVH4h5YpM0MazU6xgUuGAcEBxMsmcrwbMd4JmQVIpXVnvIZAL9JG13RotAZr/vcCDKtuyvAEBbSbR1wVQAr6RA5KaJFL1Ra9EWiCRt3xZ/fKxGpNWOgwIPu7wMNDsDoToFME2riNOJuhXvf2tMkGQJ+AEql49ji9i6Vuuw6+o8CGTIMzhjToVtTUlxfRTklWgNm1gGBIeP7hP9mUtAAhjGGxZuC1oAMANPU+PeQJkJMSsdAwzkYHwYZJ4FmRJI0i+QXIw9tMDM+MUkZhA1NsaaloYeVEFIxWDMOGNEAQDqWX4WaJzIZ5qSzLFlRrK2jG3JoCJnxXdq3bZ75xzhZGlrZ0Ea3OdA0FkFrbEZfozoA0pmOLliZdmKe1oad0WnI8KV//rlaBy6NVf/fI5FmOjrQOAeUigI+1dLlkAULRi4J0e4j3Gw7xZTPDekxFPOgyiBDvgSa8zrzdtsCetpMnbz5AfUfATLMNMAATVJDCIFQagSSQ4PDMBnsjmQENkkVavwXk9YxyAiDA5YVMRccTMfr699BnBEB0IxxcA6Q1jAYwG0z3r9cQ2cyaEpKRfJzYQCrmIQFmEYMTNAAiQ0+CGbwWH4NCM4j+eOeAzaQGK4/pZLxQVYOyUzbwmlrgzkUINcWMj9kcAyO9LQ07br30eaD153utuzQOXb/JaoHkyZPbTspjJ82nVWYozm3tU0JHbz2h0KLXuxxBvfsU+NxAjCEWMUGDEPA4BzvhkhRPFecAXYCSCbBBEfoE4QfgAXe6uxoBUBVzz2ZsUwXN8hnrFoFBvpAA/0Q899h/o4zDd3VSXrSDJ369e/o/1uQEfHCANOAYRqA1NAUAsyCYQFWuwMiwtlfn/FfDTLD/hzOOIPhJCAyGWjHBkIX0ATIcMNvUsYIIPA1IEMEYgxIJGrmgWxbczlCFckP0wCTFpidAaQDsnRsWCS24eU3Ba2NhzTi7GEYHEgkQSkTBAFSaQKAoOx5UqdyRsZGIp1Be6BYqMA0aZZuS7DcR3axd1lxePC3B34dNHbobN3IrP46NBbI7PLFQ1LJrsnUn+fEMmnqGZpffezpe70xKvkTAOKMwTAMWKYJy7FgSTMScSwa1o/BDQ6eSUNMmghzaDB2YZMEhXJkPtvaSPbqWScwke1gYupUoFBgfGUveP8A6JXnub/TLFITJyJ579/0/38gY3ICQAIMlmlABBqamzAsBmZxSEVISIn/dkqeeRHJ80/RzASEYwMdHUAmDTnoQkMj9as7CRuYuCXiuTAtgElAydi7lE5BBmWQJiRufbipHGLaiUTl63S0qU0HQBbQGUAU4/3EQmxoYo5F8R1TAObwXtYCoBSQEAAjGNOizpA4fu9p1Sv/vDJjtaeN5Ph0FDSZTWvm+QQzNGDlDLb9Vw/PZjvGFR68+ac+AD5qT+x6GruzJe24+77mZh//VHKApbUvBY0rD1Qf/PVxQ2O1CTlu05/Tb4vnaMYFLIvD0hYcx0Ko3h3IJM66SKtLTmMs0lIT8VrL5UBDQwhlAApV8zV61kVrZfLO+iHj4yaCVUrgQ4NA32rAidPa/l87d88axxHHcfz3n9m92XvYvTs9nB0QcnAIBBXuTEpDSqXIGzAmRG8hnXGRgE3klCFFKlV+SlJIjW2wMSGkcgRqglQkOJKNZFs6nXS3d7szu/MQBFJjrCbYhez5wAz838C3/L1N5JzDSeF53/+yIcLJuMNiQftbKXpPB1DZiDhjqJ0SFDYZ2eGIen+v9f988LNc+WPJvBqY/xua2YtfVz/59LPWKJ7Akx5z9f72aPGb2e4xcTmpfGQ87/rSZp3VxaRJqjR8OUS+m0P1MlhTUDKVIBkLiAcMcqerXqz/Izf+Ws7v3pjXr9vexfHc0fvi0uVoeuZc1Jj+uLEX1LG5XSJR+WDl1pXd1eX79h2Mi4+M5323uFWzFd5xY7XAZBr7mymyPQmbl0jajManW4jbAkWaEVRR5Kqv+ls7Ju12i9XHD9Xv9xb0cZG58PlceHbmfNg6/YFotMcCitvRgCrBjhLODUY6KfLdtUcL6W+LP1i8u3xkPO/ar88EC1lLNepNCYIclsj2cphRAcEBERJanTqqDVC1wsCcg5bKwRjNBSsZAGccVFa4SiLIWILJFTR4KK3jI8P5wHFkBXdsKHVVpj2IJPtx7kOF94OPjOddv7POlLHCRGIiE1EjYxy6sNClBoxFyBlCAuoRA5UWjAjVOIQ4uAEYCxRSkgEgDVDyyOWlQyodKlluG7oYCOj+vg70T3NnCryffGQ879vb6zyt1XmcZ3FOQVMyXlFhECjHYCzA4GCtgzUADwmcM8ABh4O7MAdfoVE1ZdGETiOy6XNdUR0oM//V4USJ5yPjeVdv/ksZC0gyTnkYYkoNK8oiAogKRzULOBxwRzuczgbOydCZbA0NHZsS41Ta+S/POrwR3n+GLBQbZPeY4QAAAABJRU5ErkJggg==') no-repeat scroll bottom center !important; }div[style='color: rgb(102, 102, 102); font-size: 16px; font-weight: bold; left: 208px; position: relative; top: 78px;'] { color: #555 !important; left: -70 !important; } img[src$='hp1.gif'], img[src$='hp2.gif'], img[src$='hp3.gif'] {display:none !important;};";
	GM_addStyle(css);

	css = 'body{background-color:#000!important;background:#262626 url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAENCAYAAADOoA9GAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAABZSURBVHjaYmBgYPjPACP+MYFIEPEflfUflwQRSojgUiyGX4IkJTTRi5P4R39T/tFByT8qa6OJof8GPJgGPjHQI/FTki+pWFCQXlQhsZiBmBFMwLlgwAgQYAAYPe0bQ81rlgAAAABJRU5ErkJggg==) top left repeat-x!important;color:#fff!important;font-family:segoe ui!important;font-style:italic!important}a:active,.link:active{color:#1160C7!important}a:visited{color:#999!important}span.a{color:#1160CC!important}table{bottom-border:1px}div{color:#fff}.csb,#np,#nf,#nc,#nn,#nl,.nr,.ss{visibility:hidden!important;min-width:25px!important}#logo img,img[src$=logo_sm.gif],img[src$=google_sm.gif],img[src$=nav_logo3.png],img[src$=nav_logo7.png]{top:0!important;width:0!important;padding-left:135px!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAAzCAMAAACKYutbAAADAFBMVEX////rGAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB+wWvotG7po2+juc1gUk6LrOD2b113pN/Pf170w3eEwO95pdl+x2iFrMl2sOzuWkcAAABbbpByksLzSzdr5UR6reQAAAAAAAAAAAAAAAAAAAAAAAAAAACNqt6EynBuhbGGquAiKTV2r+bheWRdOTZ1nNZsnNf02YWSxu9jq+vqbF3Nel9EJiCOreB+q+T654KRuuWLwe51uO+Ft+lwmc2bxu5ilNpabZF8uu/64IWkzvU1QFT34V8aGBOLuedZXmTdxWH76Vf134L66397Rz2IpdrTXlH67JDyeWrxoGhijtD4gW9vlcdjeJt+rOTazaFzj7/sknRwtOz4TTf2cmB/rN+Buu/PXVDUfmPrWUh+o9P4ZlBYpejLa2DwfXFpqee0V05qq+uHuuvBV0v2MyD0cF5qo9/zXkuxWE/tWUh+x3b1fW2Mxphlo+Vyj8GpVk2Qt+Rzj7nndWn3eGai3L5lbFiNruGKr+ImKS2Sv+uPss1X3TCLqd2Dym715XpY6C2y/JSi9oH4QCvxRTb0/av0XEyDrun5TDd51mCw2PiezfJrkde52/5uoeCQuOj7bVhtmN9xlNjB4P6ezvf2bmB/o976YEyWwOyEyZyw2f33OCV2qOSLxfb+8ZX2QzD4Zlf9vJe57YD0YFOa7Hv+oZBli9X50E/96Ib8lHCEten75m91nN397W/Y6+GIreT2TTz++Z6Xw/X+943A/6er/4uWy/ZWkd6m9IWl0vj2U0Fllt37fWv0VUf9k4JaiNby12Jyltn722H841X6dWL8h3RbxkJZ6C4vJPU/AAAAuHRSTlMAAAECAwUYCAQODBI7BwsJBhsTFQ0dIhoXFBYKMBEQDzMeJTIfGSghHCcrLyM4KiA1MSkmLSw3ND1Usm21V3z5t3jp/sx5fv7kJFmN6f3gLjo2Pjw5Pzs7FJci8bRLjMtV/P23HB9r/eXq+/7vzfPzHfyf/STkLO0btfrE+Ck9evi86ef1uIXOHmgz/vvq2/61WsnI+funGPIu/P6b/d/i+E+3w+VE/Ul81qqq9PR1mbRL7R79VU/298H0JAAADgNJREFUeNrFWWlUVFe2hlt1bw2XurfmeaDmGSiGQp5Lg892CTgwq0gU0VbRqC0qGiUEWEFtxzgR40TFYUWBLEFttKOixqgxTLJQNFmIuBRWBKI0c0Aw79wqQOzWJK8fjz7823XPOd/5zt7f3vvg5jYq4/yk4+Bv0kyIBEG///W5ovEFhbmFBQVFs0h/aMIfHDOPP//664sXfw2CmEwq6XfWPVeQO7H60+Tk+InVZWVlZwsXkalk0shgmTTp+M8/P582iYvKuDj8m4ueK6iuPrh57iwJncY4GTz9xfXrq9fFrWHA5JGh5fzFn5//fa1ez+PQGOTfWHFR4ov5wbNwCcoRccSoXDhlXWvpzcT4LVycSR4JIOefAxwWf7OOh1J+Y8HCxBfZRRI5W6hlsVgCgUAoXLOztar6L2FaNpcxEkDO/wPgUFvtZm+UQno3jKqy7JMSFOFpNDyBkCNiszmIdmd1dphfqEbMZZJGiA+faA+1N8p453LjW6u2beGKeXyLnoeI5DQunc6Vc3Z+HmZWS315Mgp5ZPj41WdMtFojZ76L3nMrqqoTMKHeqAvlieV0nAHDMJMye+4aja/U5qVBRwQH4ONXz2gPKU8Bv/tWqrJPCvleJqOGQ6O44huCIDLGURp9VSwFg+T+fx5OPjw9AA4a/M+/DdJRVlrtoGtMZhNfCHxhiDUSTBexeAJUQoVGAMfXv4ujsOrmB3MNvjapUUBjDtcYEhNTyGkS2EnH/vycHTu+OpE5gUwGUjtslXmrUpOSUlfNI8zD7IQ0u0Zc3CIS9CYfWzNz+r7KytxNda41QMfq0qr5YRppYLiejb8RohAZZlAIHQYoMve17VmwYEdfV9dX+ZBT3VzbrfqooSF1VWpzY0bSPIbrW2Is2ry0qaz1+vXWF8nJ24JXwgyXf7hw7M+/0xayJ6ejq//EbjljUF6Lrpe2ZgsCfAK9WDT4TVeGSANn37rjzrH9JCZdsfu9rtr+nANAnMmEfV5S84Z5EJNLGpvUWNycmoZRYOL7GeuqHeM/jiOkMHkNR4TKFdzXfGB/znlv6n4mzt7d11XbsUBOp7iQFN4sLfvcW233VHEk/xIYkBtxuq3lt49hOF3O5ojTdtT+2L8vTcQF/uw+L6M5ZStEl6MoltZcXNyYlEajA9WbkVgdDFHp3A83t5aWTdfzvQ0IO2gIR9qJvqkAukzMO9rxY23fAjaKOSX7bOnNF44Ae4xNjzLeEtmEa2RlXTqAKzhagVaLHO2o/TErRK+V49BfMwg2uIQdgcc2FgNGlEIFc9bZ1dkf4jS2WLR2SVXpi41Sf6MGGcKx8ET/nXQKjaNlGbT5gNwHc5Rip2SvKK2qdkgjYsxKBfx2HJldt49RaQhPyRKzURmYXPvDYY1BRkltbE6B6FqlBpxXQUktLi5umKASyONWAzq4QpZBIDr57c3WyWcCTd7ioH98fdGJ4/2u2rsHyIhSw9OKJ5T3XbubZuUL6TDJbUVV2acOn+iIcOAebm/DsT+r61q6jMW3aBAZHYPT+mu73gux6fhbGxs3rJIZLCq9gM3F5H++XwxwSY3as63Jc2UCb74SEaFLqso+yIuRhgIczx8SOAKyajsuUbR8FV95NPPOtamHF0ZFmpQykHNWrG6afNAaFeEv4FLfiiO/q+NSuiJU58djS2AqlZTZ1X/72hyrX2px84ZVXJVJ582hM6hUPKmxsaFhjufsb5smByN8nYrHpkvimpoOLo/0NCJBDy9+83eAYw6YvF0Ualr7Wc6dtmNHafzIiEgzHwSq25Kmq99nj4v1CHgXDnChlw7oTf4qLRcGwQDl93fceXA4wpjU3LBhLB+kcpYCyI47bd795oaXk6LDWq9+GeztFeAH1IhS1HS1ZaPVx8QKevhwGuAj9hSYvF01Z8G+a3vS0xg4R6mTSr2UROrIbfqpfX7eGI9w1jtwZGV1XjoqtZlDORKnom3t72u7ezjWnpHR+3K93lNtRDCyU9DuP+59+V+xp5sqvnfozGY/ITB/3NTekme3SvVBD795RfDxWVf5s+0LvgjZlcbHIBxkeIufypXSCyorHnU7YscQGei1nxYNjnNQf9+zu+lSHymfTXEpa3/55bu7Yj0yHtdtWG8j4h132v96/2ld3fqIM2UV7dvGAXgEjnOV3dlrAq1qI4GD8I/POsovXzpljbabtGyUQ5Q7AiHqjJcZqytKuiefjvIcFrdFSyYeWvrtt5WfHgyGSFkdnQ8Om+zOuHaKJcBx5HBsbMbjX+pSdDGBKpELh/v9CwBHjMe6n258mSD18UUwqvuiT1s26iIj1aFDfGSVP3tw2B4d6GcQcoSg1EEVQMicMn72p/pH7QmxkX5DOjYjjhjA3u2Qy+UnOq5c3hMZox7CkVV+98ip2Nikx711KXYPn9d89Na9nBAVk3eo5FHyJru/gQaTclscs/Vmz3CA45UTx7j+8s7Le8ZERepAOLFlNFBlUAc6g/GVFcRED9MwXYcgKp773aPuBKWSldlRc7nN7hFoGbgX96yau0fWxsb+d8aFuqeno+1GscTlHxkAx9rYKNvee9/fWrYJ3CNeeNCxkqEMAK5M8PE3gMOW1QdWOxNl1xlENLoEUDGUWWeBg5fcWnxGTTjAUIpj0nO/6+5O8Pf3T+8o73x2OHro3O5ZnUf22KOiJzx+2tubEhVj0tKpLhx1dSmRUWMCvabEb7t1aG/e3rMEDI7eV6fnDPIRnk+stivW6sWS4wN5cXDPosSKnpJ7O88YASGkIRwYwccnNrva+FV5TVuIh9VrYL+tfZePHA2MifAEDtL7dJyHmXBwZ+qt27Db6OGh5rMEYRv37l1S2TN/JUXO4qv0CO08wYca6GlaR3lN5xfjYv0NzmgfVn+4UQqf1PeUVExfGyrGqNBApoUpTj5iou1e6X01nZ27IsxKUFoSMt955Jgy3B4pHfv46S+AEM+BC8t4+XK9wRZj9eehqFblOW5FxaN4IcLT8zWIgnJ+IF48+e+X11y5c2eclCjcneE3hAP6cPPVkhs9V+PDQAUyCIQMEzg+CYyK8RK8/8OVzn2n1CrgCJB7/o5LUxeywwNtfqzUC72/XFhv9RUQAreq4WXKQi2IYz8hV0ITa6ZUVtxI3iTQ6fhaOYVK4Jhm84gA+XbH7ZqaH27vmoMQVZf71t3uwwqevZPrb5QsrsybjUoG6hIIyq0HfNjHgG3QBVeufFFzKoAnZ4CC6NKxhXS9P1BBOSP1IwLIGT6I3FUfbUhZKFPZ1AEgW8AMumBl4k898Us3qf35HIxKnvTNq1evjhM4uAfeu9LZ+UNfx4mc/PzMkHTIWeC5cMCSKctutT+qP5S4dwuF4aqUFy1tb2n5xAZwIDQsPaSzc1/O+5/l7Ns+NZ1E4ahMXnwxxmCMvfC09+mF1PWpHzWkzINIWl24yQIul0SCcTTuu56SxUvzpMRtz3w4bdrffp02bdpxJRs7kNO2/dmzzrbOtmvb02GcwhgKGlBqrdkInLy9/d6hxHXrluUuWwbquYS5YX52j0ggjExceGpXSEhbSMixdByXCzUqP+B7TDKMsSesT0nZkJSSOlaOyhBvo45P0O0+Y3zB5s0TAccVT5Z7sRTQzJnng4KCTp8+Y+MDEYeP7gqZ+uDu1KnpHNQlZIOEkCk0RBWW53B8vu2DbfHxjj/N3bKSwhUqvQIjpRYRDjNpiE7tYzYa2FzQfBq89aDgAX0qCdj9pIE2X6WIjaJig8sniwqXJcdvjosL3pl8r6d+8XILQgddCEWkN6kDzRZEjtHlLJ1njNUn3KSzKAUcOTbUQxNAtH5SH6uPOlynN2iFHBkqYwuVRn9/I2hgyGQG8DyVzo/P0yIIywBKHBqA4Q457X6+OpWGhSACYOfIZuUe+tLxMRnwjYvCll2tvzF5k0pLY8AUhUBlCvDVa1G6hI6yVAE2T7U5QGfhCeWS108RYEW6yGDx8jcDkCq+xsACGwpA0Hk7GxhCT1DEoOSxBAgiFIvkmKv7dtmJtpiFCJ32D3MXtydANLkMRcE5xk1/UtLuCABAKAznAgYE5eJMJq4Q8yxGX1+jRYmg9OGdPFAMnCYSaPgqVahFT6wr5og4IA/RnA8nhKCAgpgNCkOZgoa9vlGnnS0C9wKqcowCFR5qcayhiRBQs4LZmjVnK7rnW4Gv0hkMCVchl9MwnEkmUxmYQiTUCgRC4khvPBGBJoGJc2UiMUKcmMOWEf02JqEMPiSBHRm4BMMkOIUJv3mAYfZzK+pbgiG2hu/NEssUCtQwBWT+M1Z/DQhmKsxkMJgw8coEkahMCkbncp0p5p/KYohonHDwK82JgAgo55zXO5LIVCp1KNzfZh/fdCN7i5Cv0+m1MjpwEebsxO7stVaXBrrG4GbOSe94+nL9Cvp98AH533mpK6i88eUUpSncF+gEE6xBJZ1tcaitgb4gObmN4iio7Gn/k6/NpiO03nmypS1bjDa119urzv+3MSOx4tHEsDGeRFXoenibnCDzDgg3jjIfbgVPeu4tzQvUIa7UPWOZY6XcYPTliyXkUcVBLpxcX/9kXd6WlSi1aNHmD4JnQQoWn8+SMUijigPCt0zfduvWvSdLJ07cFh98kgpzRQIlS4TBkNvoEkIXhuUtX748IWHjSRTDMRrKQRARd5TpIJ6zuGJvL7PZy2Jggb5ARIiyjD4ij7D/u4shM7hipUqn87N4K0E6EotkNAlz1GEM5D6hQakBWVFLoMD+VbpHBwiR+xQokftkRO6DR+rfFv8GEpDGcIlEMrzo+88gIZKfswL+gyD+BzgwupBeyBpJAAAAAElFTkSuQmCC) top left no-repeat!important}a#logo{width:135px!important;height:51px!important;font-size:0!important}#gbi{background:#444!important;border-color:#000!important}#gbar .gb2 a:hover{background:#FFF!important;color:#FFF!important}#gbh,.gbh{border:none!important}.gb2 div{border-color:#FFF!important}.w_ind,.tld{color:#000!important}#footer_promos{display:none!important}th{color:0!important}#navbar img{visibility:hidden!important}#navbar *{background-image:none!important}#fctr,#ghead,#pmocntr,#sbl,#tba,#tbe,.fade{background:none repeat scroll 0 0 transparent}.autoPagerS{background-color:#5F5959!important}a:link,.link,td,.n a,.n{color:#64ABFB!important}#ssb,#bsf{background-color:#555!important}';
	css += '#fctr, #ghead, #pmocntr, #sbl, #tba, #tbe, .fade {background:none repeat scroll 0 0 transparent;} ';

	//var c = chrome.extension.getURL("skin/airsearch.png");
	//var c =  "http://i194.photobucket.com/albums/z184/Bloody_Angel88/Capture-2.png";
	//GM_addStyle('#logo {background:url("' + c + '") no-repeat scroll 0 0 transparent !important;}');

	//white / light gray / black color
	css += 'div, .scroll-tree li a .name-unread, #recommendations-tree li a .name, .scroll-tree li a .name, .lhn-section a, .lhn-section a .text, .lhn-section .link, #your-items-tree .name, #overview .item-snippet {color: #ffffff !important;}';
	css += '.trends, {color: #999999 !important;}';
	css += '.subscribe-button, .goog-button-body {color: #000000 !important;}';
	//gray
	css += '#chrome-lhn-toggle, #chrome-footer, #viewer-header, #viewer-footer, #chrome-view-links, .goog-menu, .scroll-tree li .tree-link-selected  {background-color: #555555 !important;}';
	css += '#chrome-header{background-color: #999999 !important;}';
	css += '.scroll-tree li a:hover, .goog-menuitem:hover, .scroll-tree li .tree-link-selected:hover , #lhn-selectors .selected, #lhn-selectors .selected:hover, #lhn-selectors .selector:hover, a:hover .tree-item-action-container, .scroll-tree li a.menu-open {background-color: #888888 !important;}';
	css += '#viewer-page-container {background-color: #333333 !important;}';
	css += '#chrome-lhn-toggle-icon {border-color:#888888 #333333 #888888 #888888 !important;}';
	css += '.friend-interruption {background-color:#888888 !important; border-color:#333333 !important;}';
	css += '#viewer-container, #entries .entry, .entry-likers, .lhn-section, .scroll-tree li, .card-common, .card-common .card-actions {background-color: transparent !important;}';
	css+='.lhn-section {background: no-repeat scroll 0 0 transparent !important;}';
	css+='#entries.list .collapsed .entry-main .entry-source-title,#entries.list .collapsed .entry-secondary{color:#333333 !important;}';
	
	GM_addStyle(css, 'rps_darkgray');
	//fireResize();
};// ==UserScript==
// @name          Another Dark Google Reader Style
// @namespace     http://userstyles.org
// @description	  I took the style created by oltra & Ka Yue, and tweaked it a bit more to my liking.  Specifically
// @author        dvdmon
// @homepage      http://userstyles.org/styles/5133
// @include       http://www.google.com/reader/*
// @include       https://www.google.com/reader/*
// ==/UserScript==
//Another Dark Google Reader Style

GRP.dark = function() {
	/* most of the credit so far goes to 
	 * oltra & Ka Yue (oltra homepage: http://www.myradioheart.com, Ka Yue : http://ka-yue.com) 
	 * Tweaking done my Levi Wallach (http://twelveblackcodemonkeys.com) */
	var css = "page { color:#C1BEBA !important; background-color:#192129 !important; } body { color:#B1AEAA !important; background-color:#0C1319 !important; background-image: none !important; } td { color:#C1BEBA !important; background-color:#192129 !important; } div { color:#999 !important; background-color:#192129 !important; line-height: 20px !important; } a { color: #42749F !important; } a:visited { color: #882C55 !important; } a:active { color: #6799C4 !important; } #guser { color: #D1CECA !important; } .cb, .cbr, .cr, .cl, .cbl, .cc, .ct, .ctl, .ctr { background-image: none !important; } .item-body { font-size: 1.2em !important; } .entry-actions { background-color: #393929 !important; } .broadcast-inactive, .broadcast a { color: #42749F !important; } .round-box { background-color:#192129 !important; background-image: none !important; } .s, .c, .tl, .tr { background-color:#192129 !important; background-image: none !important; } .selected, .cursor { background-color:#cccccc !important; } .name-text, .unread-count, .link, #sub-tree, .name, .name-unread { color:#42749F !important; } .btl, .btr, .bbl, .bbr { background-image: none !important; background-color: #393929 !important; } .button-body-container { background-color: #393929 !important; color:#42749F !important; } #loading-area, #logo { background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIUAAAAcCAIAAADA0evgAAAABGdBTUEAAK/INwWK6QAAABl0RVh0U29mdHdhcmUAQWRvYmUgSW1hZ2VSZWFkeXHJZTwAAA38SURBVHja5FoJdJTVFX6z72sya5LJzISskFUgGyVBpEaRIggKyKZVsC0itrTKkWoPpx4FS2spdkHr0lqplHJUCkQhU1ApCGYBEmayTWaSTGYmk1kzezKT3pk/+TMMS8VTVOSdOe+8/b3c793v3vv+EGQyGfrmJT6fPzU/f9Bq7dTr0a2UiN8cALLVarw6d0aFo7s3I4Ujk8puKTzIV+vIz2TLU2O9pgGX0YwCN/gcDDqDRKXk5eVGwiOgE16PHRoHhoNOlxOgypJJoUqhU2yD9m7TwLcYD0ISXylSievuzSjMlkTIfKgyOSkZPA+L5GzV9h04Fd57bDAQHrtBR6HT6VWFuf7RqK6nLxgMKpWZFovV5XJVV1ZGgl4Jk2q12JlCnrZv0Gwx3xJ4PDQbbXz0u59cHDvSQhp0hfy+IDSmiHh3zRA8ON1IzUiNuoSPPH+2/uO2G3SarDQ55EkaUFFayKPSzxv7I2FXdm5JY3MzoPXt56vNC6mbfrhi11Fmw0mtz9kLdxP7s3s6UOMZ1uFpOe/+QkgUFfIkbjq9+wZJ5IpcZDQPzcySg06o+ExQlG8xGJN43F2ENqyaXt815ZPPPunWNgNLXDIqGDx56tSuDxRBorG920yIhr7iU1r9YcjNwajkVrDnfBb64dIMqvo+zYFm7YXPksGYSLv+/D5wusFgDN4wE3LFFAgGmGQiujVSDI+qLFRWcdvhU4HPmi5eDYy4kgR1uvbk+RW1iiUroBASx6jf+tHB0bf/dAVbLV8lU94JhTBZZXeGkP2N4MBfk8aAK3HHTBGHFrHYvFDNzuSJxWmHG0PHz3RzqGTsAGBI8PEUWTrrkU1CHhe2pg7bHfv2uk/Ug1MwZ06tx+WGAaDTieuvqRPz2cn+5PEW97ku3/9drLAX5G/VD34ZPApUVMTOsPlHB0zG6wteNj03u64u9Jc/RLTNTAGX8tBmxY7nIpu2tNfVuocMk2AUamYVR33Gl8aiNgFLbJe97I1ud1sfM31cjY9ZfodoflXaB61MIp35+IPD6iyywSJ76wTZZmsBpWy3exnxYSPRMEQkYEvgHhRs28n6x+tRzSlS5rSRH2+bumie47nn//PqKy3N5wgUBouSfNqFs1KKp7ASpQ/Vp9YqtuzWfwnBXTvBXl8SDwaVoJYzEZXitA4GfNcRZlAWLJ+xcb3oqR91tWoHnG6ntlNyaknenv2UueXSo8ePlirH10ptWPDdvJDurn5bEHwENNIkltTwZ5wQFapkvP2fH1wCQ2py0c/WlD73T2ZjS4fXO6C3pL39NFJmEUP1hMb23ury4phPFV+sp78zU5Zl9njKdr8peu+vds0hoy8UOtnEP9dBOnpg8bPPGOqPDPRdNaQHMBZv1Sa2vP509rNrFe9/6nB5R78RfCXiEm6bFqMa+pgbRf1fdB6TJV76YK3N1tjb36jVjTtCCI3+/JnM6mPlEmpoy08/fOElhJYWzMnPFR0/cjiEc51Lb6UHn1dXby8oqvIZK7XnTz1wO5+aUugYbnMMaCG+0WgMewtUy1elLKtlvXuQgflUdxTc1drX2GMeVKUTies257FJRP1FTbchEOdM3qqH5vTZxsy96pyca+BxeYIrXBfXmxMtbqylpoSHMZvBEnqr3pqoT0opbXWdpGQKC8rQu2u/CfJEjgK1AFwvVwtYDXphZSjDRr/dP+lGPrFEDpy5pk7CZ5OgPWYnaeQAortkIu51wFg0I61gGhS6+k2J7SbDReOnTZ0I3XbvyhjDEB8QieOObK/ukvmOfzjiRyqeuQy8CYWcw2Ez7DY3Hmzu/ciM3PaMdPm8ud9xmxzQsiN189miY/unvup3uPOnF8fW8AdGFyxX/2pP6aq1spYz5zZvOLFzh1l3/rruI4g4dkUmlAOktveX+S5vBKQGXUdeLsSYB5NpQ7wKXS1dvoWzhFDFDRIo2Qsb1AAP/EDniuOY4RMP/DIfgMQmblwi17xciPcCYUIvgDEu2N6haGiUAScqVLEZnJTAsP0Kj0ssJOUiiydWlqWyzUNen0hGFlKRDUV9yfYfTLpjVhkUpDJmz4iAzUQBrz80QkBoLNE1sA4ZAmGlUloAK6eLyWSWX5ZKxKmkyxR0OvkjYpWQOWAYNJWw80UREbSX88unt1d3jhEIXFIoP3vGkJ/XcMDZoYsi1OQL/c+4HUSDXVIswU0H6ZyeMOkAAMh0+5u92P2FfILN7JjeQH7f1ouYTsCUP8TljiH32BI5PhFaAFR8F1iBxybP3XQBQx1WA5gBeFyNjJbQwy92Ttrzs13BjGyTWiGpnJGn0ZxM+hvmVwqWz8uEgq7bXJFHzcyfdc+qfV5eTJlGBSIii49cl7DcqKkfcoFcRKcSCVyG14+CtEwaZSwQvmTZMY+VQVUK2DaDk250icR014b5LI1mvBdcPsGU3Lc0Q8ELjlx2/vaSbSQhNWIPkxSpta7apo+PFcwtR2F09tVXBGlyu89/DbcwMeVNYSVKKuAdBcux7c1enKkghyuMYwZCr5vwAkCOGDCYI5CoAdh4vBfwMCfwGPRCS+J4XXwLHA984jgee48NLb5LhqLWny1TXI7H2fZgtzNAoAp/NJdVVlHkHJGHyCkqrzOmCmwkyyu6PKgW0tHYmUafz08jNNoGlVH5VLFEAmYjaZiIicLO5mCY+NM/GTUlBRV16b+3lb/42tkUztiT6+a+vDc4OGDW9fQulM4vVFajCCKxMKi+88eTB+yeCHp0Y2DnS47reV4EVcDsOdzo15/OgQsLYOBkhZFPImCJ7RjXA1/lxSUbSLD/2IBEW2K0TD4iyKS0ZXXiZXEPGE9Xcx9i9uPkBc+JsxREDhZNjex4fGbSiEFHwGga0raeM+hjF7/PK/ZTSJ3v7Rt1hIEl1KvXJp9+1pyaCOpvOOoJRGnendDS60KKwoeThknV5TmZyNDVSqdGO/TWe7bo3j9Ik6nKnl7KffvFu8/0i/YfaRq2xVAvzJh2yUwutzo8VdvQMMYlFf/8hS/nxoDsABi4s8BISV3ye04n/TBTD2AA14PtXb5VW/VIM84wXyQBlSWtmeTmJX//WL+z3dBOhcLKZcpdT5YlR8hgVKJ+uzOMmLExBGLMBrq3rIfJY/NmZ997/+TQOfMLHlrhO/Svxs/PunwIohDGUCw8pOU8zktVTkYkyt8tuhuZL/zmfJsee49qaTr91I73NrxwIiWVK1CSClR8vfa802UG5ajiVCSdp0paLuyPvWmm/mAN2HMIDDGXj1dTN17+Aglu6I9391SU8EDQOEh4KIfzEh5FAsMAz4A+ATwwEnMEsNQSNz+Jlj+JncCYJ24NOyYOSEwkDocTi64D3vpmVJybny7lFlSmPFwjF9I8w15/cATRqUjMI84q5m9cWSxQ3ml1RA9/eNLr9dr13WyzrSi/mL/iPqq6kJKVR7jz3qrlK1V/f6Or/nBjWxsm6IDthIRHVWeVS4u/H4hkEmhTZHkbS4pVzMEXtR2tFy5oR0fHNRfOMOyyVRYJC4sl6akjmVyipi1AoYUNZlN6FBwQGhoJIQYNeTwN5H12TzuFIpipzEwrzomuf7Rs5eNp9ywWDva7zzVe7cHxgdtjHsG7miG8pb03MFXBgPYPPrWDTwXV+TMFIFawFmBjQWS/2aCuKeHvilvp8gJueQEHwLA6RgCbX29QU6jEf2qGYCT8YGJFvBeuKxjw0gJOvyWE7QUrA1mlCamfXRwGm7r+e1LQs7YuH+ZE/GRF+skWN3Rd4b0drvCyhRWL7izNYA8KBOGoZ7jX6rXYPKFg2Oal9HuEiJHSP+D5t6YB92Ruy8+bdvcCskJlsdld+k4I1GM3oqcv0cCCe1ZWXp1RWhVyp3d2O+jRlshoXzBA1V1swWX3xKLUGYXpjmEioqeUleSrhb2IGz39aXDb3zwSSiTmIPiFkE9Pn2IXBdo8jo+PH+eFhqsXLc+ZPZsplbUb+2z//sjUDj6H5Wq2/UDcMCQRBdzlxtdK8DgRbj0IumLCnsPVfnK3HhMcwAMrMOK6EogbHpA72GTMHcDAw0zL6YlQBt8LFAIcOcaEHcI9sdg3t39VJFaTv0chIjNNoVRlKRSSVKhFRnwmR8DrdA3HX1gDPpd/2JH0B9Pp9LQUIVb2R8au5nSKhQw+nzthk0L4IopU4u7NuVRhyesfujp6nLARlUpbOk/9WJ0PyYXPPt/7zpHzRUoJYlKYtFhI43BF2js7cb9cJpWxmdhjCuqHCOZK/vr1JkAlU0oHQrv8aQuP6a44EXqvOCtxLvRe4y2AcLX/Z6DHU2LEcIM+PPz+B/yaBd/fsqe7Tddrt+jHNyIyH1lWte0J5nljdd39T6FbJpGv8Zr7FXz5yZMh7LWmtdOi1zVNdkT9r71zbOviqpidFoj9zsGbS6zr1q3bs2dPYtVkMh06dAgrY4379u0DkuDz+fffP+4QwRTy13tuNoeekS2IjtlDPk9SF3AQmZOj0QyRCaSb/dY7PMNpaWl4FeQO3LN69WooABiJyH3N33k+7wi2dTCI6cR3t8qn50zSY6mK8PftMw82M/7z+YWw33lTg1FdWQn50NCQXB5jAq/XDyoCYIB+YFqyLp5AUa7FV19ZWrNd/wolu7wo/4M3hH0trRYvOxSiREiUg+fIzT26gR7dzf7BPFOVxWYzEeLU1t7+zjtvQxlTCIzTgLISq18/HgN9+rXPHKmZVZKXRqPTS4PBUYPFgzlafpf55v3XHsxOYLLGCGrx4iWJXZh+JJqTa/lXX33iCmVs1rjnerlXfYuk/wowAJXV875wcW+BAAAAAElFTkSuQmCC') !important; } /* Make the star image better for display on a black background */ /* First for the highlighted star */ #recent-activity #recent-activity-star h4 { background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAABh0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjEwcrIlkgAAAY9JREFUOE+VUz1Lw1AUzVilYl0Up8bQjurgIjaN9QOkOJSqBaFfVqpDpaI4OYgg+hucigh26ugkgiA4qIvoICg4dBEFFwcRQXrsuWlqP1LB4fCS9+5559xzE0VRFNhheCQOj+cK/QNR2/MKx57sNx5wmDuC13vzP/LEZAIrmTOUvkaRTu2DLlo4bFZe33gWVXxrKOTXMDP31JpMJd0frcKn36H4mBby7fWgWKe6bpRryhgbr+TAW4nV7EUVezunYpnk0mcvtjZzWEieyDlXXiZu+MBDFtfCIpIsz5Xz9xcXlheXzCBpmSPhBi2y2A4kXZ47pE5TCzACCeagYDaSQih8L5t2F3y8dSB/MATDnwVHGAqnrAB/02YfbKHWMl2QTEUSG0ZWT+ZoSH4ttgtol6CyzQdjkmnFGhFJLKYaV76zHbbFjGrUTTLnGI8dS+HudkAKaZMr362wGr51k+zq0qD7Mo1pihKnwbAItW++WTk4nYSjzQ2nU8VUMFYXDFtyqxF0dobQ3aM1k1v9mn/t/wDGC79Kjd0fUQAAAABJRU5ErkJggg%3D%3D') !important; } .entry .entry-actions .item-star-active { background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAABh0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjEwcrIlkgAAAY9JREFUOE+VUz1Lw1AUzVilYl0Up8bQjurgIjaN9QOkOJSqBaFfVqpDpaI4OYgg+hucigh26ugkgiA4qIvoICg4dBEFFwcRQXrsuWlqP1LB4fCS9+5559xzE0VRFNhheCQOj+cK/QNR2/MKx57sNx5wmDuC13vzP/LEZAIrmTOUvkaRTu2DLlo4bFZe33gWVXxrKOTXMDP31JpMJd0frcKn36H4mBby7fWgWKe6bpRryhgbr+TAW4nV7EUVezunYpnk0mcvtjZzWEieyDlXXiZu+MBDFtfCIpIsz5Xz9xcXlheXzCBpmSPhBi2y2A4kXZ47pE5TCzACCeagYDaSQih8L5t2F3y8dSB/MATDnwVHGAqnrAB/02YfbKHWMl2QTEUSG0ZWT+ZoSH4ttgtol6CyzQdjkmnFGhFJLKYaV76zHbbFjGrUTTLnGI8dS+HudkAKaZMr362wGr51k+zq0qD7Mo1pihKnwbAItW++WTk4nYSjzQ2nU8VUMFYXDFtyqxF0dobQ3aM1k1v9mn/t/wDGC79Kjd0fUQAAAABJRU5ErkJggg%3D%3D') !important; } .entry .entry-icons .item-star-active { background:transparent url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAABh0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjEwcrIlkgAAAY9JREFUOE+VUz1Lw1AUzVilYl0Up8bQjurgIjaN9QOkOJSqBaFfVqpDpaI4OYgg+hucigh26ugkgiA4qIvoICg4dBEFFwcRQXrsuWlqP1LB4fCS9+5559xzE0VRFNhheCQOj+cK/QNR2/MKx57sNx5wmDuC13vzP/LEZAIrmTOUvkaRTu2DLlo4bFZe33gWVXxrKOTXMDP31JpMJd0frcKn36H4mBby7fWgWKe6bpRryhgbr+TAW4nV7EUVezunYpnk0mcvtjZzWEieyDlXXiZu+MBDFtfCIpIsz5Xz9xcXlheXzCBpmSPhBi2y2A4kXZ47pE5TCzACCeagYDaSQih8L5t2F3y8dSB/MATDnwVHGAqnrAB/02YfbKHWMl2QTEUSG0ZWT+ZoSH4ttgtol6CyzQdjkmnFGhFJLKYaV76zHbbFjGrUTTLnGI8dS+HudkAKaZMr362wGr51k+zq0qD7Mo1pihKnwbAItW++WTk4nYSjzQ2nU8VUMFYXDFtyqxF0dobQ3aM1k1v9mn/t/wDGC79Kjd0fUQAAAABJRU5ErkJggg%3D%3D') no-repeat scroll 0% !important; } #selectors-box .selected .selector-icon-selected { display: inline !important; background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAABh0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjEwcrIlkgAAAY9JREFUOE+VUz1Lw1AUzVilYl0Up8bQjurgIjaN9QOkOJSqBaFfVqpDpaI4OYgg+hucigh26ugkgiA4qIvoICg4dBEFFwcRQXrsuWlqP1LB4fCS9+5559xzE0VRFNhheCQOj+cK/QNR2/MKx57sNx5wmDuC13vzP/LEZAIrmTOUvkaRTu2DLlo4bFZe33gWVXxrKOTXMDP31JpMJd0frcKn36H4mBby7fWgWKe6bpRryhgbr+TAW4nV7EUVezunYpnk0mcvtjZzWEieyDlXXiZu+MBDFtfCIpIsz5Xz9xcXlheXzCBpmSPhBi2y2A4kXZ47pE5TCzACCeagYDaSQih8L5t2F3y8dSB/MATDnwVHGAqnrAB/02YfbKHWMl2QTEUSG0ZWT+ZoSH4ttgtol6CyzQdjkmnFGhFJLKYaV76zHbbFjGrUTTLnGI8dS+HudkAKaZMr362wGr51k+zq0qD7Mo1pihKnwbAItW++WTk4nYSjzQ2nU8VUMFYXDFtyqxF0dobQ3aM1k1v9mn/t/wDGC79Kjd0fUQAAAABJRU5ErkJggg%3D%3D') !important; } /* now for unstarred items */ .entry .entry-actions .item-star { background-image:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAABGdBTUEAALGPC/xhBQAAABh0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjEwcrIlkgAAAVVJREFUOE91k8HLgkAQxf0ueSpCMCwKEU8R5kUw6NKtUx29eY4QT0L9310Dp34T22e5CY/VnXnz3s6sf47jyBO9x/d9536/O23bOrfbzZaie5B7CMNQDoeDeJ5njRvRXnA2m0mWZXK9XmW9XsvTxa8CfdXtdquql8tFjsejrFar32SUJpPJG4vFQs7ns5LLslTrqJuc6XT6KkZVkOf5G7vdTi1DbppGcJKmqcZZKaZueCFIcheGCJl3E6uqSonaSCyPx2PdwCLJNkAqikLzhsOhBEGgI5Y4jmW5XOqmrUBd17Lf75XACKMoMg387zZVOULXMi4gE4P4dSc+yYwG8ul0UmAXoGy5MC8yVsyIIJGMGivfHIdj0aOO+ovMHJMk0cTNZqOJ2GTl2zRrNBr1yRTgEnx1U5WYBs0Cruv2yVg2dubz+UdjONJgMLBdUftf9etv6+4/APyMT/MKWJZkAAAAAElFTkSuQmCC') !important; } .entry .entry-icons .item-star { background:transparent url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAAABGdBTUEAALGPC/xhBQAAABh0RVh0U29mdHdhcmUAUGFpbnQuTkVUIHYzLjEwcrIlkgAAAVVJREFUOE91k8HLgkAQxf0ueSpCMCwKEU8R5kUw6NKtUx29eY4QT0L9310Dp34T22e5CY/VnXnz3s6sf47jyBO9x/d9536/O23bOrfbzZaie5B7CMNQDoeDeJ5njRvRXnA2m0mWZXK9XmW9XsvTxa8CfdXtdquql8tFjsejrFar32SUJpPJG4vFQs7ns5LLslTrqJuc6XT6KkZVkOf5G7vdTi1DbppGcJKmqcZZKaZueCFIcheGCJl3E6uqSonaSCyPx2PdwCLJNkAqikLzhsOhBEGgI5Y4jmW5XOqmrUBd17Lf75XACKMoMg387zZVOULXMi4gE4P4dSc+yYwG8ul0UmAXoGy5MC8yVsyIIJGMGivfHIdj0aOO+ovMHJMk0cTNZqOJ2GTl2zRrNBr1yRTgEnx1U5WYBs0Cruv2yVg2dubz+UdjONJgMLBdUftf9etv6+4/APyMT/MKWJZkAAAAAElFTkSuQmCC') no-repeat scroll 0% !important; } /* Ka-Yue.com */ .entry-title { color: #CCC !important; font-weight:800 !important; } /* font-size */ ins p { color: #BBB !important; line-height: 1.3em !important; } #entries.list #current-entry.expanded .collapsed { border-width: 2px 0 2px 0 !important; border-bottom-color: #666 !important; } #entries.list .entry .collapsed { border: solid 2px #000 !important; } body.hide-nav #entries .entry-body { max-width: 100% !important; } .entry-source-title, .entry-title-link, a, .link { color:#3c90d8 !important; } .entry .card {border:none;} #entries .entry{padding-top:0px} .card-common{margin: 0px} .scroll-tree li {background: #192129;} #lhn-selectors .selector .text { color: #3C90D8;} #chrome-view-links {background: #0C1319;} .Tzvkxd .c1norb {opacity: 0.5;} .Tzvkxd .R7iiN, .Tzvkxd .wWwc8d {opacity: 0.5;} #current-entry {border:2px solid #3c90d8} .read h2  a.entry-title-link{ color: #882C55 !important; background: #192132}";
	GM_addStyle(css, 'rps_dark');
	//fireResize();
};
/*
 * Helvetireader
 */
GRP.helvetireader = function() {	
	//helvetireader v2
	var url= 'http://www.helvetireader.com/css/helvetireader.2.css';
	GM_addCss(url, 'rps_helvetireader2');
	
	//custom changes for colorful listview conflict
	var css = '#chrome-header{background-color:#33333!important;}';
	GM_addStyle(css, 'rpsfix_helvetireader2');
	
	fireResize();
};// ==UserScript==
// @author              Scott Cowan
// @name                Google Reader Minimalistic
// @namespace          http://google.com/reader/userscript
// @description           Removes all the whitespace from Google Reader and just gives you the news
// ==/UserScript==
// Google Reader Minimalistic
// Scott Cowan http://userscripts.org/users/32932
//http://userscripts.org/scripts/show/12197

GRP.minimal = function(){
    var ids = ["viewer-header", "logo-container", "search", "chrome-header", "global-info", "gbar", "viewer-footer"];
    
    function toggle_gr(){
        var logo;
        var length = ids.length;
        //var is_visible = document.getElementById(ids[0]).style.display != "none";
		var is_visible = true;
        
        for (var i = 0; i < length; i++) {
            if (document.getElementById(ids[i]) !== null) {         
                document.getElementById(ids[i]).style.display = is_visible ? "none" : "block";
            }
        }
        var css = ".gbh { display:none !important; }"; // Hide dividing line
        css += "#entries .entry {padding-top: 2px}";
        css += ".card-common {margin: 0 2px}";
        css += ".entry .entry-source-title {font-size:110%;}";
        css += ".entry .entry-title {font-size:120%;}";
        css += ".card .card-content {padding: 2px 1px 2px 2px;}";
        css += "#current-entry .card .card-content {padding: 2px 1px 2px 2px;}";
        css += ".entry .entry-container {padding-bottom: 0;}";
        css += ".entry .entry-body {padding-top: 0;}";
        css += ".entry .entry-actions {padding: 2px;}";
		css += "#chrome, #nav{padding-top:0 !important;}";
        GM_addStyle(css, 'rps_minimal');
		
		var css2 = '';

        if (is_visible) {
            css2 = '#main{top:0 !important;}';
			/*logo = document.getElementById('main');
            logo.style.top = '0';
            
            logo = document.getElementById('chrome');
            logo.style.paddingTop = '0';
            
            logo = document.getElementById('nav');
            logo.style.paddingTop = '0';*/
        } else {
            css2 = '#main{top:65px !important;}';
			/*logo = document.getElementById('main');
            logo.style.top = '65px';
            
            logo = document.getElementById('chrome');
            logo.style.paddingTop = '0';
            
            logo = document.getElementById('nav');
            logo.style.paddingTop = '0';*/
        }
		GM_addStyle(css2, 'rps_minimal_2');
        fireResize();
    }
    
    function GRT_key(event){
        element = event.target;
        elementName = element.nodeName.toLowerCase();
        if (elementName == "input") {
            typing = (element.type == "text" || element.type == "password");
        } else {
            typing = (elementName == "textarea");
        }
        if (typing) {
            return true;
        }
        if (String.fromCharCode(event.which) == "W" && !event.ctrlKey &&
        !event.altKey &&
        !event.metaKey) {
            toggle_gr();
            try {
                event.preventDefault();
            } 
            catch (e) {
            }
            return false;
        }
        return true;
    }
    
    //document.addEventListener("keydown", GRT_key, false);
    toggle_gr();
    
    var accountname = document.getElementById('email-address');
    if (accountname) {
        document.title = document.title + " | " + accountname.innerHTML + " | ";
    }
    
};
// ==UserScript==
// @name            Google Reader Optimized Skin
// @namespace      http://userstyles.org
// @author           kouz
// @homepage         http://www.daydreamz.cn
// @include        *google.com/reader/*
// ==/UserScript==
//http://userscripts.org/scripts/show/61552

GRP.optimized = function() {
	var css = 'body{font-family:Lucida Grande,Helvetica,Arial,sans-serif;background:#fff;} #global-info{display:none;}#nav{position:absolute;top:0;width:240px;}#chrome{margin-left:240px;}#lhn-add-subscription{left:775px;top:20px;}.goog-button-base-content{line-height:1.4em;}#gbar,#logo-container,#viewer-footer{display:none;}#search{top:1px;left:1px;position:absolute;}#main{top:0;background:#E1ECFE;}#search-input{font-size:13px;height:17px;margin:1px 0 0 1px;padding:3px 0 0 2px;width:144px;}#search-restrict{border:0;}#search-restrict-button{margin:1px 0 0;}.search-restrict-contents{width:60px;}#search-restrict-input{width:60px;}#search-submit{display:none;}#lhn-selectors,#sub-tree,#friends-tree-item-0-main ul,.scroll-tree li,#lhn-selectors .selector{background-color:#E1ECFE;} #lhn-selectors.lhn-section-minimized .selector,#lhn-subscriptions ,#lhn-friends .lhn-section-primary,#lhn-selectors .selected, #lhn-selectors .selected:hover{background-color:#B6EFBB;} .lhn-section-footer {background-color:#C2CFF1;} .scroll-tree li a .name{color:#888888;}.scroll-tree li a .name-unread{color:#111111;} #chrome-title{font-size:13px;line-height:1;}#chrome-header{padding:3px 11px;}#viewer-top-controls{height:22px;padding:3px 3px 1px;}#entries.list .entry .collapsed {border:1px solid #FFFFFF;height:2.1ex;line-height:2.3ex;}';
	GM_addStyle(css, 'rps_optimized');
	fireResize();
};
//Portal theme

GRP.portal = function(prefs){
    var ncolumns = prefs.theme_ncolumns || 2;
    var w = Math.max(100, Math.round((getWidthEntries() - 50) / ncolumns));
    var css = '.entry{float:left;width:' + w + 'px;padding:2px!important;}.card-common{margin:0;}.entry .entry-title {font-size:100%!important;}.entry .card-bottom,.entry-author,.entry-date{display:none;}#scroll-filler{float:left;}';
    GM_addStyle(css, 'rps_portal');
    
    //fireResize();
    function masonry(el, entry, mode){
        var o = {};
        if (entry) {
            console.log('masonry ' + entry.className);
			o = {
                appendedContent: jQuery(entry)
            }
        } else {
           console.log('masonry First : ' + jQuery('#entries .entry').length);
		    o = {
                itemSelector: '.entry:visible',
                //singleMode: true,
                resizeable: false,
                animate: false,
                columnWidth: w / ncolumns,
                save: true
            };
        }
        
        jQuery('#entries').masonry(o, function(){
            //jQuery('#entries').css('height', '');
        });
    }
    
	/*
    masonry();
    
    //update on entries changes
    registerFeature(masonry, 'portal_masonry');
    */
};
//OSX theme

//http://userstyles.org/styles/12859 
//http://userstyles.org/styles/2336

GRP.osxblue = function() {
	//12859 - Mar 09 2010
	//var css = 'body{font-family:Lucida Grande,Helvetica,Arial,sans-serif!important;background:#fff!important}#logo{background-image:url(data:image/gif;base64,R0lGODlhhgAbAPf/AGF9uqe+qODCVsrKzJyoxNU1HJilxM6yrdPJqdJLPD1itdTJo9F5a42dws+im9bNltbHk5GgwtGJfXGJvdGBdEFltdNdShZFroOWwGaAu8/KudvEdtYkCMLIw9nFgc21sczKys6po9RELnWredRKNAqBEn6SyS1WstUtEuW/OrK5yBxKr868usTGy9NWQiJOsF56uum9JsfIy1FxuM3Dwe+6ANJuXoiyi9DKtG6GvdJmVWqDvM24tSVQseu9GOe+KqWvxs3AvtU5IE1ut93DawN+CtHKr6y0x86tqNCFeTZcs97DY9U9Jc+TiePARdJqWYuzjVZ1uNF0Zou0i8LFys+akszHx1h2udF2aHyRv77HvpSiw6iyxtYpDniOvsHEyri9ybe8yK+2x+i+K/C+AJelw9CRh9TInuTAQjOROUmZTtNQPDFZsj6VREVjvczNzo6ezDNVu7vB0szU7sHG0sfJ0bO70Vt1wTaSPJypzm2DxsrM0GaAzNjf8sbHy6iy0MzIx8DDyr/CyoCW1Fl2yChSsVt4ufL0+0Bgv8+dlaW04aqzxsPGy77K68jJy5mq3S9Ysr/HwDlftFRzuOXq9qOtxcvLy9JvYExqxMnLyc/LvImawdJhT42g2bG4yM2+vOa/NklrtszFxNYjCKixxhCDF+HCUL7By9ojBQ+DF0uaUdzIcuy/Ie+8ALG3yy6PNKewxjNowdTHmrK/5YSwh9FeVI60kBdEscjHwMzEw5akxBhHrs6ln3OK0EVots3MyCmNL4WYwN/CXNFUTNNXRPjJHq/BsNCPhc/MwbW7yHaMvth6al94wWWAvdckB9F9cGaGws+Yj7K7ys+JhMbKx8zGxTdpvy1Tue26CipUsWilbNRtW9rFesDGw9vIeM/MvNnOhtjGiJ+rxdhnUzBatDFdts+Ae1qjWszMzOHCWbXBu+65BBmHINGpotYnC+fBMfPHMc27tzaSO5ypyeBfS8LGzEpst768s+PAQ0CWRdJiUNJkU8HIwWuBwrzAyczMzCH5BAEAAP8ALAAAAACGABsAAAj/AP8JHEiwoMGDCBMqXMiwocOHEAn6OaWCFBAuKgL5GRCxI8FMWozZ0tbBo8mTEb9EGMLmBCRI2XqcsIfBE0qIAdSkKsIu0s2fQAkCUXBhSIQwLfwIguWFqAIZQRdm+jeiCDB+UbOaNNDjRQSEfgBU0LrwRolXJcmqZXjkhVeFBK6sRWg2Tdq5eAnKMHQhykJPBPIWNIvnbkQ5iBPvyVqnDkQVF140iIjk2TYdNqKJKohjQzpTAjxoKDggwgQYACIwKjilROGBgBxQwJLkgEFL6AS+cUOIj29CbkxEhQMHYoMLJ2w+lCBCHwUpJNxxsi0Qwhg0RIikqJHizEBPUSZ5/5mgZNeMHZMyuPrX+vW/IFh0SGAgRIgEQAjfxJlDsI8bOUERB9EOF7AhyENJcIAFDQJ9YMEoxDAIATZO4CCQJkvU8AMC/3xhzwlACHSEEshFMcEp7LlWUi5PkBCPQCEwwYEEIBykH38E8VHcQHQQR0dBdOQBRx5vEFTHkG8IOJAdQy42EIB5/MGXgQ61U4AIPBB0QBfumPPNO+twOJAGMdSQzj8mXLADVP8MkMUFM/zjiEDtlZRIF8cQ1AQKXYRg434FYZLHQCbo8UgndwgnEBx32CGHHm4U+Y8dbgzSCSKI7PjPHXA8MogbdujmRqNwEHiCCgcNQAWbljiyjDOXWP9BEA0WcDAMOK2AMtpAvxBRAzy4NHPBBHMKdJxfA0Gh4j+cCJGlQIAkgUIB0fypyBzYNsJHpAL9occhAvnn2D96jPvPfwK58YhAc8Sxox6DCqSIG7rFEeo/m1zQwxYHqTBDBZIoQQ4046DCgCUEAcLAKAmsQgY+mhQUTg3F3JNDUYEINIAXF2BAkLKvMSHEB/848MQaOiTyiawG6efGy27EYYKT5A6CLbaExGskunW4QclAmOzoxrU3u/GjfpJ6ssIFABxkyRdgKHNBOdLQw0GsBFmSBMMOp7DrQBDUwMoC85zQcQsyiHNCBoMtW0AXxHCyjxks1JgQ0gLRcYe558L/DPOOe8Dx8h1xAChHHDkWt5vfLwOI9z8yXHEBJKQkFMEFsfyzDQfEfEIQCBSMUos3ZPhgREFhg4LMP7pUYB4AQ3jc9msicLBGEA49/o8c3KZ7r0Fu9NJIH/8UvjviA+n4z240E6T7ET1c4Is/CF1ujSUScNAnQaI8wcE0D/hQQzgFcVPDEgNlsQMXydBVgjwlScEBE34WhHvLcUgqUKEDwaEHQT/anRvA9Y8+GG83jRDIITKVrj8AsF76+0cZolcBLiAsa8G4gALqwYI1cEAHDBIIElBAjBqZogZjsJBANDCGGKhQWEdokwz8gDaC0KIEdvnHAYTAARJQ5x9WMAMF//4UwXPdaw9ucOA/6OAGx/RsFgUkhPHQZAJKHGIQ7hIIpQL4B3otL38FqUQoVtADADSAAAQwwCZ2oIQeGIIKJavdExwQgipYYA0k+4cRtuMECCwAAgKIgSwE4geiVAA1AIABDDJggH90IwCqKEIqoBCAfyRCRkLAQhOagAUXOMBGvXtS7/QGMwAtanB0MIGi0PQy4miKUoNz0m6K+I8WROAKSjiBJCrAy1DkoBKrEaEOmEACC1jgGdUgCA6WEIPrOEEYKjTWC1ZQiGoWYmnXAII6ztGGfLRBDSNokA1EUAAhkMAGLLjJG2i5vI6sEyJUEEMlgCCGAyEkHrwIgecOooiJBZwhmgIBwwQMoYtFGPQIW1DALfrxDy1QQyAd8MlAgoAEJNxPMBhVix8m8QIuGOQ4zMioSEdKEHG8YAYZK8gWhkXSlmZUHD1QABgK0oIrnEAMLs1pXiSXAzbVEgBv0alQ1XIKQ6xAARmYAAB8MQRxDPWpZGFEBAAwgyhkoAEphapWt8pVhgQEADs=)!important}.gbh{border:0!important;background:#dddddc url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAeCAMAAADaS4T1AAAAA3NCSVQICAjb4U/gAAAAPFBMVEXs7Ozr6+vq6urp6eno6Ojn5+fm5ubl5eXk5OTj4+Pi4uLh4eHg4ODf39/e3t7d3d3c3Nzb29va2tr///+KsXasAAAAFHRSTlP/////////////////////////AE9P5xEAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAUdEVYdENyZWF0aW9uIFRpbWUAOC85LzA32WH5FwAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAbSURBVAiZY2CAA2YoZINDTjjkgUJ+OBRiEAIAEcQA92wvhr0AAAAASUVORK5CYII=) repeat-x 0 -2px!important;height:30px!important;position:absolute!important;top:0!important;border-bottom:1px solid #999!important}#search-input{-moz-border-radius:10px!important;background:#fff url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAANCAYAAABy6+R8AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAABiklEQVR42oSPzeopARyGn/lgQfnYWDMLVmYlptyDciNW5EbcxjRlx2o2NDGJpJRixYZIkikzfv/Fif46dc67fHuf3h5FRADwPE8WiwWbzQaAYrGIaZpYlqXwHVFEhH6/L47jEEURr9cLAFVV0TSNZrNJo9H4AnXP88S2bZLJJNVqlXK5DMByuWQymWDbNrlcTn4/6r7vE4YhlmXRaDSIx+MAGIaBqqoMBgN838eyrM+Tul6vERFqtRqZTEZJJBJKIpFQstmsUqvVEBHW6/WXlPp2eD/8zrt7bz6QYRgAzOfzv6B39958nEzTZDab4bouuq5LpVIBYDqd4rouAKVS6QtSrterOI7DcDhE13U0TQMgiiLCMEREyOfzdLtd0uk0gKI8n0+53W6MRiNWqxW73Q6AQqGAYRiMx2OOxyOGYdBut0mlUigiQhRFcr/fCYKAKIoQEWKxGJqmcblc6PV6nE4nCoUCnU7nD/SvPB4PORwO9Ho9zuczrVbr/xBAEASy3+/ZbrfU63V+BgCMeL/dPQOGagAAAABJRU5ErkJggg==) no-repeat 4px 4px!important;padding-left:20px!important}#global-info a{color:#000!important;text-decoration:none!important}#main{top:30px!important}#nav div,#nav li,#nav a{background-color:transparent!important}#nav{background:#e5edf7!important}#star-selector .selector-icon{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAMAAAC6V+0/AAAAA3NCSVQICAjb4U/gAAAAt1BMVEX///9Kjes4fd0tcM4hYr4AAABKjeswc9AAAAArbswoasYkZsMAAAA/gd8yddQrbswdXrpAheY0eNdKjesyddQtcM4oasZKjes4etctcM4oasZHiedAheY0eNcoasZKjetAheY4fd0tcM4yddQrbswrbsxAheY/gd84fd0yddQtcM4rbsxKjetHiedAheY+g+Q/gd84fd04etc0eNcyddQwc9AtcM4rbswoasYlZ8QkZsMhYr4dXrpo+wmyAAAAPXRSTlMAEREREREiIiIzMzMzRERERFVVZmZmZnd3iIiZqqqqu7u7u8zM3e7u7u7u7v//////////////////////n9s/LQAAAAlwSFlzAAALEgAACxIB0t1+/AAAAB90RVh0U29mdHdhcmUATWFjcm9tZWRpYSBGaXJld29ya3MgOLVo0ngAAAAUdEVYdENyZWF0aW9uIFRpbWUAOS80LzA34FfybwAAAKlJREFUGJVtzekSgiAUBWAtMbM9KysrWy0LKUmUovd/rmDcmMHzh8M3d+7VtDKmqalx3Qb0fdV0CHUFHQgdBb0o8hQMEArq3+D6KkMo+zE6Fdo6xCJYCGOPTjG8xBingr6fY71iGGZMEJ3LZ3ZCaJa2JTNyIslMwgUXTsl7K+ElJXe7G8bxTUKSnA2+5PREk8pGyTovK7SpcNwrm73PXwAsy+oX4RWAZvwDi9UXRQUgxVcAAAAASUVORK5CYII=)!important;background-position:-2px!important}#sub-tree .name{font-size:95%!important;font-weight:400!important}li.expanded .toggle{background-position:7px 7px!important;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAMAAADXT/YiAAAAA3NCSVQICAjb4U/gAAAAP1BMVEX////l6ezl6ezl6ezl6ezl6ezl6eyJk6Dc4OTU2d7X3ODJz9XX3ODJz9XAxs21tb2ss72gqbOVnqqPmKWJk6B5rClkAAAAFXRSTlMAESJEVWZ3d5mqzMzu7u7////////ckxWgAAAACXBIWXMAAAsSAAALEgHS3X78AAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1MzmNZGAwAAABV0RVh0Q3JlYXRpb24gVGltZQAxNi8xLzA4zxaVqQAAADhJREFUCJktxkkCgCAMALGRXRRZ//9WazGnENcWCUMzAhTdA7gu6V5Gll1fMHU1qyPNc4fjNv/QvK9/AtO5NvJ8AAAAAElFTkSuQmCC)!important}li.collapsed .toggle{background-position:9px 6px!important;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAALCAMAAAB1RTwXAAAAA3NCSVQICAjb4U/gAAAAS1BMVEX////k5umJk6Dk5umJk6C0usPk5umJk6Dk5umJk6Dk5umJk6Dk5umJk6De4eTY2+CbpK+KlKGJk6DIzNK8wsmmrbegqLKKlKGJk6DefV+RAAAAGXRSTlMAEREiIjNVZnd3qqq7u+7u7u7u////////pxfA5QAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAVdEVYdENyZWF0aW9uIFRpbWUAMTYvMS8wOM8WlakAAAA9SURBVAiZY+BmYoAACSF2KENCgpcFypAQ5IQywIIQhgArmCEuwsMMYojxc4DUiAsDuUAgyscGMYeLEUIDAMpzA+zpg8RGAAAAAElFTkSuQmCC)!important}.icon-d-1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAMAAAC6V+0/AAAAA3NCSVQICAjb4U/gAAAAnFBMVEX///8AAACDnLSDnLRzkq3N3e6/veW6t+C0tdyvrNuno9Wjo9Geos+indGfmtKSncCZmcycls2WmcuSmcODnLSXks2Ml754l7GTjcqCkrSPiciGjL1zkq2BireChsFzjK2EhL1ujah4ha93grF1gq5wg6hkg55uf6hkfJ1mdaVsc6taeZVpcqhcc5hgcZ5dcZ1Sc5RScY1bbJxRZ5MaRgGzAAAANHRSTlMAVYiq7v//////////////////////////////////////////////////////////////04UUeAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABR0RVh0Q3JlYXRpb24gVGltZQA5LzQvMDfgV/JvAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1MzmNZGAwAABBF0RVh0WE1MOmNvbS5hZG9iZS54bXAAPD94cGFja2V0IGJlZ2luPSIgICAiIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNC4xLWMwMzQgNDYuMjcyOTc2LCBTYXQgSmFuIDI3IDIwMDcgMjI6MTE6NDEgICAgICAgICI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnhhcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI+CiAgICAgICAgIDx4YXA6Q3JlYXRvclRvb2w+QWRvYmUgRmlyZXdvcmtzIENTMzwveGFwOkNyZWF0b3JUb29sPgogICAgICAgICA8eGFwOkNyZWF0ZURhdGU+MjAwNy0wOC0xNVQxOTo0NjoyOVo8L3hhcDpDcmVhdGVEYXRlPgogICAgICAgICA8eGFwOk1vZGlmeURhdGU+MjAwNy0wOC0xNVQyMDo1NDo1M1o8L3hhcDpNb2RpZnlEYXRlPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgg2R54wAAAKVJREFUGJWV0MsSgiAYhmE7QaJSVpqSEVIZZiTW/d9bCG5k2vgMi2/e+Vd43hSLgzZ3YtFbjtvRYQ9XI4WJJQBAXNI1sEobIYRpLkQKDRsrX4NwI+/98CsTBULowTHay1wvJExsMMZXIU/4LAM9GxNVoiGutpnicZIoEztCSNuS9pbVdURIZyNj7POOXnX8/EaMDZFqYUh3+gWUDtFh4swx6Yf/+QHPMxO40fBf7wAAAABJRU5ErkJggg==) no-repeat!important;overflow:hidden!important;margin:0 0 0 -4px !important;padding:22px 0 0 23px !important}.icon-d-2{width:0!important;height:0!important;display:block!important;float:left!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAA3NCSVQICAjb4U/gAAAAS1BMVEX////9+PL78OX34sv127/1277z07HxzaXvxZjuxZjsvovsvYvqt3/qtn7or3Lor3HmqGTmqGXkoVjkoFfimkvgkj7gkj3eizH////ACO6rAAAAGXRSTlP///////////////////////////////8AATQKtwAAAAlwSFlzAAALEgAACxIB0t1+/AAAAB90RVh0U29mdHdhcmUATWFjcm9tZWRpYSBGaXJld29ya3MgOLVo0ngAAAAUdEVYdENyZWF0aW9uIFRpbWUAMi80LzA3ipACrAAAAHdJREFUGJVlz1ESwiAMBNBNsBqsttiCy/1PKiCtVffzTZLZIP8EOfvInugrGA+xApHQ022bKUCiRKe3NCBnB1yOQAbBeQeoJa6CaQMn0IUBuq88PTTR4d7hcU0jPGcMHQQjReutBpGDhDJf+7Rif9WzfZ6z9u13XtjiEkob0Ut6AAAAAElFTkSuQmCC) no-repeat!important;padding:16px 0 0 20px !important}#sub-tree-subscriptions{color:#000!important;font-size:110%!important}#chrome-header{height:24px!important;color:#000!important;background:#fff url(data:image/gif;base64,R0lGODlhAgAgAKIAAB1eujSC6iB25kSK6zqF6kqN6yF55UKE5iH5BAAHAP8ALAAAAAACACAAAAMSaFbcziPKSKqtIQfFu/8fIAIJADs=) repeat-x!important;margin:0!important;padding:7px 5px 5px 8px !important}#chrome-view-links{background:transparent!important}#viewer-header{background:transparent!important;padding-top:3px!important}#viewer-top-controls{padding-top:0!important;padding-bottom:2px!important}#chrome-header .link{display:inline-block!important;margin-top:-4px!important;background-color:#E5EDF7!important;-moz-border-radius-topleft:3px!important;-moz-border-radius-topright:3px!important;border:1px solid #000!important;border-bottom:0!important;min-width:70px!important;text-align:center!important;padding:0 6px 4px!important}#chrome-header .link-selected{padding-top:4px!important;background-color:#fff!important}#view-list{margin-left:-14px!important}#entries .entry .entry-container{padding:0!important}.card{-moz-border-radius:0!important}#entries .entry .entry-body{max-width:750px!important}.entry-likers{display:block!important;float:right!important;background:transparent!important;margin-top:-1em!important;width:12em!important;padding-left:1em!important;font-size:.9em!important}#entries .entry-actions .item-star,#entries .entry-icons .item-star{background-image:url(data:image/gif;base64,R0lGODlhDwAPAKIAAMzMzP///9bW1ubm5u/v79/f3/b29gAAACH5BAAHAP8ALAAAAAAPAA8AAAM4GLpB/E/AaYCZb4CBmQBSpwDkxRBkqqqO8a2pYCoazEF1ekPFWmCpHmmCkgVcAMejEFoIfpnJLgEAOw==)!important}#entries .entry-actions .item-star-active,#entries .entry-icons .item-star-active{background-image:url(data:image/gif;base64,R0lGODlhDwAPALMAAP+DAP/v3//BgP+aMP/ZsP////+LEP+qUP/oz//RoP/37/+TIP/JkP+iQP+yYP/gwCH5BAAHAP8ALAAAAAAPAA8AAARFsMhZHr134Y0A2pcACCA1AEMpKUAbXITRznRrJEXQ1HTzTgwZzcDYMGrFzaF22LBajpkCkwAsPogFAHdxNKarhgOTvJQjADs=)!important}#entries .entry-actions .item-star-active{background-position:0 0!important}.entry-actions{background:#F9F9F9!important}.entry-actions span{color:#999!important}.entry-actions span:hover{color:#333!important}#viewer-footer,.lhn-section-footer{border:0!important;background:#dddddc url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAeCAMAAADaS4T1AAAAA3NCSVQICAjb4U/gAAAAPFBMVEXs7Ozr6+vq6urp6eno6Ojn5+fm5ubl5eXk5OTj4+Pi4uLh4eHg4ODf39/e3t7d3d3c3Nzb29va2tr///+KsXasAAAAFHRSTlP/////////////////////////AE9P5xEAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAUdEVYdENyZWF0aW9uIFRpbWUAOC85LzA32WH5FwAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAbSURBVAiZY2CAA2YoZINDTjjkgUJ+OBRiEAIAEcQA92wvhr0AAAAASUVORK5CYII=) repeat-x 0 -2px!important;border-top:1px solid #999!important}#viewer-footer{margin-top:5px!important;padding-top:0!important;padding-bottom:9px!important}#entries-status{top:1px!important}#viewer-footer .goog-button-base-inner-box.goog-inline-block{background-color:transparent!important;border:0!important}#chrome-lhn-toggle{background:#dddddc!important}#lhn-add-subscription-section,#gbar,#viewer-footer .goog-button-base-top-shadow{display:none!important}#logo-container,#search{top:3px!important}#chrome,#viewer-footer .goog-button-base-outer-box{border:0!important}#entries .entry-icons .item-star,#entries .entry-icons .item-star-active{height:20px!important;background-position:0 2px!important}';
	var css = 'body{font-family:Lucida Grande,Helvetica,Arial,sans-serif!important;background:#fff!important}#logo{background-image:url(data:image/gif;base64,R0lGODlhhgAbAPf/AGF9uqe+qODCVsrKzJyoxNU1HJilxM6yrdPJqdJLPD1itdTJo9F5a42dws+im9bNltbHk5GgwtGJfXGJvdGBdEFltdNdShZFroOWwGaAu8/KudvEdtYkCMLIw9nFgc21sczKys6po9RELnWredRKNAqBEn6SyS1WstUtEuW/OrK5yBxKr868usTGy9NWQiJOsF56uum9JsfIy1FxuM3Dwe+6ANJuXoiyi9DKtG6GvdJmVWqDvM24tSVQseu9GOe+KqWvxs3AvtU5IE1ut93DawN+CtHKr6y0x86tqNCFeTZcs97DY9U9Jc+TiePARdJqWYuzjVZ1uNF0Zou0i8LFys+akszHx1h2udF2aHyRv77HvpSiw6iyxtYpDniOvsHEyri9ybe8yK+2x+i+K/C+AJelw9CRh9TInuTAQjOROUmZTtNQPDFZsj6VREVjvczNzo6ezDNVu7vB0szU7sHG0sfJ0bO70Vt1wTaSPJypzm2DxsrM0GaAzNjf8sbHy6iy0MzIx8DDyr/CyoCW1Fl2yChSsVt4ufL0+0Bgv8+dlaW04aqzxsPGy77K68jJy5mq3S9Ysr/HwDlftFRzuOXq9qOtxcvLy9JvYExqxMnLyc/LvImawdJhT42g2bG4yM2+vOa/NklrtszFxNYjCKixxhCDF+HCUL7By9ojBQ+DF0uaUdzIcuy/Ie+8ALG3yy6PNKewxjNowdTHmrK/5YSwh9FeVI60kBdEscjHwMzEw5akxBhHrs6ln3OK0EVots3MyCmNL4WYwN/CXNFUTNNXRPjJHq/BsNCPhc/MwbW7yHaMvth6al94wWWAvdckB9F9cGaGws+Yj7K7ys+JhMbKx8zGxTdpvy1Tue26CipUsWilbNRtW9rFesDGw9vIeM/MvNnOhtjGiJ+rxdhnUzBatDFdts+Ae1qjWszMzOHCWbXBu+65BBmHINGpotYnC+fBMfPHMc27tzaSO5ypyeBfS8LGzEpst768s+PAQ0CWRdJiUNJkU8HIwWuBwrzAyczMzCH5BAEAAP8ALAAAAACGABsAAAj/AP8JHEiwoMGDCBMqXMiwocOHEAn6OaWCFBAuKgL5GRCxI8FMWozZ0tbBo8mTEb9EGMLmBCRI2XqcsIfBE0qIAdSkKsIu0s2fQAkCUXBhSIQwLfwIguWFqAIZQRdm+jeiCDB+UbOaNNDjRQSEfgBU0LrwRolXJcmqZXjkhVeFBK6sRWg2Tdq5eAnKMHQhykJPBPIWNIvnbkQ5iBPvyVqnDkQVF140iIjk2TYdNqKJKohjQzpTAjxoKDggwgQYACIwKjilROGBgBxQwJLkgEFL6AS+cUOIj29CbkxEhQMHYoMLJ2w+lCBCHwUpJNxxsi0Qwhg0RIikqJHizEBPUSZ5/5mgZNeMHZMyuPrX+vW/IFh0SGAgRIgEQAjfxJlDsI8bOUERB9EOF7AhyENJcIAFDQJ9YMEoxDAIATZO4CCQJkvU8AMC/3xhzwlACHSEEshFMcEp7LlWUi5PkBCPQCEwwYEEIBykH38E8VHcQHQQR0dBdOQBRx5vEFTHkG8IOJAdQy42EIB5/MGXgQ61U4AIPBB0QBfumPPNO+twOJAGMdSQzj8mXLADVP8MkMUFM/zjiEDtlZRIF8cQ1AQKXYRg434FYZLHQCbo8UgndwgnEBx32CGHHm4U+Y8dbgzSCSKI7PjPHXA8MogbdujmRqNwEHiCCgcNQAWbljiyjDOXWP9BEA0WcDAMOK2AMtpAvxBRAzy4NHPBBHMKdJxfA0Gh4j+cCJGlQIAkgUIB0fypyBzYNsJHpAL9occhAvnn2D96jPvPfwK58YhAc8Sxox6DCqSIG7rFEeo/m1zQwxYHqTBDBZIoQQ4046DCgCUEAcLAKAmsQgY+mhQUTg3F3JNDUYEINIAXF2BAkLKvMSHEB/848MQaOiTyiawG6efGy27EYYKT5A6CLbaExGskunW4QclAmOzoxrU3u/GjfpJ6ssIFABxkyRdgKHNBOdLQw0GsBFmSBMMOp7DrQBDUwMoC85zQcQsyiHNCBoMtW0AXxHCyjxks1JgQ0gLRcYe558L/DPOOe8Dx8h1xAChHHDkWt5vfLwOI9z8yXHEBJKQkFMEFsfyzDQfEfEIQCBSMUos3ZPhgREFhg4LMP7pUYB4AQ3jc9msicLBGEA49/o8c3KZ7r0Fu9NJIH/8UvjviA+n4z240E6T7ET1c4Is/CF1ujSUScNAnQaI8wcE0D/hQQzgFcVPDEgNlsQMXydBVgjwlScEBE34WhHvLcUgqUKEDwaEHQT/anRvA9Y8+GG83jRDIITKVrj8AsF76+0cZolcBLiAsa8G4gALqwYI1cEAHDBIIElBAjBqZogZjsJBANDCGGKhQWEdokwz8gDaC0KIEdvnHAYTAARJQ5x9WMAMF//4UwXPdaw9ucOA/6OAGx/RsFgUkhPHQZAJKHGIQ7hIIpQL4B3otL38FqUQoVtADADSAAAQwwCZ2oIQeGIIKJavdExwQgipYYA0k+4cRtuMECCwAAgKIgSwE4geiVAA1AIABDDJggH90IwCqKEIqoBCAfyRCRkLAQhOagAUXOMBGvXtS7/QGMwAtanB0MIGi0PQy4miKUoNz0m6K+I8WROAKSjiBJCrAy1DkoBKrEaEOmEACC1jgGdUgCA6WEIPrOEEYKjTWC1ZQiGoWYmnXAII6ztGGfLRBDSNokA1EUAAhkMAGLLjJG2i5vI6sEyJUEEMlgCCGAyEkHrwIgecOooiJBZwhmgIBwwQMoYtFGPQIW1DALfrxDy1QQyAd8MlAgoAEJNxPMBhVix8m8QIuGOQ4zMioSEdKEHG8YAYZK8gWhkXSlmZUHD1QABgK0oIrnEAMLs1pXiSXAzbVEgBv0alQ1XIKQ6xAARmYAAB8MQRxDPWpZGFEBAAwgyhkoAEphapWt8pVhgQEADs=)!important}#guser{float:right;border:0!important;background:#dddddc url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAeCAMAAADaS4T1AAAAA3NCSVQICAjb4U/gAAAAPFBMVEXs7Ozr6+vq6urp6eno6Ojn5+fm5ubl5eXk5OTj4+Pi4uLh4eHg4ODf39/e3t7d3d3c3Nzb29va2tr///+KsXasAAAAFHRSTlP/////////////////////////AE9P5xEAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAUdEVYdENyZWF0aW9uIFRpbWUAOC85LzA32WH5FwAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAbSURBVAiZY2CAA2YoZINDTjjkgUJ+OBRiEAIAEcQA92wvhr0AAAAASUVORK5CYII=) repeat-x 0 -2px!important;height:30px!important;position:absolute!important;top:0!important;border-bottom:1px solid #999!important;width:100%}#search-input{-moz-border-radius:10px!important;-webkit-border-radius:10px!important;-border-radius:10px!important;background:#fff url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA0AAAANCAYAAABy6+R8AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAABiklEQVR42oSPzeopARyGn/lgQfnYWDMLVmYlptyDciNW5EbcxjRlx2o2NDGJpJRixYZIkikzfv/Fif46dc67fHuf3h5FRADwPE8WiwWbzQaAYrGIaZpYlqXwHVFEhH6/L47jEEURr9cLAFVV0TSNZrNJo9H4AnXP88S2bZLJJNVqlXK5DMByuWQymWDbNrlcTn4/6r7vE4YhlmXRaDSIx+MAGIaBqqoMBgN838eyrM+Tul6vERFqtRqZTEZJJBJKIpFQstmsUqvVEBHW6/WXlPp2eD/8zrt7bz6QYRgAzOfzv6B39958nEzTZDab4bouuq5LpVIBYDqd4rouAKVS6QtSrterOI7DcDhE13U0TQMgiiLCMEREyOfzdLtd0uk0gKI8n0+53W6MRiNWqxW73Q6AQqGAYRiMx2OOxyOGYdBut0mlUigiQhRFcr/fCYKAKIoQEWKxGJqmcblc6PV6nE4nCoUCnU7nD/SvPB4PORwO9Ho9zuczrVbr/xBAEASy3+/ZbrfU63V+BgCMeL/dPQOGagAAAABJRU5ErkJggg==) no-repeat 4px 4px!important;padding-left:20px!important}#global-info a{color:#000!important;text-decoration:none!important}#main{top:30px!important}#nav div,#nav li{background-color:transparent!important}.tree-selected a,.tree-selected a:hover{background-color:#D8E2EC!important}#nav{background:#e5edf7!important}#star-selector .selector-icon{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAMAAAC6V+0/AAAAA3NCSVQICAjb4U/gAAAAt1BMVEX///9Kjes4fd0tcM4hYr4AAABKjeswc9AAAAArbswoasYkZsMAAAA/gd8yddQrbswdXrpAheY0eNdKjesyddQtcM4oasZKjes4etctcM4oasZHiedAheY0eNcoasZKjetAheY4fd0tcM4yddQrbswrbsxAheY/gd84fd0yddQtcM4rbsxKjetHiedAheY+g+Q/gd84fd04etc0eNcyddQwc9AtcM4rbswoasYlZ8QkZsMhYr4dXrpo+wmyAAAAPXRSTlMAEREREREiIiIzMzMzRERERFVVZmZmZnd3iIiZqqqqu7u7u8zM3e7u7u7u7v//////////////////////n9s/LQAAAAlwSFlzAAALEgAACxIB0t1+/AAAAB90RVh0U29mdHdhcmUATWFjcm9tZWRpYSBGaXJld29ya3MgOLVo0ngAAAAUdEVYdENyZWF0aW9uIFRpbWUAOS80LzA34FfybwAAAKlJREFUGJVtzekSgiAUBWAtMbM9KysrWy0LKUmUovd/rmDcmMHzh8M3d+7VtDKmqalx3Qb0fdV0CHUFHQgdBb0o8hQMEArq3+D6KkMo+zE6Fdo6xCJYCGOPTjG8xBingr6fY71iGGZMEJ3LZ3ZCaJa2JTNyIslMwgUXTsl7K+ElJXe7G8bxTUKSnA2+5PREk8pGyTovK7SpcNwrm73PXwAsy+oX4RWAZvwDi9UXRQUgxVcAAAAASUVORK5CYII=)!important;background-position:-2px!important}#sub-tree .name{font-size:95%!important;font-weight:400!important}li.expanded .toggle{background-position:7px 7px!important;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAMAAADXT/YiAAAAA3NCSVQICAjb4U/gAAAAP1BMVEX////l6ezl6ezl6ezl6ezl6ezl6eyJk6Dc4OTU2d7X3ODJz9XX3ODJz9XAxs21tb2ss72gqbOVnqqPmKWJk6B5rClkAAAAFXRSTlMAESJEVWZ3d5mqzMzu7u7////////ckxWgAAAACXBIWXMAAAsSAAALEgHS3X78AAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1MzmNZGAwAAABV0RVh0Q3JlYXRpb24gVGltZQAxNi8xLzA4zxaVqQAAADhJREFUCJktxkkCgCAMALGRXRRZ//9WazGnENcWCUMzAhTdA7gu6V5Gll1fMHU1qyPNc4fjNv/QvK9/AtO5NvJ8AAAAAElFTkSuQmCC)!important}li.collapsed .toggle{background-position:9px 6px!important;background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAALCAMAAAB1RTwXAAAAA3NCSVQICAjb4U/gAAAAS1BMVEX////k5umJk6Dk5umJk6C0usPk5umJk6Dk5umJk6Dk5umJk6Dk5umJk6De4eTY2+CbpK+KlKGJk6DIzNK8wsmmrbegqLKKlKGJk6DefV+RAAAAGXRSTlMAEREiIjNVZnd3qqq7u+7u7u7u////////pxfA5QAAAAlwSFlzAAALEgAACxIB0t1+/AAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAVdEVYdENyZWF0aW9uIFRpbWUAMTYvMS8wOM8WlakAAAA9SURBVAiZY+BmYoAACSF2KENCgpcFypAQ5IQywIIQhgArmCEuwsMMYojxc4DUiAsDuUAgyscGMYeLEUIDAMpzA+zpg8RGAAAAAElFTkSuQmCC)!important}.icon-d-1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAMAAAC6V+0/AAAAA3NCSVQICAjb4U/gAAAAnFBMVEX///8AAACDnLSDnLRzkq3N3e6/veW6t+C0tdyvrNuno9Wjo9Geos+indGfmtKSncCZmcycls2WmcuSmcODnLSXks2Ml754l7GTjcqCkrSPiciGjL1zkq2BireChsFzjK2EhL1ujah4ha93grF1gq5wg6hkg55uf6hkfJ1mdaVsc6taeZVpcqhcc5hgcZ5dcZ1Sc5RScY1bbJxRZ5MaRgGzAAAANHRSTlMAVYiq7v//////////////////////////////////////////////////////////////04UUeAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABR0RVh0Q3JlYXRpb24gVGltZQA5LzQvMDfgV/JvAAAAHHRFWHRTb2Z0d2FyZQBBZG9iZSBGaXJld29ya3MgQ1MzmNZGAwAABBF0RVh0WE1MOmNvbS5hZG9iZS54bXAAPD94cGFja2V0IGJlZ2luPSIgICAiIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNC4xLWMwMzQgNDYuMjcyOTc2LCBTYXQgSmFuIDI3IDIwMDcgMjI6MTE6NDEgICAgICAgICI+CiAgIDxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CiAgICAgIDxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiCiAgICAgICAgICAgIHhtbG5zOnhhcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI+CiAgICAgICAgIDx4YXA6Q3JlYXRvclRvb2w+QWRvYmUgRmlyZXdvcmtzIENTMzwveGFwOkNyZWF0b3JUb29sPgogICAgICAgICA8eGFwOkNyZWF0ZURhdGU+MjAwNy0wOC0xNVQxOTo0NjoyOVo8L3hhcDpDcmVhdGVEYXRlPgogICAgICAgICA8eGFwOk1vZGlmeURhdGU+MjAwNy0wOC0xNVQyMDo1NDo1M1o8L3hhcDpNb2RpZnlEYXRlPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgICAgPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIKICAgICAgICAgICAgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIj4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgg2R54wAAAKVJREFUGJWV0MsSgiAYhmE7QaJSVpqSEVIZZiTW/d9bCG5k2vgMi2/e+Vd43hSLgzZ3YtFbjtvRYQ9XI4WJJQBAXNI1sEobIYRpLkQKDRsrX4NwI+/98CsTBULowTHay1wvJExsMMZXIU/4LAM9GxNVoiGutpnicZIoEztCSNuS9pbVdURIZyNj7POOXnX8/EaMDZFqYUh3+gWUDtFh4swx6Yf/+QHPMxO40fBf7wAAAABJRU5ErkJggg==) no-repeat!important;overflow:hidden!important;margin:0 0 0 -4px !important;padding:22px 0 0 23px !important}.icon-d-2{width:0!important;height:0!important;display:block!important;float:left!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAAA3NCSVQICAjb4U/gAAAAS1BMVEX////9+PL78OX34sv127/1277z07HxzaXvxZjuxZjsvovsvYvqt3/qtn7or3Lor3HmqGTmqGXkoVjkoFfimkvgkj7gkj3eizH////ACO6rAAAAGXRSTlP///////////////////////////////8AATQKtwAAAAlwSFlzAAALEgAACxIB0t1+/AAAAB90RVh0U29mdHdhcmUATWFjcm9tZWRpYSBGaXJld29ya3MgOLVo0ngAAAAUdEVYdENyZWF0aW9uIFRpbWUAMi80LzA3ipACrAAAAHdJREFUGJVlz1ESwiAMBNBNsBqsttiCy/1PKiCtVffzTZLZIP8EOfvInugrGA+xApHQ022bKUCiRKe3NCBnB1yOQAbBeQeoJa6CaQMn0IUBuq88PTTR4d7hcU0jPGcMHQQjReutBpGDhDJf+7Rif9WzfZ6z9u13XtjiEkob0Ut6AAAAAElFTkSuQmCC) no-repeat!important;padding:16px 0 0 20px !important}#sub-tree-subscriptions{color:#000!important;font-size:110%!important}#chrome-header{height:24px!important;color:#000!important;background:#fff url(data:image/gif;base64,R0lGODlhAgAgAKIAAB1eujSC6iB25kSK6zqF6kqN6yF55UKE5iH5BAAHAP8ALAAAAAACACAAAAMSaFbcziPKSKqtIQfFu/8fIAIJADs=) repeat-x!important;margin:0!important;padding:7px 5px 5px 8px !important}#chrome-view-links{background:transparent!important}#viewer-header{background:transparent!important;padding-top:3px!important}#viewer-top-controls{padding-top:0!important;padding-bottom:2px!important}#chrome-header .link{display:inline-block!important;margin-top:-4px!important;background-color:#E5EDF7!important;-moz-border-radius-topleft:3px!important;-moz-border-radius-topright:3px!important;-border-top-left-radius:5px!important;-border-top-right-radius:5px!important;-webkit-border-top-left-radius:5px!important;-webkit-border-top-right-radius:5px!important;border:1px solid #000!important;border-bottom:0!important;min-width:70px!important;text-align:center!important;padding:0 6px 4px!important}#chrome-header .link-selected{padding-top:4px!important;background-color:#fff!important}#view-list{margin-left:-14px!important}#entries .entry .entry-container{padding:0!important}.card{-moz-border-radius:0!important;-border-radius:0!important;-webkit-border-radius:0!important}#entries .entry .entry-body{max-width:750px!important}.entry-likers{display:block!important;float:right!important;background:transparent!important;margin-top:-1em!important;width:12em!important;padding-left:1em!important;font-size:.9em!important}#entries .entry-actions .item-star,#entries .entry-icons .item-star{background-image:url(data:image/gif;base64,R0lGODlhDwAPAKIAAMzMzP///9bW1ubm5u/v79/f3/b29gAAACH5BAAHAP8ALAAAAAAPAA8AAAM4GLpB/E/AaYCZb4CBmQBSpwDkxRBkqqqO8a2pYCoazEF1ekPFWmCpHmmCkgVcAMejEFoIfpnJLgEAOw==)!important}#entries .entry-actions .item-star-active,#entries .entry-icons .item-star-active{background-image:url(data:image/gif;base64,R0lGODlhDwAPALMAAP+DAP/v3//BgP+aMP/ZsP////+LEP+qUP/oz//RoP/37/+TIP/JkP+iQP+yYP/gwCH5BAAHAP8ALAAAAAAPAA8AAARFsMhZHr134Y0A2pcACCA1AEMpKUAbXITRznRrJEXQ1HTzTgwZzcDYMGrFzaF22LBajpkCkwAsPogFAHdxNKarhgOTvJQjADs=)!important}#entries .entry-actions .item-star-active{background-position:0 0!important}.entry-actions{background:#F9F9F9!important}.entry-actions span{color:#999!important}.entry-actions span:hover{color:#333!important}#viewer-footer,.lhn-section-footer{border:0!important;background:#dddddc url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAeCAMAAADaS4T1AAAAA3NCSVQICAjb4U/gAAAAPFBMVEXs7Ozr6+vq6urp6eno6Ojn5+fm5ubl5eXk5OTj4+Pi4uLh4eHg4ODf39/e3t7d3d3c3Nzb29va2tr///+KsXasAAAAFHRSTlP/////////////////////////AE9P5xEAAAAJcEhZcwAACxIAAAsSAdLdfvwAAAAUdEVYdENyZWF0aW9uIFRpbWUAOC85LzA32WH5FwAAABx0RVh0U29mdHdhcmUAQWRvYmUgRmlyZXdvcmtzIENTM5jWRgMAAAAbSURBVAiZY2CAA2YoZINDTjjkgUJ+OBRiEAIAEcQA92wvhr0AAAAASUVORK5CYII=) repeat-x 0 -2px!important;border-top:1px solid #999!important}#viewer-footer{margin-top:5px!important;padding-top:0!important;padding-bottom:9px!important}#entries-status{top:1px!important}#viewer-footer .goog-button-base-inner-box.goog-inline-block{background-color:transparent!important;border:0!important}#chrome-lhn-toggle{background:#dddddc!important}#lhn-add-subscription-section,#gbar,#viewer-footer .goog-button-base-top-shadow{display:none!important}#logo-container,#search{top:3px!important}#chrome,#viewer-footer .goog-button-base-outer-box{border:0!important}#entries .entry-icons .item-star,#entries .entry-icons .item-star-active{height:20px!important;background-position:0 2px!important}';
	//2336 - Sep 30 2007
	//reduced h63->h:23px
	css+='#loading-area td.c,#loading-area td.s{background-color:transparent!important}#loading-area{top:50%!important;width:176px;height:23px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALAAAAA/CAYAAABAUUJTAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAAB90RVh0U29mdHdhcmUATWFjcm9tZWRpYSBGaXJld29ya3MgOLVo0ngAAAAUdEVYdENyZWF0aW9uIFRpbWUAMy80LzA3QczRCQAAAWpwclZXeJztmOFthDAMhYHcRizRSfjddVimA1Ts0g1Kr70EQvJy7Y/YUqXvE9b5BLpnPxt04v3z7WN4HV72fd+2bV3XZVnmeR4AAAAAAKwZx8mDsaEebk4EVUGUDw4hCzhPekQlP0V1D/n7MTXad7FfGeCn/tCp9X0LqPR921f9Z9Oxi1SD2L+8POPQ/l8KNP1U+++pLuYf3AoIqv/gqq72/2GNtfWpgKf7ZxgpFftnrHyE9t9VXfjvVUCsQey/o/ovz39D0go273+Ho7l/xTXd88Pkxv6Zql9/XPUfLhV2z8+vwv/zvF37+Yxb/ld70C3P2ru19t9LXd//5TUd84PUp/TfSr04ZP+hqNAyl/tn0bV04CdE/2W1wSp/sn/BR/0P//8POzrnsYZSf1Lq/dtPDlT6Y97+ZRgd81OilP82IB+/hXqWV68/4gScUPL3EUzBhdYLQAAAAAAAAAAAAAAAAAAAAAAA+Kd8AbhITzMYc3rhAAAASG1rQkb63sr+AAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAppDOhAAAg7G1rVFN4nO1dWXPbSJLGHG63fLt7YuZhXxSxsbEREzFq3AT8JoqipGkdHJKyZb84SJCwObblHl09Xgb++2ZmFUCgULgoCZSmYXYLBAooFL7M/Cozqwo8+Ll9Ne/2t2ZzLej/43A2N8amMdUcMzjZ3/LnavCWbd7sdfy51rKD3b2hP7eNoL898OctPegPjmdQ3t6BKnz6F/T296/m7R782docns+VNWWseMp7padMlVP4NlM+B3uHB1DyCEpOoURT/galM+XfcMbnoN85GmOVm4dU8+YAWjV1gnZnD1vZPjiAO8EGDo+C9mCbThp0qWywS5v2Ph1s/0ybrUNewXaX9vtDOqnbpr1unzaH7OCgN5u7dtAessIhq304YDc5YPWxzd4mtvIQW6UGnSNtNndgo2M1nSODNl04qMNGZxsDN0EpZP4iQ0ZZVzbh6AXs/w2+fYbtSDmHkkmdmGnXxEy7Lcwec8x2lDPA5RflI5RdKNNcbEyGzTQHG1WKjeclsFFzsPEcho2hV0ZHMxk8IwbPiMHjMHgcBo8TDHrv4C7jYDDg294RoGaN4AD/Ug7AlxzALeUrKNdXgBFUC5QufmYcTKiY0NStPDRHJdAUNC0PTUHTRjdrnQShbUsgHPTarGTAtnFIv+eQtskeZ4rHAX3OAR0AmD7o4rrSh2+XcGxSaLVSLDXfvFm7Nbwl7XZU1W6LMNqF42ekbtfE6IZ7gwoIqbeD0JMUQvtQenpbzHYvsVlY2NLYiLZVBZ0V21ZI6R1C5yPZDcPnBccnVkJ7aGFjIPl8nPQ7ykH6jeP0XIrTQtvuI0paTdo0BFaagb91X7XJuHGcnklx4vxdHaOVs3aeJlkMIYshZF3L3nZhO1KulG/30jPSkj67xWCyGEwjBtOIwST3yNMwrUUwfYXO7aJGpzHXBffMJXs2lUGjMmhUBo3KoFEZNGoCmiccmk1gmDPo3dvw9xJBEmK+IUDzbwDokgUtuSAZUiOj4kyUNJfjpI/zAj8K8ZYN/aQuks6g0hlUJoPKZFCZLPLTdDcZ+uGjUNwCB6qA+T0Hs1y3hwYSg9E2y+AYaptjVkBxck03swyGYCOlMHzGMdwCjD5TCuZDlG74JlhtH0rH8PmqnCaQbE0YlI7HEzTuDbF+ntEu7Y3qThkUq2L0HcfoDZjrhRSdVpi+kpNanrOOlybw0VeOD6UPKEfTXkqnQtv8B1jsDM9KYGZaDDNtLIAWJv1UhpqXZ5v+qIxWkenGcLN5X4BX3w5w7/CmPDVjaJOFfS5rl8hvX8guv+YnTjmImlE6waCpZnXTtFQGIXXUiKGfl9W6GRCX1T953yAy2vRmCU3uxuq1EdrjCKCP5MN7oDqjKG0aqtUW+R6oWvn+q0Bomu5JKU1QrJZXXbFMnisdcYyMiVm671zeOtth5pSrdHkkl/Hm5N0DpaSzwfT06mBGvpylMzRJcCXR1KalOwnmeSCIfgXoHiYTYVUgo06hME6gpyXM0DsriZk95cxGUG3z7P2NKmAf9E6fTuFLO90rlDPcHnHaRfHgo2C4vlmiQ/DNJWAL+1Rut6R6N2+2aK2DMIDATpVFEuGXhDLSl77EotciiLHL+EbObrLLGNJInKd8qgIuxVlF4JbzWOTYEqbIieMbV0kCl4BD3Rz7TEkjlBnuLLQY9HdThp6N6MMosBgpnwqybQ6D02VwktcWg1O9birAZGgyw0aycrj/R5Ey4omjgwiongOoxRMCEAGxnJLLILU5pjYH1eaosn4lRDUxRheC6ctzK9nqWS7a9apr5xJBWqicaTRLaKehy7TT5khyILNwjEw/QylDJu3SRAQcaBli0ldI5+2T7/iRyg+IcUFNlbPc+M6TZmP0HGdx0RUt4QvdkLtop8bg48q4cIQQX3KEnGkFPOMJZMQwG80Ms6+ip5o1LZOVqRnOdpiUScfL5bDb5br4OdJJEbtw/gK5g9QHqQnSZE5kijSlkQv182XjvdGtYlceqoeJHvr0ZsfaS6ZM1ZuZR1RBrSKbFGfGfMfBOpJMURsAeNiD4LSE8zIWGCYNwryoNppeNy/KobKErjeJFSKIYGk5PYXNhyhoqMJgW4TL8BhetDVoS64LTnvp91HJo75h0B+k+ggZfo8j/HCAcMRHMfI5bCQNT8p0tZNpXubKG0kDuig4yU27ZDguJREkdzA9p6h/xFmu11+g7I8YumIwI4P3R3nEzJP7MwprisZlW0vOoill19xP9EdCiotrqzlOOImmzLRDbSUTN9i2y2VAQ4985Ai2yfEQ5nH3mb4O+ty34fuoxxrXY61Yjx9F3mJZWEdLwkoBSRGshsABYTQTRorkP6Wcb61ETgKPdjnaXYY2aTBht8m0ExWZtHWXHIGyGL6MYYhxOKppLbyA+YESvKBzUD1dIIYJT/SwiL+AGoCAperq8WmbHgfWc0RfnBgh/CInC/YljMdRt0nJUalZhC7hjadcFG8I5ilPg9AEz6Uidd2RZtzI1SzSbcydVYyFjDDdhm7qtQJ1Qxao05TOrEmfy8FYbhqDMAwdOZvlhusrABn6VJE6Uzd5rcSldAZylE9aBJXkwIdf+kcxT0Jl7CFMpC3GuIrL6nNPzE96Yv7ohkj4uu68HFtdpqXMZ41zQ5RFEkdzwoxHn3urX5UvKV/2X+AojMhVyPdlrWXHcSqoJ3MJYn1YhRwxuA/S/BEe7/LjXXacOq9wdF9rcb1sMRINHQNyvXYZqZbD9KESn6GTj6YhQ1MYkpXDqZb3tIhH0uo4NouzcVFYIKCJxMHg1Llbi1+Yr+VMua+FX6g/slXmbBGW/dD2madQDtMwZsB1CKeKjzMEcNGLDFvNMhm2dtLWRxVM3ZbqqirVVUrHLTMVJeyRkis5dN4l0dagLcPM5vxY3rjDCRVdjAFkUI3NhBcVIlUlvMpd9EKKJ0sNy+NTroiGDCzPkbtQLo/nXZ7NdO2FWffD3GV7Yc5hLlPIHxVb81tix/zeJekFlRoMKoVj0pzH0ql2Qtgk7V2ygvys3HpyFJfDRg5lxjSyY4DqlDrqS0qNhG7+Aw6ioXSWGLltlZk+VibvayTdyCSAQPySuLNcjK87kghpl/XRVXAKu+MjOH5BacqidQuatAcpN+MuhMwqH6wLkLnFOhcOQQgsd0OAPYn6hY80zQJTmtPU7DoRNHvZOFwrn9GNXGzDrj5uE7qBRYv8dsPgZDcdnJTVNbBJCLp3yKX+9dZ1TSvWNU/qrWhTWSeh1WqeYbYCZwfMaNlttWyFfFwrF7/UeLYhzVe4TjJf4UspTp4CEoYMPTmGso5WXGS6yFTwnjaeYSN3EFFvWawPEQK9suB3AW6c8Fg1VbQE+KWUl2ZQxbAfyalyWj4HL/o4UvUNHex+lPBJ+9NFkP6ZQ/qa8pceLQE7pyXl2PXgCt/1ha5XB5dNYysLrlSxkx23wAyUBkqrdaWe2+CxtcHX88CW1JpP1Ygj3ePuZCJ7QeFjLJ/sJNPJFf2kZ1Eq46vyb8q7rVPi47xw1bqWTB3R1KIKaxgiKZjFEc/SL0PAkKZEr0Y5Da8lmYRAI8B0IPwSYt3jvik+Ist6xpxVMftZJIWnMSlgCP8RWGYJGdz4WhtuBY50liumYGNGoFcZ5MvqH5nbP+AxZ9Dd71zNu/EVuD7hOKCE3Cy2RMkn/A7phQFfCNnjzBKOaJc9UpeB0GWP0t0mtev2O3RKv8/KdtnmBDdBNx7FsQbxBb8YsQlNipccZ5Ys1ySdNQk2O1GLXkJ7vOgFFBPOqhex9ymcR0rn8ZEQ7NA85RMYfvi6iu7OawD+cItVvgffd3r4CpYue8WKSv+CWJEWFvH3r2DZWyxTr1+PtmQVYRH+68anI/h8NtaMcruX9Pyi3PocvbQqxUuWk5vB5GY0cqsit2dcbn1AxoOnxbzJB0F6zyIZyc45LnHOchIdMYmOGolWkeijyBIxx4rORzxY9GP517DsOKdsOcmZTHJmI7llbJFJ4IL8+LMQL8EW5ecclzjnWuyqaY1Iq4h04VuN6O1eiynKPh+wC48fZxxfTlwWE5fVSGsZafXIifRiy6d9njAKjx9nHF9OWi0mrVYjrWWk1SVEJhEeoVQWx48zji8nLYdJy2mkVUVaT7m0tvlC1F+I3+LOyVMuH9kZx4VnLCdLl8nSbWRZRZYPuSzbNJh6Hg2x+tGym7PI6sSjy8nJY3LyGjlVkdNaFNyhrbD3OIkB+aJEDMgXJcvJbMJkNmlktkyv9oYmGk5Tvdri+HHG8eWkNWXSmjbSWibY7i1GryIf/1HkHcbLjnPKlpOczyTnJxr2JFKjqTJWOiSKjzS4Fo64h2ojlh8XlC/XSI1nenHb0WKIdjt6Ys9I7JmJvSHWGgQ7lMBeRk0fczXFAUeWp8L3JH2Jqagt0wvWhLheqBt6vBCVK15oLtRGH4mF9qIQ/08WOnGdzVRnrouCWdyztt+AKS6lBM+5EvRpPc0OTZbFc9s0Ih3nK6MsoFY2LIlmy8jstm6yanhxNPorzeO5UI74CrsPxd2B7qojy83QnZYn0/tr1LMqkH5L/eVSAL2IAQRGyY31Lc0MY1OcCsxUdVV1rGdYUNq84s8uVbLbusmqAH4pAByDtogJNxaNGEMfMcp6/okPxclCV7wyF+YbvtGqjT0y8YXZFxl7aIl5rSpj7OXqWRVAzzhAWDLGbA5NyUtrodTBUVXDEd0U3VmU6u6oJXg4sZ50bOe4OOlLWzmXamKLRMncv+avmv23aS4wTeqhiYKRs1akFLpqeCmvN0JVG7stbZyFqjY1fdiTo2qPpp6qZaGarlgTW1RKKe5081elFGtR8IavybyiYLRADVzDhS46C0dTx08WjmNrbIy1LBzpXxaOkyl+pCA4Kn5KqsGdbv6q1QBLfqE4Pq4GphTHlmlrgvdgRF3jeOJ4gr04Uant6VPNlj7I1J+MvUlalKtpwqrE8SgRTaf77Ax3JLs93KUWUb1GPauGJvYWQigrzDWlTXNh82h9qYRNZLi2LXp5MZvHC1t+ls2zG2eFy/Bf6XTTHW7+TSR/t7udq/l2NzauOSV12KNZyOistOHvFb1yMiSsKanBO3pd1TtQhg/Bdm9wNe9sbeOfn+Gc/wVH5xP4vl3q26YULJzxYOEIrv6sfFPYu2C+AOV9JdU7g2Pbik/LaDGVeQznH7LlU0Fn6zWlOxetWo+1K4jd+TH0px9JkTHyi5SY1/BQ+W9FXXwSVz5P3H0PVJwtQJjx359hNfyRJ1mnwl3j1x7QS0P2lA6/5n+UudKiUlvR4KMquvI3+O7BEfyGxyb0C3oOHGtBCWufRWe24K8GJbgXJO66tsAAsPyGnQe/4++EZ3sUO/MNrVK5UD7yc3+PLUqc/TR2djjp6owZfXRNS7GEa7ah1g9wDb7wgBbsw5ZmJmS06Sn9RuAH0o/wV5FO6brz6AojccUTerncOWhW1vniHRav+evwl+GMaGZLiNMfSBoiVourohbGzjeEJ1+D1nymznuakoIhaNjizAOaTHrBf49mRt1+eJUmXMXWXSZsUarZE8BEptnPaNH/rzwnjNY7SV2/lrQMeEpfwHKX7De/Bj/2EWt4TDV85iwga3/s6pRlstegg6yBU0ZkOUVPkJbrgDTyV8BzrPyT2Sq/9gHcE4Oy85Rdtwn7C7KCAenPRaaVvQzXK/IzzzL1TrxyLbpStE46E2m6AkM/5AzdZavQGnZu2LlhZwk7ixrWsHPDzrfPzqH/PADU+Eq+hqEbhm4YWsLQItc2DN0wdH0M3Ye2I5qovw1DNwzdMHSaoe2GoRuGrp2hHympHLSiNxzdcHTD0RKONhuObji6do7+IZ3n4OfTXBeF/Uh4w9kNZzecneZsveHshrNXNnKIq2VPm3kdDTs37CxlZ6th54adb4mdJVpxB2beLVrVMHQ+Q2sNQ98Bhm5m3jUMXT9Dr2rmXcPODTvfJ3ZuZt417Lw6/3kVM+8ahm4Y+j4xdDPzrmHo1TH0KmbeNQzdMPR9Yuhm5l3D0PUz9Gpn3jUc3XD0feLoZuZdw9H1c/TdmnnXcHbD2feJs5uZdw1nr27ksO6Zdw07N+x8n9i5mXnXsPNtsXMH6kddivGdwM7cSmpj57BF64k2pWUQsnP+OHs+k4vStoUMY/JO7M2YCwtzBPuInyuXGLKkntO+NFMYcIVo/7fZw4yAk13FhM8E6nOW72Eqattzrm2LX1N4nzjrt6B9I0E38rXPrKx9v1Nav0Hde8Z1L87+oif6Pdc+zBcAe9fGdk8WdwSNi7Ww8UYl3qghWEe2NypGtPfXFxWfY9W+aDOLbXW+qCZY6H+KL1qFoftw3xk9VT0M/XRxR2XScHQhR4seTMPRDUf/ljj6PzVf8DzBb+tUM/s5n8+JKG5A+MyoLH7FBn5q4uyiVlRj0DHEJCqUusSEU2JQk7Q+ZFCMVEbw8YE1w0gOz3Zg3wfOmsD5SQb9L7hTG57Mp+dmVvYenvCMLA3t8lfYv4hQwd7g/6Lne0B3Xse/iVofQCvzrUPUzgfKSOCa30Nbk0zzvTLJy2UsoSVPEmvf64/ys+9fV5xv5dzpPz/Ot7in4ZOPgZ5ICz4mnB9alAHfxmRTkwg1h7wYn2wPPRMxzi+ne48Ssg/L6tE7+b3rw10nTB3AGiyXMEaGQs6qiHtFr80WtKvYoxLnEJX1RbJ64dvpI01BA5+AbU2gj7+ketdjLQx1b/EDQ+tctz7Xpnuye9enexP4WKBDqFkeadyIYgxX0D0Xjo4ScQj5dJQRnAq69yDTn5PpwENA7xfy4hDLbzm++FrM38TZRJOkdlSS+XfxOUg1yTp5z6py0klOyBAuxYbI0ROwYTFedKLeDKWE7M0ka8B1t+btVML+z3DXsyiq4hyj/CTyVK2+abU2VZOdAVJA9MfE2qw3RXvSEjaG5aDRJLspyc4lG5iQxyrG+rfjqb6ENqRReE9IfQV5nka9Rzqa9QSkMq+qpCtrEH+HPct5rRohu3NVm1VB8lM4B6XO/CkN2mlJbFav32YT3us5SeqMYun3vGd9D/sflHGmxJPXfOR6k7zqD8Rbop8xIc26KHmnp7Hzy99lDcpRnl/gr1h/2aefZuar8p5+cVX5p8++U9bT599FfPp4/cmnf5Hx9B+U8AeBs/IbWQiIV8ra90yCQtEdn0uRKHO3xwk00vcRc2xyRMYK+wVOeetEHBctTF4na99TCRr5d3smxaL4To8SSIj3qNqTv1R26RfufwL/HXNhl8StyD7YF9TJ1mVacp1eexL12vqd67Ufgewv6fzifhqtNo1PmStfUOauumfwBK74TOdGWTDhqWLZ1oq+wRY9xxW1pl7fIH3n62jXNNIu4w5qF/WdVNNXZUY+3nmw0wMx7fSGV/OT/S38qde3bBMsjumWxY7ilyBVJ47b3WSdTxa8fqP1Pg5Z8vq1VtLux1B+SWMN63FPtLYZV/K7X8cD1iIP2Gw84MYDbjzgxgO+8x7wA+BQXLM4jWWLu9QHsFknbJZDXawsv3c1TvZpTokKvIr5W+Rfn0ZFF6M8KnEy5nVXwMkF6L/gGblw9eg676M2oeZfcJypJkkUt6OaVHSSh06e3YhiDA+2Jo1hx3tKi0Z9ys0Hui2p/DEaC2UyWezXg/3iflU1X4Myn9jJjLyR0PteuTeSi/FauA9nHxBSdc20k935Orjr9wr3F8oOtOaSot0ZjUmuR3jUGXEWt+M6nrkaeebG3ZBJrNY/UX8df/Kw1z4jv25E82Auo1HqH6CNG9S/ZX/sAqk/I8zC7MhqJJ7fhmrStkBaDvUTNrTTpj7f56OHJtmiTyO/Gs2osmhmFc5ORR/RoTNGijjKe1sjUF9iTx2XdHpGlCt4hH/KvDZ7ppQ4HpXWhD7XMMxRrUoT8tpQ1e6Riw2aW8S4WKe6HdIEHJO0SBPQun3ShQl5JiYxgU+W79WiCT9Eto1PndQEMef4e2hhUhd+zLz6X7AdKWzm6bfoer1QE54o7xR8g8mXFWlB9v2raYDL13Gh9dtRllGn3hjXeI2JC5AtbJoXMiYe8GmmiE55SfQ569CAF3AOe+Kq0n8pvbKs5B/yGWtnNDf7NFp3mzxaj9TFu1aTtUd9N0Z3OMeMxXpsRUE61mut2POSo/4kebR27zf7/tUkgTP1dPrf4vN3XLLCVsrfCuf43TVJPAd0TmkdBytZj2YL1juHPL8V14lMzLsWmST6s8vEc7+n/NU5rcde2gcuWb+McS2Bcf+cc/1F3hogId9zSCMsOBYY2v8m9Tzri5Kae92s+1fTtCnpjErzdceUa/NImwzqdT0eeeFfi1YVhTOAsa+dUo+N/lg9ve6Invg9YBY+cTkd+FF65SXfimsgssd9v1O26MxLqOs8mq8ZP1bXfM34Pasyi0+RE+Nyj/tWbmzki61OUUG+q12d8hhaFz5lWko4czdkDENYgbdG9v0t5yqfcstuCfm+pHnfDNMz6mmRk9dXIPUyLakac+nkX6Hf5ZIu2BRRuQldGFPM7SZ0Af/36dx6ou/6deGR8lf44FrACY3nnOJ+NE+4B8c9PlsFZdBT2DtIRjTyEc6Xp6evbZ5wlTZV1ROHMjBT4gDmrTuUsYl76y3A3uaRGkbx4n49PiL+Tiqb8evT818Qgt+it36GpbhiEuueKGx1jQN9p1VrD16uLbchKbR2m+b02CAlJ7Vfj6R+oLHCb5zD2Oqrb/Dd5EyD8zu2udziq4Ywy8DW2NYprbwW3I6MLM7GGv1l+ybJ6lZZd2kZrVHEc8ZW/9Q86y1953plMqFjd08mz4Vc/ZAQxTvWGxvnt6JuWVm36cEmZPUjjbvPFJahGQC2M/4N36cwovH5hbS+X8ydqFU+6fveln/Qoux+K+YftEgyZm0Seaiwd8ckV/mG7y7cpcjva23zBWRreps3w7AcTHJN782/S9ZOXVP8bhhNuKLo3TCYxa+6llmcf9a8HYbNqmveDnPX3g7jCDpUfuW7nIXDXzY7JAbFPG1dq90bJl4tE1d/S9ftM3H63bsNFzdcfFe5uPxbSNiKn4MBkHHQ2xxezdtb+7O5z/8FXban0r+g24s4+3saj3y/eFcWZ+0HsSPHqSP9ztF4DvUM2zPcbHdpMziYzXXYG87mWtDtd+iUfp+V7bLNCW6C4Un7ah7eaIcHjqfQ/J+v5m96cI6jBrt8Oxy8g/qg1cM9aPVwrzObt/yJ6dNo3vCkezMVBdsnvat592CIj7C1T43u7dOT9DYJ1P1DdqxPlfWGh3hmbx+A0ILN3j7bDPCZNze3aG+zQ5sB1DKFMzt4/Q7WqQZ/7/1jNrdwO2C7R2zTw+t3unu4+fsAzxnBdpvtDrG6vw/ahOt+jwA9hLZ1Dw/wDz8AtzGD13sDPDkIdgb7ePr+4Bg3HbbZH5BstgYHeNL21gAf8/DtgJXR3u7wAKvbHbL0a4cIGzvXX2lLE9GDky6du3fQgZNe86huqrxSfqLPLuWuP4Fms7UTyJen0NfhCNQB2Web5s18gnOPadzuTMG3YPyT7OhjdPVPxEwe2NgXYpULOtZT8B3d3ELpyA7VxvoLdpc+NZZlYNkRHq0H+yf3r80nB6RCwz6JDSSE8jrpbJIQuydkA3+FSP8XhX5Hpdsm0X0mX2NCOQpcWfkJ/k6CwwPzag5/ZnM7oI3PNhrbqMIGtl08HwzdCmgDyrV9uIXb4eY+Nav3BjcnqDhQeHAIFxwcIsrglOy/BT3d33wLvPTzDjb7uM/0kgfq+9DEbwpLlGtIY1h4sEVW1WG6vLWPpLWN9Wz9jMXb+6D2veFudKDhvSV4r93vEckNWeuPhtj6PrLIBM7y/GB4dIILTYdHb3Fz1NuEh51Ogt5WF6XSG1Bpb0ClvW22t832umyvy/bacPdeG1h2b0D82B7s0/EeaJEDxeE6VnfDtEBaWrjE9aQHG3NDN1THNIKt/mu8mFroeK3gcNDx55rV2tBQxHbQfge3ab8jzWxvvgPmDmJ1a7a9YWHtRlT7AA+3tI2W7Wq2JdRv8/rNDccwbKuw+pbN6sVnCN7GGq4LFVusYtPcUF34Z5Wt2DI2LJMueIsNtxxqt2UK1ZvJdrsVYbENhnomLkZF3JMyxeoH2ULVE40vqlpNAdPLAUarhrsaF+cgW5xqEu+WtFqoeAttAFmI2wApv+HCNkv7e/0B1Bu83kZj2dB0K+gcE7VEFnB0SFXF6khreVEttrSW1oal2brOK9lQTafluCValKjEgQcyLd0Na9FczXWcwlqcRC0tdUPXHcM1w1papm5rxbW4yVo0Eg9cR7VoG7ZmOFBnUS2jZC0G6ICutXgtOihay9HswlrGYi2gRqrTYrUYG6bhOKCPRbV4yVrMDcOxVZcL2twA0cOBwlomYi2O5ZqGHdbimpZlFEt6mqzF2tCtluHwtxBYG62WZqvFT+SLtVgtS+OV2Bu24YLMiiqZqGIljuqoGlcX0GPQwVYhLBNNrMW1NF3lBgCK7BgtRy+sRU/WEu8SirCwZHaY5v6iakxpNcnHsUyy7hKKa+Vha1nMvrUSHJMtZ8veMGwV+5lq7CLqXCukiYr0kjQA6DxUyzStYgtw86wRqiG6WYJg4tRguRuWrWlqcTUphonzlK3SbrH+ihSTJE1bw2fUStj1JI/BbZ0JrlhtpnndCVRDyliRZJI9G1SChlFYiUAyaZ+pqBGGxCxTnlFRJbqkkoiaKj0PtCdWR0SS1YA143VEnF9RxgmGiTqxivqW4JeoV66o+61kJeDgOq5b1Q6T5BJ6GRU5IUktG5qphu/3KU9PCV7hTpNblSrHyUpM3XRMpypte8lKuBNYsQeZJCvh/mjF3izBJ6ngoehqTWJ9aoUOXpVdn3iSsm6Gp2VDWtbh8fRs2ZZ1vZIsIihZWR/QzFT20s6olW10pd1iO9v6SzvorWwaKh0qONl8WDpocbOJuXT4NMruIEoHcuPsjqp0SOll95hVImSopb8HAXjV1NXB8ORqfqCqeJsDVaNDqk4bTWUbjco0dlBnB3V2pq5jWdDfggfodwbYSCPY7w5ZVq2Hm/7ekPn57aMh67/xH743oDPcvJoH20dd/gDB673u1TxK76dSqhpPqa4pb5SpMqaZaDy1ytKqGkurqvlp1dSNgp1+52q+w3KBOywXuIMAgs+8gwjiliVbbfoHV3QGcEWHbrbT+ZnlYfF/2NuFW+x0XuONWCZ+LyPzvi5k3V/Fsu6vUln3V5Ks+6tU1v1VIuu+nsi4L+bzvYKWdWlcUZpBj/LsRwNKBh8NNinF+/+z5SHuCtcOGgAAAL5ta0JTeJxdTssOgjAQ7M3f8BMAg8BRyqthqwZqBG9obMJVkyZms/9uy8ODc5nJzM5mZJ0aLBo+ok8dcI0e9TNdRaYxCPdUCaXRjwJq8laj4/Yy2oO0tC29gKAHg3DoDaZ1ebfxpQFHcJRvZBsGbGAf9mQvtmU+yXYKOdgSz12T187IQRoUsvwZ3amYNs30t/Dc2dmeR5UTw4NUexsx9kgJ+1GJbMRIJzqKadGDjp6r3sWPcNVhGCdEmToYpAVfuh5fpkOx3EUAAAR5bWtCVPrOyv4AfzjFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2aiW3rMBAFXUgaSSEpJI2kkBSSRlKIPzb4YzxsSNmxZPiaBwx0kOKxy0Mitd8rpZRSSimllFJK/df39/f+6+trSoXfg7Iel0z7EulfU1Wf3W435fPzc//6+vpzfst1px5V1i1Vvn95eTnYY+v0r630//v7+y9Kdax6P6P/afvP4P+ZPj4+ftoAcwFto64rjHbBdYXVkfgVzr1ZmnXMOLO0+rN1ThnSP6RXUD7KMUpzpIpXaVb/5/yR/V91S/BFH/+Jz7iIL3KczPmjwohf4ppnS5VXXdexnpnNRVke8mNsyvMsW6afVJxZG0i7VL7P4P8Otpv5/+3t7fCOiH14pvfHTCN9QZsgvNLinPZH/J5WHcs3vJeRXvd9PpNp0p66si3nHPjo/p9p5v/sO32eTEr4sOxY7SbHVMpQ9zP9VN4jr/TfqB1n/67wSh8f1vlsDiAeZeT9J+89itb4P4XNmG/p5/lugO2xYfbr7Jv0vXw3GI0V+T6a/T/HkPRVliXLO6vvEo+irfyPL/Ft9rWeTn8v6ONJjrXZ92bzUdaD/Hp7yPE802TM6TbpZJlu+Tvor9rK/6WyUb4Dlm37e3v3Ne0k/cD7BGnRpnjmFP9nPMYk8iLNXr4lPer8r5RSSimlnlOX2ufNdO9lL/nWlOsgl7BhfRvNvmv699RftfZ5tT+sOdSayWzNeo3S/31tI7/zR9/8S2shrJv082soyznqR/zjMbu/lN7oepbXLK1RvybubM1pVua/iv2y3PsjX9Y88pz2wjO5zp5tJPdeOWcNl3s5JrB3sya82zrLmeuJdY/1Ztaa+rpShfc61r1MK21Xx/QZkFdeox6nxHol90mXve6lMp+j7pdsb6P+z1obtmY/vms09le83Mct6COs860JP1Yv7JdjXv+3IfchEHsZdcy1yrRVptnzGtm3/xNBnNH9kf9HZT5Hff4/xf8Zf/b+kHbinL0Zjvgz/8lYE35qvfqcl3sC+HpUp/RBt09ez/LKsNE+E/ezP3OdeY/KfK628H/fRymfUKY8LzHWMX4yltGe14afUi/CGDf4jwAb074Qc233fx9zco/ymP/5fyLzKPX73f+zMp+rY/7PuR079H6SdS318Sl9g7+Iyzy2Vfgxu2cYtuT9OudhxnDiYue0NXud+DP3KI+Vg39r8SFtJ23KntnI/6Myn/MuyH5b1il9R9/OumKP0VhF3Eyv59f92fvBmnDCluqVYdSDuaT7N+fy0TcYz/fnRnn1MNpA34tMGxM/856Vufe1S2hpvUA9vvS/UkoppZRSSimllFJKXU07EREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREREZE75B+Hl45qN6ZdJgAAAVNta0JU+s7K/gB/VYkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7dbhaYNgFIZRB3ERB3EQF3EQB3ERB7G8gQu3piH/ignngUObT/vrTWzOU5IkSZIkSZIkSZIkSZIkSZIkSR/RcRznvu9P5znLtXf3v7pP929d13Mcx3OapsfP7Bj9LPfUvXUWy7I8XscwDH++h3TvsmOVfbNhdq3N+z21f9U3v/6N7l+263tWOeuf5XqdffvG2b+6XtP9y3O+71//1+d5fto/1+z/fWXbeu7X79u2/frM9+e//b+v+h7X96v3QK7Vd/ucRdWfHddrkiRJkiRJkiRJ+vcGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4QD8K+ay4PVSpiAAADtdta0JU+s7K/gB/n3gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7Z2NkRwpDIUdiBNxIA7EiTgQB+JEHMhe6eo+17tnSUDPz/5Yr2pqZ7tpEBII0IOel5fBYDAYDAaDwWAwGAwGg8HgP/z69evl58+ff3ziOveq5+JzpawAZfj3wf9R6fmK/jN8//795dOnT3984jr3Mnz58uXfzy6+ffv2O++wN2UE9PtHRtT7tJ6Vnk/1vwI20f6u9l/1Ufp2laaT1+3f+Z1dVPKs5ARdGr1epcuuZ+28ez5wauereuvsH+Vr33W5tG97HpoPeQWq/q95ZfWO+58/f/73e+gt0v348eP3vXiGuqgvC0Q6vR7pM0T+nibyiLy5F2WrXkgX1/V56qBpIy9PRx30evyNz6r/x9+vX7/+fu4KOvtzTWXR8iNNlM8zWZ8jPfcy+7sMUZ7bCJvH39CZponvjFtccz1FGp3zOLR9RT6kRxfIqelU7vigC9qyyh3XVB+qZy2f8X3X/vrMFaz8f1Zm1v/pf528gcz+6m+oU1Z37Bx6Vn3RLuKDL9A+qH6BPFZydrpAPsohP/cVVZ39+ZDPy98Z/+8xF7jF/ug8+iP17uSl/pX9fR3iwLbYPf5GWyB//vd+hqz0UdqLQvOhTpku8LcuK+2RuV5lf2TU5738TG8rW1zFLfanHWu77+QNZPZXf4fvzfoofd39j+o27nHd/SS+I7M/etA2lulC06nNaRfI7/bHP/JM/OUZzTeuIeMz7E9fUX3QnwF19e/qbxnfHJoemelb+j2epQ90a6XIi/v4TcD/kcbvISd9LwP1xodkutByMvnJX8dD+of/77Ko/DqXqfTpuh0MBoPBYDAYDDo495fdf83yb8E9uIQrOC3zNH3F257CY+XEpVjPZHGBe2JV/urZFZ/WcZiPwqnOrui44m3vIavGtqtnKs6q8h9VXHq3/Fv5tEdB5dY9E16nK3J18fx7tetMVuXV/P4J51WlPyn/Vj6t0pPzhs4p+h4F53iQhXycA1nprNKBxhW7Zx5pf/TjnFzFeWncXmPmVfrT8m/h0yo9EaMLwLPC8yHzyv7E7VQWlbPTWaUDtT9yZvJn/v/KHpoT+1ecl3PWyr1WHNlu+dT1Kp9W2R/uWPkj5RQ9/8xGyNz9f6oDz6uSf5crW6Eaq+BG9H7FeQVIq1xMl363/Fv5tM5P0oejjGgP9DWe3bW/jhme9lQHp/a/Fepv4BqUd698U2YXrvvcwdOflH8rn9bpKbO3zjsZF7TszEYB5RaztDs6eA3769jJx/fiKS+IT1POC3my61X6k/Jv4dMy3s5lA8opVmUzJ3eulOeRZ0dnmY4970r+rl6DwWAwGAwGg8EKxL6I+ZyCdSBrmFUsqksTc9sd/uce2JE1gG4eWeauLPcG52JYd3sMfwXiH6y/d9Ym3fr1mfsZM65R15SB+E6s8FFldtcfCY9dB6ivxre69q9nY0iv+sue5xnuab2d94p77pf0zEGmM57p9El/8ziGx2iz8nfyymTM0nXXd8vI9LiDVRxJ9+RX53GUg/A4re7V1+dJoz4HnSuXo/FA5eyUD3CZ9BxRxZ/h88hHY/5al6r8nfJcxqrM6vqOvMQbVcYTrOzfnbcEXczS+S/4Ou3/6MrPM2TnO8mrOmdCOchSnY3I9O98R1d+lZfu13cZqzKr6zvyZno8QcePkd+KZ+zsX+l/52wR+fqnyxd50P2Oz9L+nsXis/I9r52zhFWZ1fUdeTM9niAb/5Vb9DZf7fu52v8zXVX9X8vu7O8c9Kr/a95d/6/mf13/17KrMqvrO/Leav+Aji0+huGfdHzp+CuXaTX+q9xu/4Ce4avOn2e6Ws1ZfDz1MU55xax8RTf+a/qqzOr6jrz3sD/1rtb/ei9rm9zXPuQ8ms//PY3OkX1On83luxiBzoX5ngEZ/D7ldeVXea1krMqsrq/SZHocDAaDwWAwGAwq6NxcP1c4wEejksvXHx8Bz+ICWbv7HszVOoL90s9EFWer9mO+ZzyLC8z2MiuyuIDu2dX9/yfrV7UVsTa9nnFu2J97ngdy6HXnIne4PNJUa/TOLpke9FygcqSVvm7lG0/g++/VPlXsj5gTfmOHI1Q/o/Erruueefbve7xR+cIsjyxenXFGHS9Yxft2OLou1qlnE+HXM33tyLjiAk9Q+X/sjwx+biXjaFUH3kc0Dqfn+Chf+4VzbnxXfVRnJnheY+v0kyxG7f2Ftsf5FbDD0a24DvKr9LUr44oLPMHK/yMrfS/jVXc4Qs5SaF/Pyu/k0Xy7MzMhD22Wclw3VTmMberfKHvF0Z1wnZm+dmXc5QJ30Olb+6z6eK/rDkeo77XM+r+O313/37E/Zzv1LOdu39K9A9pvdzi6Xa6z0teV/q/P32J/9//I7uM/+sdPVum8Pfm4Wtlf887G/x37oyO/dmX8P+HodrnOTl9Xxv+ds44VqvW/ct5ZTIDr2m87jhD5sJ/OMbNnsjlwVl6VR7V+PplbX+HodrhOT7dT9x0ZnxUzGAwGg8FgMBi8f8Dn6NrvUbiSt75b4x7vvtfYwAl2ZX9PXBRrXjgA1pSPqAN2PAHrWmJ6uq+y2wdcAY7hFBpP7HCljq8FYha+biR+FvB9rL4Ox2/oepUzGPHRmA1tS+ML6KvjdlXGzv5dXrtptE66D97luFcdQfa7I7T3eI7rlKvpApHmat/KdMT17BwLcQuNszoHo7/PRT3QDXol1oXfcfkpQ2Px1VkBtUXF0e2kcZm0rsp5Ukf9LaErdQwoD0tcD/torFDTESel3Cpe2KGyv16v7K/xcdo9bRI9eXxL8/L4dsWrZfyJ21z9mHLIip00AbWfxx89jpvxe1fquPrdMdL7+wSdOz3dt+XyeBza6xNw+ztvQD76m5TImOkGVFzUjv0rHkOxkwY9Ku+Zyat8mL9H8EodT7hDyuUDV135lhV4jjEus5nvtaAPOV9Fn9CxqeINvf1W/XHH/gH1f8rjKXbSKOeo46DKkX3P7L9bR+UE8fkdd6icn+7HugId2/Tjey3ig2/0vRzcUx1k15Vfy57vzteDyv74MuXUHTtpVCafdyrfznf6h7eZkzoG1Aa6p8fHZ9ettpNT/k+h4wdzzOzeao/d6rrvJVqNW35fy69k6daut6TxsiudnNbx9LnMd13Z/zcYDAaDwWAw+Lug6xhdz9xrHtntSYx1kL4rZadMXasS787Wgu8Bb0Fej+ew7js9R1Khsz+cAOl27K+xFtY7PPcW9HmCtyBvFo8kTu4xG+e0iD0636VQ7lbjFQGedZ+jPLTHIDwmq/y/6jNLq3kTQ6m4GC8X+TSWoxxyxylpPbX+Ki98zo5ekF3LUblO0J0xcY5HuQiNpXc+w7l75ZXhCzxGqvXz843OwVb+n3KyMr1u2d5sb//Yjdinx3yxbbZvm7YCJ+JxYuyt7aLTi8vucp1gZX/s6mVmsf8Vj+g2CjAHqGx6kp9zQd5fsryrGLDuD9J4N7HW7LejKu5VfY3urVKuJfMZK724v0OuE6z8v9tf5wm32p9+SVz9UfbXfrFrf/wGeanPI1+3/2pvB35EeVXlD8CuXqr6nmA1/6OecIy6B+UW+2u57odvtT86pBzVy679yUPHDrW57nfZyQd/rvyfy+s+P9NLds/lOkG2/vN9RTq3yM5fq24cK3vR/nX/wz3sr/O/6txyoLOb93HNk77Ms10+Pv/LZNF9GCu9+PzP5Rp8TLyF9eLg9TD2/7sx/P5gMBgM7oVs/beKZYC39K75jmc6ha7XuvG2ip2eYFfX9ywzy0/jP6u9kQFdl74FXDn7UIH41+5+zVuwo2tP/wj7V/lp7EdjFX7GKeMIHcQtPJ4Od6a8Lv2PM3HMfZUP455/J3aqdfB3JFaxkqxuGpPRduHyKLJysrrC/7iuNY7vMqm9iFM7V7iLyv9rjF/PS9HPlPOtOEIvB93BnWj56EXP1aAflyeLOep3P39LO9J4OvJ4G/C6BTyW7HxAtg/bY7PEz72uFYen+Vb64HnixhUHu2N/9/9A25aOUx53zThCBxyV8nGuw+7/XfujFz2P6TIH9GyPQtNlNlZ9Zfb3uYieravyUv0ot9jpw8vh3glW/t9lyvZaVByh64Q03fsf72F/ZKKtZTIH3pL9K27xWfbP5n/4QvWXuo8Cn1RxhK5T/H/X/wO7/g7flOk8m8Pv+H+tWybPPfx/Zv+OW3yG//cP9fdzsHruUOcpGUfo5ejZwap9e1rXhc4zq7OZbjfFav4XcPtX87/Od2bldPbvuEW/d8/531vHvdc7g/eFsf9gbD8YDAaDwWAwGAwGg8FgMBgMBoPBYPD34RF70dn79JHBfhP/rPa9s8fS32kRYG9M9nmEPnVvqcPfaVxxiexL83x9/wjvANIP+zeeyVN2dTnNR/ft8ansr79jwr4j9tnpPrcsz2pv8K3yd3v11Yb6HhCH1hvdsodM+wT5PattV+jq8sgydV+k9o2s/zjYr5bl6Z9qb54/u9obsmt/3stE+vjf37Gh9n9tvIb9/XcH1D70ww7sI66gfanbyxbX9bdFOqzsT9uhTzs8/6z/c538eZeb7qHUfZsB2pu+a4l9fvqM7rHVfLVNkobvJzgZQ1QX/q6hrG8rqFtXnvqCzPaMvfiGVZnkqe/vUZn1/XIn9ve97lznf60n55J0nFRZuM939IrMei5E86U9qNxXfNPJfnE9X6G+AHmqvk273PHn2dkBzcf3lq/kx49r/gF0p+9iUz0y5vt8pdKxz3m0TtpffU+v7mXX+ZTmkb3bj/bg/fB0TOCcUzafcWBD/+3Mahxm/bQzliPL6dywsz961TEL/+ntSO2v/l33mpPnif31XCLtV8vM3l3l86zK/vxPO74yJ0C+7ONAfnRHG878Orqr/Krne+XddYHK/uo3AW0xixXomVFd31BXnR9W5xsy+1OujuV6Xc+lep/Scx+d/ZHJ29cz0MVdducWke6q3N14d9Ke9N062pc+2nmKwWDwofEPiCRqoj90VfkAAAq1bWtCVPrOyv4Af69+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4nO2djZHbOAxGU0gaSSEpJI2kkBSSRlJIbpCbd/PuC0jJWa8d23gzntXqh6QIEqIAkPr5cxiGYRiGYRiGYRiGYXhJvn///tvvx48f/x27J1WOe5fh2fnw4cNvv69fv/6q99q+Z/1XOaoMw/uBvM/i9vCW/rm7to7Vbyd/rkdXDXs+fvzY1tVK/u7/bH/69OnX32/fvv388uXLf/qi9he1r/IpKi/O5RjnkU79XK7az7Hab/mTdp1baVpf1bFhz0rOnf4vOvl//vz51zb1T/8tuZQMkDkyYj/nVP7IFJnX/mwX9GvOJT+3E9oC5Rv27ORfMvL4r+jkzzHkQn+1DJFztRX3WeTHNeA+vjqGPgDKYz0x7NnJ/6z+T/l37wzoeeRef6stINfatiz9zFjJ33oA6PuVnnXD0HNN+SPXklVd6z5IX/eYwHn4WZLHdroh24n1jOVfbcRpDP9SdeL+c7QfXc1YnG0fp19n+ylZWd4pD/pt5l3XeSyXsqxt2iB6hjHJ6pphGIZhGIZheEUYx9+TR7DXp//zby/vWfLd+h5c6mu6NvWueITL6O1qB8/mZ0id8Jb2vruW9/Od/M/Y8Y98hnme93W+xC69lfz/hv7zFlz+9LNhz8Omjk0m/Xfp28MX5GvpI53PkPokP85d+QNN52+kjFyP/ci+LNsv7d/apZfytx/iUdtAyt9+Nh9zPyl9ic4suSAbbL7s55z0C9hnWCAj7HYF51HntA+T9me3HdoM90KemRby7uzZmV7K33X0qOOBrv8DdWi94L5tP459e12M0C5+yH3Qdl/3/0o763jnb8xnSvbr9Fldkt6z639AtukDLuyrKZnhb3F/Q5b8v5M/fd8+QMf7WJ/Azt+Y8ict/ADk08n/KL1XkT/P9vqbsrG8i/TF2xfn+t7pBvSJ2wm6xboYdv7GlL/P6+RPnMqZ9FL+nNf5w/527FtLP1tBfaU/Lf139u3ltdRt0dWR/X08R8hj5UuElb8xfYi8p3Xl8XjmTHreph4eVf7DMAzDMAzDUGNb7Jv8PD6/Z1w99oAZY78ftn3xs02+iwu9FX/D/MNnZ2fT6vzg1gnoDseE59zA9C1CXuvza19nP8zyoK9GP5yjs6sg/5Xd13YwfHzYjtAb2H89x6dIv1DG7ttn53Pst+Mvx2gf2JHxSQ3HdP3cfhfXe5Hy5/puXqd9gbbvWub4D7p5RJ7rl/PP7LfzNeiI6f/nWMl/pf9XdvD0padPHRsp7SL7sWMwzhzLdlngk9jFCwz/51ry73x+4LlfJS/PBSzO9H9wXIDLybl5zrDnWvIv0MnpOy94hhfW4c5z9fxf6Qa3OT//HatQzNyvNd27XO1bveN5fN7ZAhjD5/XEjTid1M/d+J9nAOT7v8vKsUx75D8MwzAMwzAM5xhf4GszvsDnhj60kuP4Ap8b29zGF/h65BqryfgCX4Od/McX+PxcU/7jC3w8rin/YnyBj8XK5ze+wGEYhmEYhmF4bi61lXTrhhxhfxI/bMT3XkPjld8RdmutrNi9I67g/dx+ZfuQ7in/tDM8M17XB9sbtrnCa/CsZGz5Y3/BJrdqSyubnOVvfyJl8vo8LuPKnmCbwepeKDN6zPLP9uh1Cp/BpmzbKza7+t92tO6bPJmG1xDDr4cNvms3Xf8vbNNjG1tg/U/a9vnQbn291+fymoSr7wuRR8rf646xBprXxHp0kBG4Xnbf5DIpfz87V23GcvU1nfwdb+Rj9h+zn/5Jeuw/+r6Yj5FP7vd6ePeMe7km2Mch+4VluXou/qn8u/2d/NMX1MUi0a/R7aR/9A253TH8FNbz5MHxR2fX/+17K9KPA7eSf9cebPt3PAH9PX1H3b3s2kbGqJBe+ikf9Z2Btux6SR1w5Ee/lfwLr+NL7ACs1pzOe8172cnfZcjvC/uaR5V/kTEy6cfbra/Pca+nmWl1bWYXl5M+vy6/1f7dfayuzevynK5+nmHsPwzDMAzDMAywmlt1tL+bK/A3+FN2cazD7+zm1q32ec6F5wodvT/egpF/j30YtqHlnBpY+ed37cW2kdp2zD/f5bDfqfD3RPD/gY/5WtuT8C1xL5Y/37PxPb/qPBHLzH62jJuHI/3f2eat/9nmuz6209lGa/+M2yJx/vh6sAFyrb9R6G8JOcbEcqYs+IjuraduzVlbOxztp2/mOgEpf0APuC1g16ct2DeL/Ch7zhux36+bU9Ltp936u0CvwrXl3/WfS+TvOR/o7vzWoL/JuJN/Pg86n27BM+kV5wpfW/9fKn/rbXSwY23sw0M+5HGk/1P+tI1Mk/gQxwg8sj/nEjxuoo/Rr24h/8I+Pffn3TzyvDbHfzv548er9HP89+j+3GEYhmEYhmEYhnvgeMuMmVzFf96K3fvqcB1457Y/MNeLvBcj/zWe3+D4eubH0Y+Zg2O/XaazsqF4Dl766myH8ryglQ/QxygT12b5sf86fh+fpsvT2aNeAWygaQ/Fbuc1Gjmvs6kXnlfHz363XDsU2z92/m6Ol+279ueSNmXMcqXf0f2/81ViU352+af+o16591UMTzdPKOl8Oyv5U8/pR/T8NHw/2GbtH7T/0Pe2Kj/Hco6X91d+zzLPb8VO/pbZn8p/pf9T/jn/135kjmGr55jn8u7Wh9zJ320USIs29uxtwFj/W//dSv6F/ZB+znMu4xLaA3mc0f+QbYM02bZP3O3vFXxCHv+tZPye8vf4L+f42QeY/sFiNf7byb/Ief7d+O9V5D8MwzAMwzAMwzAMwzAMwzAMwzAMwzC8LsRQFpd+DwQf/irWzjFAR1zin7/k3EvK8N4Q33JLWP+YtXMyf+KxKN+l8ue6jkrr7LcWujiUjownPuKSWEDilrwOzlGs+1H9GmKj4Npx9I6d8nd4iQvsYvcpk7/r7rhfykt8lY+Rds4XIN7cMeeO1U28NhBrCGWfZS0yx5vv+jX5nzmX8x0/S16ORbqkfok58s+xUe+xrlmu10a5OJbrfxEPTj/lfjs6PUo8l+/b3/6hLex0APG6xJJ5TkHeG8fpZ7v+Q/6OCVzh+0794ljKS+qXcykn6V5L/2dcfuLnMn2bNu191LO/t+HvKbke3G5dT7v7ct4dXhvM97Nqh36GIrfuex9w5rni+TI5d4A2lBzVL9AuHJ96LXbtOvsr/cf/o/OyTXveV5ce/Y/7Slm5r1r3rcrqtaJgJbeMDe3SpGw5j4W8EueV7Z62mRzVr88jT89VeivowVX/Pzvu/RP5c47n3GSafh528eBOt5uHRJ3nNyouWeerGyt2OtN5ZTv0+DjLfaZ+6f/dfIW3sivDkd6FTv45f6Pg3cB9lXtCxp4jdAav6ZjXeO6Q49Wtc49Yyb9rr4xTrB9W7Zv8L9Xnu3VKPW/qDEf9v/A8i9W7TCf/o7LzTKzyOg/kRF2yNtxqrGadmfJnTJjrBHqdL68r2L1be46Z3x26cvDdQ/RNrlnXcaZ+4ehbuxx7j3mLvKOu8s15GgljBch6Qb+n3vS79JHeO9Pud++Eq7GAxzmXrBN6yXN6V7+U+0iunPPs81aHYXgz/wCggvogrdejwgAAKhdta0JU+s7K/gB/1PAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHic7X0ruOwo1vaSSCwSicQikUgkFhmJxCIjkVgkEhmJjYyMjI0smX9R+5zunp7p+dT/1Ihac+k+VXvXCbAu77suVObnfTaeANqzkS3G10Zgh6PDAnBdxQVrAN+FfsPzYh3ggQoQAbYKG9CeJMF33ZPZsYTB8c18c/zxQ28AlZvdQSvVcTO2vmxPFRTgeJ1A4SjpMPBhua8rP/cJEqDcVCykX40DrzeBuHNcndvez5heQmwxKfxDEfOV0g8PK9Rr2yjuRnlOIjj1lmRQQ8xfORbI0j5PBjAmbKs0uI9JbSv+7utukHfu20cXj3LFsPiNmeABPFGqg3EJD9EUCSuvl7KFSJN9DPqhrsFlobcdf3GPua5+foJbKS6jNWODiTYs1vq4xcDBgm0Onh0EdU+g+O+oOXBc+NP9PC8bDy8/vPy3uE7EOhKek03CmwVwKbYVIBX2xJwtHNUeMnDAJw+HdUtxYAK+tM1ft+Da5sAf1S+4mfs2/DQdPH4AhQu0Hjc3U+obgcfhTt3VQlHX4dbt8+unqJR1TeD3e4+O+zXIJS5Cpk7JigsYazoYCWubTsC8bYE52A/85wIqp3WBVcV8MqiG2SU70e8RgZurHbhdRuFh15IpzwuqUkUlSFdjME1nA8Y+u/gpL3RpaJNmmPXVCdG4WIY+ysocqBLLRcvF8uMpFZbUPA8s6Tb2czTF4cB/1jWbeuBi8D+kokof8OD2XBs8GU8cTSVPIyg35DbgOqcWPQmdqur904sHWUGj98KDSA22qwiQTKBzNpvOA02DWOrI+UJjWJ0mx5hKvRN0BGW7Lsr2EvyozwkzLhhqZSiUzz/UPD+dLTHpJHCdTwE9AP1/eBQaEowL/9r9CR9dPEp0wqG3VmebmmB8SSw85LiVfeBG8w5Ral3QbyVbUGHR/QGINv0YWBJZv8084ReqPxCoWW9oAIBGnhf8MDY34YGtHzZKRvGXR1vwhQV3dimazzc/LBzkQHeOCo0Gbk3gx6bdE23MBcprPj/16MlM2mrvD7MVPYDdD9old4NaiGl6RlR4BoEQ9IQkEYGva1D2OJtFt5Bt8vgJakFPmfHU1/regKueHD5+/pKG5dzg2IaRugbpQjn6teIJhgvWpAI4Va2rSxwOQ8N2tGpi6w9MC+jl50O8Au+Aea8FoQvnHo07pG0XagtQLtQFIJf44+9Ea/EVwup3/qFV/0XCwoAz9NyowZSRlZI4eOtVwIVKyvy5cxKPoxKJnlyEswgO6Mmfjis7Bn0HBHOtGEYQ4x1RKB5LSa3u96ZY3ZuExqgKuTELy/r+K0uP+qjoZFiMH107SsSjju9jCIh4JJ2nRNHXt94PEJ6iE1hgadceIOyo69EQQGzMj/tybrBtJIGoxl7XOc6E73pCR8+eoFE9FcZuZhDka4RE6vasZTsKPKj9+BZh0/w+LLXiop6basbva4cwQp9bcCj14iS/HQC6h8egkdv2zHD9NAxuyxnLcWCUWMaT+Qn6ds+19ugY2S549UhujPuNb3KfSr6AzzWs8cHg/0jgHHWpifHq64eXjwtm4KcWDO3X12HsGJWGiVtaFxk6PjzHTUBKoznzAv0CrOIk03FdFQGhAH09SIUWDGsE0P4zxsoYuuOv+emyunS/UZM9f4IBLAk3xscGtd+7/ezq53MNxD6Q46Iz+Lbv3tw2W6bRZ5WolwxSTI3Yjaqo+RGtPxe3KAyNJnfdLjdDI35CewiCXa/TCtfil1XUVwKyDDeZ0jF/amt+gmWUY0e7v3IWy8f5H9DjRNguGxI99MtLtNzu6wjFQN1X3cexTRID+zDlgJAD4/vt6OS8MM5cBtryeH+Q8652z3HfTlqiCz4jBMYNg4SM4EJFlwmZpSmVgromedhBfXTlP0L76gtZ7G0owldJcOGBybHygPELuHy9Mpcr6P3gXDK39iDt3imQbNw4t9Z0bBgFHMFAWi5CvYCj7xgElWXxhYuNg1JT3/SBxoNtPmSYSYHp/mz+9PInTg1hhmTEokczuSWNhrwjqyk/6LzPJAUBcx8c3wkDXzU9E7LtWRzHQlIjLWsicUdQLdBlEv4i52atwQjC4SXWqS3PkzMeN+rQ5MzIONRNOZkZgc+KGYosG6zo5F8qbjtIgsH6xkUWQsaxhh3WY2y/fvjO7rHnDcudW4OOL3Nhn2e4SRUXRQgy5Sx6A9Ix2hd0gRs6kmtMxtPnzsEGoc3tHMiZCA/lo4tHKeYc1HsSN8pv8MvFbmSo+KTot/DhlXtAcvVQmD4QxmvCd4xr172+oQsjuA9rWBdmeZES1kXH95rIQanNQsI5wnVNELDb3jRQPblfBNNskpDGZ1ePrtiH3U6VFNUjll9umYdH76RwA3ALLFqFHhL/VXWbNsiT98NWppvTsLjlMEVLkTcqfLf9GF2ve538NzVGXOnUtrv6elHYFaB6IeGCxwcJdRVIgD7u//OmdXCastr29VTZo7tvM1ApiPi0W+Be1Tbj1trz42AgLZpkJhLhKj22JcTAymZZkjy/XpKD2LdgXzadqN/IfGgduMzrBTPYoT6AhDIgGVC6EPpx/9c3BxXPjrML/dUO/CxOc75qu0aZPUK1ivxgC6jtgbOVQ6fy9gRpjlWSKQFS6ZCPQEzF3wbSroSL/4kdArfHp21iPDITRkiTUnGwshzDuUa9HuXj+PdYHLppjeSOsvVPbaxHQf3dELf00n06tioavssTdQzEZgXYOh1AyqtSSJkuA/LZ74qwNsLxvLHDNo5qkOUBp2PmR09wTy0NEPqtNh1IF9L9+tzKf0udyUrm21XAzuwWOrpKx4O+nYr9yXY8Z3qO44zoBPEg8f8IMUYqcW2ZLTuTDUnyjRQANw0/A94e4k/sKFlyDdlkZccKz8lGBsoXDeWZCdL60aX/lnLF2EiWEB/LwWHsx8fboeilPhjGEAAsoZW4rzP/ixtE7FoIi7lF8crGrgHScXHw7Ng3cBuBP7iDyIzeS6wGkPfFJQ7IpySBOw/ivD8e/VGschiNNrNwUAM3YLxhmYa46V49hAeE/clS57ZfF4b1mbMpbaOExz7ARDMjHsKjDLxfJw3nSf7CHcmtdQ/Ni0PByi1SjW4QZeOvhLOyz/Mfc3OVwO5Mz8w8yK0vE7XgG1IpfEx0XzG76fLBPHX1fUUKRMh6bMLxJBRI0xEOK+9OCB1fFTLsv3MHYwHbry3yckiRVi6gGbOliPQa/87U1o8ngJHvjJmFKH0L4G8Jsu06Xeisp9s2p0ZobHexhrxAjNJ6xns2ulBfmT8MAbYNResb0t0Y0GizovbfuaODw3ai5kurDC/7QukiTdL+smg7wNfx8foX5wTQsaFvv+spZ1ICbSDDJKw1vywglEWDePwoP6o6E7ZnwFXrtYUXRrw0npnqwCAJ6OAWCPO137nDRTSMgQYhlrNxPxBs5JgHkPVBrvUOiJ8WWXa07nM6bVIeqihHB/+wWt952kdxhCt3MBEpTnr79ufhdYhZ9C3FJpWnj+jAIqJZEAk9J0mG/c4dgzjwt+gYe7uZbYgbTC9+hLmPGYPCIf6Px/v/LuNC767g2NHMQT2onvjnvLFZmcsMfHoE9PA6ZokbI8Ksf29ouTJYaoH4x7xJfDHW2GkzE0EofPmndhBmMcUDE6XWDU5LgIiaTMDNqxraLp/r0+s/0nLZXcNxQlOgXiNvFvL+LmyAJQR6AuLigYsNr8T3WdLjfmmI5JSDUK4AiHEQHut1JjcohAUc+VU7QgKhkmwgekbreNeOBrOBootNm/fL8gssfFBmDFb11qD2a4KRJ5tOuvRizJQvoSRFTpW5qgpIA0HXad77UQs9gnUtHy9U5lFBRDmTo6jSZ9XsV+3w4CVZWu+uXICf2mHUpaTjNZBPrWpyqA/L0fGp+HUiOePWQth6cIPMrNZ2bKWtbD0LgxCPHhXJuFns6Md5nxXcvjV0A/2FptIRC9dtRYOBep4r/Kod700bsb6LPqhMv2vHPYtycgw0jQP57Oqn/BQvZ/0PmkXAchL+wH5QhhimbkLfW6CuXGdbFXuhq4eSZxqj41nbA3ZSn1cnG4aHCntGZbBtMe/eAYx7CwLdd74HA0z/1TuQHTeoJiSR5/54+mPa+MPQMJ8LgY6ebt32ifPtJhH62nXFQDVzQ+gUQ9WxbZzxHzhIGIPjZWbx77nGdAySzjxQSlr/9I6wQIOP75D5yNz/6B2huxY0nUt8ro8jYA4XfRdhn2sRUk7i/6Anl35JVSHCa/JXAYCBTIybWtf1RJgETkuVwaUF98yhVeMGDKOcz8T3/d07tJpnzBLvTH5hKF3lr94hQmp26CjRZvLH9R+jv7n0XLfzQuUFfZJBdUj3UqGkoBEGzgIA1Wfr95juGk0f7guoPDeHDE+LtzrI7cpb9202de129o7dxzszjua1Pcj87ncd6ad3jG4e6Puv//j6j5cEpKQzcEv+zk2ipLalg6ire/MuAHQLriKhA/NudJoaPxPg641kafGwYsxDNrPzPbDKRQmzGaAerR7VDoUsgKUb0a5PyAqynPUwuWj+dofLRxePkjsePbrv9U1WJaUT9vebyqqIcvynAMDkwjSdSBgNHThy5NnUBkvsjYDJeLrtQRz0OsoyDdoRZcAuqawB192fME48Z53r5IP4mSeIpsruzTaj6YclwcNHzDHW1rdtfe6hXmqubu3SvdNT/TAMQ3oBi8ftTFiGM/2cyFWD9oRNO14F4v5eFX5YY7C9joABYQEa6HYDR0gFdSLh5w0xivNrTtdL/VSCPyyI2edygz3u3I6GWH02Q0IQVzbbuwCQRt8XqFzuM5ZtezQhXTn/4but19xKNG7pFNgTNUrTc4R3gtxeDKpEn/doqA+CjfSMevaCu7aj3/04/5XgHFDrlF2Xep0X8PO6MbYbeKXifhcA/LVKOCNjviWBz74TrrdjRntk85cb3d8DHbq9bx33iEB3xTCJUXNQr+O5EppfFcyBziA/CDN5QjLEkHt8vv8FNbOnuId9yz54e3EoYb+y29GCYaE/BYCO0P5RkyXyp8xswaz2NPSCpM+CeG1XSdeGgEftr6ZD6BrS9OwxEuoSkgjbEmvXUdb9jDNpSmgb3CzH/4D64/qJGku6mlKI98XE8KIVxMLI9shPAWD6yOeFyrK7ho88IfONWxCeuE532fS2YcTc+LaiWoCOwHiJXFJ0dpoB0l5aSu3dYVwoAcoeyFqZUEWWj+v/7iAxipreowWhaI7g953seQYw91MAkEwhyHkOzVEDUA/MnhDtI1JA07EmNK9hnzkQAicyyQGexIvgtkkVrEXHOFjJ+Ely1cQKNKgTlip5nv1iH89/i8u80xovI4kNeLDd0dw7xjJSfhcAqosB9eIZ1uFPN8/tomjvk9WYVY7zXginawT0DbuapeOnKOS+oCyliJ8yGIf81ynPQwf3OijZkDuXHFEzPr3+NOEp+iWI+dRiNu4XQjgB/VygFB+zAHC19ZrJ7KtlPOq67VPpuRCQgtjs2ivTanPwxHCMhLgI3yU8Jhl0ezM/jKMIrHxOBilwNxFimdQCf+7j6T/UYaRp5EQTtVdsCH+SFgGhvfCIWJefAsBa2j47dfidKaRrbwMpI1fhyM1Tmm6uY1K9ePSUe1vAc1h2MaSsOTWJEV+sGqwwS+kY9cEYihG21Zk32j6eAFRwoTWHi7jZtKRsGjOlU/wi2J3qTO69iFiQ6oXnnatb4TVt9qH4Dgy6v1EAPSJ1ffaRxnDPmCp4jWL21Ym67uOX4yNpTSuz+UC7WiGQCf63z65+auDSWZTdrBUYkaG00iQePzWKlaBtBnTqdYhdIIcljkCO992FOg40aDjbg7iYobt0dewXM8A7+grOkU+kMUEvcou/BL6ZBQobxhHPUio1wMf7/8vsadwmaiMEWR4yOrokWggoYa1k5kDfPid6Cp4UBoTXTBCsr7Os2wIX64e2qb02WpDRwDh8YBvGNt0iAuWMWAEx31+AD3oFJxAN7kYtqfe70Y/7P7D6WF4C8gtBOj8xCKIHO9jMaC9LGJ5WQif1Bwz8dk9uEh8ZzwRGU/KCvMkM9QbGpOqw78zeUXs9a2g3mcAXTeWvwHdYUflw/Fx2782Tzk8v/7Yuxfba8bkK9I1OM7fNSEtS8MlsikuWIptxHQ/ylB6JXlfcBLNogbwxd3T5HuOgC2hABwKnrNEz8GUSHzb+TnyWkhe2wamLSTt57o/zPx8DOHRbBoNb6SGRC/qltSQsH86uTK23ZZYijwV6puUlSd6GQepr3MwXEVLkbCEzdfo44NqBeRPf6z8TX55Xxem9KYNBYkPS9en1T/khcnq/hGGipDVTsc1u1pejs4gRI8IUPP00M3mP3DYiqhWg0lL96tH034NDgYJRBOW/Jj64W4+8IwpCAEjNx73fe3ahZeAF12tPw9dUyWxxKI9VSAPwzbVojw8Mu92UOBC6LEB0sLX2yMPVgkzbe3AItBmV/B+JL9gqy0wijRRkX3kMH+9/n2ssNO4LR8yW/dFiRD4swc8ub2sSIv1EO4Z8N5ZbLhUctUTWQ+0XQZyfEeQjiWnH5uls//yvic+foUnWrNAW8gji894fRL9xvV0r3hhlRQmV8pZfqy0toJmDpgvasGOpHJuz6OeAXvi/pUz0EphxsTF+EesQQ5DfQ5P/lPieQ5M5oY4IZ06NEeTz/f/7GpP1SMgEOEIWa2jq56tKwY4jWqQtYPpWgW+nmU3LYSA5chgRFyQAE+7VuhQDWi28aPNraPIfCh8/Q5Mktwn7XpbxdMSP9785ZCiROBZQ3YVd2raao9d3WxKiAXdsGOnPO7WMZJXUbpfXhvRvzkur6I1k+QxIGqbehChE+q+Fr5+hSW78ScwgTe/j/F8oAPmBvA4Z8Bqckhju8DUpNhJIL/b1zFnNMYe4ILFRUuaMax8sbsvW+1hIva0GyonwDpGDyss/FD7/GJpkZpMEAecmNrN//Py9XkV/FUqWbYsSFKrpdN7Ie6VDl7WbvcxDrAJjYL3u2TDKhXYeNR3Dwng85IPzXDlZArfd/2Ph+9fQ5H0x2jA2Ite0IdaP85/rOepkbDonlgz7MUgiwTxITrYCJl0LxDXP9o82tjnHIRZJ7TE7IpDJHvjuWXhBz9dLLZd59X9tfGh/H5oMZBwNoiJd8M/X/9vruQhVuS5ha6tnYmJ3MjSsjab9mIPAai25IFEOqszCAE9kli3WBNbBOk6KFAlkR6eXy6VN2f6l8eX496FJCVb4Rz2zV/h/IQFyNumbd9FIM/OxGLsW+9JwIvEd19uLFwwBuaGCoyNnNip4pTkf8K6E72t7SJCuPFeQqPYI7dxCFlHfjU/nvw9NVgQR+YV7S2j1n148zEZ/FYlXDR085LVMwIbH/Tp3JHywb1mAnC1RXTwTyqvN2iHhIeWeufvwRs8ecUAQfTNmoVL4JR27mI1vFcS/D02Oo9AGcq9E9fLx/g8ry0587FnNWfyZjjb9ahuXcgMx0TEVazT4+mknWMkZ/GaDXDrcZa7evPcg3H65UDma5dIx7d+Nj7MK9h+GJjeOOFGhYXBl9cfx74bo9og1IDlvc6ZN2nmXCfVLBC3R23WKpHUWOebcB0JkeDdIh1aZvtbYJqZfD6ivnSFD8qNsARhnTA4g/zA0ibF/t3lT9wKlfXz+cdmz3mvQ8OwB2frMYq5zOgFmuicv0PyCwA4d47yzQCH+XSW5g9x6I9c9xEqkc8dgM5d/VyBlejyNUElH8g9Dk4Ku+zCoQOg07cf7vwsD1d4e+zW4AjVntZV4/2OO7VS/R/Tc+1UZ9COvUtQbQ0PGP3RkeMcc9Ib4TGCMxoE4p/Xr6WRnc1TiPw9NNn0sDAJfnZqTIB+WXIJr2awE3viebHTOhGyvc6CLOm0iMtfjNbdiAWVcXQhc8gzLm9zke3hh30xvuYtR039sUHdLN43s6T8PTe6liQBeYSzVH1/+bGIo1MAxhz/xv+uDBu3zDs8zkx2E3YxeN6Lb9jrwEIXL3oPDw166dXOsz5pxQrk4KsGN6GiAR3iMH7BZ/g9Dk201AoNNfu17Ux9nwDlu6JFSWJYdQ31b+auLF59oB0/OdEOblzEjVzPoByqa+zo7vSZfGIdHFNvbgrQmnEh8id3Q4MHoNYJMkYn/PDTJg+/yXGIFpvvH+7+GEZdEP11mTXtWNiqCU+Q8h5vZ22WZjTAsoCGr2A1BtMvYvrzn9oXkofaMS7gIn22knG2dwcbfjcNyi529T/dvQ5OtpJr8vDKJCggf93/W4SODw3AnJLRGkMu/QCHSezCeF1aEEaZZV6nYwm9lrSypiieqi0gnur/3YOdy/THO4troFYMjms2/D01SU5Ya3RATWbqP33+SWkId0GjEfJZ4srdI80ANNttZemlXH2yEd1ETwQwRHOF9gnlxDxdz4K3ssyFgq7Mffnkjoi1PGN0L1ZGq9rehSaJYlfeQbdbLERR/vP4H8ajMec/xgdH1n3zv/Cowb0CigRtd25OJXihgUA8RynHtq8KDdratZWa3AenPdu4nmk9BPUKA+x6Mg92CcOTvQ5NKIwq8qBAM1p6ej6f/cZXmNbENUtHD7he6gOuBd1Ym7YUpDNSpg9luQHBv743nsl3dzHszrHa2Ogv6DhjH+rWG3sNZkejNZiphV+/SX4cmJwpKazBupYmir0S4eOiP+38LlFwvSJPczMlEDOF1A85xD1qWXNqMRyvllbVYC3/sWqVUPnonETf5UYeBcRGbhLmOvrnJjO0CI0viUi7yL0OTuwdW1txnx1HXyKyo5enj8x9cC+IQ7GC4tz9k3NsXMXmzlOV1Tds2xrU4WlhdOMP4XnCFqndR6xZFvucNJgjvjIetMRZmchNSmgPBS2n78efQJBBHpBbOE9Pw1N2cnY/bxwHQlRgejK/waDMngcCuwviUt5MGx3u8HBQBsZoeHjs71n5GoPZL7jM30GuaFJbMdTwIcPa1ZMqO5eiIK0OofxmapAiZDI1S4Q+R9016ucaP5783GyluANKACKnmBPbUIGxFAw5HHRt5zWy9hzoSzJH/SY3e7ZJvH7FC7DxBXI6Mmlw2j2Tw6P1GpuBxH+DPocmFUYlb4rUxPGuo7t1Owz7e/5dTJXzrgs7Qle9zAVR1xmxlwfWSYppBfUG46+btFp7NtP4x4/0bMMBBex/JS/mTypgbFNO6vHRq0Qfyx9BkFkxJPXKeCREPolBSZ/P7x/NfTGK4UrOj6Q3FnusQbD+r4pCUnikhsNZbq4lGwuYIb9bnC3dpJgJrXpRDVih0QHD8VzLT97IO83to0niBSJdHUm6yBM2JjGURBENi+ngF1ImwgarpNkfBs6n3HZGsjVGF1mQyN1zM2KtknFORG8k9XLtGAqdmKrww6ZEdA9ujANwOT1ADkPrHNShyhFrfmRN4UZEQWhY+CKV+R6BBZR5OLfXj+f9qWfTcN5fSvm47+m4/07kiULeveNJ9Foe3lRoWEB0v4E7k9hgA3lc63YomtJfXvobZOngiDOqtpdGDEDuGxFLnFO2OlLkXDIGuY+SbhdGZ9bHx3BX9/P0XRWxtR8KnYT2PCxdoCPIWwqhCR1/mdYWz11luWuyrrUZZcyD0Vem1IhV6TRsmyzrL3UduuAHPde0u9URYiRqDyTVYbhQcmsGh9gKbO959ttSrJVhPP71+Mib53dgc7rgHRnJqaqIRGKIdhTiImwt5QcrG5BcqsVcQCRGhsxOJgKnSEEmQ0hGY9wSTOS+5p3WCYin1gVqzbBg66wxz4bwOuSA4sgg1wMBK9Zo+fv9ptIGcgZDQ85hJPJBrne0OwrYNiNmk416iU9d4mluL6Aey1nMOgK1HRBe44RbA4yiGACuJlyJFo7mzSG7WhkFfm+FcRrALWvm92Rkl0swbi5LE0j/e/zRgtQSsrHed1x5fe9k3oRwcErkQIvTdMKtZ7QbxrkCTZn2YpbbJ/+fFUEVqr23I2nY671HIHh2IvwTv0t5yTr6vW3fM9J164Cr2sYo1HAiLYz+iah+f/+UYlKyUZp03tbWXP0tf0RpQndEnLCBzWihvVA18kerDk1wtJerolJL7aISS7HmDwfjF88pcCWNLLxcJy6dZR9S72pD+ho0S0XomYyIMKscoLN/Rf9z/t3ntRZ9xKJp5B5hb9byyHHFg5WGgN1jEvN3gfhD/wf6kvlKupdAv5sl7aJJohfHMIqZn+MMaET13CJiO992g+9WXiIqEP/rT6f/MtpF1Ek4daHvcZxcP8/o/dHGqnoht7SzlonWiW/dZwvPab3T/BqEr9IAUIatoZtrnLjJd7N25P4cmlZx3QeFSiLS+RsPEvuu2vhFVZa2Cqwcl/Z1kz8tsAhuzafiBi9r+cf6XTXMm5zaZWJt3Fi0mzh4WWe2+hTMopa2ZRzmRrHtj14HM1qzHvw9N5t07o6Kt6Rx23vD6gG6BIpfOCAHtYrUduSkEvTyD177N3PGHZV/wMbYVHfyccOjo9+d996sxMfTdRiOR31lYg4FwFaRxFBpdl9xzjn8fmixbwiUqJhyhBrFAgx1EvGbzw9K5QYfZmWZzlAy9yyyog94+v/4zWc8c1JUXCDvnOiNoRUys151bAVJPZIvKEV5H6ZpBjcupZt9+WSH9y9DkReXqGPEIbhe3DvT8MK9+xeAvq0EO3fKBCpZL5W33ggGxED5e/91XWaJxhiK1ARITpeI8GAjRhkaKss7rKmMHub06Gnjbd4R8pM2ed62XJf1laFJnsOXY+gHm3OZkvznntPzMlarLw3aeM8B2DURnmY1o5z4+P//yM+mJaJ9ZRGuQZ0PjKAPKuRDCg6rUlY3011PJAbeGrNScfOgNETJRwfw5NKko8b0/T0cUlVEzNIUNZutjY7O2UG9wA1SAWWGDllcooz4fx/9ArXTjWDSIYPBMR6bZnnCVCIvJhONh7+OaxbBsHlykWzmCY/syNvPiVQ5/DE02Ziy6ivK8ywAnmxekEYUGnkPQ1vE0+Gk8RPduBLLvoSP4ePyX0LMNSHo1574PW6oKsl+pz8G36Bu0UXScwW2Jdk7LQ1/M8WCgh3jo0fzifg1NYggNcwAW1xRQRXi7hsfYhzviwPdjV8EXjCpuXAKY1j+Z/4/Xv3aDOk8I9bEzQGa+H4PC0lLPJsZl2/L18x0V78dtBZZbbdmcQweEh+o1Zhco/AxN1uTW2U5pA7+OWVjQeNCoE6Xm1T2nNAp5xEgYT5E85J4wfJqP538cEzP0pcwQCMxb//ZCCTp/ZDGRIlrZTyQrS3j3acySPe9zmOVKuP6A1GemiMgMBX7faVtSeieGGLyaB8ZHFZ4jr3aRl33aPqU/V35wH69zz6A/nv9rs95B99dLw3LFtcTFzmtAlknwfD5eePBzuD/9XNXwYCxEG+jk9cySAamMsI77Na8H6Z1XAxeP2/zJXqMT6PjndwuARNMZtU0HiOEW+FhmXzg8JXweABM4X+yZiXASUPMxhoXj7oRX/sBsbd+DmJOKZj80nv28uzq98syBD5Nfo9SUdiD7jx37TeA7a546cM3Wf7IfDuIcjV/W+eFzatiOcXddJEaHo30c/6IVu3mrDdfX+yxiGCfV6LBOh87+PdRvufbW9NQwLAr1qMf/urvifpbGTYseg8T7ClmVUrSJpTTiNishj5R9QH51h2qwY3SdQ9T64PVQLsVZKP14/9eOj6C913q1PzcSMMZXWEbco75vGwOMG723r4szeg6LgYqAMAh/sBauEMFjOKhSo+pHsaJnH5sw4PYTDAKmVJdV6xr48oS9uwSLnXetIi80s97Wj4/3v77uQ75RYFsFe0+zkwS6Y8hur12VA7YrlXvbe63nvN7VzgtOESGBM5WBPK7ex1btgux5eOksIUMK5plisi6g6ghsZtbX5cH4Jw6E0sFcINefzs/t4+tndSwQzry3uJp3LS8W9N8z26X5uvHtTrDt4lgom2MNg47T4m/1TRFE8JFzyhmiYbcj/CMwe2MNwcjA8CW1dURXQ0IBE6VagEHpzVo2uyzYj+f7eP0LKFolh7G12Od3gNHA4YpIYgZoVGIy+f48JPfGKmPAvOYIbmv3s5Rf99eQlfCr0Pe/I3tEK0IQPJkh4sf8Uy+8Z/8Dw49g+DmUrS5eB12fj8OfmcZD7cwrPpnsM++DK5UF/TXG612kBnGdh4TEcKZqJwpyrzm1vEZEyKwpfjoM4+gTup+XOUdt3OyTeDKSpfktP3MGlnJhRyJ5dlWzgXBhO1IPDwKr5+P498SDnBcgzEGfXCYX+rmTCv8/jSPEB+xuCdvtMNplZY29tJNkfm+SceW2ra8hACHHslBeSCk+vm+168iRLq7EvAiR1LY9SHm7GTe0U7QtTQK9CuE/3v/0OHmjY7bOEZnfp3EThHzcIwjeNSL5MtCRC4dstW0jl/1VidHKDrvs/WX8zqTOVobOyGIXTZAUg6TNmAX3akHMYzcGvlofCuRdPgs0vWdi9grEFf3x9XMJMldScxVLZwPtNt4I5ucNJ3M4cR8bevFUVFuUUptbd8QAzSlJi5c5+DV4pY7cV2r92g0jlCFuTit6UJLE2pQT4gnBSxBn4rLB3lRFjCwHwgHB+cfrP7Ole+leUn+oRN2lPbQEUqV1XnrDrmOvkqezzAelJkQOvASJJ2k3NPhTFctKvRzflI/tJkil5lWpG0fguxxbEfuC4WNyCMPNpoGKPPqSi6Ee179+Hv6JNH3ahRie7WiisM47r/zybHBBWvC0JZJY1FoWO3SuUT+EE7H39x0OnvN5me9rMSvGs3U2wh1bq6nM1uiGDOFE9ZljNL/GnNrz0N0qZISVQiMhfd7/ZT7Hc2FtaKG5/+pHM2Ne5x7mlzh1OfO8tZUb4riI34LPVel5h4dCO2YLIlmQaT3WRKcLPcriHILBNJHtiiahjpLe13y+Q/2T0jO7xPeaZ13Yfvz+m1dnagZoU0lYVQ6TkSIxQTVGHn9yNAbXEnv84dzrQeSX6Wxqn3e4VPDO4ZbddDY8He8vTsGgII1c+6T186tSpXTH+w6YYXwMxmmozM0+iVQumldvPj7/eIyVz6+8WbzmyHvnt7cAbSwHSrJ7Z2d9yXZ+KepdDxfR5nMhP3f46PdYm4mB5uiYHkeXRrClbCE3joZVnNZ8Q27hFmbvs4U6LkBtcSWuweiHlLF/3P/TUgYXdT8HLpaPOq/oYULrvNa6zMwPRSNHHINnJ3lYq0Tl/3WHU1e65JnHikQpjJgyMdfRtRmJVrWIYWdXrOBQjrOycY2956vPyJLPCwPNFnOUHz9/wraVQOVnIimq7arnqXNc1lTy4vR73gHqq2YzZ/eJbwLR/s8dXhB3Ol7rvCIAld17uRiqZCOzFRghz4Z04H2pLG7GeVdGS3YIj8KEWJQSNJaDfDz7jUIrBKDorsI4iGk9jy07tAizWAk1HGw9L3hs6vOOd5WW5fcdbrNd7CAKGeArU9vTvCx71Z4Ary/QlOJWAKH7uys8PA3YzAikrsBvIB6f4t7n6NSHZU5w+V5P//4WvNn5jk92C3FStiCjE3dIAUYz+92B3z1v/Y87/GB+a5JSzwN3Q9/P7bKUdcKm4xlroWpFmBN8+4lxz6mO1BQEgktWLM8L4M8qP97//nhr4dx9UZB4wVW56RMGnC9N2/zeA8TC4YE9nQuk1bBw/b7K5j3nipAIHs5eePpCFsuP9xfe2kt4q6fTQPBbkPLOSZm+1FlCXRZUqqbinpAHmY/n//rRS3EFyS4C4b2AUNbbdxv/vMPTQUdc9JpXws+LgdjiOfnjDs8yUx6zl+VBXOiTWVyc33k9x6jwR2r3vszpx/XVosJN7kAa4ox01IK2hHYDRH++/IMOes4rstnMQg7Euly3n6z8vMPVrIX32es2y9trmTZM/rjKptpS319y/W6dbHxVQc+vEDwRCqK5y3ymsiGCuDu6EsE4mV8x3Gfpc96N+cZDn4f/v+QgCz7qVkKJfuYstrmuGaDLmF//JmaZ5NVqcPEvV9nUjcp3YQD5TyC8mrBIDBIzydv7/r4BSWCYyPJ12PkVu/W4MerNpMn7twjIz/f/f+UrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yla985Stf+cpXvvKVr3zlK1/5yle+8pWvfOUrX/nKV77yFYD/B92aGZl3Kab3AAABrklEQVR4nO3YsVHjUBhF4fO0IQW4ABNtQgN0QURGCS6FEpyR4BY2cgPOcQEugPgnkOwBM7O7VuDHnTnfjBI9BTc4gaRWVZxrrS2A++m6+/aAdD07YAtsq+pwftg+B9xauwGegIdrrZMusAHWVfV+vHEKeIr3GVj22Sb9lz2wOkY8gPEqyhJ4npodA2Z8bTBepVgyNksDFsBLzzXSTI+/GEv+3XmINEcbgNveK6SZbhvwp/cKaa7h349IP5cBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK5oBK9oA7HqPkGbaDcBb7xXSTG8D8Np7hTTT61BVB2DTe4l0oU1VHY4fcWtg33GMdIk9Y7PjX4iqegdWGLF+vj2wmpqlVdXppLV2AzwBD12mSX+3AdbHeOEs4NPN1hbA/XTdXW2e9N0O2ALb6Xvtiw95DU/qRF6DCgAAAABJRU5ErkJggg==) no-repeat!important;margin:-32px 0 0 -88px !important}#loading-area p{display:block!important;text-indent:-999em;overflow:hidden!important;width:138px!important;height:25px!important;background-image:url(data:image/gif;base64,R0lGODlhsAA/AMQAAP////f39+/v7+bm5t7e3tbW1s7OzsXFxb29vbW1ta2traWlpZycnJSUlIyMjISEhHt7e3Nzc2tra2NjY1paWlJSUkpKSkJCQjo6OjMzMwAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJBAAZACwmABQAYwAYAAAF/2AmjmSGHFiprmzrvnDcXo4lXgRhi1Yq/8CgkAQpoDK4wa5C2Q2f0GjGUihAkAQlkkLxSb9gWKNguCRtzEp4zUY+1MhDoXGuMH2YHuxib49yCiIKBlIRBwcMNhFkGQ8OGUw2GExNMAQAAH4imASQmAxRFwuHBw8YEBIkFzYWXFxeLZeZmpwiAgAXXxMJhw8srVxOL7KaGbVtpwsULBeVP8QrCJgBoCMKtwACEyQMAQDUtTgEERkRBAgXBp8kFdgK5oEW8ha5Lxj395aYKheY/gAIRvzDtC2DgoG1KqxjgBBANYUICTRIQJHioxYVJmjUuMwFNBKy1KgDQK6cwGybMP/lkgagE0RQDLNNcIBJgAhvANTElFiR4pUWFjZyHLavBKaAKZGawLYvAqaLxlp6cpghZkFsSU92WiWvngt8+YjOGvFSa4YJ/mRligknqsuFmOAQK5uy0wgMERh05DehAiyxJfoBCJSSkLcAIojFLOl2Ksy4ifcJVnrsLIMFC1KtqCChszCPnxiIJudPxOKoNqNmEmyXptSybCPP8qczXAPMDLZN2DtFjYXOEib8XaE2bbm0NWUznYUtgNq3VGNngOY0YgYJmCPkmtDAl8brEdRM6tw2lvXj/pRewCmA5R9/Ci5Bf5xT9ogIh9FKxTBhBwYHDQj3wAPNQBABHp89wcdYZl4FVt4XmBBGQgQNOHDPgLlEAEFBxXSowjgV4AcZCRY00MAyGGAIiYENetihfv8oNQJ3vmSQIoEiSAABby526IABgDwoAn94qGijXz0mKUQEjCnppAohAAAh+QQJBAAZACwmABQAYwAYAAAF/2AmjmSWIFiprmzrvnDcXo8lXkVhZ5ezy8CgcDiKHBIpnE50IDiI0Kh0ZDkcIrycLUIYUKbgsMxhvSgtGMNgIW67eZDKDXFwnB0DwkWEQcMuFXJvIgQECiIKBlMSCQk+GUYIGQ9PTU8ZFhQUPy0EAACDIp8EGRWfDFIXDY0JEBgREyQSEpgVmhUpL56goaMiAgB7UxMKjRAsF5oUwjC7oRm+b68MXysYFZzNnywInwGoIwrAAAKxIwwBAN++F4VYXAgXBqckFeMKXIcW+xbMLRgAAWrjReLCp4MAJIlCCMCcAoa+TAFAxQDiRBESGTpZwJHjsRaZlGnSta3ELjnzAP9ggTTik4CFwTJ0A0BKIkWXExy4FJEOgJyKNB105LiShYUJSJFW61SSxCeF0BKOQDBuW4RPl6LWpAfU3LiFUNnx8/cv4MASNlvSzDDh4C5QQAVpLcX1kyBnaReSGoFBggO5JZIBPlvw06GFitIFILQNaNGIdX0yBmVQqt4RFBpoNqfiKNJsTCcyGI3loAjHUV9GpRxN59q0cSfD/MnugWYHXygAtiDH8wQKuVy8dQvJ7c4Mu6ryGhfg7daLsZGXvAqR1ATNElJQeHBs5AQJgiogHbxieDTqT0dc6Clg5oi3Cjw9vylZOsEIituuxbCJz4MHwEEQwTWz5NJHGICsUAFOWeqRJ4VhKkjAHUACpjDLUs9kaFIEFeBnV2D/yYEBBK5gMguDGoaiH0JQYfbASiOWyBZ4KdaYgQMGFKKAg/wZSKKBuNgoZBCzDGnkCiEAACH5BAkEABkALCYAFABjABgAAAX/YCaOZLYoZaqubOu+cHtBl3gdh2U7euz/wCBJklhgMrecKFF4CJ/Q6MiSSEiQOJ2kUKBIv+DYo3q5GSyYQ4ERbruRkYpNkXiYLQ9ur8J7XSpybyIEBCgZCgZSEwsLdhlEKBBOCE1ICwQDDi8EAACCIp0EGRWdbFAYDowLERgSEyQTEBgPmANKLpyen6EiAgA1UhQMjBErDwMDBVcwuZ8ZvG+tDoEpFI1HMc0qCJ0BpiIKvgACryMMAQDevBeExREECBcGpSQV4grvKGX7Lxj+/ps6pbjQqSAABCMMdiqnQCEvUgDYMHAYUQREhQQgNNi4sRiLP4AqUKC2QhuJXHLm/wHw6PHZOFCdanADIAqixE7kHOAUgQ6AnIk0NXJssGyFBQpIkZJUYTLhQacIRSAQJzBCJ00wa9IDWk4czKguRe27gM3Fv7Ismo6ilzXDhIK5PAGl9nBrp0DNbDoVNQJDrKUjLlDokU0gCYIADLlMhC7AIIFAW9atOPexJ8RgoWWg8KCzFxUWJkwYXDgig9PFCoqI7FIAzMvQdNJcS/mu5dc/eWGQ5HkUSQs6jo6mgLakQ1FWQ+3MkIuqLnEB4mqt7fN2huQYN3eecKQChGKA3E7YI5pw2uMisD+10VPAzBFxFXCafrM6c8PXG7+dPQrYbgjESSABBqFxJwKBYPyhQlEFwAwEWBSdKDZCLKy0MqB4DzqjIXNxRNDTUjNAIIeFRxTY4IYb7mcQWCN4twyJIlAwHoo0ZuCAAYQo8CAGFWCDQQQXZkBgcTUW6YJoRiapQggAIfkECQQAGQAsJgAUAGMAGAAABf9gJo5k1jBlqq5s675we0WXeCWJZT967P/AIGmyYGAyt5xIcXgIn9Do6MJYTJA4neRwqEi/4FhkscAkLZjEoRFuu5GTHqYKSScuEG4tU+G9LhVebyIEBApLBlIUDQ0QNUQoERAZTJNUBQUOLwQAAIMinQR8nShQGBCMDRIZExRDdRAGmEounJ6foSICAHtRFQ6MqyoQmAYRMbafGblvGBMQgikUCQ5HyJ0rCJ0BpUu7AAJXIwwBANy5F4XHEQQIFwakJBXfCuyHF/j4f4GBm9glFzoJBIBgxMBO4hQczFUhHoOFAEo1XEggwoOLF4WtaFCoY8EWyUrY8gIPwLEMJ5f/gQPVqYY2AKImongIboKDTgJElAPghWZFjBfFrXgwoOiAdtZWhCTR6aNKpwi+YYvQSRPLmA4R6vrX1CDMDGbwJWUBKFAPkP9GyPQqaoJAW55oRmOYlSchbGuvlqAQ4WwJDP18LLXR6RDLROUC3I3bKSXdiBnkLkbSVa+ICpIiRCthgUKgXrVIMRh9TKAImqVXqvQU8GuGm1/XSs4QUmDPXBgkQICgmY/fCzouUBheYaxSiijf4lws9da3AHCxQp4dkiryCrwpHKkg4Uq/4T06U/B7/KCo5AKdXtgp4OUIuAo4SZ/ZSdDSCInduq6wJ7eE4hNMgIF41pgBBiAq8LcCRoJtFCaNBKs4I2AGxCljoVKa4VcfQBDqIOERwlEA2oUW6jeQU2p1J8KHl41H4ouvGVCIApuNAFiBASaFBow8/jBcj0CqEAIAIfkECQQAGQAsJgAUAGMAGAAABf9gJo5k5jRlqq5s675wi0mXeC1LnV2QFf/AoLA0aThsOB0jARk6n9DRpdGY7JKZSQJRiXq/MQkVc1tYMIrEEcxuYya+DOYUwSQhiYSuAtG1LhVdbSMEBAoiCgZRFA8PNBkUVBkSERkLCJVTBwcPLwQAAIMjoAQZFaAMUBgRjQ9WFIIiFHUQCJsKfiyfoaIZpCICALlOfI1WKhEHBgcSMbu9vgClorNxKRQKDxg/zyoIoAGpIwrBAALHIgwBAOG/F4WVEQQIFwaoJBXlCvKHF/4X21wAChRLF6gUF0ApBIBg1EIAxxQ8/HUKQCoGEy2KqPiQgAQIIEGiU+GggEmTCVz/dCOxq4s9AJUyxIwmQITCGt+kmbqH0dwEB6BqZlgHoEtPjyEhRKDQ4gGBkwUSBFyx0mFDmwxHICh3MAKoNdFKVbwI6lg5rFfDyvk3lcXACtYM8hox1mGpCQp3heoZiyJPUIKe1cU6bQQFCXFJTDDQYFiLqjtAHcKqaF0AEc96zvSrkS/mgwmzEh5hQYLpgooHDCgAoa1cBrAZVFKYDtRsc1hDhZ4GVGddzxm6KTT6600E0z4sxPU3qYDqA4lV6M0rM2/Qz+YWAgOnV+zfothFeJ0o1jSFbRYmWLHQpQIFHxgaqAYrd+G08aDSXiAqICchhQp84l1ngIUnnmV46ZSBYAU6vDFBBW+cZwEsdLXmBSAqVOCYDahFIVkKFagnxwTnQfIeNChSFUEFERCF2gXqwafeNhdQUGKKOGYxUVqkkShChAG5F12OojhgQCEKdCjHGSOQONWQREbZQiBSVqlCCAAh+QQJBAAZACwmABQAYwAYAAAF/2AmjmQGPWWqrmzrvnCLTZeINU2dXZEe/8CgcER5QGw4nWMRGTqf0NHl8aBkbrkMZbGoRL/g2ISKwV4wjAUqzG5jKDrMaWKWcHWW3utS8bZHBAQKIgoGURUQEHQZFVQZExIZDQuRUwkJRy4EAAB/I5wEjJwMUBgSiRBWfSQUEhgRCpcMPiybnZ4ZoCICALROeRGpKxKXCpEwtri5AKGeFRIWKxUMEBg/ySoInAGkIwq8AAITJAwBANy6F4FNEQQIFwajJBXgCu2DGBf61i4XFv/RNHFKcYGTQQAIPh0EMC6DgoW6KshjABFAN4kQCUCSwFGCFRYPDogUOagFNhK2vP/EA9AkQ8tlAkQYrKGNmSiLGSiGm+CAU8wM5gB40amxI0c/KyAYMDCyZK2BJTgllIlwBAJwAyNwcqAwFEZSOhuCozp1WagyaPcADGgS6oivXR8ZtNVJJ9KIEzn5SQaXarO3NFZMOJAlxkkRBQE45WTIXAARyXS+xIvTLuSBicvqEmFhgme2JSAUKGAg0wtbDFIzaGJQhGSYVDslbtbTJlzLGbAZHKprhucJ0SzQkuDglYHRCECvoDvX5Vyfl8Md3LWNrte8QqOL0JoxQ+cJFax1tvIvQ4IBKC44GM1V4MJm3KVKCSqgJiCDCjZdr6xX+3bHE2xmAT9aUBANBeFBMABbAQHlQeATfKhQgS9SIAUGJ04B9hGC1hQwwALKhLhcBBVEEJSFV0xgoAgUUGBNBAt+JOKMAS5U1gjjEeGiCAgM0N6MMzpgQCAKoIgjgS3yMwWFQDb5wipORrlCCAAh+QQJBAAZACwmABQAYwAYAAAF/2AmjmQWQWWqrmzrvnCLUZiIPc9lT3rs/8AgqQKJ2HC9R2MibDqfo8upkrnlMpVGwwLtemOUIsZ6wTgaqK96jan0MKcJeaLtWSS91qVCXY8IBAoiCgZQdxI0WBFGFExKTBcQCwtGLgQAAH4jmARYmAxPGBMSpFQVXCMVTBMMkw15LJeZmhmcIgIAsE0WoxJ9KROTDEwwsrS1AJ2aqrqpDRE1McYqCJgBoCMKuAACxCIMAQDXtheARhEECBcGn0PbCuiCY/MvFxb3qC3TJBeY/gAINv0DQEzBQFsV2jE4CABbwoMEGk2YOOGXCggJMmbEFgtTCllU2AGoVAmZABH+dP9US+apYYaF3CY4wHQyQzgAVGBGpDjRYooIGjda8lgCU0CUAEcg2OYxAiYHAjs9BAWT2DakR5F1mjemHr58HWelaoe00wR/sjLB/IVQIaY+xqZGLWGBQjMRFBJckUY0CiZBSAuFCyDCGMySbV2uLeyxX9KyI+pSoACWBIQDBxCUHNqQgWcj/r5hAs0NaSbHymaylLs4wzR/OW3NmEw5gwVYEh7AQYBZQWUVadGaQEuTMbd/t6ylleoWp3ERTiHanozqAgUqDkAhKIDiggPMD14EtzXcX9YLNwWs/ONPwSXmit8+hz74LMsMZUZcdzOAgIUHBRhgBzRd7KGCGysYqMZTXynURcUF/VmAwQEFcHTMhSUQEEEFEdzk02w6QOhfBhIUUAAFGKYogn3/ZBXZdSKIiEoCBYSnYooOGACIAj5FEQUg1UFw141EspAAAtEUqSQJIQAAIfkECQQAGQAsJgAUAGMAGAAABf9gJo5kJkllqq5s675wi1WYiEXQZU967P/AIKlysuF6kcdEyGw6R5iTJXPLZSqPx/TJ7cKIEkz1goE8UN60etaLSihVDCVby1h4r0uloiYRCAoiCgZPdxNwdkUVFBlJjDcNDWgtBAAAfSOWBFeWDE5yE6F8FlsiFowTDpEPPZSWmCKaIgIArU0XoRN8KhSRDowwlZewspintiQWZ3XBryoIlgGeIwq0AAJLIwwBANKyF38RjQQIFwadQ9YKEYBUYmJ5pKQvwikXlvgACJn5ANkK/WRVQMcgIIBpAwMSWEThEIVdKyIsmDjRgYt6JYTxOQdAXCN+AmJZ0gENwKaEngr/XktlKWQGbgD4qFxIoWbNUiokUKx40RkJS/tEBs2AwNqrCJYsijxJ0FI2a0L5bXrHrMUFechUYByBUmqGCfiEXVIJUWDTmCLqdV1awgKNFRQWQKjac9iIewACiSTELUDaVyo9ZjB7MAPZv5fwDi2W4cJDCjhJREiQQMGkugwyMxCHT0TgwddEJi7mgHBKS7sw4pMpa8bDPTcEf50rQQHlBVlTiA3bKGxLxEaHWQsglmnhwxkwIlVo56GFGhAGEFKVIcEBCFQgUMZeN9+m3viGXoApoOQIsQoqGT+NNrnPCH3BmhRBhj6BAQ4uFChgAcKBcqaEwYUeKlSQW2MQdWGJVF4kMDBAARfoxx8GCBzQACwYUhJBBfChVkIFAxCAnYRTSHDAAQlmqKJ8+Qw1wgMEHEDfflsscJ2KOI7ggAF/KJAifazMyB99VuRoJBAKMHjkkimEAAAh+QQJBAAZACwmABQAYwAYAAAF/2AmjmQ2TWWqrmzrvnCLVZiISVKdYZQe/8CgcGQ52XA6CYQybDqfI8zJskNmLBDIBcrtxionzC2XiUBQ3rQaY9nuTjQkxay79F6XSkVNIhAUIgoGUEUTNFdGehlKTFIPD2gtBAAAfCOUBBkVlAxQFRQTFFRtJBZ7FBCPED4sk5WWGZgiAgBuT3YUoisUjw97MK6wsQCZlqa2JVgTrC7BKgiUAZ0jCrQAApEZDAEA0rIXfhFlBAgXBpwkFdYKEX87YmIvGBf0yCvOJBeU+wAIl/wA0CgAKGsTgE4MCB4UYRAggU+5clFhIaGBRYsPmlFK4WrPOQDiyvwTIGLfFmjENP+hS3htggNKJDNwA7CH5UM9eijYKzHhIkaNr0hQ8ley3wgE1jZGoOTgXyaDCCmhsVaU6LBi8JipmFfvBT6G6IpmmrDPVSWWv66qXIhWRDCoTklgeJAgW7oGEbS22piPEqCig7gFcLuRZUi1cNtmCKbPqNgREQwMGNBUhYQFCxjY3XuQgWdx+0QYHhYzdONiL1MmpvTL2b6asiwcmExg1YPDJvJOYIC5wU6OBDMtxQST8DV+s6KZfbqStXERwx1meDCAAIMtEAocmN50QQJxGCBgxn0vOHR+Vi/MFIByhFkFk5izdb6YbxnBZFNiiPDLXAEH5hxgQQQJJOBGEXoFkYdZChX8lsGCafiVQgMFGDCPAQJioEAClQnjIUf8RTBTWgwVUIA4FxwgoAkFkvihh/mhl0J2RKW4ojbfvahjBg4Y4IcCLopwgRZCqjjRBRE4uOOSK2DG5JMqhAAAIfkECQQAGQAsJgAUAGMAGAAABf9gJo5kRlFlqq5s675wi1mYiE1TnWGVHv/AoHBkOdlwuomkMmw6nyPMybJDZiwSyQXK7caKqFsuo0R5z+iZ78REVrK6C8XHulSY6BGBoBApDFByFD1XRhZtSzsUERBmLQQAAHkjkQQZFZEMUGAUVBZbREwVjBASdCuQkpMZlSICAKBPdhWdK6MQEXgvqausAJaTd6cjFxKOMLwqCJEBmiMKrwACEyQMAQDNrRd7ERkRBAgXBpkkFdEK3313d1QuGBfwsSzJJBeR9wAIlPgA1BkK/FphAqCJQUCCIgbyI5CAwICHA5ytmPCgYsVujyKlSMVkHACMGH0JEHFvy7Jfl8j/GZQ2wUGkkRmuAWCykuGemw1aULB40QW9ffpI5huBIJrGCJEc7LM0sGAkf9GEBvVl6dAdeSvexdulsRw5oZYm3EslaaUugSoj4eHVdCkJDA4OSLD1wNSPnxnsAegjFNC1ACJ4rQyJFqHZwBr1Tm0lIoKBAgUeTGzQwMGxjAQZaO52T8RgkUIl6QXmEmXbwxmS3aOpDQFkAxAwlCJBYS4FB5QfYFVBdqy3sS8RS8PnihlZpmlnCm980BIEyA22RDiQIAMECBkaLJiLQQJlf5jxAUN6b+oFmQJO6rmnABJyw2qXN/4rFiWGXCIuIDigO0GCYgswAIocwwhhhwoV7JafUy5dRMIXCXEh8I5/NDCwAHa9ZMhbLhHIxOAlBxzQzQUUmrDAAh9q2Et9+Ew1AgQH8EViAu04sJ2KOGbggAF7KJBiXhEMWOIOWuRoJBCUHamkCiEAACH5BAkEABkALCYAFABjABgAAAX/YCaOZFZRZaqubOu+sGthIkZNdIZVeez/wODoQqmMbrmbUchsOmuniwiZsUwm0qd2C7OcprjMFcUtmy8OsoliySAr19yF95ovzSICQSFSGJ4QBAMKbV4oFm03bTYSEncsBAAAeCOSBCaSDE4XCIIEDhkXWSIXbRWNEmEukZOUGZYiAgCjTRIGAwMPKxaobTCsrq8Al3gYDggTKxcTjy/AKgiSAZojCrIAAskjDAEA07AXehEZEQQIFwaZJBXXCuV8XhUVvi0YoqLOkikXkv0ACJX8AdCmQCCsCuoYGARADaHBPQUiRqS2gkKEixclrNJXgpWRdADGkQsoQEQ/KdGG/2FimEEhtgkOJJXM0A2AEZcQJRYAxYIChJ8/NbZ4RkISQJP/RiC4pi+CJJ7CLjnU5FLbNaRHo1aZZ4HWCnuiekDiOGJqwEsT+rGa5PLOwYSSlgAzi5RYjQfIdkFQ9YssKUl8kP7pFiCPPpcitZpta3gSv6R1R0hAcOAAhIoPHkBQs5Ehg8/j+olALGym6MfEYqpcHLcxUpstwSmojCAChgjaRMBxk1mzVxVr1ZJTK7Mx01bXAqyVChd2hmdOH2aAUNmBFAkJFpAb96BBMgwTMuceK5BYdKNDagpIOWKtgkjMWTJ+TjYC4bQqMTgilSABhAsLLLBMA9aRQoFYTMyhQlYFv5HSzBOApfBAAgrYE6AUDjSQWDAcdhRBBfa1RoIF/WkEoIBuNNAAPR12iJ8/WY0QQQLUnJhFd+O1yKEDBuihwIOhSJAFBhfWwJeOSPrgAFRJNplCCAAh+QQJBAAZACwmABQAYwAYAAAF/2AmjmRWVWWqrmzrvnB7NdZIUZiIWXns/8AgCUIw9Co4EWVSEzqfUFGFMIBIk5flJcrtxhgDwgWDzC1R3rT68qCILoVBg4yz3HrknuykJhEICiIKBlEQBQULNRADhBc1SzVkExNoLQQAAH0jmAQmmAxQFwmHBQ8YEBIkjhkWkxNJLpeZmhmcIgIAW1ESB4cOK62TTS+ytLUAnX0YDwkTK1mVMMUqCJgBoCMKuAACziMMAQDXthd/ERkRBAgXBp8kFdsK6YEW9fUvGPn5xJgpF5gAASDYFBCANwUFbVVwxyAhAGwLExJYcKDiAQMNWlSQwJGjNxbT/GBC0Q7AOXQEBf+IALilGjJPDzM05DbBASaVGcIBQDFzosWKDzR29BirXwlMA1cKHIFgW78ImH4p7RQR1Exv25QmPdbJUT1dLTBcGKsHpNERVQl2mgBQVqaZlRQyHCmiWNqpJE4p+FjCggRY0s6+wRRIKaFwAer2m3mSK0yrdDMU+7cUrwgJCTI3LlEBAoQI0Sx9YkD6HEARjI/hPE05mc2XaeEqngWQJ7kFmRVIwCCBLxITETzv5lewE1RON2c7nbUtgFuqc3fOFnG8OLrMD7ZMWJCRYwYIbTJgoODZTVHr6AJuvaBTgMsRbhVcgh5TtuSzERCzfYmBiY4FC+zWQANZPGDKG6E5cUFQgiaAVcKCahCWAgQLMJDPgFsYmIoxHKpAAGj5RTaCBQA6gwGGJhg4TIcd7qdeChJwpwOK6ITH4o0OGPCHAgzypsuJBOoA2I1E+uBZkUiyEAIAOw==)!important;background-repeat:no-repeat!important;padding:0!important}';
	
	css+='div#entries.list .collapsed .entry-main .entry-source-title,div#entries.list .collapsed .entry-secondary{color:#555 !important;}';
	//fix icon followers
	css+='.scroll-tree .icon, .scroll-tree .favicon{width:0px;height:0px;}';
	
	//color:black so set white text for header children (colorful conflict)
	css+='#chrome-view-links,#chrome-title{color:#fff!important}';
	
	GM_addStyle(css, 'rps_osxblue');
	
	fireResize();
};//Mac OS X Snow Leopard
//http://userstyles.org/styles/16900 : Google Reader: Mac OS X Snow Leopard
//http://userstyles.org/styles/16901 : Google Reader: Prettier add subscription, edit tag
//http://userstyles.org/styles/18581 : Google Reader: Mac OS X Snow Leopard+ Offline
//http://userstyles.org/styles/19191 : Google Reader: Mac OS X Snow Leopard+ Delicious

GRP.osxblack = function() {
	//16900
	var css = '.banner{overflow:hidden!important}.gbh{border-top:0!important}.goog-menu,#stream-prefs-menu-contents{background:rgba(255,255,255,0.93)!important;border:1px solid #ccc!important;-webkit-border-radius:5px!important;-moz-border-radius:0 0 5px 5px!important;-webkit-box-shadow:0 5px 8px rgba(0,0,0,0.6)!important;-moz-box-shadow:0 5px 8px rgba(0,0,0,0.6)!important;z-index:1000!important;margin:0!important;padding:4px!important}#stream-prefs-menu-contents{-moz-border-radius-topright:5px!important}.lhn-menu{-moz-border-radius-topleft:5px!important}#stream-prefs-menu-contents .menu-item.selected,.goog-option-selected .goog-menuitem-checkbox,#stream-folder-chooser .chooser-item-selected{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAkUlEQVQokY3QMQqDQBCF4b8IOYCQIkUKkeAZ7FOFFBZiZWUfRFLlBFa5gKWEveazGWEJa3YHplj2e8PsQkJJuki6p1gk3YDFOoprwFm3MVx5uPm9PEl6eOcMmA33oYEvwEnaJr0NT8AhFOgMLPYb2yrl3spH4ONBBzz/PhIoPPwFzrEAwGiBIQUD5Ba4pgaitQIWADO6QoO6aQAAAABJRU5ErkJggg==)!important}#stream-prefs-menu-contents .menu-item:hover.selected,.goog-option-selected:hover .goog-menuitem-checkbox,#stream-folder-chooser .chooser-item-selected:hover{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAMCAYAAABWdVznAAAAiUlEQVQokY3PsQkCQRCF4YsEazAyMjISBME+rMH0wOgiwdTUGgRBMLUJU5uwgAXhMxlwldPdlz3m/4eZpqkIpmhr2AZrJKQauPPOrgSvMnj7PRxjk/URHgEf+rZd8k24Rr9h0CfsA0hos1OWv+4d4u4zx9KT8wx+YvJXCOkcwqkIhzALYVEl1OQF/Ge2+8g/mgEAAAAASUVORK5CYII=)!important}.menu-item:hover,.goog-menuitem:hover,.goog-menuitem-highlight,#stream-folder-chooser .chooser-item:hover{background-color:#36C!important;color:#fff!important}#stream-folder-chooser.menu-item:hover{background-color:transparent!important}#chrome-lhn-toggle{width:0!important;height:0!important;background:transparent!important}#chrome-lhn-toggle-icon:not(:hover){opacity:0!important}#chrome-lhn-toggle-icon{position:fixed!important;top:28px!important;left:0!important;width:8px!important;border:0!important;min-height:100%!important;z-index:10!important;background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAABCAYAAADn9T9+AAAANElEQVQImQEpANb/AERERLlUVFSpZmZmmXh4eIiHh4d3mZmZZqmpqVa6urpGx8fHN9PT0ymIYxUW0qXgDwAAAABJRU5ErkJggg==) repeat-y!important;margin:0!important}#chrome-lhn-menu:before{background-color:#6DA6E5!important}#home,#viewer-page-container{background:#9aa7ba!important}#overview{margin-left:12px!important}#overview .section-header{color:#000!important;margin-bottom:1em!important;text-shadow:rgba(255,255,255,0.3) 0 1px!important}#overview > .section-header:first-child{margin-left:.5em!important}#home .title,#home .section-header,#overview-footer,#overview-footer a,#overview-footer a:visited{color:#000!important;text-shadow:rgba(255,255,255,0.3) 0 1px!important}#rec-preview{margin-top:1em!important}#rec-preview .section-header,#tips .section-header,#home #rec-preview a,#home #rec-preview span,#home #tips a,#team-messages .section-header,#team-messages a{color:#444!important;text-shadow:rgba(255,255,255,0.3) 0 1px!important}#home a:not(:hover),#home span:not(:hover),#footer a:not(:hover){text-decoration:none!important}#overview .item-snippet,#overview .label,#rec-preview-body .recommendation-preview-feed-summary,#recent-activity .recent-item,#recent-activity h4,#tips p,#tips ul,#team-messages,#team-messages-snippet{color:#555!important}#overview .item-title{display:block!important;margin:8px 0 6px!important}#overview img{color:#000!important;border:1px solid rgba(0,0,0,0.3)!important;-webkit-box-shadow:0 0 0 #111!important;-moz-box-shadow:0 0 0 #111!important;padding:0!important}#overview img:hover{-webkit-transform:scale(4)!important;-moz-transform:scale(4)!important;border:none!important}#home .overview-segment{border:1px solid rgba(0,0,0,0.3)!important;background:#b3bccd!important;-webkit-box-shadow:0 0 2px rgba(0,0,0,0.5)!important;-moz-box-shadow:inset 0 1px rgba(255,255,255,0.5), 0 0 2px rgba(0,0,0,0.5)!important;-webkit-border-radius:8px!important;-moz-border-radius:8px!important;padding:1em!important}#rec-preview,#recent-activity,#tips,#team-messages{border:1px solid rgba(0,0,0,0.3)!important;background:#9aa7ba!important;-webkit-box-shadow:0 0 2px rgba(0,0,0,0.5)!important;-moz-box-shadow:inset 0 1px rgba(255,255,255,0.5), 0 0 2px rgba(0,0,0,0.5)!important;-webkit-border-radius:8px!important;-moz-border-radius:8px!important;padding:1em!important}#team-messages{padding-top:0!important}#footer{margin-left:1em!important;border-top:0 solid rgba(255,255,255,0.3)!important}#trends{padding-left:10px!important}#trends h2{padding-left:.5em!important;color:#000!important;text-shadow:rgba(255,255,255,0.3) 0 1px!important}#trends-item-count-header{color:#555!important;text-shadow:rgba(255,255,255,0.3) 0 1px!important}#trends .explanation{color:#444!important}#trends .cloud{background:rgba(255,255,255,0.9)!important;-webkit-box-shadow:0 0 2px rgba(0,0,0,0.5)!important;-moz-box-shadow:inset 0 1px rgba(255,255,255,0.5), 0 0 2px rgba(0,0,0,0.5)!important;-webkit-border-radius:8px!important;-moz-border-radius:8px!important;padding:.5em 1em!important}#trends-bucket-chart.tab-group{border:1px solid rgba(0,0,0,0.3)!important;background:#b2b8cd!important;background-image:none!important;-webkit-box-shadow:0 0 2px rgba(0,0,0,0.5)!important;-moz-box-shadow:inset 0 1px rgba(255,255,255,0.5), 0 0 2px rgba(0,0,0,0.5)!important;-webkit-border-radius:8px!important;-moz-border-radius:8px!important;padding:1em!important}#trends .trends-columns-fixed .tab-group{border:1px solid rgba(0,0,0,0.3)!important;background:#9aa7ba!important;background-image:none!important;-webkit-box-shadow:0 0 2px rgba(0,0,0,0.5)!important;-moz-box-shadow:inset 0 1px rgba(255,255,255,0.5), 0 0 2px rgba(0,0,0,0.5)!important;-webkit-border-radius:8px!important;-moz-border-radius:8px!important;padding:1em!important}#trends-bucket-chart .tab-group-contents{background:transparent!important;width:515px!important;overflow:hidden!important}#trends-bucket-chart .tab-group-contents .tab-contents{margin-left:8px!important;border:none!important;-webkit-border-radius:5px!important;-moz-border-radius:5px!important}#trends .trends-columns-fixed .tab-group-contents{background:transparent!important;padding-left:6px!important}#trends .tab-header,#directory-contents .tab-header{padding-top:3px!important;border:1px solid rgba(0,0,0,0.5)!important;border-right:0!important;color:#000!important;-webkit-box-shadow:0 1px rgba(255,255,255,0.3)!important;-moz-box-shadow:0 1px rgba(255,255,255,0.3)!important;-webkit-border-radius:0!important;-moz-border-radius:0!important;margin:4px 0 3px!important}#trends .tab-header:first-child,#directory-contents .tab-header:first-child{-webkit-border-top-left-radius:3px!important;-webkit-border-bottom-left-radius:3px!important;-moz-border-radius:3px 0 0 3px!important}#trends .tab-header:nth-last-child(2),#directory-contents .tab-header:nth-last-child(3){border-right:1px solid rgba(0,0,0,0.5)!important;-webkit-border-top-right-radius:3px!important;-webkit-border-bottom-right-radius:3px!important;-moz-border-radius:0 3px 3px 0!important}#trends .unselectable.tab-header,#directory-contents .unselectable.tab-header{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAWCAYAAAABxvaqAAAAYUlEQVQImQXBoQrAIBiF0fv+z+AjWGawGIQli2XJsmCxCMJfRFj4do7MDH3fh845aO+NzAyttdCcE40xUO8dve+LWmvoeR5Ua0WlFHTfN8o5o5QSijGiEAK6rgt575Fzjh9C5ExXiWjjBQAAAABJRU5ErkJggg==) repeat-x!important}#trends .unselectable.tab-header:active,#directory-contents .unselectable.tab-header:active{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAWCAYAAAABxvaqAAAAXElEQVQImS3KoQ3AIABFwbcVA6EYgAVQVDRBYAiCIBAEQtjw11TfYYwRzjnxPI9orYk5pzjniHuv2HuLtdYPYwzRe/9zrVWUUkTOWaSUxPu+IsYoQgjCey+stfoAwlQ7XFXx490AAAAASUVORK5CYII=) repeat-x 0 -1px!important}#trends .tab-group .unselectable.tab-header.tab-header-selected,#directory-contents .tab-group .unselectable.tab-header.tab-header-selected{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAWCAYAAAABxvaqAAAAb0lEQVQImQXBWwvBAABA4fOvvXlSFDWhZLXcIrdQ01paa1kRyouUBym/5Pg+0vItxf0n+fUr2eUjafmWpHjJIX/K/viQTXKTZXyW2e4k41Um0TyVwSSWXrSVTriWoL+QZncqjfZI6sFQas1QKtWWfwLxQrmtHL3iAAAAAElFTkSuQmCC) repeat-x!important;font-weight:400!important}img.trends-sorting-unsubscribe{width:0!important;height:16px!important;padding-right:16px!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACl0lEQVQ4jX3MzUvbcBwG8O/FP2Kn7TLcISBF3EEpdFRarU6TvoZou3atIV3b1DZJC2tCbId24sukoIzJDtoN2WCeJp7Eg7KxgfawofOltr+2+e7gP7HbBnb1gef2PB+Af+nSNI2VZflNKpU+DgaDxO12o9frNYLBYEOSpB+FQuFTPp8PA0AX3Ewul3vn8/laDMPgbWVZtpXJZD60AeEw32AYBh0OB/b39+Pg4CD29PSgxWLB3t5etNvtaLVakWEY5Hm+0QZomvbFbh8yKIpCm83290xRFFqtVjSZTGi32zEUChkLCwvf24BIJPJ8bq6I6bSE4+M0WiwW7O5+gH19fWgymQyapg2e51FVC1goFPJtAABALBYzkslko1x+3zw8PDT29g6Mo6OKUalUmmtra0TX9ZqqqvjfMwCAx+MhmYx0Icvy5fLyUlXXdbK4OF/VNK1WLBariqLURFHsDLjd7lO/31/LZrNEkqT6+vr6pSzLpFQq1RVFaaqqShKJBOkIcBz3NR6Pn05OTl7l8/m6IAikVCqdp9Opmq7rNY7jiCiK5x0Bv9+/43K5LmRZvorFYmRlZaUqCEIrl8s1AoFAM5FIkGg0etwRCIVCG1NTwsno6DiRpKwRCPCYSCgGy04YipIxvF4vmZ6e/twR4PlnrwcGHv3kuKd1hmFREFIYCPCYTqvoY58YNO07E8XUVkdAEOI5mvZ8M5utVW4i0hwaZpBmJtBstqHT5WuZzdYzXS8sdQQoyhTd3Nzan519eeZ0elojI2NGOCLgzMwLnJ9/1SyXP14MD49pHQEAuOdwjCa3t3f2Nja2TnZ392uE/L66vr7+tbr69sBmGyoCwP3bAACAOwDwEAAcAOAEADcAPAYAMwDcvTn+A1A5RBJ/o+pRAAAAAElFTkSuQmCC) no-repeat right!important}#trends .sorting .primary{background:#b2b2b2 none repeat scroll 0 0!important}#trends .trends-sorting-homepage{margin:0 0 0 2px !important}#directory-box .tab-group{background:#fff!important}#directory-contents .tab-group{padding-top:4px!important}#directory-contents .tab-header:first-child{margin-left:10px!important}#directory-contents .tab-header{padding-bottom:2px!important}#import-prompt{padding-top:12px!important}#main{z-index:0!important;top:0!important;margin-left:0!important}#chrome-view-links{background:transparent!important;z-index:0!important;position:fixed!important;top:44px!important;right:6px!important;color:transparent!important;font-size:0!important;line-height:18px!important;-webkit-border-radius:2px!important;-moz-border-radius:2px!important;padding:0!important}#chrome-header{border-top:1px solid #dcdcdc!important;border-bottom:1px solid #404040!important;background:#B1B1B1 url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAbCAYAAAC9WOV0AAAAU0lEQVQImU3EuQ0AIQwEwO2/ERAC8YhX4MKIluAc3AQDEbkQEX6dc4i9N7HW0uacxBiD6L1rrTWi1kqUUrScM5FSImKMWgjhn/eecM5p1lrCGHMfSCNTcRAlrXYAAAAASUVORK5CYII=) repeat-x!important;height:23px!important;margin:0!important;padding:2px 6px!important}#chrome-title{font-weight:400!important;font-size:14px!important;line-height:24px!important;text-shadow:#ddd 0 1px!important;margin-left:3px!important}#chrome-lhn-menu{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAXCAYAAABwOa1vAAAB+ElEQVRIidXRsaraUBwG8INLq4ND8T2EPoHiSc45QY04GBxcMtynKF3aBwiZ3G4dRdBacHBxEcRBQTIoF+JgBhVxMWBACHwd0itUigYv3MYDv+Eczv/jgz/JZDIpIcRXIcRLoVBAFAkhXjjnXxhjn4iqqt91XYdlWfB9H1E7vu/Dsizouo5isfiNlEul1Ww2g+/7kTabzVAulVYkn8/D8zycTqdI8zwP+XweRFEUHI/Hh6AoCogQAofD4SEIIUA459jv9w+Bcx4U3mw2VxFCQrmV81accxDGGBzHuepwOMB13fNqXNf9y+vbrZy3YowFhZfL5btKJpP/3FAikbg6dy68WCze1W63Q7lcRiqVOuOcY7vdXp1jjIHIsgzLskKLxWKh3MpxHAeKoiCdTiObzWK1Wt2ckWU5KDydTkPbbDZYr9dnl/dXYbJs20atVsN8Pg/1X5ZlEEmSMB6P/xvHcUL/lSQpKDwcDh+CJEkglFIMBoO7xOPxUO7Nv0QpDQr3+/272LYdyr35l86Fe73eQzgX7nQ66Ha7kdbpdILCmqbBNE202+1IM00TWqWyJfV6vaWqKgzDQLPZRKvVipRmswnDMKCqKur1eouMRqPcj+fnX9VqFZRS5HK5SKGUQqtUto1G4+dkMskSAB8BfAagAXiKKO1Pxw+/AZxSisyg+A/hAAAAAElFTkSuQmCC) no-repeat!important;top:1px!important;padding:0 0 23px 46px !important}#chrome-lhn-menu:active,#chrome-lhn-menu.goog-button-base-open{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAXCAYAAABwOa1vAAAEtElEQVRIic3SXU8aWQDGcdK0Wb3d2M9gvGnMRnvlhW+8SBBjFMFpzAyK00RDNWpQ6kLIYA0jYAkMBFotyujYUkjtfoUmTWv64pVeN+n3+O8FK5WuzXazXe3FLzPnmXPmPMk5pvHx8ZY7d+6ERVFkaGgIp9P5UxkaGkIURSYE4XeXy/WracrrXbNYLLS2ttLW1kZ7ezsdHR10dnbS2dnJ7du3L9XZvh0dHbS3t9PW1kZraysWiwVRFKMmSZLo6urCbrcjCALT09PMzs7i9/u5d+/elfD7/czOzjI9PY0gCNjtdrq6upAkCdPg4CA2m43JyUkCgQCKoqCqKolEgmQyeSUSiQSqqqIoCoFAgMnJSWw2G4ODg5gcDgdut5ulpSVUVSWfz1MsFimVSui6fiVKpRLFYpF8Po+qqiwtLeF2u3E4HJjsdjuSJBEOh9E0DV3XKZfLVCoVqtXqlahUKpTLZXRdR9M0wuEwkiRht9trhX0+H4qiUCgUODg4oFqtcnh4yOHhIS9fvqy7zKxarXJwcEChUEBRFHw+X63wwMBAQ2HDMKhUKrx48aLOZDJ9l/Nr/qtKpYJhGA2FBwYGaoWnpqaIRCLkcjn29vbqV+LsWpyennJyclJ3enp6YXb+SL++Uv82K5fL7O3tkcvliEQiTE1N1QrbbDa8Xi/hcJhMJsPOzg6GYfD06VOePXvW4EdlN27cuPCErl+/Xp9rGAY7OztkMhnC4TBerxebzVYrLIoiq6urpFIptre30XWd/f199vf3MQyj7kdlHz58wOFw0NLSQktLCzdv3sRsNvP+/fv6PF3X2d7eJpVKsbq6iiiKtcJWq5WJiQlWVlZIJpMUCgWKxSK7u7uUSqUGu7u7XLt27btctPb8+OjoCKvVyq1bt+jp6eHo6KhhbrFYpFAokEwmWVlZYWJiAqvVWissCAKBQABVVclms2xtbfHkyZMLHR8fc3x8zMePH+vvF/nW+vNev37N+Pg4r169+tu3ra0tstksqqoSCAQQBOFLYY/Hw+LiIuvr66TTafL5PI8ePeLx48cN/o/s3bt3F+b5fJ50Os36+jqLi4t4PJ5aYYvFwtjYGHNzc0SjUTY3N9E0jVwud6U0TWNzc5NoNMrc3BxjY2NYLJZa4ZGREfx+P5FIhHg8TiqVIp1Ok8lkGnydNTc3N2hqaqKpqalh3NzcfOHab2VneSqVIh6PE4lE8Pv9jIyM1AqbzWaGh4eZmZkhFAoRi8VIJpM8fPjwH719+7bBmzdvGp5nvudfX0smk8RiMUKhEDMzMwwPD2M2m2uFnU4nsiwTDAaJRqPEYjE2NjaIx+NXYmNjg1gsRjQaJRgMIssyTqfzS2Gr1YokSSwsLBAKhVAUhbW1NdbW1njw4MGlOttXURRCoRALCwtIkoTVaq0V9ng8dHd343K5kGWZ+fl5lpeXCQaDBINB7t+/f6nO9l1eXmZ+fh5ZlnG5XHR3d+PxeDAlEonnvb29mM1mRkdHEUURn8+HLMvcvXv3SsiyjM/nQxRFRkdHMZvN9Pb2kkgknps+ffrUl9W0PwRBoL+/n76+vp9Kf38/giCQ1bTDz58/95iAJuA3wA3IPyn3Xx1/+RPcR+aNKjTV2AAAAABJRU5ErkJggg==) no-repeat!important;top:1px!important;padding:0 0 23px 46px !important}#nav{background:#d1d7e2!important;border-right:1px solid #8b8b8b!important}.lhn-hidden #nav{border:1px solid #8b8b8b!important;-webkit-border-bottom-left-radius:5px!important;-webkit-border-bottom-right-radius:5px!important;-moz-border-radius:0 0 5px 5px!important;-webkit-box-shadow:0 5px 8px rgba(0,0,0,0.6)!important;-moz-box-shadow:0 5px 8px rgba(0,0,0,0.6)!important}#lhn-subscriptions{background:#d1d7e2!important;border:none!important}.lhn-hidden #lhn-subscriptions{-webkit-border-bottom-left-radius:5px!important;-webkit-border-bottom-right-radius:5px!important;-moz-border-radius:0 0 5px 5px!important}#lhn-add-subscription-section,#your-items-tree-container,.selector{background:#d1d7e2!important}#lhn-subscriptions .name{padding:0 0 0 20px !important}.lhn-section a,#friends-tree .friends-tree-item-action{color:#708090!important}#reading-list-unread-count.unread-count,.unread-count.folder-unread-count.unread-count-d-1,.unread-count.sub-unread-count.unread-count-d-1,.unread-count.sub-unread-count.unread-count-d-2,.tree-selected .unread-count.sub-unread-count.unread-count-d-2{color:#369!important}#stream-folder-chooser .chooser-item{width:146px!important}#lhn-add-subscription-section .goog-button-base-open .goog-button-body,.scroll-tree li .tree-link-selected,#lhn-selectors .selected{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAVCAYAAACHUoQEAAAAcUlEQVQImWNwrL32nyFi0pP/DOF9j/8zhPQ++s8Q1H3/P4Nv253/DF4td/4zeNTf+M/gWHPtP4Nd2ZX/DBbF5/8zGOee/c9gkHXmP4NO6qn/DOqJR/8zKMcd+c+gEHnoP4N02P7/DJLBe/8ziAfsgRAACIAzvNeNmHoAAAAASUVORK5CYII=) repeat-x!important;margin:0!important}#lhn-add-subscription-section .goog-button-body:hover,.scroll-tree li a:hover,#sub-tree li a:hover,#sub-tree li .updated,#lhn-selectors .selector:hover{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAVCAYAAACHUoQEAAAAZ0lEQVQImQXBXQvBYABA4fPjpYhy4WIavTX5ajEpom1IUrJIDT/neB6SdSVZ+ZOs/Mqq+Eia17LY1zLbvWWyfUmyeUrIKhkuHxKndxnMb9KfXqU3vkg3nKUTTtIeHaUVF9KMcmlEB/9zzEA2wM3cSQAAAABJRU5ErkJggg==) repeat-x!important;margin:0!important}.icon.folder-icon.icon-d-1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB2UlEQVQ4jc3TSU9aYRiG4fPDTFwYFy6MiQm4UusAWhxQDMhBQC22pVVQDnCQ0ZEyisIBwTLjSnDVP3R3Q1ptbGNc9U2u5f18q08Q/otTmT2KWpR4SmX2KK8eUIsS/sqPZ/4c/Oe4WpQ4zHdfTS1K/IonbGFlwh7hTWxhRVBZg4Qqjy8Klh85LvcI3PaQSz38xS6+Yhev8oCn8IDKGkQYF2WcmftnPqfv+ZTqsJfq4Ei2+ZBos/OtxXa8he2yydZFE8t5g3FRRhgzSb+jdIePqQ57/Wi3H9kvm1j7kXjWwHxax3RSY8wkIYwaXP2ogyPRZrf/mj3ewnbRZOtJtHlSwxirsRGrsh6tMmpwIYysOtmJN9i+rGO/qGM9r2E5qyGeVtk8qWKMVtmIfscQuWMtfIc+VGE1WGH5uMzIqhNhWOfAEqtgjlYwRcoYw2U2Qresh0rogyX0gSIrssKSX0HnK7DoLbDgzaOV8gzrHAhDGjuGQIE1OY9evmHFf8Oy7xqd95r3Uo4FTw7tUQ7NYY559xVz7itm3VlmXFmGNHaEwRkLS54suqMMi4cZtO40Glea+YMUcwcpZveTvNtPMv01wfSXBFNPDM5YEAYmjcrAlJE3mTS+/r/87X4C6Cv7ugda0GYAAAAASUVORK5CYII=)!important}.folder.unselectable.collapsed .icon.folder-icon.icon-d-1{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACUklEQVQ4ja3T20vaARjG8d+/1W4iiCCIIMJqNxutbW1FNrfWtOy0Sau0UDtYanZcecoOmmmetTI7q2kHa1Crv+O7mxGNbRCxBz6Xz8N78wrC/4hIqnFWyLTcJ5JqnA8eqJBpGfakflMh0/KgcmWbwVnZbuRR2gxOQSTXEzu5/ato9pZI9oZw5oZQ5geB42sCqWt8ySu8yStEcj1Ceesorv3vd5x7lyzvXrK0c4EjccHCdg5b/BzL1jnzG2d8i50yEz1hKpylvHUUoUw6xMqv0uLOBY5EDvt2Dmv8HPPmGXMbp8zGTpmOnDAZzmIKZjAEjhnzpSmTDiGUNqlZSOSwx3NYt+6VoidMRbJMhLKMBzMY/MeM+tKMeFMMriXRuI8obVIjlEhUf5xmCmUwBo7R+9Po1lMMe5IMrh2hXj1kwHWAcmWf3qU9SiQqhGJxD6ZgGqM/xZgvhc6bZNhzhNZ9iNp1QL9zH+XyHj2Lu3Q7dlDYE3TZtumwxCkW9yAU1SkYXN1D49xlYHkH1VKCPkeCnoVtum1xvli36LJs0jG/gXwuRstsFOlMhObpMEV1CoTC2k567Rt8tcVQWGJ8no/SMRehbTZM60wI2VSIT5NBPpoCfDD5kYz7aDSuI9avU1jbiVBQI6d9NkjbdICWKT/SCR/NpnWajF7eG7y803toHF2jQeemXuembmSVN8MuaodcFNTIEfKrZYiHHDRoF6jX2HmrtlE7YOV1v5VXKgsvVWZeKM1UK8087zPzrHf+Tn61DCGvSuJ88lTCY+RVSR7+cP/KT4dEPr+OEU6HAAAAAElFTkSuQmCC)!important}.collapsed .toggle.folder-toggle.toggle-d-1,.collapsed .toggle.folder-toggle.toggle-d-0{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAASklEQVQYlWNggIBMBgYGFQYiQBcURzAwMAgRo7CLgYGhlYGBwZ2BgYGZkEIYzmNgYJAgRiEMyxNSmMbAwCCCz8QmYtxI0NcEwxEALfsTN9gUUSQAAAAASUVORK5CYII=) no-repeat center!important}.toggle.folder-toggle.toggle-d-1,.toggle.folder-toggle.toggle-d-0{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAAS0lEQVQYlWNgIAFkMjAwdOHBmTCFKgQUqiCbGoFDUQS69UIMDAxNaIpaoeIYwB1NoTsuTzEzMDCkQRXlQfk4gQhUoQQ+RTAgj00QALnzEzeoJyUDAAAAAElFTkSuQmCC) no-repeat center!important}#search{z-index:1!important;top:4px!important;right:120px!important;background:transparent!important;margin-left:auto!important;width:285px!important;-webkit-border-radius:10px!important;-moz-border-radius:10px!important}#search-input{-webkit-appearance:none!important;-moz-appearance:none!important;background:#fff!important;height:14px!important;width:188px!important;right:130px!important;padding-right:8px!important;padding-left:87px!important;border:none!important;-webkit-border-radius:10px!important;-moz-border-radius:10px!important;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.9)!important}#search-input:focus{color:#000!important;-webkit-box-shadow:0 0 4px 1px #2878d4!important;-moz-box-shadow:inset 0 0 2px 1px rgba(40,120,212,0.7), 0 0 4px 1px #2878d4 inset 0 1px 1px rgba(0,0,0,0.9)!important}#search-restrict{border:none!important;position:absolute!important;top:1px!important;left:20px!important;margin:0 0 0 1px !important}#search-restrict-button .goog-menu-button .goog-button-base-content{padding:0!important}#search-restrict-button .goog-button-base-outer-box,#search-restrict-button .goog-button-body{-webkit-appearance:none!important;-moz-appearance:none!important;border:none!important;background-color:transparent!important}#search-restrict-button .goog-button-base-inner-box{border:none!important;background-color:transparent!important;width:63px!important;border-right:1px dashed #999!important;padding:0!important}#search-restrict-input{background:transparent!important;width:56px!important}#search-restrict-input:focus{-webkit-box-shadow:0 0 4px 1px #2878d4!important;-moz-box-shadow:inset 0 0 2px 1px rgba(40,120,212,0.7), 0 0 4px 1px #2878d4!important}#search-submit{position:absolute!important;top:3px!important;left:3px!important;text-indent:-9999px!important;font-size:0!important;height:16px!important;-webkit-border-radius:10px!important;-moz-border-radius:10px 0 0 10px!important;padding:3px 16px 0 1px !important}#search-submit:not(:hover){background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAo0lEQVQ4jbWSMQ6DMAxFX5KtnThBJxYuwN52gC3u/Q/T5UeKUJwGoVr6i/P9bIPhDxGACCQpKjcUCXgAK7BJq3JppHgBMmAHZb25kKAuGdhlnqRFuSxPc52oUa3qFKQymckTvfE3maZDl6CcydNc4zLg8gojH9GA2QOUNbzfaMAHeAJ3OoflHdIMvAX6CWmdclTRq4LcPEAPXCD5bHENOd25G1+f7RN5dg0R8gAAAABJRU5ErkJggg==) no-repeat!important}#search-submit:hover{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAArElEQVQ4jbWS0QnDMBBDn2M8QekAGSQD5DtzZIq29Dd0AeOQQfsjg0l9rUOoQD9nne5kG/6ADvBAEL1qTQjAAMzAIs6qhZbmCYhA2jHqzDTpNCUCL4l7cVItSlON47VqKiY5MW+WpPHW+otEvRoznGpJmmqM0wanI7Rc4gqMlkGOYT3jCmzAHbjuIn6Y1D7SCDxldPtlUvvKXk2PwuRiGVhwhUk82lyaHJ78FW9WySaEE+MSawAAAABJRU5ErkJggg==) no-repeat!important}#search-restrict .goog-menu.goog-menu-vertical{max-height:480px!important;font-size:12px!important}#search-input,#search-restrict-input,#viewer-search-parent,#viewer-search-item-parent{color:#999!important;font-size:12px!important}#search-input:hover,#search-restrict-input:hover{color:#000!important;font-size:12px!important}#viewer-single-item-parent .single-item-return-link,#viewer-allcomments-toggle,#viewer-allcomments-return{line-height:16px!important;padding-top:1px!important;padding-right:6px!important;color:#fff!important;text-decoration:none!important;-webkit-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAVCAYAAACZm7S3AAABQElEQVQ4jZWRPavCMBiFz2LapbQUtEOLUn+DuGu0seIHooiDOujSqOnk/z93uHAvom1jINN5nkPyvoDFMcYwTVOmacp+v888z6m1ZqNYFAV7vR6fz+cLLKWsl6/XK5MkYVmWb2CSJNXy+XxmHMcsiuIjFMfxZ/lwODCKIl4ul8r2KIres91ux3a7zdPpVPunTqfzmq/Xa4ZhyP1+3zjJMAz/mfl8ziAIuNlsmlcAIAiCX04pRd/3uVqtrEQA8H2fWCwW9DyPSilrEQA8zyO22y2FEFwul1/JQghiNBpRa00hxPcyAIzHY2qt2Wq1rAteWCklb7eb9QveOCkn1gUfmcnErqAyn04z3h8POo5TWVCXIcsyPmoKauWmgm632zxYpRSNMXRdl67r0nEcDodDDgYDu7XOZjmNKf/u8XgkAPwAuWKTIVoYWDkAAAAASUVORK5CYII=) 1 2 2 12 stretch stretch!important;-moz-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAVCAYAAACZm7S3AAABQElEQVQ4jZWRPavCMBiFz2LapbQUtEOLUn+DuGu0seIHooiDOujSqOnk/z93uHAvom1jINN5nkPyvoDFMcYwTVOmacp+v888z6m1ZqNYFAV7vR6fz+cLLKWsl6/XK5MkYVmWb2CSJNXy+XxmHMcsiuIjFMfxZ/lwODCKIl4ul8r2KIres91ux3a7zdPpVPunTqfzmq/Xa4ZhyP1+3zjJMAz/mfl8ziAIuNlsmlcAIAiCX04pRd/3uVqtrEQA8H2fWCwW9DyPSilrEQA8zyO22y2FEFwul1/JQghiNBpRa00hxPcyAIzHY2qt2Wq1rAteWCklb7eb9QveOCkn1gUfmcnErqAyn04z3h8POo5TWVCXIcsyPmoKauWmgm632zxYpRSNMXRdl67r0nEcDodDDgYDu7XOZjmNKf/u8XgkAPwAuWKTIVoYWDkAAAAASUVORK5CYII=) 1 2 2 12 stretch stretch!important;border-width:1px 2px 2px 12px !important}#viewer-allcomments-toggle{margin-right:105px!important}#viewer-single-item-parent .single-item-return-link:active,#viewer-allcomments-toggle:active,#viewer-allcomments-return:active{-webkit-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAVCAYAAACZm7S3AAABTUlEQVQ4jZWUMavCMBSFz2LbpbQUtEOLUre6CeKgk1YTWwoddFAQFx2Mmvf/t/MGRZFWWy98JJfc7yRTgAaltWYURYyiiP1+n2maUinFWvF8PrPX61Fr/UaSJN/l4/HIMAx5Op1KhGH4WT4cDgyCgLvdrpIgCKrl7XZL3/dZFMVHfN8vy5vNhu12m1JKCiEohKCUstR3Op13uSgKep7HyWTC6XT6pKr3PO8lZ1lG13U5HA4b4bruXZZS0nEcxnHMwWDAOI7f9lWr4zhEnue0bZsAfsK2bWK9XtMwjJ9lwzCI2WxGpdTPAY95YD6fUynFVqvVWH7M3itJEl4ul8YveN78Clg0DijJALBYNAuolAFguRS83m40TfOj/DirLiEEb18Cvsp1Ad1ut/4nkVJSa03LsmhZFk3T5Hg85mg0qpcBYLVKqfXfk/1+TwD4B0ucPYvYKQl0AAAAAElFTkSuQmCC) 1 2 2 12 stretch stretch!important;-moz-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAVCAYAAACZm7S3AAABTUlEQVQ4jZWUMavCMBSFz2LbpbQUtEOLUre6CeKgk1YTWwoddFAQFx2Mmvf/t/MGRZFWWy98JJfc7yRTgAaltWYURYyiiP1+n2maUinFWvF8PrPX61Fr/UaSJN/l4/HIMAx5Op1KhGH4WT4cDgyCgLvdrpIgCKrl7XZL3/dZFMVHfN8vy5vNhu12m1JKCiEohKCUstR3Op13uSgKep7HyWTC6XT6pKr3PO8lZ1lG13U5HA4b4bruXZZS0nEcxnHMwWDAOI7f9lWr4zhEnue0bZsAfsK2bWK9XtMwjJ9lwzCI2WxGpdTPAY95YD6fUynFVqvVWH7M3itJEl4ul8YveN78Clg0DijJALBYNAuolAFguRS83m40TfOj/DirLiEEb18Cvsp1Ad1ut/4nkVJSa03LsmhZFk3T5Hg85mg0qpcBYLVKqfXfk/1+TwD4B0ucPYvYKQl0AAAAAElFTkSuQmCC) 1 2 2 12 stretch stretch!important}#entries.search #current-entry.read{border-color:#9af3ac!important}#viewer-single-parent{margin-top:2px!important;margin-right:170px!important;color:#fff!important;text-shadow:0 1px #404040!important}#viewer-top-controls{border-bottom:1px solid #404040!important;font-size:12px!important;padding:5px 3px 4px 8px !important}#viewer-top-controls/*,#trends .tab-group,#directory-contents .tab-group*/{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAdCAYAAABrAQZpAAAAbElEQVQImU3EoRIFEQAF0PtdWOybVwQzgiAoiiJJiiL4Bp97N+3MnnBwziH23sRai5hzEmMMovdOtNaIWitRSiFyzkRKiYgxEiEEwntPCCG+SSkJKRWhlCKuSxNaa8IY82Ytcds/8bvfnHN8AG6EOWbVTEXzAAAAAElFTkSuQmCC)!important}#viewer-all-new-links,#viewer-comments-all-links{margin-top:3px!important;margin-left:-1px!important;color:transparent!important;font-size:0!important;line-height:13px!important;-webkit-border-radius:2px!important;-moz-border-radius:2px!important}#view-cards,#show-new,#show-commented{font-size:12px!important;margin-left:0!important;-webkit-border-top-left-radius:2px!important;-webkit-border-bottom-left-radius:2px!important;-moz-border-radius:2px 0 0 2px!important;-webkit-box-shadow:0 1px #5a5a5b!important;-moz-box-shadow:0 1px #5a5a5b!important}#view-list,#show-all,#show-all-shared{font-size:12px!important;margin-left:-2px!important;-webkit-border-top-right-radius:2px!important;-webkit-border-bottom-right-radius:2px!important;-moz-border-radius:0 2px 2px 0!important;-webkit-box-shadow:0 1px #5a5a5b!important;-moz-box-shadow:0 1px #5a5a5b!important}#show-all,#show-all-shared{margin-right:6px!important}#chrome.search-stream #view-cards{-webkit-border-radius:0!important;-moz-border-radius:0!important}#view-search{font-size:12px!important;margin-right:-2px!important;-webkit-border-top-left-radius:2px!important;-webkit-border-bottom-left-radius:2px!important;-moz-border-radius:2px 0 0 2px!important;-webkit-box-shadow:0 1px #5a5a5b!important;-moz-box-shadow:0 1px #5a5a5b!important}#view-cards,#view-list,#show-new,#show-all,#view-search,#show-commented,#show-all-shared{background:#323232 url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAJCAYAAADzRkbkAAAALklEQVQImQXBIQIAAAQEwXuookiapGmSN68Z3R3aXTQzqLtRVaHMRBGB3B2ZGQ/qgxUlW0iG0QAAAABJRU5ErkJggg==) repeat-x!important;background-position:0 -1px!important;border:1px solid #000!important;padding:2px 5px 1px!important}#view-cards:active,#view-list:active,#view-cards.link-selected,#view-list.link-selected,#show-new:active,#show-all:active,#show-new.link-selected,#show-all.link-selected,#view-search:active,#view-search.link-selected,#show-commented:active,#show-commented.link-selected,#show-all-shared:active,#show-all-shared.link-selected{background:#000 url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAJCAYAAADzRkbkAAAAL0lEQVQImQXBIQIAAAQEwfuMKKqyKKuy/8c1o7tDu4tmBnU3qiqUmSgikLsjM+MBiqQQjX6lTZ4AAAAASUVORK5CYII=) repeat-x!important;font-weight:400!important}#view-cards:active,#view-list:active,#view-cards.link-selected,#view-list.link-selected,#show-new:active,#show-all:active,#show-new.link-selected,#show-all.link-selected #view-search:active,#view-search.link-selected{background-position:0 -1px!important}#viewer-top-controls .goog-button-base{border-bottom:1px solid #5A5A5B!important;margin:0!important}#viewer-top-controls .goog-button-base-outer-box{border-top:1px solid #000!important;border-bottom:1px solid #000!important}#viewer-top-controls .goog-button-base-inner-box{border-left:1px solid #000!important;border-right:1px solid #000!important;background:#323232!important}#viewer-top-controls .goog-button-base-top-shadow{border-bottom:none!important;background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAASCAYAAACaV7S8AAAAP0lEQVQImWXIoREAMQgEwGsNhjJiMCgcCheHouZ7nzcrFrtLzAxx7yW6m6gqIjOJiCDcnTjnEGZGiMgPVX3vA/34JQPPLvviAAAAAElFTkSuQmCC)!important}#viewer-top-controls .goog-button-base-content{line-height:17px!important;color:#fff!important}#viewer-top-controls .goog-menu-button.goog-button-base-open .goog-button-base-inner-box,#viewer-top-controls .goog-button-base-inner-box:active{border-left:1px solid #000!important;border-right:1px solid #000!important;background:#000!important}#viewer-top-controls .goog-menu-button.goog-button-base-open .goog-button-base-top-shadow,#viewer-top-controls .goog-button-base:active .goog-button-base-top-shadow{border-bottom:none!important;background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAJCAYAAADzRkbkAAAAL0lEQVQImQXBIQIAAAQEwfuMKKqyKKuy/8c1o7tDu4tmBnU3qiqUmSgikLsjM+MBiqQQjX6lTZ4AAAAASUVORK5CYII=)!important}#stream-prefs-menu .goog-button-base-content{padding-right:.461em!important}#global-info{z-index:2!important;right:0!important;background-position:center!important;background-repeat:no-repeat!important;color:transparent!important;font-size:0!important;margin:0 1px 0 0 !important}#settings-link,#help-link,#sign-out,#global-info a{width:26px!important;height:23px!important;display:block!important;float:left!important;text-indent:-9999px!important;margin:-1px -1px 0 0 !important}#global-info a#settings-link{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAC60lEQVRIibXWv2siaRwG8C8jg0wQFIQUhwQMiTIwYJEwMKS1sNTtLa65+wfu2psilRcImzbFomCTIGEaYRhhwKzyFjJIfkgKtXAFG3+AxZBbyPlcseQdNvsO2eJ84VPMfN/3eWCaeYmClSOiP4nobyI625JvRcfHx58eHx+nm83mX2xpERHRzs7OXw8PD19eXl6wTUREJEnSx+fn583Xf77iPavVCkTErVard8+8ev2MZ77vI0y320U+n4fv+1gul5AkiVsul/B9H/l8Ht1uNzTD9/2gbL1eQ6TT6UBRFMiyDMMwMBwOoSgKNxwOYRgGZFmGoijodDrCnPV6HZQtFguIlMtlxONxJBIJxGIxSJKERCLBSZKEWCyGRCKBeDyOcrkszFksFkHZbDaDyHw+h2ma2N3dfZdpmpjP58Kc2WwWlE0mE4QZDAZIpVJIpVLIZDKo1+vwPA/1eh2ZTIbPBoNBaMZkMgnKxuMx3opEIohEIohGo0in00in02g0GphOpxiPx5hOp2g0GnwWjUb5GVEeL3t6esJbBwcHP+j3+9/t6ff7wn2iPF52f3+Pt1RV/UG1Wv1uT7VaFe4T5fEyz/Pw1mg0wmg0AmMMmqZB0zSoqoparQbP81Cr1aCqKp8xxvgZUR4vY4whTKlUQi6XQy6Xg6ZpSCaTkGUZyWQSmqbxWalUCs1gjAVln29vIVIsFpHNZnF0dPSubDaLYrEozPl8exuUua4LkVarhUKhAF3XYZomHMeBruuc4zgwTRO6rqNQKKDVaglzXNcNymzbhojrumi326hUKuj1erBtG4ZhcLZto9froVKpoN1uw3VdYY5t20FZs9lEGMdxwBjjzycnJ9zrO8YYHMcJzWg2m8EvxrKsjWVZ+Bl3d3fcz56xLOtb2d7eXuXi4mJ6c3ODbSIiotPT01/39/c/nZ+ff7m6utpcX19jG4iICMAvl5eXfxweHp5JkvTxf7rchF54CMAegA8AfgPw+zb8B0lORcLrtCJ4AAAAAElFTkSuQmCC)!important}#global-info a#settings-link:active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAEkElEQVRIibWWQUsbWxiGh5GgLRYDQheXIAgdRB0I1BIoLV1USFtQWhRbIyFEa2Ja2iqNNpiQGCdNMDfRsZlGYqRpYiQTCIMKoQt3+lfa3+FzF+LkSu3twtuBZzHn+14e+GY45whC67ELgrAkCMLfgiBk/hBnIovFUrbZbD9kWT69c+cOd+/evTJDQ0PY7Xb6+/ux2WwIgiAI169fj92+ffvH6Ogobrcbv9/Pu3fvrozP58Pj8TA2NsbDhw/PZKIobj558uT05cuXhEIhFEVhfX39UlKpFIIgmKRSqV/2KopCOBwmEAgwPj7O+RgzLpeLpaUl0mtpClsFqtWqiaIoDA4OUi6XqVariKJoct4zODiIoigXcoWtAtlslnA4jNfrbcmmp6eJxWJomka1WsUwDAzDIJvN0tHRgcViYWBgAMMwuHbtmolhGAwMDGCxWOjo6CCbzZrZvb09ClsFFEXB7/e3ZD6fD0VR2N7eRtd1Dg4OODg4YGRkhK6uLqxWK52dnYiiiNVqNRFFkc7OTqxWK11dXYyMjJhZXdfZ2dkhmUwSCAQul9VqNfb399nf3+f4+JhgMMjNmzd/SzAY5Pj42Mz+WzY3N9eSzc7OEo/H2crn2dvbM0dhGAbNZhObzYbNZkOSJHK5HM1mk1wuhyRJZq3ZbF7InY8xkUhcHOPMzIz5zb5+/Uq9XqetrY22tjba29vp7e2lt7eXYrHI0dER9Xqdo6MjisWiWWtvbzcz9XqdcrmMpmnE43F8Pl9L5vV6iUQibG5u8uXLF2q1Grdu3fqJRqNBrVYzaTQal/bVajVKpRKfPn0iGo0yMzPTknk8HpaXl1lfX2d7e5vdyi79/f0/sbq6ym5l12R1dfXSvt3KLsVikY2NDSKRyMVf3+12EwqFSK+l+fz5M6VSiZOTE05OTjg8PESWZWRZRpIkYrEYpVKJWCyGJElm7fDw0MyUSiW28nkymQzLy8t4PJ6WbMo1xWJwkVQqRS6XY2dnx8TpdGK327Hb7ciyTHd3NxaLhe7ubmRZNmtOp/NCLpfLkV5L8+HDB9xud0s2OTnJ/Pw8iUSCjY0NtvJ5tvJ5hoeH6evrY2ho6Lf09fUxPDxsZlVVJZlMshhcZMo11ZJNTEzw9u1b4vE4mUwGTdPQNI1KpYLT6cThcBAKhdB1HYfDYaLrOqFQCIfDgdPppFKpmNlsNouiKMzPzzM5OdmSjY+P8/r1a6LRKOm1NKqqoqoqhUKBRqPBysoKhmGgquqFY0RVVQzDYGVlhUajQaFQMLPptTSxWIw3b97w/PnzluzZs2f4/X7C4TCJRIJMJmOiaRq6rpvv9+7dMzlf03UdTdMu5D5+/EgkEuHVq1etXV8Uxc3Hjx+fTk9PE3wfJBqNkkwmf8m3b99M/qsvGo2ytLTE7OwsT58+PZP19PSkHQ7H9xcvXuD3+3m/sEAkErky7xcWCAQCuKfcPHr06EyWSCSmb9y4UX7w4MH3iYmJU6/Xy9zc3JXxer24XC5GR0e5f//+mQz4q1gsLkqSlBFFcfN/utz88sIjAD3AGOAH5v4E/wCiodrt8Cv+HAAAAABJRU5ErkJggg==)!important}#global-info a{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAACZUlEQVRIib3WsUvjYAAF8DeXtkOLi1WDibYIiU1oEpp8W7Hg7Oh8cIP+Da4Ohwj+AToU6lVQAjUQe1BpHTq5mEEXB0GcXByEE4R3Q0hBrE1vqB/8xvceHx+BANH59U0ASZL4HQcAsLi4yPf396kDAMiyzLe/b1MHAFAUha+vrxPZ39/n1tYWG43GxJkYAGB5eZkvLy+JNjY2mE6nmclkmEqluLOzM1EuBgAoFot8fn4eq9PpMJfLcX5+nrIss1AoUJZlPj4+JmZjAIBSqcSnp6exdnd3qSgKDcOgZVksl8uUJIkXFxeJ2RgAYGVlhQ8PD2Pt7e1R13W6rkshBB3HoaqqbLVaidkYAEBVVd7f34/leR5N06QQYkjXdV5eXiZmYwAATdN4e3ubqFarfRhbX1+fKBcDAKyurvLm5masMAx5dHT0Yezw8JBhGCZmYwCAcrnM6+vrRGEYDoccx2EQBBPlYgAAwzA4GAzGajab3N7eHr6bZVms1+s8ODhgr9dLzA8Gg2jMNE1e9fsj/T4+pqZpTKVSnJubo2EYFELQNE1KksRsNstMJsPNzU3+6XS+7Lnq96Mxy7LY7XZHWltbYy6X4+zsLEulEm3bphCC1WqVqqpyYWGBMzMzzGazrNfrX/Z0u91ozLZtBkHwyfn5OQuFAovFInVdp23bw+8sHqxUKtQ0jbIsM5/Ps9VqjewKgiAaq1ar9H3/k9PTUy4tLQ1v8xXXdWmaJhVFYbPZHNnl+3405jgOPc/7pN1u8+7u7r/4vj+yy/O8aMx1XZ6dnU0dAEAIwZOTk6nDt//wkPxB8ue0/QNmzb86i+HRxQAAAABJRU5ErkJggg==)!important}#global-info a:active{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAELklEQVRIib3WXWvaegDHca9L14uO3ayuMu0Dgp2KD1PjRSls3U0pVOiqiITiQwqylvVh1GBpY8PqkppTQ0QUpGeVdYw99EXsfX3PRbCbuHE4lDPhc/cLX/xHQxwO+6P9IQ6Hy+XC6XTi9Xrx+/2EQiHi8fidhUIh/H4/Xq8Xp9OJw+FwOB4/fszS0hJra2vkcjkKhQKvXr26s0KhQC6XY21tjaWlJTvmdrtJpVJIkkSlUkFRFM7Pz+9MURQqlQqSJJFKpeyYx+NBFEUqlQq6rtNutbm6uvolURR58eIF5XL5t5uBdquNrutUKhVEUbRjs7OzFItFFEWh3WrT7/f58uXLCEEQGB8f5969e4yNjZHJZH65G+j3+7RbbRRFoVgs2rG5uTkkSUJVVbrdLtfX19zc3Ax59+4dk5OTPHr0CLfbzdTUFNPT03z69GlkO3B9fU2320VVVSRJsmPz8/OUSqWh2Ldv34aUy2U8Hg/BYJBIJILf78flctFoNEa2Az/HSqWSHfN6vRSLRWq12m+P8c2bNwQCARKJBIIgEI/H8fl8vH379l+PsVar/ThGn89HoVDg+PgY0zS5vLzk48ePQ5rNJuFwGEEQbgUCATqdzsh24PLyEtM0OT4+plAo2LGFhQU2NzepVqtcXFzQ6/X48OHDkK9fv7K4uDgUe/bsGZ8/fx7ZDvR6PS4uLqhWq2xubtqxJ0+eIIoisizTaDTodDq8//v9kP5VH8MwhmLn5+dcvb8a2Q50Oh0ajQayLP/46fv9fnK5HIeHh2iaRsuy6PV6I25ubm5D8XicTqfzy91Ay7LQNI3Dw0NyuZwdCwaDZLNZDg4OqJ/VaTabdLvdIScnJ7x8+fL2vkUiEZLJJLu7u1iWNbLvdrs0m03qZ3UODg7IZrN2LBwOk0ln2NvdQ1VVDMOgZVm0LAvl5ISZmRnGxsZwOp0Eg0EEQSAcDuNyuZiYmGB8fJznz5/z10/XtSwLwzBQVZW93T0y6Ywdi0QibGxssL29jaIo6LqOaZqYpkksFmNycpKHDx8yPz9PNBpFEARisRg+n4/p6WkePHjAxMQET58+vb3ONE10XUdRFLa3t9nY2LBj0WiU9fV1yuUyR0dH1M/qGIaBrutMTU0xNzdHIBAgGo3e/s8GwVAoxMLCAm63m/v371Or1TAMA8MwqJ/VOTo6olwus76+bsdisRipVIqtrS1kWeb09BRN01BVlZmZmdtv8zuJRIJwOIzH46FWq6FpGpqmcXp6iizLbG1t/Xjqx+NxVldXyefz7O/vU61WUVWVer3O9+/f/xNd11FVFVVVqVar7O/vk8/nWV1dtWOJRILl5WWymSySJPF6ZwdZlu/s9c4OkiSRzWRZXl62Y4IgkEwmWVlZIZ1OI4oipVLpzkRRJJ1Os7KyQjKZxPHHX3iAPFD6v/0D/AM0znFW+TsAAAAASUVORK5CYII=)!important}#global-info a#help-link{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAADjElEQVRIib2WP0gyfxzHb4xQarE4SOI0Fa1TRD3vD4hBBIJQbW4N/UAkpGiphloCG5wKnBqeh5asQExQxPCq6wEVkvQKnHzAIScbHIQnCN6/4SjwOXueZ6kvvKb7fl+vuw/f4QhCWfEvgiAmJyfxFYsgCIKgKAqvr6+fDkEQBGEwGPDy6+Wv/Gz+xPdv37G7u4tYLIbkSRLtp/Y/nX359aLEjEYjer3eh8iyjIWFBQwNDUGj0UCr1UKr1WJ4eBgajQaRSARPT09/dPR6PSVmMpnQ7XYHks1modPpMDo6ivHxcej1elAUBYqioNfrMTY2hpGREVgsFtRqtQ893W5XiZnNZnQ6HRWVSgUkSYIkSZhMJqysrOD8/Bz1eh2SJGFraws0TcNoNEKn08Fut6PZbA50dTodJWaxWNBut1UEAgFMTEyApmkwDIPV1VVsb28jFAphb28Pz8/PiEaj8Hg8sNlsIEkSGxsbA13tdluJWa1WtFqtPkRRBEmSoGkaLMuC4zg4nU5YrVaYTCZMTU2hWq0iHo+D53l4vV5YrVbo9Xo0Gg2Vr9VqKbGZmRk0m80+9vf3YTab4fV6IQgCOI6Dy+UCTdOYnp5GOBzG4+MjAoEAWJaFIAjweDwwGAw4PT1V+ZrNphKjaRqNRqOP9fV1OBwO8DwPQRDA8zw4jgPLslhcXIQsywgGg7BYLO8vxPM8aJrG4eGhytdoNJSY3W6HLMt9bG5uwu12QxAEFblcDmtra6AoCjRNg+O492dOpxMHBwcqnyzLSszhcKBarfYRj8fBMIwqFAgE8PDwAL/fD5vNptrjcrlwcnKi8lWrVSXmdDpRKpX6yOVyA2N+vx/hcBgOhwNut/t9zG/4fD5UKhWVr1QqKTG3241bSeqjUi4jEon0iXieh8/nQzQaBcMwfeN7IxaL4cftrcp3K0lKzOPxQBRFFTc3N5ifn++LBYNBZDIZzM3Nqb4qFAqhUqkMdImiqMQYhkE+n1dRLBaRy+WwtLT0Hnu7/r+PcHl5GZIkoVAoDHTl83klxrIsstnsQERRxP39PXZ2dgbGZmdnkUgkUK/XUSgUPvRks1klxnEc0un0h2QyGZTLZdzd3eH4+BiJRAJHR0dIJpOo1WqQJAkXFxd/dKTTaSXG8zxSqdRfyWQyKBaLuL6+xtXVFS4vL5FOp//pbCqVUmKCIODs7OzTIb78hwfAfwDCn83//IUvmHzJ7pYAAAAASUVORK5CYII=)!important;margin-right:0!important}#global-info a#help-link:active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAFHklEQVRIib2WTU8TexSHuzREookR0wQ0BQspOjSkL/SFGK3RsikkVEkhk2ZsaDtEEHOvJbZjG5hSQ52W2tY2pU2QdzSAdOOC+AX8Vs9dNNRwcWfuneRZzTnnmfnlzD+j07Uu7X9Cp7tz5w7d3d2YTCbMZjMWiwWn0/nHWCwWzGYzJpOJ7u5udDqdTmcwGPB4PExOThIMBgmHw7x69eqPCYfDBINBJicn8Xg8LVlvby9+vx9ZlkkkEqiqSj6fv0QqlUIURcbGxhgfH0eSJNLp9G9r8/k8qqqSSCSQZRm/39+S9fX1IUkSiUSCXC5HrVpjd3e3TS6Xw263c+XKFa5evUpnZyednZ10dHTQ0dHB06dP2djYuNCzu7tLrVojl8uRSCSQJKklMxqNRCIRVFWlVq2xt7fHyckJJycnqKrKjRs3uH79Ordu3aKnpweDwYDBYKCnp4euri6uXbvG7du3+fTpU7vv5OSEvb09atUaqqoSiURasv7+fmRZJpPJ0Gg0ODw8pNlsUqlU6OrqQq/XYzQaEUWRjY0Nzs7OOD4+ZmFhAUEQ6Ovr4+bNmxiNRvb392k2mzSbTQ4PD2k0GmQyGWRZbskGBgaIRqMXZKenp7jdbrq7uxEEAbvdTigUQpZlxsfHWVhY4OfPn0QiEWw2G4ODg+j1egKBAKenp5yenl6QRaPRlsxkMhGJREin0+0Yi8Uier0eQRBwOBw4nU6Gh4cxmUwYjUbu3r3L58+feffuHS6Xi5GRkfaKHxwcXIgxnU7/ivH+/fuEw2GWl5cpl8tsbW3x8uVL+vv7GRkZwe12t78bQRC4d+8ewWCQ/f19Hj9+jMPhwO12Y7PZ6O3tZWVlhS9fvrC1tUW5XGZ5eZlwONySCYJAKBQimUxSLBbZ3NxEkiTMZjMulwu3243L5cLpdOJwOPD5fHz//p2HDx8yMDDQfiCXy4UgCLx9+5aDgwM2NzcpFoskk0lCoVBLNjQ0hCRJKIrC+vo69XqdaCSK1WrF7XZfYmdnB1EUMRgMCIKA0+ls3xseHiYRT7CzvUO9Xmd9fR1FUX6tvtlsJhgMEo/H0TSNaqVCPB7HbrdfEnm9Xo6Pj3G5XAwODl6qsVgsaJrG5uYm1UoFTdOIx+MEg8GWbHh4GFEUWVpaIruWpVQqUa/Xfyt78OABz58/Z2hoCKvV2o75nNHRUfb29mg0GpRKJbJrWZaWlhBFsSWzWq3MTM/w5u83ZDIZCoUC21tbhEKhC4POB7948QKbzXYhvnOURIKNWo1qpUKhUCCTyfDm7zfMTM+0ZDabjUAgwOLiIqqqksvlKJfLfP36lSdPnlyQjY2N0Wg08Hg8l97q2bNnHB0dUS6XKZfL5HI5VFVlcXGRQCDQktntdqamppifnyeVSpFdy1IoFKjVahwcHDAxMdGWna//vyOcmZnh27dvlEolCoUChUKB7FqWVCrF/Pw8U1NTLZnD4cDv9zM3N4eiKKyurqJpGpqmtY+nWCz2W9mjR4/48OEDZ2dnlMvldp+maayurqIoCnNzc79OfafTycTEBLOzs8RiMZLJJJlMps3a2hpHR0ftgdlslnw+T71e58ePH2xvb/P+/fsLPZlMhmQySSwWY3Z2lomJiZbM5XLh9XoRZ0RkWeav169RFOUSKysrlEolarUa1WqVjx8/kkqlflurKAp/vX6NLMuIMyJer7clO19Zn8/H9PQ0kiQRjUb/GEmSmJ6exufzMTo6iu5//+EBZoHof80/AHLXvOdV/WIAAAAASUVORK5CYII=)!important}#global-info a#sign-out{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAADFklEQVRIibXWP0gjCRgF8I+UQcXCRosJZjKRBJ0QkhnNCILBP60cYisnx24VG3f3ihxaWOmArCFCkL0FC72NSHDAgaQwB5GQNGli4tj4J7MwhQS8FOItuHlXhD24IzOxycCve+99MM0MEZHcRdtE9J6IfERE5HA40K2n2Wx+r1QqX4PB4Gci8tHw8DBeXl666vLyUrfb7evkdDrx7e9vlhp/NbC+vo4vf3zpmG3n+fm5abPZPhLLsnh6erIUi8XQ09OD/v5+6LreMd8OEcnEcRwajYYlVVXhcDgQCoXw8PDQMd8OEcnkdrtRr9ctPT4+olAoYG9vD6urq4hEIojH44jH49B1vWO/Xq+3jo2MjMAwDEu5XA6SJMHr9WJwcBB9fX3o7e2F3W7H4uJix75hGK1jHo8HtVrNlKZpCAQCcLlc8Hg8cLvdEAQB9/f3UFUVAwMDyOfzlhu1Wq11bHR0FDc3N21NTU3BbrdjaGgIh4eHmJmZgSiK8Pv92NjYgK7rWFpawsHBgenGD0Qk09jYGDRNa6tYLCKfz+P6+hp3d3fY3t6GJEkIBAKYnp6GpmkwDAO3t7emGz8QkUw8z6NcLrd1dXUFTdNQrVZRLpeRTqcRCoUgCAJYlkWpVDLt/h8RyeTz+VAqlV5lbW0Noihibm4OXq8XmUzm1V0iksnv96NQKHR0dnYGjuMwPz+PWCwGnudxcnLyqm6hUGgdCwaDuMjlOlpZWYHL5UIikcDvnz6B53msRiL4LRpFNBrFrx8+4M9s1rRPRDIJgoBsNmsplUqBYRiEw2EUi0UoioKFhQWEw2GMj49DEAQIgoCtrS3TDSKSSRRFpNNpS8vLy2BZFolEAplMBtlsFtVqFZVK5T8uLi5MN4hIpomJCaiqauro6AgMw2B2dha5XM4ya4WIZAqFQjg9PTWVTCaRSCT+fX1WWQutT4wkSUilUqYURcH5+TkURbHMWdnd3f3KMMwWTU5O4vj4uCuSyWRzZ2dHdzqdnzc3N3+mbv7w2Gy2jxzHyfv7++8ADBGAXwC87ZI3AH4CwBAR/QPmTPaEdAWZ1wAAAABJRU5ErkJggg==)!important;width:27px!important}#global-info a#sign-out:active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAEwUlEQVRIibXW309SfRzA8TO3bljWTTc5tRVog4nMQEpp1Vi/l1mShY7nBCZHrJguNRM6jB3EcR6QEIqhFlG4oy2t1uqm1UU39YfU39H7uWCx8eDzY2tdvG7O9/Pdezu/BUEQkr/Rn4IgzAiCYBEEQRD27dtHc3MzRqMRi8WC1Wrl8OHDv8xms9HR0fGjubn5+44dO0qCIFiE/fv343Q6GRgYQBRF/H4/t27d+mWSJOHxeOjr6+PQoUPfdTpdRDhw4AAul4tAIEAoFEJRFNSEWiM+H+f06dOIf4h1a/9EURRmZ2e5ceMG586d+9HQ0JAR9Ho9Xq+XUChEKpWikC9QLBZr+Hw+du7cye7du8lms3Xr2ynkC6gJlZmZGYaGhhAEISm0tbUhSRKKolDIF1hbW+PFixc1UqkUra2t2Gw2NjY26ta3Uy6XyeVyRCIRfD5fJdbe3k4gECAej7O6usr6+jpbW1s1Pnz4wKtXr1AUhStXrnD58mWCwSDBYBBN0+rmt7a2WF9fZ3l5GUVR8Pv9ldjBgwcZGxuriW2+3KyxlFnCbrdjMpnYu3cvu3btorGxEZ1Ox4kTJ+rmN19uomlafcxoNCJJErFYbNvT+Pz5c0wmEwaDAaPRSHt7O1arla9fv/Ls2TP27NlDLperO41ra2vkHz0iGo0yOjpaiXV0dOD3+4lGo+RyOUqlEpqmoWkaFosFnU5HU1MTuVwOp9OJ3W6nq6sLSZJ49+4d/f393L9/v7rnp6dPn1av2cjISCVmNpsZGRlBlmWWlpYoFouUy2XK5TKbm5u8fv2az58/8/79e2RZpre3F6vVisPhoFwu8+XLF96+fVvd89OTJ0/IZDKEw2G8Xm8l1tnZidfrJRwOk06nWVlZqd6+mqaxsbFBuVymWCyyurpKT08P3d3d6PX6mtm/W15eZnFxkbm5OURRrMQsFguiKDI3N0cymST/6BGPHz/e1vXr17Hb7Zw8eRKTyUQ6nf7H2YcPH6ImVGZnZ/F4PJVYV1cXHo+Hu3fvoiZUstkshXyhjppQMRgMnDp1ing8TmdnJwsLC9vOFvIFstksCwsLTE9NMzw0XInZbDaGh4aZnpomHo/z4MEDcrlcnYsXL2IwGEgkEtWY2+1GFEVEUWR4eJhMJlOdT6fTxGIxJiYmcLvdlVh3dzdut5uJiQkURSGVSpHJZGrMz8/T0tLC8ePH0TSNpaUlzp8/j8PhwGKxYDabMZvNjI+PV/ckk0mi0SjBYJDBwcFKzG63c/XqVW7fvk0kEkFNqCwuLta4cOECer0eVVVJp9Pk83k+ffrEx48fa5RKpeoeNaEiyzI3b97E5XJVYkeOHMHlcjE+Pk44HGZ+fr7m7R2RI7S0tOB0OimVSv/7rR+LxQiFQkiSxKVLlyqxnp4e+vv7GR0dZWZmBlmWURSlKhqNkkgkePPmDbFYrGbt38iyzNSdKXw+H2fPnq18Ynp7ezlz5gyeYQ+BQIA7k5Pcu3ev6ufDLstyzfH/cmdyEkmSuHbtGna7/Vtra6sqOBwOjh49Sl9fH0NDQ3i9Xvx+/y/zer0MDg7+OHbs2LfGxsZSLBbzCb/zh6ehoSHT1taWXFlZmQaaBGAUGPtNJGAAaBUEQfgLaLZXufwV2FMAAAAASUVORK5CYII=)!important}#current-entry.read .collapsed,#current-entry.read .card{border:2px solid #ace!important}#current-entry.entry.read.expanded .collapsed{border:2px solid #ace!important;border-bottom-color:#fff!important;border-width:2px 0!important}#trends .trends-sorting-homepage,#entries .entry-original,/#current-entry*/ .entry-title-go-to{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAXCAYAAAALHW+jAAAApUlEQVQ4je2RMQrDIBSGPUou4aBBqBAUweUNhizewNFZ6AUKOYIn/Tu0lDQlYGkpHfzgLR/83/IY63Q+h3N+llJCSgnOeTlyzQAYUkrVe49pmjCOY9k7IcT70ZxzJSJYa6G1LltnjPmTaIzxEkIAEWFZlnXv5nlem2NCiOKcQwgBOecKYFBKvbjmmDEGRPQYaq2LtfbJ/T7G2O0ZAE73G45cp/NFrjfpq4P9EmtAAAAAAElFTkSuQmCC) no-repeat center!important}#trends .trends-sorting-homepage:hover:active,#entries .entry-original:hover:active,/#current-entry*/ .entry-title-go-to:hover:active{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAXCAYAAAALHW+jAAADd0lEQVQ4jb2V4WtbVRiHRykllBJKiY01hC6NaaPGUg0yLbhWJE7GRIeU0lVmupWbpSUkN/fe3JuBGhErWIdj1IFbS6ggk2DNsrPe5dxkm3ayDm1sm5ptbPO6Nl3btPo3/PySO5PV0WnBA++X8+Hh4bzv+zs7dvyvJ4KKTfVfQZ0RVHZGUNkVQ5VW2t2jg4ugrhiq3FHoGIJqnwy9VgxBtTsKnQbfkqfBBmKoCcRRy1PUswSmIIWZJTD5EzByBAafDL07Ct3DoUUzdxQ6nww9T1HPTaKRo7ALCtokCqeUwnM8hUOQYQ0k0RCIo/Y+dNMTRFChmfkTMAoKbBKFU1DQEVawV0zhTZHijRCFK0yxi6OwswQmDVresKIdQ1DNERjMrjNDj3V8s/rEvnOFl7xTX0kK+l/2T3/75P7zf1j2yxvOw+nTIkU7R2H3J2AciKGm3LJo55OhZwlMV1Qc7Pt44VLjuwvLzX2Zguvo3LmxDL70nFDnmpnra5Z3flp7/tDFUxKFk5tEY5llKbDYBEsohRcncjjKfK5ee3pQXXV4Fzb2fJC7MJrBmGckP9vivXOvsffnFUfvhRPhNJp5inqGoPrvBkVQ4Y5CxyZRJ8iwihS7JQU947M4zpy8N9/KrxRaB3/deD2SS45mMMaMLGeavItLDW9fze/cNzH0UCBHYBAU2ESK3WIKB6QU2J5jd688G1pfbQ2ohZ5Pb10Np/Fh97B6uWlwZenx3hu/u458H/UnYNzKsF1Ko7uTn/nuGW9u3RHMrx75Ip89NYPonvdzcotnoWDpVxf7PrmRms6jt6wxD75hkMIsUTidhy+fbnLPrNkH1BXPSH5uNIOx197LTT7FzG/YPLeXDw3f+oH+Bq+gwMYRGDYZdkZQqc3gzr0TQ0bX5JK5+5fF/mPq9Pgsjr8azsZbeqbWbQezy/3Dd348fxMBQUFbkMIciKO2K4aqsuHWtiQQR222gLdu/4nP5gs4efY6RDGFA19n8dHUXZy5toRxchN+KY0XBBnWMruybSkZbjaJuiCFmadwhCl2CQo6QhSuUBKviBTtgoI2QYbVn4DRJ0O/ye7B9dOggSQaeApLOI1mjsLOUdgFGVaWwMQRGAZiqNk6dUpCQkscjsDAU9RzBAY2iTotxh45wv4pE7UqzcJ/HbSlqV1a9yHb+Q62959s8/wF57CiEtXLCOoAAAAASUVORK5CYII=) no-repeat center!important}.goog-tooltip.date-tooltip{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAABmJLR0QA/wD/AP+gvaeTAAAAGElEQVR42mNkYGCoZyACMDEQCUYVUkchANsIAJN3G7QXAAAAAElFTkSuQmCC)!important;color:#fff!important;border:none!important;-webkit-border-radius:4px!important;-moz-border-radius:4px!important}#viewer-container{border-bottom:1px solid #999!important}#viewer-footer{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAeCAYAAADtlXTHAAAAfElEQVQImS3EbQ+BUACG4ftv2ijazno9OpKVSSTMSyt+8eOL68PFzFRiHh3EImyEFzbCi4/Ci9t/ftIKPz2LZXoSK9uJwF5EYDth1r0weS+Mu4rQ3UVU3ERSPES6fYqsfIls9xZ2N4isGkRej8LtJ+HqUeTNJMr2KzbtRz8kOUaQ9kihAwAAAABJRU5ErkJggg==) repeat-x!important;border-top:1px solid #383f4c!important;font-size:11px!important;padding:3px 6px 4px!important}#entries-up,#entries-up .goog-button-base-outer-box,#entries-up .goog-button-base-inner-box,#entries-up .goog-button-base-top-shadow{background-color:transparent!important;-webkit-border-top-left-radius:4px!important;-webkit-border-bottom-left-radius:4px!important;-moz-border-radius:4px 0 0 4px!important}#entries-down,#entries-down .goog-button-base-outer-box,#entries-down .goog-button-base-inner-box,#entries-down .goog-button-base-top-shadow{background-color:transparent!important;-webkit-border-top-right-radius:4px!important;-webkit-border-bottom-right-radius:4px!important;-moz-border-radius:0 4px 4px 0!important}#viewer-footer .goog-button-base-content{padding:1px 6px!important}#entries-up,#entries-down,#viewer-details-toggle{background:#eee url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAWCAYAAAABxvaqAAAAYUlEQVQImQXBoQrAIBiF0fv+z+AjWGawGIQli2XJsmCxCMJfRFj4do7MDH3fh845aO+NzAyttdCcE40xUO8dve+LWmvoeR5Ua0WlFHTfN8o5o5QSijGiEAK6rgt575Fzjh9C5ExXiWjjBQAAAABJRU5ErkJggg==) repeat-x!important;-webkit-box-shadow:0 1px rgba(255,255,255,0.4)!important;-moz-box-shadow:0 1px rgba(255,255,255,0.4)!important}#entries-up{margin-right:0!important}#entries-up:hover:active,#entries-down:hover:active,#viewer-details-toggle:hover:active{background:#eee url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAWCAYAAAABxvaqAAAAXElEQVQImS3KoQ3AIABFwbcVA6EYgAVQVDRBYAiCIBAEQtjw11TfYYwRzjnxPI9orYk5pzjniHuv2HuLtdYPYwzRe/9zrVWUUkTOWaSUxPu+IsYoQgjCey+stfoAwlQ7XFXx490AAAAASUVORK5CYII=) 0 -1px repeat-x!important}#viewer-footer .goog-button-base-outer-box{border:1px solid rgba(0,0,0,0.7)!important}#viewer-footer .goog-button-base-inner-box{border-color:rgba(0,0,0,0.7)!important}#entries-status{top:3px!important;right:100px!important;color:#fff!important;font-size:12px!important;text-shadow:#363636 0 1px!important}#viewer-details-toggle{z-index:1000!important;position:absolute!important;right:6px!important;bottom:4px!important;line-height:14px!important;color:#333!important;font-size:11px!important;-webkit-border-radius:4px!important;-moz-border-radius:4px!important;-webkit-box-shadow:0 1px rgba(255,255,255,0.4)!important;-moz-box-shadow:0 1px rgba(255,255,255,0.4)!important;border:1px solid rgba(0,0,0,0.7)!important;padding:1px 5px!important}#viewer-details-toggle.details-loading{margin-right:3px!important;border:none!important;color:transparent!important;-webkit-box-shadow:none!important;-moz-box-shadow:none!important;padding:0!important}#viewer-details-toggle:after{content:"..."!important}#loading-area{position:absolute!important;top:50%!important;width:120px!important;height:30px!important;background:rgba(0,0,0,0.7)!important;-webkit-border-radius:4px!important;-moz-border-radius:4px!important;margin:-32px 0 0 -58px !important;padding:4px!important}#loading-area-text{margin-left:24px!important;line-height:30px!important;color:#fff!important}#loading-area .message-area-inner{display:block!important;overflow:hidden!important;width:100px!important;height:30px!important;margin:0 auto!important;padding:0!important}#viewer-details-toggle.details-loading,#loading-area .message-area-inner{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACGFjVEwAAAAMAAAAAEy9LREAAAAaZmNUTAAAAAAAAAAQAAAAEAAAAAAAAAAAAGQD6AEB5Fud7wAAAVdJREFUOI19009LVVEUBfB3n2mWmDh5pUIqiCYPQswosj+kouhDJVOKl0ObBEENGjRp3LhPEEGjoE/SvEmjRn2LXwPXjdfV+85o77P3XXuttc9tNCoHzZ54E98wUO0792ACn9BO/hJ/MIDBAM71A7iKH/ic/DV+J17CMa7VTW4l7uAn1vAOv7CMF1hJzyBaKBpo4gO+5qPL+II3uIltdLGPSxnWwTMMlwxm8B7f8TGNF3sYlh7ciYwdTJ0nZSXTmmeKp/U2FqqXG9HXDa3rfUwewV08xCPcbuA53kbzK8z2ARjNKnexh8fVhqkYV9QAzNRpH8YqTvAUF2oA1mLifYyWlwW2UrjVo7Od+AqmsZ4VL0T2EYZKkDlMJG4FbD5b2cFk7hbTM5Z6s0pxKAZ1wmwVB6ndy6bG60wupx9iMvmD5EXoP8GNfgDFv+d5mi/nnRQ9DP/7tf8C99TysVTycpkAAAAaZmNUTAAAAAEAAAAQAAAAEAAAAAAAAAAAAGQD6AEBfyh3OwAAAW5mZEFUAAAAAjiNfdPNSlVhGAXgnfuoJZ0UM00qjVP0o9GRSikSLCoqkQRTC6xmNqsmYlCTLqJJBF1D0KgIuptu43Hg2rKprd/k24v3b71rfbsoagf9aKEneAlvUQYfLw46OImPuIQefMMP9GEY7/GmqfBQ7iF8xafgbfxCiWf4i43/inEOneD7+I4b+IwveICf+F2rmawalNjEuyROYAsvcRrLuIk/WMcYFvF4TxOcx2t8wBou4HCNZRvzeI4NLKCD/n/XuZfEVpNOmEnhYD1wDbdC9TqmKlEbmrQy/Sruoluk60oC6xg6wObxDFzGHSxW+5UYiNfT1UNqaDCKueQfrQcGcCUCzmGsobidVZ+E7XgV6I19K/F+IjQnMZKpHdwOnsVqao5U6p7BKbtP9iyexvtuPB/GC3Qz9AQuyz9SpzmIR2FTZurDsJzFK7T3E7nIpCVcDF5Is14cy/6dfRtUYtW+p/O4Wll1BH31/B0WfCxsbaEoEgAAABpmY1RMAAAAAwAAABAAAAAQAAAAAAAAAAAAZAPoAQGSvqTSAAABemZkQVQAAAAEOI2F011vTGEUBeB3pjXTjyFCW22kMSlpNYr6KpUpTadoJT6CcEEi4kIkbtwQ/AhBuHfhn3DhVz0urCOTybTem3P22e/ae6+19iml56CB/RhJvIanGEo8UXY7OBTAcuJ3+IQ6LuA1uoOAtTwnA3qGvXiBzxjCG/xGZ1CBw9V4uIb3WMErfMATfMe33BkNvVrBMDq4jqto4yGu4Di6OI0vuIWL+IGv2CwYwXQKPMYZnEIT9R5xV/ESP/ELb9EuqEWkUSxhEa0BNJvR5iPu/9MO59J1A3OY38Wlk3iOhdA9UdL1ZnTYwOx/bF7GdkRcLxjL+BM4ivmKex+4gX04m2Ubx1iVPJjKt3EJU2j0FTgQfe7E4ukqMRzL7uFyHFjKJDOZbC4NFgLexA00KxdmcSx02uG4kkLd5O9iNU2nQqXev8rj2MrCNHA+7y2s4wFmdhK5RKQtLCbu4FH2ZDJjH9mxQEAtf3+eWvZjLd/r2dg9vff/APdLSufE3SSEAAAAGmZjVEwAAAAFAAAAEAAAABAAAAAAAAAAAABkA+gBAX901qgAAAFjZmRBVAAAAAY4jX3TS0tbURQF4GvSaFRUnKSmgdqCVEUI4gNL0weNIaUWW3yhaIY6EQQdOOjEccf9BaXQUaG/pHMnjhz1X3wddN/0cjU5o73O2medfdbeJ0lyCwOZ+ACtDC7k8/OHZ/AO5cAXOIr4Ca5Q7SdQRQeNwOc4jPgzfqByp2RUMBh4Gceo4RT7WMEvNCPnYbcSlLGLzRAaxQ7qeIrHOMQXjOADfuNr1xM8CqKD53iQM7OAYXzHNb5h4b6nPLtD/OeHwpNmnljCKzTiraN9TK7jEmc4QTtBKzzYxgbG+wi8xw1u8Qc/09IHMl5M9zhcDDOXMriYkiN4ESau9xAo4ROOsIhSSgxiK9TnQ6wZkzcWbV3AWnRiJS5qZ0ubw2Tg2UiooR1tTfeqkTOFmfvKnPDvA70MvInXEW/ErJR6mZzEHOxhLPBHvIm4FmNd6SdQSP9E4LdYzeBydkKTJEn+AqwQ8rHUfie2AAAAGmZjVEwAAAAHAAAAEAAAABAAAAAAAAAAAABkA+gBAZLiBUEAAAFxZmRBVAAAAAg4jX3Tu05UYRQF4DMwg0QkkInOcNFoCBHNeEGESDQQxThRVIYYbBQLG6IN2BD1JXwECytb7UhsfRlf4rNZRw8E5m/O3mdf/rX2+ndRVA5O4XTsBpaxUIlPFf0OJrCOUdSxgW5ic3iPy8cV1vIdwxssxu+m4SB2sIepMv9fcX624t/Ea5xDDw9wH5+xiiG0cQe1AgN4hue4jlYSZ4PoEjrYwhW8wFd8xFCJYjoNXmIB4xiooBzGDD7gO96ic4h/7EXM9BnywygzHuT1Aiu4Gxo3MN2nQRs/sI8DbBaB3Mvt6xju0+ApdvETX/CpqDycsdxw7ZBM/4tH8Bjb8VtloIGzofEK82geKR4M1V/4jXc4XwZHQ2ETVzEZ7SdwEc3MZge38Q1/8i7OlE0uZLI13IrWnaBaCbVtzCa/G0nrx015C6vxn+BeJFtLrHHSkIvAf4TJ+D2sxS4XrX1ig8q0y+VaknUOiuZR2H8Bq0smZsvnDzgAAAAaZmNUTAAAAAkAAAAQAAAAEAAAAAAAAAAAAGQD6AEBf5E0HQAAAXhmZEFUAAAACjiNfdNLb4xhFAfwp2/NTF0iZaJDSSsTFVrqfq1x6ZhKNFSDjVg0WFjYshRiZ2klPgVfwcbX8E1+Nv83eSPTPsnJOed9zuV//ud5S2kctLAPrfjLuImJ+Edqe+zBQaxhPv4jDGPPYYS5cYl1h2m8wL0guYshquinaVKhasJeQC/+FTxDHwNcxzk8yd3u3K2gXbAXdwJ9gGNJOo4DOBy5jRtYxXu8RregjW5gb2ApRarGiJP5dh8fws0JTBZ0IvtxGvPojOGphYu4hlPYhekSaCt4HC4WdthSHx/xDt+wWQJ5hEvhoLdDgUU8wGe8wVap4WImcy02528kzwT+p5DaqTmoQtAAm7icF9eu3wj24Cpe4Q++41ZdYCrJGyHxZDr1s8oL+JLOq9nCD3xFt4Z3FL2saxkPcSbJb7GFv3iZ+CWs1yj//xeeZzNV9DDv5Dd+YXY7kgsOJWk2/gjrDfsnzm5bIIHd6ArnIxNhfYipZvw/OThW8RJtxdkAAAAaZmNUTAAAAAsAAAAQAAAAEAAAAAAAAAAAAPoD6AEB/DF+hQAAAVpmZEFUAAAADDiNfdNPS5RhFAXwd2Ya00LDzeQk9AckiwEJm1A0i0yMlBKtUMplbYLAFi3atG7tJxChVdAnad+mVau+xa9F55WXYd55Vvdy7j33Oec+T1FUDloYS9zABhYr+DgaRd3BLeziQgheYi3YleSdUQTTeI2V5HtYDdk2npU3rDY1cROXkt/GYSZuoR/8sJyOLuZKgjG8wgHmc/3HuIYpXEQPy4nvhuzJmR+YxP0A6zXyzuEF3kbW+LCiWVyvIWhgAbODwCM8j0GbmBxh8g28xxE+4qDAPTzEg1LnCIKr2M+m3mBjsGAevZrmZhr7ddq3YuIS2mhV8POYwFf8wOczr/I89/NQuincybSnMe4Ip1nxOr7hC5qlux20Q9iPvkX8xqc0/cJ2ajroDpMyExl3kv/Bh8Qn+InLdSYXmMsq2/7/zL94F6yH46GTa8ha+I7N6iYG6/4BmevysSavJL8AAAAaZmNUTAAAAA0AAAAQAAAAEAAAAAAAAAAAAGQD6AEBf82VjgAAAW9mZEFUAAAADjiNfdLNatNREAXwfyJNFIMptkZbbVFrKbUu/DYoWuu3qUrBRqQLERe6FHeCKxe+gktx5Urc+gI+gY/hS/xceK78CU0uXO5cZubMOTNTVbWDNnrYgyau4joa8R+qJh3MYoh5NHAfg/gWsYVjuyU2805hG3fD4Boexn6Ex5gpjEpyA6dwolbpRd6b6ONcgFfRisxVNKugr4f6Oo7gPE6jE1m9gBzPO8QA+wqLaVzGJjawv04zRTqJeY4VdKua7m7ss5if0OQFzAWshW6Vht3GM1zByQkAbeyE5RD9CkvRvoIb/3XtDrCEtei/UADKCKdDb2McSJKGaI/SWoyMnSzPFg6ONPFMmvwe73CxODu4F1o93MJv3MnsL+EJPqVQH29yDxSQWbRif8OvbOBH/MBRfMerxBzGMqZGNQ7wB6/z/4rP/m3ry4AtjGtyhQf4UHYBX/AzM5/DW6yNBSjTqNlPsR27kbu3Hv8X4dovdFsOKhMAAAAaZmNUTAAAAA8AAAAQAAAAEAAAAAAAAAAAAGQD6AEBkltGZwAAAXhmZEFUAAAAEDiNfdNNahRRFAXg6k7FoB1/ujVGUTu0wZgQfyJGUVHRoI0SiRhIokIGgmQkIjgRBRWn4sQNuACHrkLcgHtwEZ+TUyEU6S4oeLfeO/ede86poqg9mEAj66u4j2bek2jVMTvBx7CCudRLeIwSR7GOqUHgBlq4F9Ae3Eo9ijt4irGcb1bAJmYxjX04lQbXcB79MNvETDBncAllke5LWMNNnMZCtGhjP6by7XgYPcPdik2RGXt4guvo7DLiXtzAQyziQLXRzmYHB9EbInInTEocwViBy3ieMTbQHdLgBK5khD5WCpzD2Xi+ELHKAQ3K6NSNyNN1er/wBeNVmGrgi3GmXVlf2fgK//AHb3EbkzUBe6H/MkLOo1UkMD/xMQ508QPvko9HObyFuWSij2Ucqhh0cDi3vcZfXMAnfI5tb/ACIzk3sZtIk/iNr6m38D3rB/iAxUEuVTa9T/Iauf0bRpLMVcwPazC6rW6x/Tuv7qjH65j/u0o4aMOl4xcAAAAaZmNUTAAAABEAAAAQAAAAEAAAAAAAAAAAAGQD6AEBflrxdwAAAVxmZEFUAAAAEjiNfdI9S5xBFAXgfXd1XVeipNlkFfwA0YiwBJOQ4EdEXVY0qGgURbdMGiFgihRpUqfOLwiBVAF/iX0aKyv/xWNzB17Ud6c6Z+6dM/ecmVIpt5ChluNvsJbjVZRLRQsNHGMs+Cp2Az/BEWZ6CfTjA7aDv8dO4GWcYOSxg9N4HriJLmbxDh2Mpb3oeYoXqCSBTjS8xiDeYh5DMfok1lHHHE6xj2p+9Jc4wx76CyxuxEWLqKfNShoFC6FeKRCYwGjgDFkJ/3CLG1xjq0fIw9jGAQ7RTv4/4wu+odVDYChyWsIKFu43rOMCAwUC85hB9ljhN/7jT7xEOVfP0BfP2o2/MpqKZfzCVRTq+BlhjmMKLXwMCw3sRAa1JNLEs5yNy/B6jPP4SJ/wKnqqIfTASgN/8T34KS4CL8X4zaKQ0yQ/MBn8DF8D17CJ6UKBlEkOt3GSD/N+/x3lr/KxERjJFAAAABpmY1RMAAAAEwAAABAAAAAQAAAAAAAAAAAAZAPoAQGTzCKeAAABbmZkQVQAAAAUOI190llqlFEUBOC/23Rsm5aE0IJxSNC0diI+GEWjaAyJGsdIRgUVHALi/OyT63ANgu5B3IA7cCmfD9Yfftqk79Mp7rl1q+qcoqgcDKGDRnAPy9gXPFoMOmhhBaeCL+ExGhjDLfR2ezhUqZexFjVnsYk65rCFif7HNbzCm+ARPIv887iBM3iIa+k/gBnUi7C/xB/8wn28wOU0Ho/8q6l7UbiOTqliFKv4gd+4jnafyhbO4QkuYhyNAsMBNdzD3R3m/7M6isl8WEO7wDt8xU98wfMBU6rH4lxsXClH9R1v8Q3dAQSHcBp3cAGLRWVpxjCF19i/B8ERLFTHXl6cwMco+BD2Zl9PJ+Ncz25Mo1b6ep8cttDFo1ibSnATuInDub+dvWiX7CfT1MQsPuNBxvUUB7GBhcqyHdvNSidhfvJvleeTdiNqtjG+V8hFJG5jNng+dlrZl6VBUypJRip1NyTN4CaGq/1/AVy2Mm+nTr5NAAAAGmZjVEwAAAAVAAAAEAAAABAAAAAAAAAAAABkA+gBAX4GUOQAAAF5ZmRBVAAAABY4jX3TW2oUYRAF4B7bmVxMSELIEI1EzYiaiDJqMCKKeImDaAgmUUR9EAUVBB9EEBdgduCjuAbBHYgLcBNu4/PB06EZnfmh6a6uOqeqTtVfFH0Hq2jmexk3MBp7AhP9mDp4Ht+wWyN7hAMYw12cHATehxF8xG8s4hzuYT/O4BnaVXwdfCnZ2jiFn/iejFuYwUNcTPxBnECzQAPv8Au7OI+3yXYbUziEq1hAFxvYxFhRY3yNH/iMNUz2tTiVNu5jHfOVYxRNzKb852gN0KmNC9GrhbLANXzBG3zF0SFTmsNZbAe3UeABXuATdnAHjSEk61iJPt29NvLupf/x/wAb6OSZyb9W5TyGJ3iPlziMkb4dmcZpPMX1EI1Xzi18yHjmcCtjm05gGzexlJH2osNsVdoKFpOtg1cJXk2vnSxVD2UwC/9olWq2I2QZ4p34uniM5UECF5iMykdir/l7mZrxXcHSMIIyG1fGPo7LcnH2Vrd2/gBbLDhpiMUJTwAAAABJRU5ErkJggg==) 5px 50% no-repeat!important}#lhn-add-subscription{margin:0!important}#lhn-add-subscription .goog-button-body{padding-left:.461em!important;padding-right:200px!important}#lhn-add-subscription .goog-button-base-content{padding-left:0!important}#lhn-add-subscription .goog-button-base-outer-box,#lhn-add-subscription .goog-button-base-inner-box,#lhn-add-subscription .goog-button-base-top-shadow{border:none!important;background-color:transparent!important}.subscribe-button{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAhklEQVQ4jdWRIQ4EMQhFx0xSga7EYWowTTBc9N8JxQF6ljUrmu5O0lTtkjxDfh4QruvXC2+uiLhnPpJrICJuIgIR4Xh8rRW11r0NvoWYGcy8v0EpBTMiAhHB2n8UtNaww6NgjIEZVYWqYu1vn9R7R+/9/AtmBjM7F7g73P1ckJnIzHPBf9QLxPVrQoVs/0EAAAAASUVORK5CYII=) no-repeat!important}.subscribe-button:hover{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAiElEQVQ4jdWRIQ5EMQgFkW2Cr6zC1GAqKrh7D8EBOMr7ZkXTzU+aql2SMeRlgED064UPFBFp5Su5ByIiMTOYGdfjSykopZxtQEQ050wrtVbUWs83yDljRUQgItj7r4LWGk54FUQEVlQVqoq9f3xS7x299/svjDEwxrgXmBnM7F7g7nD3e8F/1APptYBaaf/KFAAAAABJRU5ErkJggg==) no-repeat!important}#logo-container,#gbar,#chrome-lhn-menu .goog-button-base-outer-box.goog-inline-block,#search-restrict-button .goog-menu-button-dropdown,#search-restrict-button .goog-button-base-top-shadow,#stream-prefs-menu .goog-menu-button-dropdown,#email-address{display:none!important}#home a,#home a:visited,#home .link,#overview-footer,#overview-footer a,#overview-footer a:visited,#trends-item-count-header b,#entries-up .goog-button-base-content,#entries-up .goog-button-base-content{color:#000!important}#trends .trends-columns-fixed .tab-contents,.lhn-section,#lhn-selectors,#search-restrict .goog-button-base-outer-box,#entries-up .goog-button-base-top-shadow,#entries-down .goog-button-base-top-shadow{border:none!important}#trends .sorting th,#trends .top-links,#trends .alt .sorting-sub-primary{background:#ccc none repeat scroll 0 0!important}#trends .alt td,#trends .sorting-sub-primary{background:#e5e5e5 none repeat scroll 0 0!important}.lhn-hidden #chrome,#entries-down{margin-left:-1px!important}#lhn-friends,.scroll-tree li{background:transparent!important}#overview-selector.selected .text,#reading-list-selector.selected .text,#star-selector.selected .text,#your-items-tree-container.selected .text,#trends-selector.selected .text,#directory-selector.selected .text,#lhn-add-subscription-section .goog-button-base-open .goog-button-body,.scroll-tree li .tree-link-selected .name.name-d-0,.scroll-tree li .tree-link-selected .name.name-d-1,.scroll-tree li .tree-link-selected .friends-tree-item-action,.sub.unselectable.expanded.tree-selected .name.name-d-2,#reading-list-selector.selected #reading-list-unread-count.unread-count,.tree-selected .unread-count.folder-unread-count.unread-count-d-1,.tree-selected .unread-count.sub-unread-count.unread-count-d-1,.tree-selected .tree-link-selected .unread-count.sub-unread-count.unread-count-d-2,#chrome-view-links .link-selected,#chrome-view-links .link{color:#fff!important}#viewer-allcomments-toggle .link,#viewer-all-new-links .link-selected,#viewer-all-new-links .link,#viewer-comments-all-links .link,#viewer-comments-all-links .link-selected{color:#fff!important;text-decoration:none!important}#current-entry.expanded.read,#current-entry.expanded.read .entry-actions{border-color:#ace!important}';
	//edit tag 16901
	css += '#quick-add-bubble-holder{z-index:1000!important;margin-top:0!important;background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVgAAAByCAYAAAAWLMmkAAAL3UlEQVR4nO3d32+UV37H8bc7WRuDwYQ6YIydOM7z2NizZjfGzqaQTQh4nmfMYjDpOhtWsTatmqZaCamN1BAparlg07BVshe7UhJuctFKjbZSpbSNmrZStSvt5Uq7UpUfajCQ3va6f0Avzhlm4hrwjB+YCby/0ksgzWNzTiJ9dHTmfJ8DX43qikoNf7csy7I2UY3B+jWgO/5p0FqWZW2iasHaDfSeOXNmz3vvvffzixcvHgK2Aj3Ug9ayLMvaYNXCtQfYtrCwMPzOO+/8y7Fjxz546623/u611157EtgObMGQtSzL2nA1hmvf0aNHH3r33Xc/mpmZ+ackSVbL5fK/vfnmm++/8sorTwM7MGQty7I2VI3huv3IkSOjb7/99r/WwrWmFrKvvvrqUQxZy7KsW9aGwtWQtSzLaq6aCldD1rIsa2PVUrgaspZlWbeu619ozc3NjTQTroasZVnWjWvT4bqBkLUsy7rnqouCwrUhZP/dkLUs616v2r5rYeF6i5C9k1sFG/23Ov05y7I6sLpuZnl5uVQul7uHh4d7iw7XG4VskiQ9y8vLpfXGc7PPfM7nfM7nbuKOVBfQCwwAe4GHgNHo4QZjwCNAAkwA5dsRrmtD9tKlS38K7AfSNeOpudlnDzfMxed8zud8rvbcQ4S8GyDkXxcFVxfQNTw8vAsYWVpaev7cuXM/OX/+/K9ef/31/37jjTf+51ZuV7g2huyPLlz4342M5WY2Oh+f8zmfuzeeO3/+/K/OnTv3k6WlpeeBkZiDXUUFbRdhD3UAGH3hhRdenZ+f//nU1NR/pGl6ZT1rw2+jz0lSp5mYmPj1zMzMh6dPn/77l19++RxhVTtAAcdDa+HaD4yurKy8MjMz8483CswbhabhKulu8NRTT/3D2bNn/zyGbP9mQrYLKCVJ0gPszbLsB0888cT7raxGDVZJd4tqtfp+lmU/APaePXu25XdVdxFegL0VGF9ZWbmwdlug3ROVpDvtwIED/7yysnIBGI/52N1swNa2BrYQlsHfWF5e/jBN08/aPTlJaqfx8fFfLy8vfwh8I+Zj001OXUnYGugjbOY+tri4+HG7JyZJnWBxcfFj4LGYj31lyt3NBGzj6nUv8O1qtfpFuyclSZ2gWq1+AXwbGCR0kfY0E7D3Ab07duzYBYwAR6u5AStJSZKsZnl+FTgKDPf3999PaEDYcHUTLhrcQ+jKyvM8v9ruSUlSJ8iz/BpwPObjQMzLDdcWwrJ3D6Hd9USeZ5fbPSlJ6gTVavWLUqm0DJQJ26j9TQfs9ti9BWR5nv9XmqRtn5gktVsM2GeBbxK2Ue9vNmC3A78LvSPAkUpW+XTcgJWk1TzPr953333VuIIdDlnZUsDyIHBsPq98knbAxCSp3fI8v1YqcRKYigE70ErA7ia8qiubr8wbsJKUXD+m9V3g64QtgpYDdhRYqMxXPm/3pCSpE8SA/f0YsA/SwhZB7RRBCizmedb2SUlSJ4gBe5qwRdD0l1w91M/BjgOn8jy/1u5JSVInaAjY/cAQsKvZgL2fcL5rAjhtwEpSsE7AbnwFm5DUAnYwrmBP+y4CSQrWCdidGw7YcrncTdi0HaytYA1YSQo2F7Dh1VsD1PdgFw1YSQo2FbAHOfg14IG++jGtigErSUFef5vWQ319fbsJp66aWsHu3ha2CBJgwYCVpCDP82tANS5AH6CZt2nVAnZrOEWQAksGrCQFcYtgKebjYFMBS3gf7O74g/vxSy5Jum6dPdiNbxEQzsHu2Rp+cD/wjAErScGagN1LM19yEVpldwP7gEnguwasJAWbOkVAuOt7N+E1XF8vlUrL3sklSUERATtAeEvMdHep9JytspIUbDZgewidXPuAcqm7+3tuEUhSsLmALdNNeBfBEDBVKpWedYtAkoLNrmB/J/5AfJtW6VSWZZ+maerNspLuaWmaXs7z/OPNBmw/4RzsI0BWreauYCUpSVar1eoVYB4YYxuDNHltd9eagD3uHqwkBfFdBFXgYcKJq6Y6uSAseWuNBnZySVLU0Co7TnjroAErSUVo+JJrwoCVpAKt0yrb1B6sAStJN7DZY1oGrCTdgAErSbdJEQHbT8O13QasJAVFBOwO6pceeqOBJEVFBexuwpUIJ22VlaRiWmUbV7APA/OuYCUpWU2T651cx4Ax2LaHJq+MgXqrbAJ8x4CVpKDhVllbZSWpSA17sCnhMIABK0lFaAjY8ZiTBqwkFWGdUwS2ykpSEezkkqTbpKiAHYy/YMk7uSQpKLyTy2u7JSkoImC39/Wxm3AO9pQBK0lBIQG7bRt7CHdyncjz/BNbZSXd62Kr7CebDdh+6q2yFb/kkqQgtspWgLGYky0d09pL2IO1VVaSooZW2TFCq2zT7yLwmJYkrWNNJ9cgdnJJUjHW3CrruwgkqSgxYJfwVllJKtaaFaytspJUlCJe9lK79NCAlaQGRd0qO4itspL0JYV0chHOdxmwktSgyIBNgJO2ykrSurfK7m01YL1VVpLWqFarVwi3yj4SF6Itfck1SLjUy1ZZSYpiq+wC9XcRtHRtd+0UwZIBK0lB3IM9FRege2ihk2sHYfN2Ar/kkqTr1nRytfQugu1xBTsBnHIFK0nBmlMEe2lhi2B7TOYJ4FSWZ1fTDpiYJLVbEa2yWwl7CylwIqtkn6fJeNsnJknt1rBF0HLA9gIDhGMIx7NK9pkrWEm6foqgFrCDrQRsdwzYMWChUsk+TVNXsJLucWmymuf5KrBI6HRt6RxsN7ALGAUWsqzyWdsnJkltlqbJaiXLPgdOELZQH2hlBdsTAzauYCu/ScfHbZWVdE9L0/HL8/OV3wDfifm4ixaOadX2YEeBY1lWudLuiUlSu6VJuppl2WfAEeDBVgN2K2Hp+wiQZ3l+LUnStk9OktorXc2y7DKQxxXsIC3swdaOaSXAySyvXG3/xCSp/fIsu8omTxH0Uj8Hu5hl2WVXsJJ0/ZjWpl5X2BiwJ/Isa/ukJKkTFPHC7VrAjgOL1bza9klJUicoImC3UX8f7MmskrsHK0lJcVfGXH/ZS54ZsJKUJMUE7A68tluS/p+iAnbIgJWkLysiYHc2rmDzPP/YW2Ul3euKulW2didX2IPN8w+mp6dtl5V0T5uenr6S5/kHhDu5JmJOtnSrbC1gFw4dOvTTgwcPtn1yktROBw8eXD106NBPCbfKth6wo6Ojg4RzsE+PjIxcOHz48C/K5XLbJ9isNE2vpGm67uq79tnNnmn3+ByP43E8d2Y8t8qDcrm8evjw4V+MjIxcAJ4GxmNONh2wOwiNBmPA48BzU1NTP5udnf3Pqampr9xe7M3+x7YrWDttDI7H8TieGz87NTV1Oebfz4DnYi6OxZxs+tLDrdRfV3iAsBx+MU3TS7Ozs7+cnp5enZycXE3Tu+v9BHfbfCS1Lk3T1cnJydXp6enV2dnZX6Zpegl4MebhgZiPAzEvm6re4eHhXcAw4Zuyxwnfmv1waGjo7XK5/DczMzMfzc3N/XZ2dvbK3eJum4+k1s3Nzf12Zmbmo8nJyb8dHBx8B/hhzMHHYy4Ox5zsbTZgt1Dfhx0DHgWejL/8j4A/A/4CuAD8FXAR+HEH+et13OqzN4AfdeD4HI/jcTy3dzwX13z2Y+p58JfAy4TcO03IwUeBsYb91y00Wd3UtwlGCGk9R9jYPQ4sA98H/iD+w38MvBT9yVfQS4Sl/x92wFgk3Tkv8eXsqv39RUK+PU/Iu+OE/Jsj5OEI9e2BbpqsEnEVS7g1cRSYir/8SaA6NDS0CDwDPEvY9D3TQb7fYKOffS/+h+zU8Tkex+N4ih/Pc9QzrOYMIQ+eIZx3rRJyb46Qg6PUb5PdQsjLpqqLkMq9wM64FB4F9u/bt++bhD2IJ4GjhKsTFjrM8aiZz6p3cC6tjM/xOB7HU/x45oFK/DOPallwlJBzj8fc2w+MxjzcScjHbkJeNlVdQClJkh7CEngnIbFHCHuy+4Fpwl7ELPAY8C1C8Haim43tW9FcnEunjc/xOB7Hc/vG83tR47OPEbLgUULO7Sfk3gghB3cCW2M+loCu/wMWlNrfQ2qYQAAAAABJRU5ErkJggg==) no-repeat!important;color:#fff!important;height:114px!important;width:344px!important;border:none!important}#quick-add-bubble-holder:hover{z-index:1000!important;margin-top:0!important;background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAVgAAAByCAYAAAAWLMmkAAAQ2klEQVR4nO3de2yVZZ4H8G8v9nJO77anp+diL5y3pT1TBnphGIig0L7vKdfWHURcCNkRx81kIWBcSyBilGFxJurIEEXYBJI17rg1G83urO6izUyyMbgZdwgbwTi0XFyHGIRhSURAjL/943nec6OFntMXTgvfX/IJhL70vG9Nvj783ucCTI7K0nLifs9isViTvuxAywaQC+AuAHkA8rU8/We5+honAzA+WO3PvQsMWhaLNcnLDrBcqCB1ASgBUA6gEoBHq9R/VqKvydd/Z7wBaAdrHoDClStXVu/bt++fnnvuudlxn2MHLYvFYk2aig83N1SA1hw6dOiXFy9elOT6+uuv5fDhw78EUKOvdeu/m24A2p+fD8Dd09MT2L179zsLFix4+4UXXvjHLVu2zAVQDKBgHJ/BYrFYt7zsUWsBgDIANUeOHNmZHKrnzp2T06dPXxO2hw8f3gkVtGX6e9ij2VQ+3w7Xovnz59e++uqr77a1tf1LKBQaCofD//H888//+sknn7wfatTMkGWxWJOi7HB1AbgbQO3Vq1dFROTq1asyMDAgq1evFrfbLUVFReJ2u8XtdsvixYtl//79cuXKleiIFkCt/h4ujD1k48O1+L777qt75ZVX/t0OV5sdsps2bZoPhiyLxZoEFR+ulQAavvvuOxER+eCDD6SjoyMaqLb4kHW73TJ37lw5evRodDQLoEF/r7GE7JjClSHLYrEmW9nhVgA16mz45ptvRETkrbfektLS0miYJodqfNgWFRVJaWmp7N69Ozlk78b1AzClcGXIslisyVRZUC+lygDUHjx4cK89co0P11S88cYbIiJy8ODBvVDtgjL9Gcnhl1a4MmRZLNZkKLs14IZ6OdUqInLp0iWZPn16wgi1p6dH+vr6rgnT5uZm2bJli9TU1IjL5RK32y0VFRVy5swZexTbqr+3G9e2CqIvtDo7O4OphCtDlsViTfTKggq4cgBTBgcH94mIvP766wkhumDBgug/+19++eXon8+cOTMapAMDA1JQUCC5ubmSnZ0tmzZtEhGRwcHBfQCm6M/IRyz4xh2uYwhZFovFylhlQ72EqgEw7dKlSyIi0tvbmxCw7e3tcvny5YSQnTNnTjRcRUT27t0rACQrK0uysrLE5/PJt99+a49ip+nPcCG24suRcI0L2QMMWRaLNZEqFyqMagHMEhG5ePHiiH3VtWvXih3AIiJfffVV9PcHDhyQ7OzsaMDav9qzCgDM0p9RgthyV8fC9QYheytbBWP9rIl+HYvFcqDugvqnuwHgfhGRU6dOSXFx8YgeeeSR6HzXkcI1XlZWlrz33nt2wM4H0FhcXFxZXV3tDgQChU6H62ghGwqF8pcvXx6/f0HU9b7G63gdr+N11zGmyoOaq9oMwBQRGR4eluLi4ujUq6KiomjAzps3T86fP58QsDt37rxm5Go7cOCAHbBrAJgAOgF8D0D4ZoRrcsju2bNnA4CpUP8DqR/B9b5WD6BO43W8jtfxOvu6WqiWZyWAQlwncPOhNm0JA+gREblw4ULCqNUO2Hnz5snZs2ejwWr3V0VEXnrppYRgtR06dEhERNasWfN/69ev//PmzZvPPvvss1/u2LHjzM0K1/iQ/dm2bV/t2LHjzHhs3779FK/jdbyO19nXPf300//Z39//Ym9v7yoAwUAgUIFRRrYJAWsvMJgxY0ZCyNbX1yeE6/vvvy9r1qxJePG1devWaLACkOzsbLlw4YKIiHi93tPBYPCz+vr6E6FQaNgwjBHdzMAlInJCU1PT79va2n7T19c38Pjjj/frUW0lRpgemtAieO211/5NRGT79u0JAdvb2xsN0sHBQcnLyxMAsmrVqmjIvvPOOwkBu2LFChER6e/vv+jz+W4YsJn+oRERpWrevHn/vG7dur/VIVuaHLIJL7kArBVRu2X5/f6EkH3qqadk27ZtUlJSktAG6Orqkp07d4phGAm92A8//FBERKqqqs74/f4/1dbWnmpoaDgeSgrYTP+AiIjGIxKJ/No0zTUAatatW5ewV3XCNC0AK/fv3z8oIrJ///5ouMbvN+ByuRJGqvaviHvBtXHjRhEReeaZZ772eDxfBAKBz+vq6k7aAZvpHwgRkVOmTZv2r6tXr94GoBFqrn90W4CEhQYAFgP4G7sd0N/fHw1YO2QLCwsTAhZJMwcWLVok9jaHlZWVX3q93tOBQOCzurq6EyGGKxHdZhobG3+/fPny3wD4vm4TRBc5ZSFuqSyAewE8DGCTHbK7du1K2PDF5XJdMy3LDtoNGzZE58lWVFSc9Xg8X/j9/s/j2wOZ/mEQETltyZIlHwOYqd9pFYURzrMDNmGzFwAWgLUAttohe/LkSVm/fr3U1NQkjGBtK1askI8++ij6Iqy8vPxcVVXVGZ/PFx29MmCJ6HYViURO6gGqV7dd8+0XXVmI264QQIduFfwEwNZdu3b9lx2cV65ckU8//VTefPNNGRgYkMOHD0enYomIbN68+bIdrl6v97Tf7/9f9l6J6HZnWtZxqBWrgdLS0nKoBQjRgE3YcFsPdRfrkewmAM+/+OKL/y2j1BNPPHG5tLT0fEVFxdn4cK2trT1lT83K9A+AiOhmsUzrBICFiJ3kUhw/H9ZuFUSPjNEjWUv3ZDcCeAbASwD+HsDbwWDgfGlp6fmysrI/l5eXn6usrPzS4/F84fP5RgpXBiwR3bYikcjJnJyc5VCLtmr0yy6MFrJ363ZBq+4rPADgxwA2ANgKYHcoFDpTVVn1ZVVV1RmPx/OFHrV+rnuuJxmuRHSn0AH7IIDpAIJ64sA1ZYds9NhuqNkFnbq/sAzAXwLon/b9aZ/5ff7Tfr//T4FA4PNAIPBZbW3tqaQXWgxXIrrtWZZ1PDc3N6JHsAE9SB2x7J5sHtTsgnKoZWAtcUH7yMwfzhq6Jxi0Q/WkHax8oUVEdxrLsk7k5GCpzsmAbrWOWvbOMLlQ0w0qAPigVirMAPDgvXPv/bShvj45VDlqJaI7jp6m9SOo7ViDNwrY5KB16ZGsH2rfgqVd87uOhRiqRER2wP6FDth7rtciGKkKoCbPVuuAXWJZZsYfiohoItAB2wfVIhj1JddolQ81r6saqk2wzLKsE5l+KCKiiSAuYKdCtVMrUg3YcqhZBU0A+hiwRETKCAE79hFsCCE7YL16BNsXiUROZvqhiIgmghECtmzMARsOh/OgmrZeewTLgCUiUsYXsGrrrUrEerBLGLBERMq4ArYd7XcBqCpSByTWAehmwBIRKVZsN63aoqIiD9Ssq5RGsB63ahGEAPQwYImIFMuyTgCI6AFoFZJ20xpTwLrULAIDQC8DlohI0S2CXp2P3pQCFmpfAo/+i1PBl1xERFEj9GDH3iKAmgdb7VJ/cSqABxiwRERKUsDWIJWXXFBLZT1QexE0A/gRA5aISBnXLAKozV48UNtwfS8nJ2d5xGLAEhGFQs4EbCXULjGteTk5D3GpLBGRMt6AzYdayeUHEM7Jy1vBFgERkTK+gA0jD2ovAh+AlpycnAfZIiAiUsY7gs1G7IyuJiBnmWmaRw3DOJbpByMiyiTDMI5ZlvXxeAO2FGoe7BQAZiRicQRLRBQKDUUikWEAXQAa4IYXIxzbfb3KSgrYhezBEhEpei+CCIB6qBlXKa3kAtSQ115owJVcRERa3FLZRqhdBxmwREROiHvJ1cSAJSJy0AhLZVPqwTJgiYhGMd5pWgxYIqJRMGCJiG4SJwK2FHHHdjNgiYgUJwK2BLFDD3miARGR5lTAeqCORFjKpbJERM4slY0fwdYD6OIIlogoNGSEoiu5FgBoANzVSPHIGCC2VDYEYBEDlohIiTtVlktliYicFNeDNaAmAzBgiYicEBewjTonGbBERE4YYRYBl8oSETmBK7mIiG4SpwLWq79BL8/kIiJSHF/JxWO7iYgUJwK2uKgIHqh5sMsYsEREiiMB63ajGupMrsWWZR3hUlkiutPppbJHxhuwpYgtle3mSy4iIkUvle0G0KBzMq1pWjVQPVgulSUi0uKWyjZALZVNeS8CTtMiIhpB0kouL7iSi4jIGUmnynIvAiIip+iA7QVPlSUiclbSCJZLZYmInOLEZi/2oYcMWCKiOE6dKusFl8oSESVwZCUX1PwuBiwRURwnAzYEYCmXyhIRjXiqbE26ActTZYmIkkQikWGoU2Wn6IFoWi+5vFCHenGpLBGRppfK9iC2F0Fax3bbswh6GbBERIruwS7TA9BqpLGSqwSqedsEvuQiIopKWsmV1l4ExXoE2wRgGUewRERK0iyCGqTRIijWydwEYJlpmceNCfBgRESZ5sRSWRdUb8EAsNjsNv9ohBoz/mBERJkW1yJIO2ALAVRCTUNYaHabn3AES0QUnUVgB6w3nYDN0wHbAKCnu9s8ahgcwRLRHc4IDVmWNQRgCdRK17TmweYBqABQB6DHNLs/yfiDERFlmGGEhrpN848AFkO1UKvSGcHm64DVI9juPxiNjVwqS0R3NMNoPNbV1f0HAIt0PlYgjWladg+2DsAC0+wezvSDERFlmhEyhkzT/ATAfQDuSTdgXVBD3ykALNOyToRCRsYfjogos4wh0zSPAbD0CNaLNHqw9jStEIClptV9PPMPRkSUeZZpHsc4ZxEUIjYPdolpmsc4giUiik7TGtd2hfEBu9gyzYw/FBHRRODEhtt2wDYCWBKxIhl/KCKiicCJgHUjth/sUrPbYg+WiCjk3JEx0c1eLJMBS0QUCjkTsCXgsd1ERNdwKmB9DFgiokROBGxZ/AjWsqyPeaosEd3pnDpV1j6TS/VgLevt1tZWLpclojtaa2vrsGVZb0OdydWkczKtU2XtgO2ZPXv2r9rb2zP+cEREmdTe3j40e/bsX0GdKpt+wNbV1Xmh5sHeHwwGt82ZM+e34XA44w+YKsMwhg3DGHH0bX/tetdk+v54P7wf3s+tuZ8b5UE4HB6aM2fOb4PB4DYA9wNo1DmZcsCWQC00aAAwC8BDLS0tuzo6Ov6npaVl0vVir/cfNlPBOtHugffD++H9jH5tS0vLMZ1/uwA8pHOxQedkyoceuhDbrnAa1HD4UcMw9nR0dPyutbV1qLm5ecgwbq/9CW635yGi9BmGMdTc3DzU2to61NHR8TvDMPYAeFTn4TSdj5U6L1OqwkAgUAEgAPWmbBbUW7Of+ny+V8Lh8D+0tbW929nZeaijo2P4dnG7PQ8Rpa+zs/NQW1vbu83Nza95vd7dAH6qc3CWzsWAzsnCVAO2ALE+bAOAGQDm6m++FsBGAE8B2Abg7wA8B+DnE8gvRnCjr+0A8LMJeH+8H94P7+fm3s9zSV/7OWJ5sBXA41C51weVgzMANMT1XwuQYuUh1iYIQqV1J1RjdyGA5QAeBvBX+oN/AuAx7a8noceghv4/ngD3QkS3zmNIzC77949C5dsqqLxbCJV/nVB5GESsPZCHFCsHehQLdWpiHYAW/c3nAoj4fL4lAB4A8CBU03flBPJwnLF+bYX+QU7U++P98H54P87fz0OIZZhtJVQePAA13zUClXudUDlYh9hpsgVQeZlSZUGlciGAMj0UrgMw1e/3T4fqQcwFMB/q6ISeCWahlsrXIrfwWdK5P94P74f34/z9dAHo1r9amp0F86FybpbOvakA6nQelkHlYx5UXqZUWQByQqFQPtQQuAwqsYNQPdmpAFqhehEdAGYC+AFU8E5E17u3H2id+lkm2v3xfng/vJ+bdz8/1OKvnQmVBTOgcm4qVO4FoXKwDIBL52MOgKz/B7DfD4yZ/7Y7AAAAAElFTkSuQmCC) no-repeat!important;color:#fff!important;height:114px!important;width:344px!important;border:none!important}#quick-add-form{padding:18px 0 0 19px !important}#quick-add-helptext,#quick-add-instructions{color:#fff!important;font-size:12px!important;padding:6px 0!important}#quick-add-bubble-holder td{background:none!important}#quick-add-subs{background:none!important;padding:2px 0!important}#quick-add-close{height:28px!important;width:28px!important;text-indent:-999em!important;background:transparent!important;margin:-3px 311px 0 0 !important}#quick-add-close:hover{height:28px!important;width:28px!important;text-indent:-999em!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAC2klEQVRIie3WP0jrUBTH8SSIaJJacKtODg5uiuIi2EEX0aFOXRQHnUUnBVEC4m4REVw6CRIHN4eqY8FBKCIIDqIdtFQNoWCtteL3Le9eeltf+/wzvOEdOKR0uJ/8cs9Nq2n/63dlMhknn89TWc/Pz2SzWefHIN/3nUrE8zzu7u6qcM/zvgeXSiUASqUSrusyOTmJZVnYto1lWViWxdjYGPF4nGKxKBN/CXt/fwcgmUzS19cnAdHlqGVZDA4OcnFxIdN+Cnt9fQVgf3+fYDAoF69EynHbtgkGg2xtbX0OFXuWTCYV7DO9u7sLgO/7Tl0QoFAo0N3drSQYGRlhfHy8avGuri6WlpYIhUKYpollWbS2tnJ/f18/ZTabdQB2dnaURYeGhuRj2tzclN/39/fLhV3XpampiYaGBgzDYHFxEaD2kSkUCgBEIhEF7O3t5eXlRUEHBgYkBrC9vY2maei6jq7rtLW18fb2VjslQD6f/3BfZmZmEDcE8PT0JD8nEgkMw5CguIqprQmm02kCgcCHPT09Lc/bR1h567rO4eFhffDq6opAICBH3bZtCYbDYXzfV8BYLFaVTHQikagP5nI5JZUAw+Ewj4+PEhL7A7C+vq5AolOpVG1QHPienh4F7ejoULCjoyOmpqaUQVpZWZGQpmkYhkEul6sNZjIZB2BtbU0BI5GIXPj4+JjGxkY0TWNiYkKiBwcHChiNRgFIpVLOH0HxWD3Po729XUGXl5dZXV2lpaVFeWzDw8PEYjE6OzuVvTw5OamdTtTDw4MDEI/HJVb+vjRNU0kirlrZwMzPzwNwe3tbO115SoCFhQUJCrS5uVkBtYrJHB0dRfys/RVWiW5sbCgvcNM0q46BgOfm5uQ5/RRWid7c3DA7O0soFFISio5Go5yensrB+hImSkwuQLFY5PLykr29PVzX5ezsTI4+wPX1tfMtrLzS6XTVfxtR5+fnPwf9r3++fgHMwqHTPPLucAAAAABJRU5ErkJggg==) no-repeat!important;margin:-3px 311px 0 0 !important}#quick-add-close:active{height:28px!important;width:28px!important;text-indent:-999em!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAC3UlEQVRIie2WvUszQRDG74IoMV82QrDQykYSsBA/SBUQYpFCUqUMWKmQJljngiKCNoJJkSqQxE5JIWIgIBYKsTCRnBz5dPYved7GXW7vNDGvb/XiwLBwt8xvn5nZuVOUX/swwzC0wWAAIhLOGMNgMIBhGNo/A3W7Xc0MISI0m008Pz/D+rzdbv8M/P7+DiJCv99HNptFLBaDy+WSfHNzE6enp+h0OmLvj2BXV1cIBoMC4Ha7pZX76uoqarWaUDs2jDGGfD4Pn89nC26Gm9/5fD4cHx+PB+U1u76+htfrtQE+g1rXi4uL79f0YyOWlpakwOFwGFtbWzbw4uIi9vf34ff74XQ64XK5MDMzg5eXl9EqDcPQiAjn5+cSbGNjQ6Tp6OhIAJeXl0XgbDaLqakpTExMQFVV7O7ujlbJ71kkEpFSFgwG0el0wBgDEeHw8BArKysCxhjDyckJVFUVPjs7Cx5vaDoNw/i0QeLxuGh9vo8foFgswuFwQFEUKIoioLxrhwKfnp5E93k8Hsnj8Th6vZ40aTjMrI5Dy+XyaODDw4MNxH19fR2tVkvAiAiZTEZSZlZYLBbBGBsO1HUdHo/HpnBtbQ3NZlOoM8/VdDotgbjf3t4OV8inSyAQkGDz8/NoNBoCUCqVEIvFpJomk0lJqcPhgK7rw4GtVksjIhwcHIg6ut1uRCIREfjy8hKTk5NQVRXb29tot9tgjKFQKEjAaDQKIkK1WtW+BPK0NhoNzM3NSSqTySRSqRS8Xq9Uq1AohHQ6jYWFBSmtlUrle+Pt7e1NIyKcnZ2JOpqvh9PptNVKsVyHnZ0dEBHq9fpwdWaVRIS9vT0bcHp6WoIolmYJh8Po9/vjfzE4NJPJfKnQCkskEuh2u+PDuPG79vj4iEQiIQa0NaXRaBQ3Nzd/9y202uvrq/jF6PV6uL+/Ry6XQy6Xw93dHXRdh+lg2o9gZqvX67Z/Gz5xRrb+r/1X9getNGMGOKD4jQAAAABJRU5ErkJggg==) no-repeat!important;margin:-3px 311px 0 0 !important}#quickadd{-moz-appearance:none!important;background:rgba(255,255,255,0.6)!important;width:280px!important;height:16px!important;border:none!important;font-size:12px!important;-webkit-border-radius:9px!important;-moz-border-radius:9px!important;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.9)!important;margin:1px 0 0!important;padding:1px 10px!important}#quick-add-btn{position:absolute!important;top:76px!important;left:254px!important;height:20px!important;padding:3px 20px 0 1px !important}#quick-add-btn .goog-button-body{width:66px!important;height:19px!important;font-size:12px!important;color:#fff!important;padding:1px 0 0!important}#entries .tags-edit{z-index:1000!important;background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARIAAAByCAYAAACftF7NAAAQ7ElEQVR4nO3c7ZMV1Z0H8O9ABAeBGWRwhEDP6T59L/Nwb/fp2/MAEpGHGR5cLFEBHxZWjYDIqrsxm83srhYmCIxotMQkhmztltlKYrlVW+v6EGNtpeKWW6msxigwDjPTfXeTt/sif8O+6NNw6Ok7DHRqweR7qj51H7r7PPzOmZ/9cAWYWpoANANoA7AUQAcAodma+Z6f+ZmfP1+fOzKfG32XHiv09qVI8kIzkjyRW5oANC1cuPB6ACu2b9++e3h4+IVDhw59cPTo0d+OjIz8LxH9QYhGRkZ+Z3z+nf4ud/+jR4/+9tChQx8MDw+/sH379t0AVug80ZRNKE0AZutsIx544IHh9evXv14ul39mWVa9gTgj7zsi+gPgOM5H1Wr17e3bt//zE0888XV9ltKm80aTmURaAIg9e/b8ted5/2Y1TiCNEgYTCdEfgbVr1/7LY4899jWdTFp0/sBs13XnAli6cePG+1etWvWadWkJJMVEQvRHYmho6LWNGzfeD2DpiRMn5gLAHADzAJT37Nlz2HXd7OXMFe80EV1durq63tqzZ89hAGWdP3CtPj3xd+zY8XZHR8fZK91JIrq62bb90Y4dO94G4Ov8gfn6pkn/tm3bRq90B4no82Hbtm2jAPp1/kCLfj5889DQ0G+udOeI6PNhaGjoNwBuBrAU6e9GAKxnIiGimRoaGvpvAOt1/sAyAJ0A7mAiIaKZ2rRp0/8A2KIfAzORENGl05c2d+j8wURCRJeOiYSICmMiIaLCmEiIqLBsIllqJJJR27ajK91BIrr68YyEiApjIiGiwvg7EiIqjGckRFQYEwkRFcZEQkSF8fEvERXGMxIiKoyJhIgKYyIhosL4OxIiKoxnJERUGBMJERXGx79EVBjPSIioMCYSIiqMiYSICmMiIaLC+DsSIiqMZyREVBgf/xJRYTwjIaLCmEiIqDAmEiIqjImEiApjIiGiwvg7EiIqjI9/iagwXtoQUWFMJERUGBMJERXGREJEhTGREFFhTCREVFj2dyR8/EtEl4xnJERUGBMJERXGREJEhTGREFFhTCREVBgTCREVxv/7l4gK479HQkSF8dKGiApjIiGiwphIiKgwJhIiKoyJhIgK4+NfIiqMZyREVBh/R0JEhfGMhIgKYyIhosKYSIioMCYSIiqMj3+JqDCekRBRYUwkRFQYf0dCRIXxjISICmMiIaLCmEiIqDA+/iWiwnhGQkSFMZEQUWFMJERUGH9HQkSF8YyEiApjIiGiwvj4l4gK4xkJERXGREJEhTGREFFhTCREVBgTCREVxkRCRIXx8S8RFWLbdjQ0NDSaTSQrAdw+ODj4Rnd3d/1Kd5KIrm7d3d31wcHBNwDcrvPHuUSytb+//4RS6op3koiubkqpuL+//wSArQBWYsmSJTcCKANY397efnhgYODn5XL5inf0MtUzuI3buO33uy0ul8vxwMDAz9vb2w8DWK/zB9oBOABWAbjHdd2XgyA4XSqVLv1eiTA/i9iyrFg02ke/CpFXl7iwDmHFjiWSuoSILduOLGHFtm1F5/cTaZ3TXZpxG7dxW4FtpVIpCoLgtOu6LwO4R+cNBwDa9L8n4OnTlH1CiJNKqfe7u7tj13VjIcS5ioSVkxwsK7alHblSxFI6sSNF7DgyFkLEIk0KQlyQRBxLJxFhxZYl6paw6pYl6pblxMISybHCiYXlxK4jY+nISSnluJTumJT2mC3tMSHtMcd2xoXtjDuOjBxHRtKRkWXJWFgitq3GN47NMV3SNusyt5njn6a9bGK97L6ITCIXIrYcETuOFTvC0XPj6DkQM2rv/H4itiw7Evq9o+fKEk4sc8aYtNWon5ZRZ5FYn+9bozGIC/qi14bQ+ztWLJx0rZpjLrheZrRNXNieEFPnLzdm2fmZpr3ptjXq57mxO7HrunF3d3fkKfW+JcT3AOzV+cIDILBw4cLrASzXd15X6buwBxcvXvzdcrn8T57nvRuG4SdKqXoqCIJYKVUPVBAHSkVVz5+oVCpnPd+f6OnpniyXuyPXdWNXylgIJ3aEiB1HxMIRsXCsWDhW7AgrdoSIbWHXbWnXbduuJwvcjR0hY2nLSEoZua472dnZebba03W6Uql82ClLv+gQ4v0VlvUflrXiA8ty/tOW9i9KpfKH5a6uT7qqPaPVqnem4vtnPd//xFPeuFJqMgiC2PdVXflJ/2u12qlQhfUwCOJz49HvwzAcDYIgClQQK1/VfWPstVrts6AWREEQnjsuFYbB6TAM4yAMpmxTYTiaHBdEQagyx6nRIAiiWi2ILjhGqXoYhqNp38IgiMP0e12nUmpCqaQvgQrP1+urM0qpSd9X456vxqvV6ljV885UvOqZ7qr3y0pP5dNKxTvTU618VqlWx7yqN1b1/aimaqeSOpOYBUZ8wjA8XVNqMlB+5KtqVK1WxyvV6ni14o35fvVjr1od86pqzPO8CaX8ybQOFaozQRBEoQovWD9JXNSZMMzEKo11UBsLwjCu1VQ0NdbhaBAEubEOw3C0VguiIAxi3/d1myoOVDVSvv9JteqfrXreWf065lWrY77vT/qef9rzvQlfeRNKqUmlVKSUipXv11UYnsmbc+1MUKtF4YXjSl571ZkgCONzn5PxR0GgopqqfapUEKvAj/yqH3m+N1H1vHHPq5wNvOBj5SUxrAYqUloQBFFQC04pX481SNZoUmcQhWF4+oK+nV/bUbqWzs9BWNdzFNVqtU+Nv4PIT2IWeUpN1Gq1jyqe944r5Q8WLVr4bQAHdZ5YpfPGcgBo0fdJHAABgLV6p70AvgLgKQCHARwFMALg2RwvzMKsl+7ecdcvler9qLuz+6xbKk26rpucTbhuLG1Zdx0ndpzkv2COK2Np23VXylhKWXcdN7ZtWZfSrUspIzdJIhOdXeVTYS341cDq/p/1r+p73bKW//2CBS3fm98y/5X5C+e/Mr+5+bvNzc3fmXtN87dnz559YtasWS8Cs54H8ByA4zme1eM4pl/T744b4znW4NhjhhEjHtnXvPaOGsc9i6l9yYvrMQBHGtQ7klNftr20zbSeZwB8E8AhAE/r99/U21KHjeOyY0/becGQxtqM5UjGEaM+c3zmGMy1ddw4LhvbmcTzGWPc2WOe0fUezYw7HfsxvS07jux3062l7LHZuTP3S+P4ohHP4zqmzzWo7wimrgWzn9k20rU03RyY43vWaCddI38L4HEAX0aSH25Gki8cnT8wD8nlzQok2aUPyQ2UWwHsBHAfgAeRJJb9AB7WDhgeAXCwLxx4ac8D+99U/ave7+rpPFUul846Uk46Uka2dOvSdWJXOrF0nNh19CWLa9elLetSyrotZd22S3VXunGpXBrvKneNKt//r7Vr174zuG3z97u6up5ccN11fwXgCSRJ7isA/lJ7HMCjSLLlQd3HfUZ/Tfv1ePK2PWyMc39mnOY2Mw5mnfsN2fb25fRpv/4uW29qH6bGPH2f11a6j9le2v5DeiE8qF9Ne4190vfZMT6czjWAP9fvHzH6mTeGfZm+pPvtN7alnw9gakzzNGovjUmjud2fGV/WQzn9TI/NxvPhnG3TraW0f49kth00ZNeaGfe0XbP97LrMW3fmWt6XqXd/pl6zvn06Hg8C2A3gbgB3IvmnFdchyROdSPJGGwBcC6AFwA1I7pV0653WAtjS1tZ2m65gF5KbK/dOY++am24+su/AQ6/19q36956enlOuW/7Mkc6kI5xYClF3hIilELF0RCykEztCxkKKuiOcWNqyLh0ZS9uZKJe6RpWvPrzlSze9deedd51USu27bsF19+tB/SmSBHeffp9K+3Ffpl/Zft+jA5N1j7Htnsz36XG7Mvvm1Z0n24Z5XN62vP0axT+vrfR1p7Yj407DDj2udN9duLDPZtuN+pjGZZch+3kX8uOeNwfZecqOOS9eeXNrxqRRLNLv7sr5Pq/vjdZJtk95Y8rG0Fy35th25YzzbkxdC43auxdT+3mxtWkek8bkDgB/giSBbASwBkAvkiQikOSNFgCYA6AZQKs+RREAOltbWxWSa6C1ADYA2Izk5sp0bgewc93Quq8fOHDgR6v7B97rrHR/bLuls47tTAp9A8cR+gbd+ScxdWGJumVZdcd2JmWpNFatVn51yy23vPXQQ1/+vt/Xt3v2nOa7AGxDcqZ0sX6kthivW2aw3bS5wfdZ2fo2Z47dPE0bjdrP1nm5NmmDeg7XG9Zp6ecNer9B47jN+vXWTNyz49xs7Ls5c7z5eVNmv8ux5SLf523fBGBI26jHujEz9g2YGodB47iU2f9LnY/snDYaR9rf9NWcy7w1le1Ldt1snqZ9c17SMZrr5UsAVgPoBxDOmTOnguR3Zx06X7QiyR+Y7bruXCSXOK1IMswKJPdMOgFUkVwL9erKBpAkmDw3IUk8t27dtPWRg48+9oPVqwd+2l0u/dqW7phl2ZPnkkeDO/G27U5Ue7p/vWbtTe88/hdf/cdarXbbF/CFjUiuydZM03aeAUO/8dqf2Tad/ovo0/ozdee10X8J9Wbr78tpL9u22VafnrMQQE3PYQBAIbnT7mvpe6Wl+9X0sReb97zx9F2GmcbgYnU0im0ajzQGgRGD7PjNOKTxS2PZa9TVaI7y5qNR7NLXRmPuNdruy9Q70zV0MQNGezXNQ/K3X0FylVICIAFYAL6I5HKmBcA8nT/QhPPJpFlvbNPZZjmSMxQHyY9OVmqdDXQB6NETsWrHHXf82Vef+No/9K9e9W6X2/2JYzvjlmVN5j+CErHd4UysdDtPr1m9+s0nnxz+YeiH63UAPT2gRu1mrcxRLqhRfXltXY5GdZVxaf1Pjytprp4/0YBtcPRicfRxaR1pnV1IFpUZ5+nibvarlPM5+112HJc69kb1p++lHmc67o4cZlzSeKRcQ179jeY2L1ZZeWNI25LGXKZtXmxdz3S9mfFK20pjZCE5qfgikl/AtyNJIIsALEByW2QOgNnQpUl/mKM3zgPQoh8NtwFo14ll6QwsQ5KAbACV3bt37/q74b95tS/ofbck5Rm7w56wLCv7+47Itu2Jcqk8NtA/8PaRIyOvDwwMhHpwHbq+ZZk2lmW+S92Yo30aefs3MpPxT9eP3+cxjfrYbry2aa0AFurJNy1E8h+OVCuA6wEs1sct0dpzYt2O5Ox1ibFvetxiQ5thiT7mhsuMf6N4NNrHjMkSJH8A5ngXNpDGYpGOh9n/NB43Gm1M14dlmLpelxnHpHWlcVmCC+O62Hh/Q+aYS1mP08Urnct24306f9frWLQiWTPzAczV0iTSBKM0YWpCaUaSVPIW3HQW6U7cCKBj7969t3/j8Dderfm1n5ZLcty2nWwimSzbznhfX99bx44ff6N3dW+AJBO263oWXaS9tO8sLCxXSTETSmqO67pz9eXPtTPUDOA6JH/o7Y8++ujWw8eO/rCnp+e9DkeMG2clkS3t8TDsffulF194c82aNSuRZOAWfXzzDNpiYWG5yksTgFmmp59+ekZ27tw5OwzDa5YtWzavpaVl0fDw8OBzIyM/6ursea/D7piwHCuyHSuq9dbefPmll9/ZunWrbG1tbV2+fHlzGIbX7Ny5c/ZM2rmy4WFhYfn/KOnZzbUAWoaHhzd86/nnf9zVtfI94cjY9/03T77yyk/WbVkncP76a8p1FwsLC4uZTBY89dRTtzz/rRd/vGHDhn89efLkT2677TYLyWUMkwgLC8u0JU0mcwHMGxkZuenVV199/d57721Hch8k9w4wCwsLS7aYN3KvQZI8rsH5BMIkwsLyOSz/BwHrXEneEVcoAAAAAElFTkSuQmCC) no-repeat!important;color:#fff!important;height:114px!important;width:274px!important;border:none!important;margin:-90px 0 0 -16px !important}#entries .tags-edit input{background:rgba(255,255,255,0.6)!important;border:none!important;margin-left:10px!important;-moz-appearance:none!important;-webkit-border-radius:9px!important;-moz-border-radius:9px!important;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.9)!important;padding:1px 10px!important}#entries .tags-edit-tags{border:1px solid!important;background:#fff!important;width:220px!important;height:16px!important;margin:13px 0 0 20px !important}#entries .help{font-size:12px!important;color:#fff!important;margin:6px 0 0 12px !important}#entries .tags-edit-buttons{margin:12px 0 0 95px !important}#entries .tags-edit-buttons .goog-button-body{width:66px!important;height:20px!important;font-size:12px!important;color:#fff!important}#quick-add-btn .goog-button-body,#entries .tags-edit-buttons .goog-button-body{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAAAUCAYAAAA5g+sCAAACkElEQVRYheXYX0vbUBzG8bwHm6QprIZUK0mT4zTOqTNZGyOiQvFSvHIw/K8gqOhCB30RpTe9W2cVrX/qhfZmuLu9q+8uhHUbynbb5gefF3AeDofzeyTphXEch3Q6jaIoJBIJ+vr6ulIikUBRFNLpNI7j8NJ5nw1AURQKQUhUKlNvNLlvP/Lt+4+udN9+pN5oEpXKFIIQRVH+HYhlWThimEq1xvlli0/RZ5aXV5hfWCQMZ7vS/MIiy8srfIo+c37ZolKtYTsCy7KeD8M0TXw/z81dm6PjiGAmpBDM9JSZcJaj44ibuza+n8c0zT/DcF0X2xHc3LVZ/fCR9/lCT1v98JGbuza2I3BdtxOGpmlUqjUODo/xPD8WDg6PqVRraJpGEARIIyOjFIKQs4tbPM9netqLBc/zObu4pRCEjIyMIhlGhqhU5uDwhKmpd7FycHhCVCpjGBmkZDJJvdGkWFxiYmIyVorFJeqNJslkEkmWZe7bj0x7PuPjb2Nl2vO5bz8iy3IniInJKUZH3ViZmJzqBKGqKvVGk7m5eYaHX8fK3Nw89UYTVVWRdF0nKpXZ3dvHESJWdvf2iUpldF1HEkJQCEK+nl1h2za5XC4WbNvm69kVhSBECIEUBAGqqlKp1tjY3ME0zVjY2NyhUq2hqurTh0qSJEkIgSOGuW49UCwuMTQ01NOKxSWuWw/Yjni6Db+Prhv4fp7r1gNr61tks1kGBwd7SjabZW19i+vWA76fR9eN5zfQ/v5X2I6gUq3x5fSS9Y1tPM/HyuXIZDJdycrl8Dyf9Y1tvpxe/lrDDeOFEDrFjEUqpfVsMZNKpRgbe/N/TZU7ZmM7JoZhoGlJZLl7qzpZltE0jYGBQVzX7TyMf81POmKZwWJSjWEAAAAASUVORK5CYII=)!important}#quick-add-btn .goog-button-body:active,#entries .tags-edit-buttons .goog-button-body:active{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEIAAAAUCAYAAAA5g+sCAAAB5ElEQVRYheWYTWviUBiF/dWSkLtSiKjYJFUc6KjjzSTGIrbg26V01UKp9hMKWmxDCv4IcfHMolqHoZUyO82BZ3kX93Bfzj1vJrNFuVxOTNMUwzAkm83uJIZhiGmaksvlZNtdv1QQRhInc/ZFcTIn7HQxTfN7hrheVRbL98Ov8RvD4Tn9k1O63eOdpH9yynB4zmv8BsBiCa7rbTdD60AAnmcxnahL2In2iqh7zPMsBkDr4HMzXNcTgIvLK34H4V5zcXkFfPIylFKyWMJkOkNrPxVMpjMWS1BKbcwIwkjen4tPu61TgdY+AEEYSa1Wl4xt2xIncybTF1qtX6liMn0hTubYti0ZpZQADAZnNBrNVDEYnAGr8TAMQwDa2ufo6GeqaK/GwzCMjRGNZot6/UeqaDRbGyMsyxKAXq9PtVpLFb1eHwDLsiSTz+clTuY8PD7hHR6miofHJ+JkTj6fl4znebKOT9d1cRwnFbiu+xGfnrf6WFmWJYsljG/uqVQqqWB8c89iuRqLf8vWOkbL5fJes47NL8vXunRdj24plUoUi8W9olQqcT26BcD3A7bXcNf7qOGj8R1a+xw4DoVCYSc5cBy09hmN775fw//WPi5mgjD6vy2VbduilNr5VZ1SSgqF4lYT/gDqlq8QaRlLsgAAAABJRU5ErkJggg==)!important}#quickadd:focus,#entries .tags-edit input:focus{-webkit-box-shadow:0 0 4px 1px #2878d4!important;-moz-box-shadow:inset 0 0 2px 1px rgba(40,120,212,0.7), 0 0 4px 1px #2878d4 inset 0 1px 1px rgba(0,0,0,0.9)!important}#quick-add-btn .goog-button-base-inner-box,#quick-add-btn .goog-button-base-outer-box,#quick-add-btn .goog-button-base-top-shadow,#entries .tags-edit-buttons .goog-button-base-inner-box,#entries .tags-edit-buttons .goog-button-base-outer-box,#entries .tags-edit-buttons .goog-button-base-top-shadow{background:transparent!important;border:none!important}';
	//Offline 18581
	css += '#global-info .offline-status{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAACdklEQVRIibXWyU7bQADG8VEkLki8QJCCQAnLIYQIySjE8hIjJ7G8b2OPxhM7Qe0LtNdeOLVcOHPi3ehz5OsBUSvtcWCk3/mvmdEshLRjRAj5Tgj5RQh5/CRvob29vZdut/v7+Ph42+/3cXp6Km0wGKDf7+Pk5ARHR0cghBCyv7//4/Dw8PXi4gLD4RCj0QjX19fSxuMxRqMRhsMhzs7O3mKdTufp/Px8Ox6PMZlMoKoqDMOQpmkaVFXFzc0NLi8v8b6Mj1dXV5hOp7AsC4vFAq7rSlsul5jbc+i6DkVR2piiKDBNE47jIAxDJEkiLYoieJ4H27Zxe3vbxiaTCWzbRhAESNMUeZ5Ly7IMURRhsVhAVdU2Np1OMZ/PEUUR8jxHURTSKKVIkgSO40DTtDamqiqWyyXiOAalFKxk0oqiQJqmcF0Xuq7vxhzHQZqmKIoCnHFpZVkiyzJ4ngfDMNqYpmlwXRdZloGVDJxzaaxkyPMcvu/vxnRdh+d5yPMcnHEIIaRxzkEpRRAEME1zN+b7Piil4JxjtVpJq6oKZVkiDEPMZrM2ZhgGgiBAURSoqgp1XUsTQoCVDFEUwbKsNmaaJsIwRFmWEEKgaRppq9UKnHHEcYy7u7s2NpvNEEURWMlQ1zXW67W0uq7BOUeSJLBt+/8YZxx1XWOz2UhrmgZVVSFN092YZVmI4xicczRNg/v7e2nr9RpCCGRZhrk9b58YwzC27zP7yNj7zP7Ger3eT0VRXn3fR1EUEEJ83J6xf/bs4eGhOTg4eFFV9TUMwy2l9EOvK9/320MNoPv8/PxtMBg8djqdp0/46Ox8eAiAHoAYwBcAXz/DH0gjUqWx0pFbAAAAAElFTkSuQmCC)!important;width:27px!important;height:23px!important;display:block!important;float:left!important;padding-top:0!important;margin-top:-1px!important;margin-right:-1px!important}#is-connected,#is-disconnected,#is-syncing{position:absolute!important;background-position:0!important;width:27px!important;height:23px!important;padding:0!important}#is-connected{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAACHElEQVRIibXWP2gaYRzG8R8uB1k9HAqeIOikJ4Ih4sFN3upQEFwcQqAdHFzatUvI0AoSR2/Iroicg+Ci3kXByTT1LwgOJpDJxUHSgPXpEPoWSdR3uYPPds/7hVvuJfr/hIjoKxH9IKKcTV5DkUjkZjQaPW632z+w6SEiopOTk2/D4fBhs9nATkRE5HA4rp+fn7cvv19gp3+fMbder8HD7/dDEIQdLpeLa8tiq9UKPGRZhiiKOzweD9eWxZbLJXioqopgMAhZlplwOMy1ZbGnpyfw0DQNsVgMiqJAURTEYjGcnp5ybVlssViARzwe34kpioJgMMi1ZbH5fA4e78VkWebasth0OgWPfTGeLYsNBgPsc3V1BUEQ4HQ6EQgE3o2JoghBEJDJZPaew2L9fh/7TCYTZLNZuN1uhEKhN7FwOAxJkpBOpzGbzfaew2K9Xg+HjMdjXFxc4OzsbCekKAqi0ShSqRRGo9HBM1isc3uLY37d3yOZTL6JJRIJ/Ly7Q7fTObhnsVarhWNM00S324WmaSykaRpM04RlWUf3LNZoNMCj2WyiVqtBVVWoqopKpYJ2u821ZbF6vQ5e7XYbuq6jWCzCNE3uHfvFGIaxNQwDvCzLgmVZ3O8bhvEakyTpe6FQeKxWq7ATERFdXl6ee73em3w+/1Aqlbblchl2ICIiAB90Xf/i8/lyDofj2oaLzs6FhwBIAD4C+ATgsx3+Au/Fqr/obdm6AAAAAElFTkSuQmCC)!important}#is-connected:active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAADyElEQVRIibXWT0sqawDH8UEIIWhTrm7qrkXhHyqp1JAKoYKk0CwNEzUdLToZlYmKIjMZecd/acqoaN4UbSNG0Kn3c87r6HcWcfV6m9pEA9/d7+EDz4gMQfQeOUEQPoIg/iYIgvmm3qCBgYGaUCj8LZFIXhUKBZRK5Zebnp6GXC7H+Pg4hEIhCIIgiMHBwcjU1NRvnU4Hi8UCkiRxdHT05VwuF6xWK/R6PZaWlt4wHo+XWV1dfd3b24Pf7wdFUUgmk1+OoigEg0F4PB4YDAb8e42M2WyGz+dD/CoOtsCiXq9zNjo6Cj6f39fw8DDnli2wSCQSCAaDsNlsPcxutyMSiSCXy6Fer6PdbnM2MTEBgUDQl0gk4tw2Gg2wBRYURYEkyR7mcrlAURSKxSJarRYeHh44UyqVkEqlkMlk3eRyOee21WqhXC4jFovB4/FwY81mE51Oh7PFxUWoVCqo1Wqo1WqoVCooFArO7X8xt9vdw5xOJ6LRKAr5PBqNxofX+H9MrVZDKpV+eo00Tfdfo8Ph6L6z29tb3N/fc7awsPAOk8lknNtarYZcLodoNAqXy9XDbDYbQqEQMpkMKpUKms0mZx9hXNtqtYrr62uEw2E4HI4eZrVaEQgEkEwmUSwWcffPXTeSJMHn8zEyMgKJRMKJCQQC8Pl8GPSG7rlSqYRUKoVQKNT/07dYLPD7/YhfxXFzc4Nqtdrt8fERJElCJBJBLpe/wyYnJyEWi7G5uYmXl5fuuUI+D4ZhEAgEYLVae9iOeQdnp2e4vLxENptFuVzu6/n5Gbu7u5idne2D1Go15ubmYDAY8PLy0ncmm80ifhXH+fk5LBZLDzOZTPB6vaBpGqlUCoV8vi+2UMDPpyfo9fp32NraGn4+PaHIsn1n0uk0YrEYzk7PsGPe6WFGoxE/fvxANBoFwzDI5XLvKhQK6HQ60Gq1XUir1aLdbqNYLL7bJxIJUBQFr9cLk8nUwwwGAw4ODhAOhxG/iiOdTnPGsizu7u6g0Wig0WhQqVRQKpU4t/GrOCKRCA4PD7G1tdXDNjY2QJIkgsEgaJoGwzAfVi6XkUwmwTAMKpXKh7uLiwuEQiHs7+/3/vV5PF5mZWXl1W634/TkFOFwGLFY7NNqtRpqtdqnm3A4DJ/PB6fTifX19TdMLBbHZ2Zmfm1vb4MkSZwcHyMUCn25k+NjeDweWHYsWF5efsNomrYPDQ3VNBrNL6PR+Gqz2eB2u7+czWaD2WyGTqfD/Pz8Gwbgr1KpdDY2NsbweLzMN3zo9H3wEADEAPQASADu7+gPQs0hpG5BO/wAAAAASUVORK5CYII=)!important}#is-disconnected{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAACFklEQVRIibXWv4vaYBzH8S8ZXTUnNpAhICJKiqAYDbgLCnr/QZd2l3atg1MbkHN1OHDUQbIIDuJwHRxE8CeKouAdCIKLg9gD66dDuaccnvrckMBrCp/nDVnyEP1/PhLRNyL6SUSGRf6FgsHg/XA4fDoej39g0UNERDab7ftgMHg8HA6wEhERCYJwt9/vj8+/n2Gll89o7HY7vIdpmshms+/asNh2uwWvdrsNh8MBm82GUqnEvWOxzWYDHqPRCB6PBy6XC5Ik4ebmBo1Gg2vLYqvVCtcsFgvEYjFIkgS/3w9VVSHLMhRFQbfbvbpnseVyiWvS6TScTid8Ph80TUMkEoGqqpAkCaFQCNPp9OKexebzOS7JZDIQRRFerxfhcBi6rkPXdWiaBr/fD6fTiVQqdfEMFhuPxzjHMAzY7Xa43W6EQiEWehEOh+H1eiGKIjKZzNlzWKzf7+Oc2WyG9XqN9XqNVCp1EtN1nb1fLBZnz2GxTqcDHslk8iSkaRrXlsVarRZ4JBIJRKPRV7FAIMC1ZbFfDw/g8VZMVVWuLYs1m03wSCQSiEQiJzGeLYvV63XwiMfjb8Z4tixWq9XA41yMZ8t+MaZpHk3TxDW9Xg+TyeQEz5aIiGRZ/lEoFJ6q1SqsREREuVzuk6Io9/l8/rFcLh8rlQqsQEREAD4Ui8WvbrfbEAThzoKLzqsLDwGQAdwC+AzgixX+AqDssKrkHJhVAAAAAElFTkSuQmCC)!important}#is-disconnected:active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAADyklEQVRIibXWS0tqawDG8YXQRGhSiHQ0oYEDSQy7qRkVQZkDKRJTQ0RNl3Y1ygsqiiwz8njXFC+kna2oDaIGZw/ae9oX2H2FvT9HzxnE1iOu9iQS/iOflx+8S2QRRO8zRRCEmyCIvwmCiH9Sb9DQ0NAtl8v9JRQKX2dnZyGTyT7czMwMpqamIBAIwOVyQRAEQTCZzND09PQvlUoFg8EAkiRxcnLy4Ww2G4xGI7a3t7G6uvqGMRiMjFKpfN3b24PX6wVFUUgmkx+Ooij4/X44HA6o1Wr8vsa4Xq+H2+1G7CqGUrGERqPxxzweDzQazR83pWIJiUQCfr8fJpOph5nNZoRCIeTzeTQaDdzf379bNpvFyMgImEwmXC7Xu7tms4lSsQSKokCSZA+z2WygKArlchntdhuPj4+01et1TExMYGxsDBwOBywWC4lEgnbbbrdRrVYRjUbhcDjosVarhYeHh4Hu7u4gFovB4XAgFAohEonA4/EwPj6OWq02sP8/Zrfbe5jVakU4HEaxUECz2aS9lpWVFbDZbExOTkIqlUImk0EkEnXxTqdDe42RSKT/Gi0WS/eZ1et1dDqdvrRaLVgsFgQCASQSCeRyOeRyOaRSKYRCIdhsNpaXl/vO3N7eIp/PIxwOw2az9TCTyYRAIIBMJoObmxu0Wq1uh4eHGB0dBZ/Px9zcXBf6nUQigUAgAIvFglar7Z6r1WrIZrMIBoOwWCw9zGg0wufzIZlMolwu48s/X7p9/fcrXn684OXHC1Qq1QAml8u733//9r17rlKpIJVKIRAI9P/0DQYDvF4vYlcxXF9fo1ar0aZUKgcgqVRKuy0WCojH4/D5fDAajT1sV78L17kLl5eXyOVyqFartCkUCiwsLPRhYrGYdpvL5RC7isHj8cBgMPQwnU4Hp9OJSCSCVCqFYqFAGx0mEolot+l0GtFoFK5zF3b1uz1Mo9Hg+PgY4XAY8Xgc+XyetvX1dchksgGMbptIJEBRFJxOJ3Q6XQ9Tq9U4ODhAMBhE7CqGdDpN29raGi1Gt41dxRAKhXB0dISdnZ0etrW1BZIk4ff7EYlEEI/HaXsPo9teXFwgEAhgf3+/96/PYDAyGxsbr2azGedn5wgGg4hGo7Q9PT3h+fl5ILptMBiE2+2G1WrF5ubmG8bj8WLz8/M/tVotSJLE2ekpAoHAhzs7PYXD4YBh1wCFQvGGRSIR8/Dw8O3S0tJPjUbzajKZYLfbP5zJZIJer4dKpcLi4uIbBuCvSqXi4vP5cQaDkfmEF52+Fx4CAA/ANgASgP0z+g/a5iP/lsBrpwAAAABJRU5ErkJggg==)!important}#is-syncing{background-image:url(data:image/gif;base64,R0lGODlhEAAQAPQAAFVVVQAAAFJSUhISEiwsLAICAgwMDEdHRzg4OAcHBycnJyIiIkxMTDIyMkJCQhgYGBwcHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAAFUCAgjmRpnqUwFGwhKoRgqq2YFMaRGjWA8AbZiIBbjQQ8AmmFUJEQhQGJhaKOrCksgEla+KIkYvC6SJKQOISoNSYdeIk1ayA8ExTyeR3F749CACH5BAkKAAAALAAAAAAQABAAAAVoICCKR9KMaCoaxeCoqEAkRX3AwMHWxQIIjJSAZWgUEgzBwCBAEQpMwIDwY1FHgwJCtOW2UDWYIDyqNVVkUbYr6CK+o2eUMKgWrqKhj0FrEM8jQQALPFA3MAc8CQSAMA5ZBjgqDQmHIyEAIfkECQoAAAAsAAAAABAAEAAABWAgII4j85Ao2hRIKgrEUBQJLaSHMe8zgQo6Q8sxS7RIhILhBkgumCTZsXkACBC+0cwF2GoLLoFXREDcDlkAojBICRaFLDCOQtQKjmsQSubtDFU/NXcDBHwkaw1cKQ8MiyEAIfkECQoAAAAsAAAAABAAEAAABVIgII5kaZ6AIJQCMRTFQKiDQx4GrBfGa4uCnAEhQuRgPwCBtwK+kCNFgjh6QlFYgGO7baJ2CxIioSDpwqNggWCGDVVGphly3BkOpXDrKfNm/4AhACH5BAkKAAAALAAAAAAQABAAAAVgICCOZGmeqEAMRTEQwskYbV0Yx7kYSIzQhtgoBxCKBDQCIOcoLBimRiFhSABYU5gIgW01pLUBYkRItAYAqrlhYiwKjiWAcDMWY8QjsCf4DewiBzQ2N1AmKlgvgCiMjSQhACH5BAkKAAAALAAAAAAQABAAAAVfICCOZGmeqEgUxUAIpkA0AMKyxkEiSZEIsJqhYAg+boUFSTAkiBiNHks3sg1ILAfBiS10gyqCg0UaFBCkwy3RYKiIYMAC+RAxiQgYsJdAjw5DN2gILzEEZgVcKYuMJiEAOwAAAAAAAAAAAA==)!important;margin-top:0!important;margin-left:7px!important}#scour-menu-container,#scour-menu-container-shadow{margin-top:8px!important;margin-left:-100px!important}#global-info .offline-status + #settings-link{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAACnUlEQVRIib3WP2viABjH8R+RIAHBgNBJKOmfhEDaUNqGpq4OjvoC3A7uZWSWexMKTkVKl0KIEPBOySBBWpAO6lCELlahQ+AKhd8NxwWKie0NNvAZkud5vnOAv8+PLwLs7u7yKx4AgKIofHt72zoAwN7eHl9/v37KarUigNhqtfr0LQBgf3+fURSlGgwGLJfLjKKIy+WSgiDElssloyhiuVzmYDDY2AEAHB4e8uXlJVG/36ckSRRFkbZtczKZUJKk2GQyoW3bFEWRkiSx3++ntgAAqqry+fk5Ub1eZz6fpyzLzOVyFASBsizHBEFgLpejLMvM5/Os1+upLQCApml8enpKtFgs6DgOd3Z2PuQ4DheLRWoLAKDrOh8fH1ONx2MWi0UWi0Wqqsp2u80wDNlut6mqajwbj8cbOwAAwzA4m83WZDIZZjIZZrNZKopCRVHY6XQ4n885m804n8/Z6XTiWTabjW+SegCAo6MjPjw8rDk4OFgzGo3e7YxGo8S9pB4A4Pj4mPf392t0XV/TbDbf7TSbzcS9pB4AwDRNhmG4ZjqdcjqdMggCGoZBwzCo6zpbrRbDMGSr1aKu6/EsCIL4JqkHADg5OWEQBKlqtRpN06RpmjQMg4VCgaIoslAo0DCMeFar1TZ2AABnZ2f89fNnomq1Sk3TeHp6+iFN01itVlNbAIDz83P6vp+o2+2yUqnQsiw6jkPP82hZVszzPDqOQ8uyWKlU2O12U1sAAMuy6LpuIt/32ev12Gg0OBwO6boubduOua7L4XDIRqPBXq9H3/dTWwCAi4sL3t7epvI8j0EQxO+lUin271sQBPQ8b2MHAGDbNm9ubj7t7u4u9j93AIDLy0teX19vHQCgVCrx6upq6/DlPzwkv5H8vm1/ALbwXtlaD0HvAAAAAElFTkSuQmCC)!important}#global-info .offline-status + #settings-link:active{background-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAXCAYAAAD6FjQuAAAEe0lEQVRIib2W70safxzAxZAaBAnBHgnDbTexbpPhJmv1qMCeFEFCZIhIpF4QK2Y/SNHqyki8deShiIJohSfIUYHsQc/qH3t9Hxy7fWPtuwfxnfB64L3fL17w4bg7m838Ff8SNtuLFy9wuVx4vV58Ph9+v5+xsbEn4/f78fl8eL1eXC4XNpvNZnO73UxOTjI/P080GiUej/Ply5cnE4/HiUajzM/PMzk5acZevnxJKBRCkiTS6TSyLPPt27dHOT4+xmazWRwfH/92V5Zl0uk0kiQRCoXM2KtXr4jFYqTTaRRFoVqpcnFxYSHLMqOjozSbTS4uLrDb7RY/dkZHR5Fl+YFXrVRRFIV0Ok0sFjNjgiCQSCSQZZlqpcrl5SWGYWAYBoqiMDAwgMPhYGRkBMMwePbsmYVhGIyMjOBwOBgYGEBRFMu9vLykWqkiyzKJRMKMvXnzBkmSyOfz1Ot1dF3n+vqa6+trZmZmGBoawul0Mjg4iN1ux+l0WtjtdgYHB3E6nQwNDTEzM2O5uq5Tr9fJ5/NIkmTGPB4PyWTyQezq6oqrqyvu7u5IpVI8f/78j6RSKe7u7iz337FkMmnGvF4viUSCw8PDX47RMAx6vR4ulwuXy4UgCJRKJXq9HqVSCUEQrFmv13vg/TjGw8PDn8coiiLxeJz9/X00TaPZbNLpdOjr66Ovr4/+/n7cbjdut5tarcbt7S2dTofb21tqtZo16+/vt5xOp0Oz2UTTNPb394nH42bs7du3LC8vk81mOTs7o9Fo0G63ef369S90u13a7bZFt9t9dK/dbtNoNDg7OyObzbK8vGzG3r17RywWI5PJcHp6Sq1W47x1jtfr/YWDgwPOW+cWBwcHj+6dt86p1Wqcnp6SyWR+3vo+n49oNMru7i7FYpFKuUyj0eD+/p77+3tubm4QRRFRFBEEgVwuR6PRIJfLIQiCNbu5ubGcRqNBpVymWCyyu7tLNBo1Y+/fvycSibC9vU3hpECpVKJer1sEg0F8Ph8+nw9RFBkeHsbhcDA8PIwoitYsGAw+8EqlEoWTAtvb20QiETP24cMHlsJLbKY2yefzqKpKpVymUi4zNTWFx+PB7/f/EY/Hw9TUlOWqqko+n2cztclSeMmMffz4kcXFRdbX15FlGUVR0DQNTdNotVoEg0ECgQA7Ozvouk4gELDQdZ2dnR0CgQDBYJBWq2W5iqIgyzLr6+ssLi6asUAgwMLCAmtra+RyOQonBVRVRVVVqtUq3W6Xvb09DMNAVdUHrxFVVTEMg729PbrdLtVq1XILJwVyuRxra2ssLCyYsU+fPhEKhVhdXSWTyXB0dESxWLTQNA1d163/4+PjFj+u6bqOpmkPvKOjIzKZDKurqz+f+mNjY8zNzbGyssLW1hbZbJZ8Pv9bvn//bvFfe9lslq2tLVZWVpibmzNjnz9/Znp6mshSBEmS+LqxQSaTeTJfNzaQJInIUoTp6WkzNj4+zsTEBLOzs4TDYWKxGMlk8snEYjHC4TCzs7NMTExg++sfPMAKkPy/+QcHJfHKKXH2UAAAAABJRU5ErkJggg==)!important}#search{right:142px!important}';
	//Delicious 19191
	css += '#sub-tree-header{color:#768693!important;text-shadow:0 1px rgba(255,255,255,0.5)!important}#lhn-subscriptions .lhn-section-footer{background:#d1d7e2!important;border:none!important}#lhn-add-subscription-section{z-index:1000!important;position:absolute!important;bottom:3px!important;left:8px!important;width:0!important;font-size:0!important;color:transparent!important;border-color:transparent!important}#lhn-add-subscription-section span{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAUCAYAAAAHpoRMAAABbUlEQVRIicXWoYvCYBzG8aevWcQDD6aCtmMTGQsDcckmFzRfufsH7uqB8U6ERZP/gMFgMVlsWqYDQdDiQEwrBoPgc+G4n1wcb3gHn7A3PHzhDRtwf54AfAD4BtDT5DfEcZxhFEXx7XajLgCATCbzGUXR4Xq9UicAgGEYweVyoW5/19Q7n8/UTWKSJKGKfD5Px3GUNiTmdDpRRalUoud5ShsSE8cxVVSrVTabTaUNidntdkxjvV7TdV26rstGo0HLslir1Viv1+Us7abEbDYbprFcLpnNZpnL5VgoFGjbNi3LommacpZ2U2LCMGQaq9Xq3337vs9OpyPvx+Mx1V4YhveYxWJBFb7vs91uK21IzHw+pwrP89hqtZQ2JGY2m1HFfr/ndrtV2pCY6XRK3eTbNJlMqBsAoFgsfgVBEI/HY+oEAOh2uy/lcnnY7/cPo9GIugAASD4MBoP3SqXSMwwj0P2nB5KPJJ9JvpJ80+EHgQcUHO+clHQAAAAASUVORK5CYII=) no-repeat!important;padding-top:20px!important;padding-left:35px!important;color:transparent!important}#lhn-add-subscription-section span:active{background:transparent url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAUCAYAAAAHpoRMAAADRUlEQVRIicXWTUsqbRzH8dlLmyDCFjdlmzYxGCEGgSDtWgTVQpHIQK1pzFB8GnJipqZ8Kq9BjXGyac5gGlkY5hto1S7oPZzzOs7vXshpOJuTLqSBz2Lg+l984ZphhqLMi6YoKkFRVIGiqOI36YeMjY39sNlsv1wu12+/349QKASGYcCy7MgwDINAIICtrS1sbm6CoiiKGh8fP3Y4HL+8Xi8ODg6QTqchCAIkSUI2mx0ZSZLA8zxisRiCwWA/xmKxyNvb24hGoxBFEaVSCVdXV1BVFTc3NyOjKAoIITg5OUE0GsWfYyqGw2EIggBZlnF7e4tWq4WHhwe02+2RaTabqNfruLy8BMdxZkw8Hkc+n8f19TXu7+/R6XTQ7XbR7Xbx8vLypampKczPzw+09o+npycYhoFyuQye582YdDqNUqkEXdfx+Pj4OdDr9QZis9ngdDoHXt/r9dDpdNBoNFCpVHB8fGzGcBz3GdNut9HpdPD8/Dwwu92OlZWVoWba7TZ0XQchBEdHR2ZMKpVCsVhEvV5Hs9n88rwbjQZomgZN03A6nbDb7VhcXITD4QBN03A4HAM/M8ViEalUyoxJJBLI5XJQFAWGYaDVav2TruuYnJyE1WqFzWbDwsIC7HY7ZmZmYLVaMT09/eUehmFAURTkcjkkEgkzJhqNQpIklMtlaJoGwzD+6e7uDh8fH5/cbjc2NjY+79/f37/cQ9M0lMtlSJL096sdiUQgiiIIIVBVFZqmDcXtdmN9fX2oGVVVQQiBKIqIRCJmDMuy4HkehUIB1WoVtVptKMvLy1hdXR1qplqtolAogOd5sCxrxoRCIaTTaZyfn4MQgkqlgmq1OrC3tze8vr4ONSPLMrLZLDiOw97enhmzs7ODWCwGQRCQz+dBCAEhBLIsj8zFxQVOT0+RTCb//jZ5PB4wDINkMglBEHB2doZsNotcLjcykiQhk8ng8PAQfr+/HzM7O5tfWlr66fP5sL+/j3g8Do7jkMlkwPP8yHAch1gsht3dXXi93n6MKIo7ExMTP1wu10+Px/M7EAiAYRiEw2FEIpGRYVkWwWAQPp8Pa2tr/RgAU7VaLT43N1e0WCzyd//pUQD+A7AOIARg9zv8D6ejZVeU+KygAAAAAElFTkSuQmCC) no-repeat!important}#lhn-add-subscription-section .goog-button-base-open .goog-button-body,#lhn-add-subscription-section .goog-button-body:hover{background:transparent!important}.lhn-hidden #lhn-subscriptions .lhn-section-footer{-webkit-border-bottom-left-radius:5px!important;-webkit-border-bottom-right-radius:5px!important;-moz-border-radius:0 0 5px 5px!important}.lhn-hidden #lhn-add-subscription-section span{padding-top:8px!important;padding-bottom:12px!important;margin-left:0!important}.lhn-hidden #sub-tree-subscriptions{margin-left:33px!important}.lhn-hidden #lhn-add-subscription .goog-button-body{padding-left:0!important;padding-right:0!important}#sub-tree-subscriptions{position:relative!important;bottom:1px!important;left:0!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAUCAYAAAAHpoRMAAACn0lEQVRIicXWPUjjABjG8WfPIoLQHigRP1qbxsbQkrS1nQTFweGgKDgdyN3geree6CCcoVCcnMSliPgFulQErYl1UMRCoFjsZBzSpUsHB7HPDYJz45Lht7zDn2d8AcDw0QaAPwBiAICRkRF2Oh1fvL+/d2zbdjRN2wYQw+joKN/e3nxl2/Zzb2/vX4RCIb6+vvpOEIQCwuEw2+22Z09PT2y32xRFkT09PXx8fGSr1aLjOF/qATAQiUTYarU8WV9fZ19fHw8PDymKIoPBIMvlMqenp5lIJFiv1z03ARiQJImu63atVqtRlmUGg0EODw9zbGyMkiRRkiQGAgEGAgHu7Ox4arqu+zEmGo3ScZyuvby8sFKpUFVVyrLMXC7H5eXlz0Fra2t0XddT03GcjzGyLLPRaHQtFosxEolQ0zTOz8+z2Wyy2Wwyn89T13UqisKBgQGen5976gIwoCgKa7Va1+LxOCVJoq7rXFhY+LxvbGwwlUpxYmKCg4ODNE3TUxeAgUQiwWq12rXr62vu7u4ym81SVVXOzs5ycXGRiqIwk8nw4OCApmny4eHBUxeAAU3TeHt727WrqyvOzMwwnU5TVVWKosj+/n5Go1Hqus65uTmapsm7uztPXQAGdF2nZVldu7m54crKCpPJJDc3NxmPxzk+Ps6lpSXqus5cLseTkxNPTcuyPsYkk0leXFx4Uq1WWS6XeX9/z6mpKaZSKRaLRRaLRdq2TdM0PTcBGEin0yyVSp5dXl6yVCqxXq+z0WjQsixWKhWenZ19qQfAwOTkJE9PT30nCEIBmUyGx8fHvjk6OmKhUHCGhob+IZvNcn9/3xd7e3udfD7/HAqFtldXV3/Az09PEIRCOBw2tra2fpP8BpJLJH/55CfJ7yQHAOA/k1bvJMAW/3oAAAAASUVORK5CYII=) no-repeat!important;margin-left:32px!important;padding-top:10px!important;padding-bottom:10px!important;padding-left:35px!important;font-size:0!important;color:transparent!important}#sub-tree-subscriptions:active{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACMAAAAUCAYAAAAHpoRMAAAEaElEQVRIicXWTU8TaxyH4WdPTIzRBI4RX4jaMiCUqExBaGLcGBfqwQWEGCDSYi3WtCmlExnsyGgLFaaUmr6DFRhi1WmKS+POhSZ+C/0c3mfRHFen9WyIi2v5/+XOZJIZIYRI/EErQog5IUSPEEKIs2fPcufOHe7evcv09DRerxefz3dgvF4vHo+HyclJXC7XzzNnzvw4dOjQKyFEjzh37hxut5tgMIiqqui6TiwWOzC6rhONRolEIjx8+JCxsTEuX77848iRI4vi/PnzBAIBnj59imEYZDIZisXigcnlcrx8+ZK1tTU0TSMQCDAxMUFLS0tS2Gw2FEVhdXWVQqHA7u4ulUrlt/L5PJVKhePHj3P48GGy2SymabK1tdX07s2bN5imyebmJslkkmg0yuzsLEKIhOjs7ERVVVKpFOVymXfv3rG/v9+Ux+Ph6NGjLC0tcfLkSdra2kin08iyjCRJbG9v/+ddrVajVqthWRZ7e3vk83mWl5cJhUL1GEmSWFxcZGNjg+3tbSzL4sOHDw2ZpondbqetrY2Ojg7sdjuSJGGz2WhtbaW1tZUnT540vP837O3bt2xtbbG2tkYkEqnHdHV18fjxYwzD+PWIq9VqQ/v7+1iWhcPhoLu7m9u3b3Pv3j0kSUKSJMLhMJ8+fWq6YVkWlUrlV4yiKPWY7u5u5ufnSSQS/+udsdvtdHZ20t/fz8jICN++fePr169omoYsy/T29tLe3s76+nrTnd3dXQqFAolEgvn5+XpMb28vc3NzxONxMpkM5XIZ0zQbcjgcSJKELMuMjIywt7eHaZooisLAwAAOh4PTp09TKBSa7pTLZTKZDPF4nLm5uXrMpUuXCAQC6LpOKpWiVCpRLpcbsiyLTCbD8PAwfX19uFwubty4QU9PD0NDQxSLRarVKjs7O013SqUSqVQKXdcJBAL1mP7+fvx+P5qmYRgGuVyOUqnUULFY5Nq1awwODtLX18epU6c4ceIEXV1dyLLM9evXKZVKbG5uNt3J5XIYhoGmafj9/nqMLMv4fD5UVWVlZYV0Ok02m22oWCwSCoVwOp3EYjEuXrzIhQsXmJiYQJZlbt26xerqatONbDZLOp1mZWUFVVXx+Xz1GKfTyf3791EUhVgsRjKZJJ1ON1Wr1ahWq7x//56rV68yMDBAKpUik8nw8eNH8vl80/uNjQ0Mw+D58+dEIhE8Hk89ZnBwELfbTTgcZmlpiRcvXpBMJn8rn8+TTCb5/PkzX7584fXr1+zs7LC+vt70zjAMDMNgeXmZaDRKMBhkamqqHnPlyhUmJyd59OgRCwsL6LpOPB4/MLFYjGfPnhGNRgmHw3i9XkZHR+vfpqGhIcbGxpiZmSEYDKIoCqqqHpiFhQUURSEUCvHgwQPGx8dxOp3fOzo6lsXw8DA3b95kfHwct9uNz+fD7/cfmNnZWbxeL9PT04yOjv50uVzfjx079krTtCnxJ//0WlpakjabLZHNZkPAXwKYBmb+EA/wN9AuhBD/AGJfV6EyLEs7AAAAAElFTkSuQmCC) no-repeat!important}#nav{padding-top:6px!important}#overview-selector .text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACn0lEQVQ4jX2S2yukARjGnzL/grEzrkxqHfYCtSmHYU3IamwOc6G1N5Q0TYlQE2G3KZqyjNh8sbEaTQ5xMbvb1kdpHdrlk6WpKfqwmBqHDOsQYZ698tU22bfem9/b76n37QUeKS2QFglMRAITWiANAIpioS+JQVFRLPSPeQAADaDXAlOjfX0c7eujFpjSAPqBhnzz/ek+BxryzY/KT4AMLeAe6emhLImUJZEjPT3UAu76krSPf37/osOcWf2Y/EIDfBvq7KQsidxamebWyjRlSeRQZydL8/L4efgD35U9rwuRIwBDBDDTb7dTlkQ6LVl0Dwt0Dwt0WrIoSyL77XaaDAaWpce4/pHVQLYa+N5rs1GWRO6uzVIw6bi6HeDqdoCCScfdtVnKkshem42v0tOpBrIf5Bw1sNjV0kJZEunzzNHnmaNg0nH74JLbB5cUTDqFy5LIrpYWqoFFNZCDcGApWqVqM8Wg8mJvnX7vIv3eRTotWZx3j3HePUanJUvhF3vrNMWgMlqlagsHlpQ1XI2FVVc+D482fv63r3weuhoLq0KOONhgNF/7vQxsrTCwtcIFZwetqRpaUzVccHYo/Nrv5WCDMfQPhJpcy83hJs9313i+u8bu4ngut5Vwua2E3cXxCr853KRQk2sJCXCYDdW3xzKvfB5e+Tx0GKO48LaA6+9f82utQeG3xzIdZkPoI7WXp9Ten+zwxu/ljd9LwfSUM9YczjYZWamDwu9PdthenlIbEtBcmlQfPN3j3dEG7442+OnNM36p0fOHrZCzTS8VHjzdY3NpUn1IQF1BnJUXBwye7TN4tk9XRSInzcmcNCfTVZGocF4csK4gzhoSkAEImYCUCUgJQKsuLGw8SqWyR6lUdl1Y2HgC0PowzwCEB+8vYlzQiRXi5qoAAAAASUVORK5CYII=) 0 2px no-repeat!important;padding-left:20px!important}#reading-list-selector .text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACPUlEQVQ4jZ2T30tacRjGv33rpuv+hc3L/QvBCoKoC3FGRLMIYmIJW9QpJh6LtpXRT9SLNpKJWmgjkuJsa25REmYjxi5c9IstIzNr0/R01OOxZzdDGJWsPfC5e54P781LyJ8oWLb2Acs+KoSyp+cOuSlynU6dyuWQFEUkRBGxTAZRQcARzyOUTMKzugq5Tqeu6eq6e62glmE0QjaLuCDg18UFzngex+fn+H52hu1IBE6OAwDUMoymuqNDlh+6laR0uZmq9W33vSlJQiKVulZicjjyPJTf8y03U7VbSUqJV0VkK5oyy/RLPdKSBD6dvlGyHYkglExi+hWLFU2ZxasiMrLUVFIRHKtat5oYiLkcBFEsKDnieVhNDIJjVetLTSUVhFMVtwQnajbMRi2yuRzS2WxBSTSVgtmoRXCiZoNTFbeQxUY6GJpt3x/qa4V0eYmMJBWUxDIZDPW1IjTbvr/YSAeJp4FOxn0jwqi2HJ+nDQg4DPgZ3rsiOfqxBd/rp1iz6zGqLUfcNyJ4GugkmaunUwm/GTHfOGK+cZwuD2PzjfHKJQHXC0Q/Ded7Cb8Zc/V0irjqqC3M9WNnphM7M504XOjFF2s7Ag4DAg4W63Y9/HY9NqfacLjQm++FuX646qiNOBXUeTDP4pv9cZ7w22eIvB9A1GvE6cchnHwYxPG75391DuZZOBXUSWxy6t51d+Orte1W7Lq7YZNTN7FUF3F7LgZbjie3Ys/FwFJdxJGBSmIaqCBr/0UlMd34nf+a37QegacceVmzAAAAAElFTkSuQmCC) 0 2px no-repeat!important;padding-left:20px!important}#recent-activity #recent-activity-star h4,.entry .entry-actions .item-star-active,.entry .entry-icons .item-star-active,#star-selector .text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACDklEQVQ4jZ2Pz0vacRjH3yq1oF02GAwmtdpgyNgPPOzUtmOXjrMuw+Uh+ge2XbbJJ4ddKiL8qpkUKtWhMJwHM8mY5MKlDtOvKXO2SLe05VfUEDzEs9MithTcG96X53m/Xw8P0EBBB5RBB5SNMg0VdGIy6MTkf5X9S+jgN7pW+Y2uVf8SOpoH2DFwEH8RO4grY347BpoGbC6DOznWF09+ccXNZXBNlb0L6Aw4pd6aoKdaQUcB5w2vdwGdF4bXrHBd5MRWX6KUeUWlg5cU/9SbqJeDywyp2ybmgu4H4XKeq1YFI1VyWqocvichPUxCepjKP95ROfuGKocaOt5/Xd123Q67bWLOZYYUAMAYxG6LpH99sd2zF3meKWXfUj6lov1dBSUjfcSHeikZeUY7H59m1hcvedwWST9jEP/zjssMqccqnktFFYV49DHxOz1njm0/KXis4rmzq/U0P4Ep/nOPsLcrp/OObt0X5icw1bDMGFqtYyJfLvXoNJeSUf7bQ8qn7lHuq4x+JmWn1jH4GENrXYBJC/mHmct88ftdyvJ3aiumdn7F1MZn+Zs1IX2LHDNtvEkLeV2AcQRDPvvVzBfP9aPZUVHAqMGgUYPB2VFRILx27chnv5IxjmCoLkDPMG0Zb4kaGGwGhu4/cwNDt4HBZhlvieoZpusD1Ajp1FApFJD8vVMoINGpodKrETo//w3pNimC4MiL4wAAAABJRU5ErkJggg==) 0 1px no-repeat!important;padding-left:20px!important}.entry .entry-actions .item-star-active,.entry .entry-icons .item-star-active{background-position:0 -1px!important}.entry .entry-actions .item-star,.entry .entry-icons .item-star{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB3ElEQVQ4jZ1Qy2qrUBS1pT/Qx7g/UTpIob/REjoo/YEUSgelhWpByFGpLUSheyjBiYiOfIAnBAKSQQwBCcIhBBETiJwIwS+4k3svgZsEchesyWattffaDLMDGOMaxri2S7MTQRDcBEFw819m3/dPwjBshGHY8H3/ZO8Az/MuCSEsIYT1PO9y7wDHceplWX6XZfntOE59L7NlWacY46eqqqCqKsAYP1mWdbpRbJpmYxOjKPpYLBawWCwgiqKPbTpG1/Vj0zTr3W73bblcKqvVCiilQCmFPM8hz3OglEJRFEAphfl8rnQ6nTfTNOu6rh//OeTAMIwL27YfkyRBRVFAlmVACIE4jmE0GkEcx9Dv95Ft24+GYVwwDHPwT53f19wnSSKPx2OI4/gvR6ORbJrm/frWjVBV9XY4HH4RQmCdg8HgS1XV251mjuOOWq3Wc5qmP2maQpZlkGUZpGkK0+n0p9VqPXMcd7Q1ACF03m632dlsBpPJRNU0jdU0jSWEqHmeQ7vdZhFC51sDRFG8dl0X9Xq9T1mWXyRJqkmSVJNl+aXX6326rotEUbzeGtBsNu8URXkXBOGB47iztWpngiA8KIry3mw273ZVeOV5/orjuMMN/znkef4KIfS6Pv8FT+RM81mAcrkAAAAASUVORK5CYII=) 0 -1px no-repeat!important}#your-items-tree-item-0-name .name-text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACQklEQVQ4jZ3S3U/SUQDG8Z8n/qW2ti5ic212kzXH0KCQyRI1oXQ5W1g0A18AURMwIBTs52CaGGAD5W2kQw18ibSxsezF4iWdCl61uaeLvLHjmuvZvpfnc87FYZjjRWqJNCLmaM5ULZEyfy8k5miP0uP49cH+z47S4wiJOVoaEHH6DpNmZOe6seV5jI+uNqzaZYibJAj3CTDz9DpeKa6AbeVCyWUSFKDkMgmL9DxsTRdgl10E23IJE+2XMdN5DSFNNd4OipAw1yPjVsBaWeamAMvVsumEtQGhXj5i/TfxzlyPlF2GTbYFaVcbMpMPsDXdgUJEC/+tc88owCckxlyoF0mLFCmH/ORBtwJfvUp8f9OJ4qIBPiExUoBHQIZL8SFk/SqknfeRmWjHp6mH+PL6EbZ9T/DDr8LPsAal+BA8AjJMAVM1xFJaGMReWIOsX4XP0x34dnxr1q9Cfq4be2ENSguDmKohFgqY5JORg/kBFGN67Ed1yAXUJ9qP6lCM6XEwP4BJPhmhACePOHYjWuRnu3C4aDi1/GwXdiNaOHnEQQEsj7A7wR5se5XIBdTYiWhPlAuose1VYifYA5ZHWAoYqyKuQkCNtReNWLM1YX3kDt6PNiNll2HDIcfm2F1svryHQkCNsSriogBrZZl70ViHUC8fYU01orobiOmFmB8QIT4kxpKxDssmCTYc8tM/Un8FE1yxNmDJJMGySYLE89tImuuxam3Euq3pz2tGm5Eeb0V/BROkAFU5Y1CVM/EzZqCA/91vfM/XivoJOAsAAAAASUVORK5CYII=) 0 0 no-repeat!important;padding-left:20px!important}#your-items-tree .broadcast-icon{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACf0lEQVQ4jZWS3U+ScRTHT7+e29J52UV3/QXlRVut+bCUrZfNzRTnW16oqc3UJKfOqRFQYCAJKgqapCIMUp+piIJOVxrBxEzyLXUpmi3LBERcL6erXKw2xnf7XJztfM92zvkChJA5A86aUilRfxpVa0yC6FD9QRq6AVGmVEp0ONvi+Wyp3uxJJk/CGmBKIwVzdWxLwKnCfbvcq0skirDMI9kRSp9N7gk4VfimIX5KE388KzyzXeHxO5Totcm9+pSTbcprcDqkeewmufUyP1J24FDsBZwq3O4rnGtLOtFr4JBmYxJpGcukxGOZlNiaQcUGGYc5cMqSQfLHcyPl+3b5nt+hRL9DiT/mOxBX9P9gzaQkAAAwkAbnTOmUeDQ7osklix3xTNZ5vK8U+De/FruCarexyG1Kp8QAAMCkEOnHPu6m93UjfpmQ4ifLI9wa4uPGwH38wFTh9rAQv7s0+O2FDBuvHjP8oeEKXAQAgB4OUXmm5Lg98hDdgzxc663EJX0pujqKcKY1H1eM5Xg4oz5iZ1To7eUQ+dHuukTSvjshxa1BHq4zVbhiKMMFbQnOae7gjDoPl/Wl6Lc3oUuT91XCBrOEDebHcRBzNKAzgWh3rCJcZ6pw7XkFLuvu4XxnMb5tL0CnOg+Xurnom6xH32Q9bvVX+joTSGvQ9dXXSde7pzk7m/01uGoow0VtCbqeFeJs2210qnJxoesu7o1LkCm75ObRYOPREPw+WRzESNnAaHPOTA9WXHhvrYnbsMlSdqebsgLTzTk/l7q5uGsV4aqOeyBlA/Pf8FSfhyghC6KFNCQ/iIFiPg21AhZ0CGgYENBg5rNgSkCDlc+CyyGTGK5+A0OshBWHqVp0AAAAAElFTkSuQmCC) 0 0 no-repeat!important}#your-items-tree .created-icon{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABuklEQVQ4jcXSzUobURwF8GPyID6JlD5D110IrdAXKFRBEEk14lAnYgYGMVpj7Oh0dJwmOpNVceFCcKO4kwbFjwrmazITzcecLkJCpne67h/O5l7O78+FC0TMNTB2A+jXwFjUfeQUixh3HMw4DmbOgYPmxATPgYP+2XCKRYwLgG1jtl1Ps1mWWdr6wKPRUeY+vuND6QubZXmQdn2Fto1ZASgUkHipqqzcJfnwK8Gri2me/PzE9dVJlm/nB3murLBQQEIA8nnMteubdB9l/i595tXFNC/Ppnh5NjUoV+8X2aplmM9jTgAsCwsdd5vPFZXuo8zKXTK0uXq/SP9JYcfdomVhQQBME1K3scNWbU1A+uWX6iq7jW80TUgCYBhYCrzvbNc3QshwuVVbZ7exS8PAkgDoOpYDb48dNxtChssdd5OBZ1DXsSwAmgaFvsnA2w4hw+VuI0f6+9Q0KAKQy0Glb5G+9hfSK5+evh8kk4l9FYBsNpbpATshpL/5+Pgty7fzVJQRI52O+OKqOrJL/5A9xGLvOXsMPIP092nbb5hKxX+kUngllAFAlmNJWY4f/iuSFHckCa8jy/91/gDHosicNoypLwAAAABJRU5ErkJggg==) 0 1px no-repeat!important}#trends-selector .text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAC/UlEQVQ4jaXKb0jUdwDH8S/0pEbuD1sg27JsFZq6cx5lSqXumMHhRSZGLnywojM8vOXVqakdOrOrxP5IJfYHmy6dF2uRI2Meq8uuu+7O3e1Or7tfespvatuVBi4IBvHegyiQHtU+8Hr0/ogeU4HGUleofRs9pgKN6KrdUvL8aZR/ZyffyPOnUbpqt5SIjpr83ZNhF3LQPsemTjvL2jwsa/OwqdP+Wp8Mu+ioyd8t2is0pc+eyMxGw3PEt7oo9EChB+JbXa/1Z09k2is0peKcQa2Th+8S8dvmWHraierXaZSWUfJ+NFHZr6SyX0mzNZ+I34Y8fJdzBrVOnNHnls1GR3g8EZhjSYudnBuPSOsZQX2pBsuMFsuMln03vuDxRIDZ6Ahn9LllokWn0o/6bIQHrbgV6XjEB3gTlSw+fpus63+T2i2xsWM/rQ8KMLtVlP+iIDxoZdRno0Wn0otmbfae6YkgU5FBnOJ9MFaAsYKmpg7W9U6h6Arz1QUjp0KbabyXg/7nZKYig0xPBGnWZu8Rh3dkGkIeK0POPu6I9/gnfSNRsRTzd+fJuPonKT/c58s2AyeHNTQ4sii9nMiQs4+Qx8rhHZkG0VCcvvfhmI/xkINb4l1mUnOYFItpPNDKmp/GWfX9EFmnv+XYH2rq76xH27WS8ZCDh2M+GorT9wpTUZox4OjDO3CNfhHDX4mZjIlPqNt3DKVllIR2P+tO6Dj6ey6m25l8c/EzvAPXCDj6MBWlGUXVVkWlLLmQ/Daui4XI8WmERSwHyo6Q2i2x8oKPtU0lmN0qam+tpfjsEiS/DVlyUbVVUSnKNQnV3oFe3DevcFW8w8jHSQTEIvbvrOPzSyFWnPey+tBODjqzqf5tDdtOfYr75hW8A72UaxKqxfaM2HpZchEJ2ukW83kQp+D+hyswfl1FardEcmeQ5KoiGu/lUG9fj+bQR0SCdmTJxfaM2HqRlxKzS520wKxOWmAuWjTP8tKGuDjL8lUZLyjiLMtXz3vl5T8vJWaX+L/7D27dbSiQPqSLAAAAAElFTkSuQmCC) 0 2px no-repeat!important;padding-left:20px!important}#directory-selector .text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACFElEQVQ4jZWTy2riYBiGPxEkQgwE4pX8m9aFeEiKnTKknlKr8dCJoARN4mkCIshQsuod9BrGRUuhGxeFQheFgsvC0EKhlCm9iHc2o0SxA/PCy794eJ/Nx0+0nh9E9PPvu5l/sVVmruuC5/n5JuB5fu66Loho9tn4VJKkB1mWIUnSgyRJ50sgSdK5nxHR6TbBped5GAwGsO0BotHowl/P8+C632FZDojocpvgajqdolrVkc9XwBiD4zhwHAeMMUynUxiGgVxOAxFdbRNcTyYTlMvHiMViYIytVVEUNBoNqGoeRHS9OT4TRfFRluXVQFVVmKYJ0zShqioYY5DlNBhjEEXxkYjO/IL5eDyGbVsoFArY3Y1BEIRf/haLRXS7XTSbTTSbbRDR2qVuhsMhajUdsizj4KCISCTyLAjCjiAIO5FI5Hk0GsEwvmF/P4NM5hBEdOMX3PZ6PVQqx0gmk8hkcgiHwy9LGA6HX/r9PhqNOvb2FCjKVxDRrV9wZ1kWSiUN8XgciqKC47jXJeQ47tW2bVSrOtLpFFKpLyCiO7/gvtPp4OSkgUKhgKMjHaFQ6G0JQ6HQW6fTgWEY0DQNmlYGEd37BYtEIoF0OrW6QjAYfF/CYDD4nkwmoSjKihPRwi94arVa0HUdqnqIfL6EQCDwsYSBQOCj3W6jXq8hl8simy2CiJ78ghkR/d7ohY9fbOGffqr/yh+Dk/7tHtwHLwAAAABJRU5ErkJggg==) 0 2px no-repeat!important;padding-left:20px!important}#friends-tree-item-0-link .name-text{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAACiUlEQVQ4jc2TvW/TUBTFH0IwAksnCjJqm7R246R262LZThw3if1cPze2YvtVcSMqNy1JOrIwM4DExABiZ2NAAv4CRliQmFgBsbAwIAa+dJgSgWBh40pnuUfnd4arS8h/M7VabWlxcfGeIAiPRVG8qqrq2am3trY2J0nSUBTFm7Iss83NzTN/hAVBeF+pVFCr1VAqlbCwsPBIVdVTqqqeLZfLL6vVKhRFgSRJqFartyRJOk1+aRgsLy+jXq+jXq/DsiwIgvBD07RLlmXJsiyDUgrf90EpRaVS+WaaZmkGUBTFWVlZgeM4cBwHtm1jaWnp6/r6eplSOq9pGqIoQhzH6Ha70DTtc6fTWZ4BNjY2tiRJQrvdRrvdRqvVgiiKX0zTLFFK5w3DQJqm4Jyj1+vBNM1PnueVZwDDMNZXV1e/u64LSilc14Usyx8dxzlPKZ2zLOsL5xz9fh9JkqDZbL6J43h+BlBV9ZSiKE+bzSYYY2g0GtB1/T4h5ESSJCd9378RhiH29vYQBAG2t7evEUJO/HYJ27avGIaBKIqg6zoopZ2pF0VR1fM8DAYDeJ6HOI4v/xZmjF2yLOsZYwycczDG4DjOkyRJLna73XM7Ozt3syxDURRIkgRRFN3mnF8ghBDSaDQemKb5IY5j5HkOzjnSNH3e6/XuhGH40Pf9d5xzDIdDHB0dYTgcIssyMMZex3F8nei6jn6/j/39fQwGA+R5/mp3d/dVlmXI8xxFUWA0GmE8Hs80Go1QFAVc1wWxbRsHBwc4PDxEURRI0/TFtHEanEwmOD4+nmkymWA8HoMxBuI4Dra2ttBqtdDpdGCa5lvbtuG6LoIgAGMMjDGEYTjTdBcEAf7p4f42PwHLJSMAFRqVqwAAAABJRU5ErkJggg==) 0 -1px no-repeat!important;padding-left:20px!important;margin-left:0!important}#friends-tree .friend-tree-comments-icon{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAB00lEQVQ4jc2Sv0sbcRjGH65/gEUpDhaCo6ubQxFnuxhShPRclMTgj1ACDpEmaGg62CFFzpSDuAS50BOdcoEEXQQHQwiWEGxAaZqkOe5sopS7mEutr1PPpkSxhUIf+MCzvJ/vF94X+K8iOtEVd2MkPocpaR4LkhteyQ2vNI+F+Bym4m6MiE50dRzensFAcrHXe5xaSuinmfJV87NBrSpR6wtdNYuGrqTLx0lfIrnY692ewUD7yy70pfz9AU0+KNHFJyKtQKR9/I0C0cUJaZW9UspvCYgu9JmCLRcm5A9ClvQC0bfc3WhHJGci2S0XJm5+MA3/5Xlep7MsxYJWigWtdFnbM7tSfNXWv5Z4XZyG3xQIDmb5e/2wQfUMcZ5h4jzDpBaDZleKgbYun7xuCA5m2RREJ+EoHfC5Vm2Hzisc1cuhWzmrvKWjXWcuOgmHKYjYYdn0PF5V8mFZVzZIq67fSvUwIL9/8Wg1YoelbRM8i8HobHcoHWP31fya0pBjLUPdJEMVqamKZKgipTfG96OzD0M8i8GOt8CNoWfNDus7Fr7wc4YLswz/kx+1BIVZhufG0HOPm7zJEsC8eYahFRsjrNgY4Y+Gf41vFE9ePn0g/bXgn+UadXBgkCDu+9sAAAAASUVORK5CYII=) 0 1px no-repeat!important}#friends-settings-link{padding-left:48px!important}#lhn-selectors .name-text-d-1,#lhn-friends .name-text-d-1{padding-left:2px!important}#lhn-selectors.lhn-section-minimized #reading-list-selector .link,#friends-tree-item-0-name,#sub-tree-header{padding-left:14px!important}.lhn-minimize{position:absolute!important;left:8px!important;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAAS0lEQVQYlWNgIAGYMjAwuOLBpjCFQgQUCiGbqoNDkQ669ZwMDAyOaIqcoeIYQAVNoQouTzExMDAYQxWZQ/k4ARdUIQ8+RTAggE0QAGBACaAQEc5JAAAAAElFTkSuQmCC) no-repeat 0 2px!important}.lhn-section-minimized .lhn-minimize{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAJCAYAAAALpr0TAAAASUlEQVQYlY3QMQqAMBBE0YedYiGeIaVdEGuR3P9KKTStuwO/+yw7w5sTu0Tax4E5IzY8KJgicXBhzYiDLRIrlr+Ld+bHsHW4YwcauwmgIbS+2gAAAABJRU5ErkJggg==) no-repeat 0 1px!important}.lhn-section:not(:hover) .lhn-menubutton{opacity:0!important}#sub-tree-refreshing{background:transparent url(data:image/gif;base64,R0lGODlhEAAQAPQAANHX4mZmZsrQ2p+iqMTJ04KEh5mcoWZmZoqMkHR1d62xubW5wm1tbqersWdnZ3x9gJGUmAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAAFdyAgAgIJIeWoAkRCCMdBkKtIHIngyMKsErPBYbADpkSCwhDmQCBethRB6Vj4kFCkQPG4IlWDgrNRIwnO4UKBXDufzQvDMaoSDBgFb886MiQadgNABAokfCwzBA8LCg0Egl8jAggGAA1kBIA1BAYzlyILczULC2UhACH5BAkKAAAALAAAAAAQABAAAAV2ICACAmlAZTmOREEIyUEQjLKKxPHADhEvqxlgcGgkGI1DYSVAIAWMx+lwSKkICJ0QsHi9RgKBwnVTiRQQgwF4I4UFDQQEwi6/3YSGWRRmjhEETAJfIgMFCnAKM0KDV4EEEAQLiF18TAYNXDaSe3x6mjidN1s3IQAh+QQJCgAAACwAAAAAEAAQAAAFeCAgAgLZDGU5jgRECEUiCI+yioSDwDJyLKsXoHFQxBSHAoAAFBhqtMJg8DgQBgfrEsJAEAg4YhZIEiwgKtHiMBgtpg3wbUZXGO7kOb1MUKRFMysCChAoggJCIg0GC2aNe4gqQldfL4l/Ag1AXySJgn5LcoE3QXI3IQAh+QQJCgAAACwAAAAAEAAQAAAFdiAgAgLZNGU5joQhCEjxIssqEo8bC9BRjy9Ag7GILQ4QEoE0gBAEBcOpcBA0DoxSK/e8LRIHn+i1cK0IyKdg0VAoljYIg+GgnRrwVS/8IAkICyosBIQpBAMoKy9dImxPhS+GKkFrkX+TigtLlIyKXUF+NjagNiEAIfkECQoAAAAsAAAAABAAEAAABWwgIAICaRhlOY4EIgjH8R7LKhKHGwsMvb4AAy3WODBIBBKCsYA9TjuhDNDKEVSERezQEL0WrhXucRUQGuik7bFlngzqVW9LMl9XWvLdjFaJtDFqZ1cEZUB0dUgvL3dgP4WJZn4jkomWNpSTIyEAIfkECQoAAAAsAAAAABAAEAAABX4gIAICuSxlOY6CIgiD8RrEKgqGOwxwUrMlAoSwIzAGpJpgoSDAGifDY5kopBYDlEpAQBwevxfBtRIUGi8xwWkDNBCIwmC9Vq0aiQQDQuK+VgQPDXV9hCJjBwcFYU5pLwwHXQcMKSmNLQcIAExlbH8JBwttaX0ABAcNbWVbKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICSRBlOY7CIghN8zbEKsKoIjdFzZaEgUBHKChMJtRwcWpAWoWnifm6ESAMhO8lQK0EEAV3rFopIBCEcGwDKAqPh4HUrY4ICHH1dSoTFgcHUiZjBhAJB2AHDykpKAwHAwdzf19KkASIPl9cDgcnDkdtNwiMJCshACH5BAkKAAAALAAAAAAQABAAAAV3ICACAkkQZTmOAiosiyAoxCq+KPxCNVsSMRgBsiClWrLTSWFoIQZHl6pleBh6suxKMIhlvzbAwkBWfFWrBQTxNLq2RG2yhSUkDs2b63AYDAoJXAcFRwADeAkJDX0AQCsEfAQMDAIPBz0rCgcxky0JRWE1AmwpKyEAIfkECQoAAAAsAAAAABAAEAAABXkgIAICKZzkqJ4nQZxLqZKv4NqNLKK2/Q4Ek4lFXChsg5ypJjs1II3gEDUSRInEGYAw6B6zM4JhrDAtEosVkLUtHA7RHaHAGJQEjsODcEg0FBAFVgkQJQ1pAwcDDw8KcFtSInwJAowCCA6RIwqZAgkPNgVpWndjdyohACH5BAkKAAAALAAAAAAQABAAAAV5ICACAimc5KieLEuUKvm2xAKLqDCfC2GaO9eL0LABWTiBYmA06W6kHgvCqEJiAIJiu3gcvgUsscHUERm+kaCxyxa+zRPk0SgJEgfIvbAdIAQLCAYlCj4DBw0IBQsMCjIqBAcPAooCBg9pKgsJLwUFOhCZKyQDA3YqIQAh+QQJCgAAACwAAAAAEAAQAAAFdSAgAgIpnOSonmxbqiThCrJKEHFbo8JxDDOZYFFb+A41E4H4OhkOipXwBElYITDAckFEOBgMQ3arkMkUBdxIUGZpEb7kaQBRlASPg0FQQHAbEEMGDSVEAA1QBhAED1E0NgwFAooCDWljaQIQCE5qMHcNhCkjIQAh+QQJCgAAACwAAAAAEAAQAAAFeSAgAgIpnOSoLgxxvqgKLEcCC65KEAByKK8cSpA4DAiHQ/DkKhGKh4ZCtCyZGo6F6iYYPAqFgYy02xkSaLEMV34tELyRYNEsCQyHlvWkGCzsPgMCEAY7Cg04Uk48LAsDhRA8MVQPEF0GAgqYYwSRlycNcWskCkApIyEAOwAAAAAAAAAAAA==) no-repeat scroll right center!important;padding-left:6px!important;padding-right:20px!important}#quick-add-bubble-holder{top:auto!important;bottom:30px!important}#entries .tags-edit{background:transparent!important;color:#fff!important;height:auto!important;width:auto!important;border:none!important;-webkit-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAAAyCAYAAADhna1TAAAJhklEQVRoge2bXVDU1xXAfxVFRU3Q/bOyui4BWZEsoRhEI4bGsjXEuIUYyyBq1KSmRNGWasfvXcryFWG7aiuC1q8Ym6hN49hxtDOOMzrqQ2dQ8NtElNU26Ws7fWgf+3DPdf+si2LG1IDemTPjMLh7zu+ec+459x4g+vpehPQDYkT691LR+veLYt9DVySI/kAsMBAYDMSJDBEZ+h0XrafWe7DYEmuCZQb1QCgxwAD5gDhgGBAPjAAMwCoyspeI1tcQG+LFpjixcYDYHBWO/qH2kDjgOcAiH24HkoAUwAmMA9J6iYwTnVPEBrvYNEIADSbsQV3gmKEMRLlevPxnx65du94/d+7cX8+ePfuv06dP/+fUqVO9Vs6dO/ffM2fOnA0EAm8DY8ST4sURYk2ecw9MjMlT4gEbkLJ///41x44d+7fX6/17aWlpR2Fh4Rcej6fXSklJyc2qqqqvTp48+U+/3z8HeEEc4HnxnP6Ec849bxksv5AIjM3Ly3vt+PHj/5g7d26H0+lsT0xMPG8YRqvFYum1YrVaz6elpbVXVFSETpw4cQZ4SeBYJawGmr2mn3jLUCBBfjFz+/btDfX19V8nJSVdeNIGPW6ZNGnSlUOHDnUCucCLkndGSMToXEMMMEhCaDQwHsjdsmXL1mXLlt3u7V4STZKTk9t27dp1FygAJgKpJq+J1WD6CymLeEsW4A4EAr8vKyu79aSN+DbEbrdfaGlpuQu8DeSJ14yWVDJQooj+EkZWOdYmA566urp9fRnMtm3b7gLzADfwfTnKR0j09ANV4AyTk2g88Cow2+/3f/oUgHkPmAFko+oci0RPDBJTz4sruYBpwJzKysqDTwGYMsADTJI8k2AGM1ASrx3IBPKBeZWVlX/sy2Campr+BiwFioBXJI1YTSfTPTBjBIwbmO/z+T57CsCUA28BU0xghkSCcUgS+hHwzlMIZlyPwHi93j89BWCWPQPzzGMeLg6H40Jzc/MzMJGSlJTU1tzcfPcZmAhJTk5ua2lpuf0oYDKfhlPJ6XS2bd++vbOnx/V9dczSpUtvP2kjvkUwd3pa4NlRFzf5wLzy8vK9K1euDPXFaweXy9W+Z8+eELAEKEQ1zmYw3fdKNpttbVNT01dOp7PtSRvyuCU/P//qzp07L9C1VxpLRK8UtbsGlnu93mNlZWUdfeUWzzCMVqfT2VZbW3u3qKioma7ddTKqux6swUS7j/kx8D6wvqqq6vS6detCBQUF1/Ly8q7k5uZezsnJuZSRkXFx/Pjx7dEkLS2tPSUlpS0xMfH8/9Nom812PjU1tS2aTi6Xq93tdl/1+/2d5eXlR4CVwHy63scMx3QfE3mDNwGYjrrEqQD8brf7QCAQuFhdXX25srLyqs/nu97Q0HCrtrb2ntTU1NzW4vf7b61YseKmx+O55nA4Hru3Wa3W89nZ2ZcWLlz45apVqzpXr17duXbt2k6/3x/yer0dWg+Tfh2BQKBj69atV9LT03cCXkm8s3nADV7knW86MFWy9U+BXwHVwGagBdgNfAR8LLIf+APwCfApcBD4DPjc5/NdKy0t/cJutz82OFar9fyUKVMu19fXd9rt9r8An8v3HQQOiB6fiE77Rcc9onsQqJINXyBhlEPXO98BRHklsKJusiagTqfZwGJghVCuAwIC6bfA74CtItuAZmCHwPsYOFBXV3e9pKTkscAxDKN18uTJlxobG+84HI6jAmCffN8OMb4ZaDLptUWA1IsNFcC7svF5QAaqVLnvlcD8rqQf25yo23M3MEvoLgF+CawG1suXVIr8GvADNcCHwG8E2o6YmJj99fX114uLi2+MHj36G8MxDKM1JyfnUkNDQ8jpdB4B9gqILbJZHwK1oodfdKoENgBrZXOXAO8IlGniACl0865kfokcIuRGo0rkl4XqG6gb9VKB9J540s9QR94HqJhdLgqsEcUagK0xMTF7Ghsbr8+aNeuGzWZ75IRsGEZrdnb2pY0bN4bS09MPi3dsFg/2yWatkO8vF10+EN0Wi4fMExtmiE0TxAFshJ9pBxDxEml+ux6KSsSjhKZLvGcq8ENUYp4BvImqATyoU6wIFXpzgEWi3CokP8XGxu5ubGy8UVhYeP1R4BiG0TphwoSLdXV1oaysrMOoMNkonlAhm7NAvnc2qsQvQhVuHtGzAJUaXhVbXGKbDXUSDSHK27WG04/7H/atqPgbi6pxXkK9O2XLF+SgiqPJqH4jTxR4EyiWnaoQ7wnGxsbuDgaDX3o8nh7BMQyjNSsr62JNTU0oOzv7MCo8awX4B+IFRWL4NDE8F1XiTxbdJop3ZKIOlrF0fdAfIjbfN+3QHRw9GzNcPsRGeBwkWYiPFUlFuWW6KDBJFC2U3fw5Kt6DcXFxe4LB4M2ZM2c+EI5hGK2ZmZkXq6ur7+Tm5h5BJftqVP2xGPgJ8DrKk19GJdHxhMc+UkW3FFQZMgYVBVbCIyB6yqHLY360ZR4e0oAGC9XnhPBwVKhZUMM4CSIankMUyxSlZ6J2drkJzt5NmzZ1FBQUXIsGxzCMVpfL1V5VVRWaOnXqn01QVqC88C0BP1E2I0U2zUZ4UEjrpXWNR9UpQwkPDempqh6NnJln0zSgAYRHzgYJLPPomR4/0x42EuVZLlSIzYiAsyk+Pn5fMBi8NX369C5wNBSfzxdyu91HI6AsQoXOD1DV6liUF2jDh9F1tEyPlw0S3fUEVY/HzHoCSYealpgI0QAHiYIWlPu+iIp5DUeH1WaLxfJxMBi8nZ+ff1W3Dy6Xq33Dhg2hgoKCY6icYoZSiMpjmahwtqK8wOwBkcOIGkC0ocRHBvJNltnLdAI3w5mCSsrzCcPZlJCQ8JGGk5GRcXH9+vWhwsLCY6j6JBoUPdOSQLj2eGiOeNKru6P/QXACo0aN2r1jx47bTU1NXxcXFx9FVap+VEG5iPuhmAuy7zwUvbqD40DlnFwUnHmod511QG1SUlJTSUnJIVTRtgH4BbCQruHzAr0Uil49gTMDVUmXEW411qCO4yUocB6iQxlEL4SiVzQ4BmE4r6DqkLdRofUuqtVYgKpR3kABjAyfXg1Fr0g4w1BwxqCKsYmoo/d1VL3jQQGZhioSXahjv09B0SsaHAuqIEtFVawvE24tslFe4kQB1KdPn4KiV7Sw0oXgGMIT53qC24GqYi30YSh6RcLRY/kjCLcUI+XfI7i/cOuTUPTq7g85dDsxjK69TI8avL6yov3pj+7FYgn3MmYgfR6KXtF6Fg3rifQzket/0r9VEA4npCMAAAAASUVORK5CYII=) 12 16 28 52 / 12px 16px 28px 52px repeat!important;-moz-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEYAAAAyCAYAAADhna1TAAAJhklEQVRoge2bXVDU1xXAfxVFRU3Q/bOyui4BWZEsoRhEI4bGsjXEuIUYyyBq1KSmRNGWasfvXcryFWG7aiuC1q8Ym6hN49hxtDOOMzrqQ2dQ8NtElNU26Ws7fWgf+3DPdf+si2LG1IDemTPjMLh7zu+ec+459x4g+vpehPQDYkT691LR+veLYt9DVySI/kAsMBAYDMSJDBEZ+h0XrafWe7DYEmuCZQb1QCgxwAD5gDhgGBAPjAAMwCoyspeI1tcQG+LFpjixcYDYHBWO/qH2kDjgOcAiH24HkoAUwAmMA9J6iYwTnVPEBrvYNEIADSbsQV3gmKEMRLlevPxnx65du94/d+7cX8+ePfuv06dP/+fUqVO9Vs6dO/ffM2fOnA0EAm8DY8ST4sURYk2ecw9MjMlT4gEbkLJ///41x44d+7fX6/17aWlpR2Fh4Rcej6fXSklJyc2qqqqvTp48+U+/3z8HeEEc4HnxnP6Ec849bxksv5AIjM3Ly3vt+PHj/5g7d26H0+lsT0xMPG8YRqvFYum1YrVaz6elpbVXVFSETpw4cQZ4SeBYJawGmr2mn3jLUCBBfjFz+/btDfX19V8nJSVdeNIGPW6ZNGnSlUOHDnUCucCLkndGSMToXEMMMEhCaDQwHsjdsmXL1mXLlt3u7V4STZKTk9t27dp1FygAJgKpJq+J1WD6CymLeEsW4A4EAr8vKyu79aSN+DbEbrdfaGlpuQu8DeSJ14yWVDJQooj+EkZWOdYmA566urp9fRnMtm3b7gLzADfwfTnKR0j09ANV4AyTk2g88Cow2+/3f/oUgHkPmAFko+oci0RPDBJTz4sruYBpwJzKysqDTwGYMsADTJI8k2AGM1ASrx3IBPKBeZWVlX/sy2Campr+BiwFioBXJI1YTSfTPTBjBIwbmO/z+T57CsCUA28BU0xghkSCcUgS+hHwzlMIZlyPwHi93j89BWCWPQPzzGMeLg6H40Jzc/MzMJGSlJTU1tzcfPcZmAhJTk5ua2lpuf0oYDKfhlPJ6XS2bd++vbOnx/V9dczSpUtvP2kjvkUwd3pa4NlRFzf5wLzy8vK9K1euDPXFaweXy9W+Z8+eELAEKEQ1zmYw3fdKNpttbVNT01dOp7PtSRvyuCU/P//qzp07L9C1VxpLRK8UtbsGlnu93mNlZWUdfeUWzzCMVqfT2VZbW3u3qKioma7ddTKqux6swUS7j/kx8D6wvqqq6vS6detCBQUF1/Ly8q7k5uZezsnJuZSRkXFx/Pjx7dEkLS2tPSUlpS0xMfH8/9Nom812PjU1tS2aTi6Xq93tdl/1+/2d5eXlR4CVwHy63scMx3QfE3mDNwGYjrrEqQD8brf7QCAQuFhdXX25srLyqs/nu97Q0HCrtrb2ntTU1NzW4vf7b61YseKmx+O55nA4Hru3Wa3W89nZ2ZcWLlz45apVqzpXr17duXbt2k6/3x/yer0dWg+Tfh2BQKBj69atV9LT03cCXkm8s3nADV7knW86MFWy9U+BXwHVwGagBdgNfAR8LLIf+APwCfApcBD4DPjc5/NdKy0t/cJutz82OFar9fyUKVMu19fXd9rt9r8An8v3HQQOiB6fiE77Rcc9onsQqJINXyBhlEPXO98BRHklsKJusiagTqfZwGJghVCuAwIC6bfA74CtItuAZmCHwPsYOFBXV3e9pKTkscAxDKN18uTJlxobG+84HI6jAmCffN8OMb4ZaDLptUWA1IsNFcC7svF5QAaqVLnvlcD8rqQf25yo23M3MEvoLgF+CawG1suXVIr8GvADNcCHwG8E2o6YmJj99fX114uLi2+MHj36G8MxDKM1JyfnUkNDQ8jpdB4B9gqILbJZHwK1oodfdKoENgBrZXOXAO8IlGniACl0865kfokcIuRGo0rkl4XqG6gb9VKB9J540s9QR94HqJhdLgqsEcUagK0xMTF7Ghsbr8+aNeuGzWZ75IRsGEZrdnb2pY0bN4bS09MPi3dsFg/2yWatkO8vF10+EN0Wi4fMExtmiE0TxAFshJ9pBxDxEml+ux6KSsSjhKZLvGcq8ENUYp4BvImqATyoU6wIFXpzgEWi3CokP8XGxu5ubGy8UVhYeP1R4BiG0TphwoSLdXV1oaysrMOoMNkonlAhm7NAvnc2qsQvQhVuHtGzAJUaXhVbXGKbDXUSDSHK27WG04/7H/atqPgbi6pxXkK9O2XLF+SgiqPJqH4jTxR4EyiWnaoQ7wnGxsbuDgaDX3o8nh7BMQyjNSsr62JNTU0oOzv7MCo8awX4B+IFRWL4NDE8F1XiTxbdJop3ZKIOlrF0fdAfIjbfN+3QHRw9GzNcPsRGeBwkWYiPFUlFuWW6KDBJFC2U3fw5Kt6DcXFxe4LB4M2ZM2c+EI5hGK2ZmZkXq6ur7+Tm5h5BJftqVP2xGPgJ8DrKk19GJdHxhMc+UkW3FFQZMgYVBVbCIyB6yqHLY360ZR4e0oAGC9XnhPBwVKhZUMM4CSIankMUyxSlZ6J2drkJzt5NmzZ1FBQUXIsGxzCMVpfL1V5VVRWaOnXqn01QVqC88C0BP1E2I0U2zUZ4UEjrpXWNR9UpQwkPDempqh6NnJln0zSgAYRHzgYJLPPomR4/0x42EuVZLlSIzYiAsyk+Pn5fMBi8NX369C5wNBSfzxdyu91HI6AsQoXOD1DV6liUF2jDh9F1tEyPlw0S3fUEVY/HzHoCSYealpgI0QAHiYIWlPu+iIp5DUeH1WaLxfJxMBi8nZ+ff1W3Dy6Xq33Dhg2hgoKCY6icYoZSiMpjmahwtqK8wOwBkcOIGkC0ocRHBvJNltnLdAI3w5mCSsrzCcPZlJCQ8JGGk5GRcXH9+vWhwsLCY6j6JBoUPdOSQLj2eGiOeNKru6P/QXACo0aN2r1jx47bTU1NXxcXFx9FVap+VEG5iPuhmAuy7zwUvbqD40DlnFwUnHmod511QG1SUlJTSUnJIVTRtgH4BbCQruHzAr0Uil49gTMDVUmXEW411qCO4yUocB6iQxlEL4SiVzQ4BmE4r6DqkLdRofUuqtVYgKpR3kABjAyfXg1Fr0g4w1BwxqCKsYmoo/d1VL3jQQGZhioSXahjv09B0SsaHAuqIEtFVawvE24tslFe4kQB1KdPn4KiV7Sw0oXgGMIT53qC24GqYi30YSh6RcLRY/kjCLcUI+XfI7i/cOuTUPTq7g85dDsxjK69TI8avL6yov3pj+7FYgn3MmYgfR6KXtF6Fg3rifQzket/0r9VEA4npCMAAAAASUVORK5CYII=) 12 16 28 52 / 12px 16px 28px 52px repeat!important;margin:-104px 0 0 -24px !important}#entries .tags-edit input,#entries .tags-edit .help{position:absolute!important;z-index:100!important;margin-left:0!important}#entries .tags-edit .help{margin-top:30px!important}#entries .tags-edit input{background:rgba(255,255,255,0.6)!important;border:none!important;-moz-appearance:none!important;-webkit-border-radius:9px!important;-moz-border-radius:9px!important;-moz-box-shadow:inset 0 1px 1px rgba(0,0,0,0.9)!important;padding:1px 10px!important}#entries .tags-edit input:focus{-webkit-box-shadow:0 0 4px 1px #2878d4!important;-moz-box-shadow:inset 0 0 2px 1px rgba(40,120,212,0.7), 0 0 4px 1px #2878d4 inset 0 1px 1px rgba(0,0,0,0.9)!important}#entries .tags-edit-tags{border:1px solid!important;background:#fff!important;width:220px!important;height:16px!important;margin:0!important}#entries .help{font-size:12px!important;color:#fff!important;margin:6px 0 0 12px !important}#entries .tags-edit-buttons{margin:54px 0 0 90px !important}#entries .tags-edit-buttons .goog-button-base-inner-box,#entries .tags-edit-buttons .goog-button-base-outer-box,#entries .tags-edit-buttons .goog-button-base-top-shadow{background:transparent!important;border:none!important}#entries .tags-edit-buttons .goog-button-body{font-size:12px!important;color:#fff!important;background:transparent!important;-webkit-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAUCAYAAAB8gkaAAAAD1ElEQVRIiZ1Wz2tiVxR+MKv+DRMK3ZiF3nPLM4aoURvrr4mxGl9A8utFNBq1BVFSJpIsk3HCpKHQlRCFJJRRiZk2+hx/LQqFrgqFbucP6LYwMDAQ+LqIT9SYlPbCx/nOdw/3vHvfe+dcQZg8nnDONxljPxPRByICEYFzPrAqH5q7JaK3RJScmpr65IF1R4dOp3Nyzt9xziHLMsrlMtrtNprNJhRFGUGj0YCiKOh2u7i8vIQsy+pD/MUYW3s0ERF9yzm/DYVCaLVaqFQqODo6QiaTRSr1NRKJJBKJJHZ2Enc2kUAqlUImk8WLF3lUKhW0222srq6qu/9hYiLGWJyIkMvl0Gw2sbeXw9raOoJBCcGgBElaGfBJfjAoYW1tHc+f70FRFBwcHIBzDsZYfjwRI6KP6XQab978hPjOzmCB5eXgowgGJSwHR/1YPI7r62uk02n1nXqGkzXMZjN6vR4SyST8/kAffvgDgVFf5QHV94/qfSSTKfR6PZjNZhDRH4IgPBG0Wu2nnHOcn58jn88jEAjA5/PB5/NhaWlpwMd9lY/HqJrf70c+n8fFxQWICFqtdl4goiTnHN1uF7K8hWfPFv8bFr2jdghbW1totzvqUX4vENGF3W5HuVzBotcLt8cDt3sYbrjdHrj6djA/HjfBX1z04vXrMjweDxhjvwmMsc7GxgbOzs7gdDrhcDjgcDjgdDoH/jAf9scxab5QKCAWi4Ex9k5gjDVCoRCKxSIWFuyTYZ9g+9xu/3KgqXygLdhRKBQgyzIYY38KnPOC2WxGrVaDy+WCzWYbgdVqhdVqnaj/m+ZyuVCtVmG328EY6whElCQiNJtNyLKM+fn5EVgslnvaQ7BYLCPx6+vraDQaIKK7n1uj0TzlnN8eHh7i1asT2GxfwGg0TcTcnHHEPqZbrTa8fHmM09NTcM7vPv1+TfxRFEX0ej1sb2/DZDJhdnb2f8NkMiEcDqPb7UIURRDRr4MKMj09/Rlj7L3X64WiKAiHwzCZTJiZmcHMzAz0ev09rtfrJ+pGoxGbm5uo1+uQJAmc89vBroYq/ldEBEmS0Ol0sL+/D4/HA4PBAFEUH4Rer4coijAYDHC73cjlcmi1WlhZWVEL8TcP9bIQEX2Ym5tDsVjEzc0NTk5OkM1mEY/HEYlEEI1GEY1GEYlEEIlEEIvFkMlkcHx8jHq9jlKppNbDvxlj8Ud7mlar/ZyIfiEiiKKIbDaLYrGIq6srVKvVe6jVaiiVStjd3YUoimrzfKvRaJ4+mmis7dgYY98R0e9E9H74OjB8Legf1cd+3JlOp/M+tOY/9aB5sCrUufkAAAAASUVORK5CYII=) 0 12 / 0 12px repeat!important;-moz-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAUCAYAAAB8gkaAAAAD1ElEQVRIiZ1Wz2tiVxR+MKv+DRMK3ZiF3nPLM4aoURvrr4mxGl9A8utFNBq1BVFSJpIsk3HCpKHQlRCFJJRRiZk2+hx/LQqFrgqFbucP6LYwMDAQ+LqIT9SYlPbCx/nOdw/3vHvfe+dcQZg8nnDONxljPxPRByICEYFzPrAqH5q7JaK3RJScmpr65IF1R4dOp3Nyzt9xziHLMsrlMtrtNprNJhRFGUGj0YCiKOh2u7i8vIQsy+pD/MUYW3s0ERF9yzm/DYVCaLVaqFQqODo6QiaTRSr1NRKJJBKJJHZ2Enc2kUAqlUImk8WLF3lUKhW0222srq6qu/9hYiLGWJyIkMvl0Gw2sbeXw9raOoJBCcGgBElaGfBJfjAoYW1tHc+f70FRFBwcHIBzDsZYfjwRI6KP6XQab978hPjOzmCB5eXgowgGJSwHR/1YPI7r62uk02n1nXqGkzXMZjN6vR4SyST8/kAffvgDgVFf5QHV94/qfSSTKfR6PZjNZhDRH4IgPBG0Wu2nnHOcn58jn88jEAjA5/PB5/NhaWlpwMd9lY/HqJrf70c+n8fFxQWICFqtdl4goiTnHN1uF7K8hWfPFv8bFr2jdghbW1totzvqUX4vENGF3W5HuVzBotcLt8cDt3sYbrjdHrj6djA/HjfBX1z04vXrMjweDxhjvwmMsc7GxgbOzs7gdDrhcDjgcDjgdDoH/jAf9scxab5QKCAWi4Ex9k5gjDVCoRCKxSIWFuyTYZ9g+9xu/3KgqXygLdhRKBQgyzIYY38KnPOC2WxGrVaDy+WCzWYbgdVqhdVqnaj/m+ZyuVCtVmG328EY6whElCQiNJtNyLKM+fn5EVgslnvaQ7BYLCPx6+vraDQaIKK7n1uj0TzlnN8eHh7i1asT2GxfwGg0TcTcnHHEPqZbrTa8fHmM09NTcM7vPv1+TfxRFEX0ej1sb2/DZDJhdnb2f8NkMiEcDqPb7UIURRDRr4MKMj09/Rlj7L3X64WiKAiHwzCZTJiZmcHMzAz0ev09rtfrJ+pGoxGbm5uo1+uQJAmc89vBroYq/ldEBEmS0Ol0sL+/D4/HA4PBAFEUH4Rer4coijAYDHC73cjlcmi1WlhZWVEL8TcP9bIQEX2Ym5tDsVjEzc0NTk5OkM1mEY/HEYlEEI1GEY1GEYlEEIlEEIvFkMlkcHx8jHq9jlKppNbDvxlj8Ud7mlar/ZyIfiEiiKKIbDaLYrGIq6srVKvVe6jVaiiVStjd3YUoimrzfKvRaJ4+mmis7dgYY98R0e9E9H74OjB8Legf1cd+3JlOp/M+tOY/9aB5sCrUufkAAAAASUVORK5CYII=) 0 12 / 0 12px repeat!important;padding:0 8px!important}.tags-edit .goog-button-base-content{font-weight:400!important;padding:0!important}#entries .tags-edit-buttons .goog-button-body:hover:active{background:transparent!important;-webkit-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAUCAYAAAB8gkaAAAAD6UlEQVRIiZ2WTWgrVRTHhwdun5iNLtrk3jNSs1AsPMaNlG6EilRBXAQfeVAslLrpyoW815YplUK+03yMaZt0ZpKmDbT5ImYs6Zex7cJmkpm8tisRfAgV3SgFxQcPj4tO8/LNwws/zv+ec+Ye5s79GIbp3u5QSt8GgE8ppY8AgH8B5imldgDgGIZ5qce4rW1wcJBlWXYGAPjp6enI3t7esaZpP2uadlWr1rqgXdXr9SeKonw3NTUVAQCeUvoFALzVtxDLsu8SQubtdnuwWq3+qNV03N87wEKhiLlcHnO5HGYzuTadw0KhiAf7h6jVdNSq+k8TExNhAOAtFssHXQuZzeZ7AMA7HI6t8/OLp0VFwVQqhcmNJCY3NjtIGP4be6O3NlOoKAo+Pj9/6na7U8b0vtdSiFL6Ksuyc7Ozs7Ku688y6SwmEglMJJJtJHr4W2PpnQxqmvZsbm5OBgB+YGDg9UYxALjPcdzS5cXldXong/F4HGXZoEnH23QzjXyDTDqDlxeX1xzHLRFCphmGucMAwMsAwBcKhaNSqYSSJKEkSSiKYovt5WuONSPLMpZKJSwUCkfGdJoZAOAAgK/X638mNzYxFl3H6FoMY9H1PsS66E67mdzEer3+BwDwhJD3GYvF8vHo6KhDVVWMRddxdTVqsPqctWiT/zbW7otitC0vFl3Hsx8qODY25qaUTjKU0geTk5PC6ekpRiKRrqysrPyvWCQSwePvj3FmZmaNEDLDAMB9u90ePDk5wbAg3BAWUBC+NuyNvrFNsZbc54Tb8svlMhqb/XOGUvohx3FLqqr+KwgChkIhDAaCGAqFOmj3N/e7PSMIAlYqFRwZGXFQSh80Foiqqk9kWcbAcuCF8Pv9DXrFRVHEs7OzXxqb22Qy3SWEzIfD4fTu7i4GloPo9fo78fnQ6/Wjz+dDn6G9Xq+BvxG7tYHlICrFb1GSpEJj6Rub+hPrkHVB1/UrWZbR4/Gg2+1usbc0+3vh8XhQkiTUdf1X65B1AQA+az4XX6GUPhwfH/dUKpVrURTR4/Ggy+VCl8uFTqcTnU5ni77tt/vcbjeKooiqqv5ls9kChJD5xls1nY9vAABvs9kC1Wr1t/ROGkOhUGMwh8PR17pcLgwsB3B7extrtdrvNpstYFw37/S6Yt6klD4aHh7+KpvN7lcqlb8VRcGtrS2Mx+MdR5IkSSjLMqZSKSx+U0RVVf/J5/MHHMctAcCXZrP5Xt87jRDyGsuyEwDAW4esCzzPx7PZ7H65XFYPDw87ODo6UvP5/MHi4uKG8X14SqndZDLd7VuorSghhIxRSqcopQ/7/RKwLDtn5H0EAEO9xvwPzBFbs0IaopEAAAAASUVORK5CYII=) 0 12 / 0 12px repeat!important;-moz-border-image:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABsAAAAUCAYAAAB8gkaAAAAD6UlEQVRIiZ2WTWgrVRTHhwdun5iNLtrk3jNSs1AsPMaNlG6EilRBXAQfeVAslLrpyoW815YplUK+03yMaZt0ZpKmDbT5ImYs6Zex7cJmkpm8tisRfAgV3SgFxQcPj4tO8/LNwws/zv+ec+Ye5s79GIbp3u5QSt8GgE8ppY8AgH8B5imldgDgGIZ5qce4rW1wcJBlWXYGAPjp6enI3t7esaZpP2uadlWr1rqgXdXr9SeKonw3NTUVAQCeUvoFALzVtxDLsu8SQubtdnuwWq3+qNV03N87wEKhiLlcHnO5HGYzuTadw0KhiAf7h6jVdNSq+k8TExNhAOAtFssHXQuZzeZ7AMA7HI6t8/OLp0VFwVQqhcmNJCY3NjtIGP4be6O3NlOoKAo+Pj9/6na7U8b0vtdSiFL6Ksuyc7Ozs7Ku688y6SwmEglMJJJtJHr4W2PpnQxqmvZsbm5OBgB+YGDg9UYxALjPcdzS5cXldXong/F4HGXZoEnH23QzjXyDTDqDlxeX1xzHLRFCphmGucMAwMsAwBcKhaNSqYSSJKEkSSiKYovt5WuONSPLMpZKJSwUCkfGdJoZAOAAgK/X638mNzYxFl3H6FoMY9H1PsS66E67mdzEer3+BwDwhJD3GYvF8vHo6KhDVVWMRddxdTVqsPqctWiT/zbW7otitC0vFl3Hsx8qODY25qaUTjKU0geTk5PC6ekpRiKRrqysrPyvWCQSwePvj3FmZmaNEDLDAMB9u90ePDk5wbAg3BAWUBC+NuyNvrFNsZbc54Tb8svlMhqb/XOGUvohx3FLqqr+KwgChkIhDAaCGAqFOmj3N/e7PSMIAlYqFRwZGXFQSh80Foiqqk9kWcbAcuCF8Pv9DXrFRVHEs7OzXxqb22Qy3SWEzIfD4fTu7i4GloPo9fo78fnQ6/Wjz+dDn6G9Xq+BvxG7tYHlICrFb1GSpEJj6Rub+hPrkHVB1/UrWZbR4/Gg2+1usbc0+3vh8XhQkiTUdf1X65B1AQA+az4XX6GUPhwfH/dUKpVrURTR4/Ggy+VCl8uFTqcTnU5ni77tt/vcbjeKooiqqv5ls9kChJD5xls1nY9vAABvs9kC1Wr1t/ROGkOhUGMwh8PR17pcLgwsB3B7extrtdrvNpstYFw37/S6Yt6klD4aHh7+KpvN7lcqlb8VRcGtrS2Mx+MdR5IkSSjLMqZSKSx+U0RVVf/J5/MHHMctAcCXZrP5Xt87jRDyGsuyEwDAW4esCzzPx7PZ7H65XFYPDw87ODo6UvP5/MHi4uKG8X14SqndZDLd7VuorSghhIxRSqcopQ/7/RKwLDtn5H0EAEO9xvwPzBFbs0IaopEAAAAASUVORK5CYII=) 0 12 / 0 12px repeat!important}#star-selector .selector-icon,#trends-selector .selector-icon{display:none!important}#your-items-tree-item-1-link,#your-items-tree-item-2-link,#friends-tree.scroll-tree li#friends-tree-item-1-main a{padding-left:39px!important}';
	GM_addStyle(css, 'rps_osxblack');
	//fireResize();
};

/**
 * Experimental Player theme 
 * 
 * based on the Google Player http://www.google.com/reader/play/
 * 
 * Author: 	Ludovic Valente
 * Version:	0.2
 * Date:	03/25/2010
 */

GRP.player = function(){
    var taskcce,lastEntry,lastThumb;
	var playerOn = true,itl = 0,entries = get_id('entries');
	
	//Expanded mode ONLY
	var mode = getMode();
    if (mode!=='expanded') {
		simulateClick(get_id('view-cards'));
	}
	
	var css = 'body{background: black;}';

	var h = getHeightEntries(true);
    //css += 'div#current-entry{display:inline;height:100%;position:absolute!important;width:100%;top:0px;z-index:10;visibility:visible!important;}';
	css += 'div.current{display:inline;height:'+h+'px;position:fixed!important;width:99%;top:0px;z-index:10;visibility:visible!important;}';
    
    //adapt main when nav is on
    css += 'body:not(.lhn-hidden) table#chrome-viewer-container{width:auto !important;}';
    
    //background black
    css += 'div#entries .entry{visibility:hidden;background-color:black;}';
    css += 'div.entry-likers, #no-entries-msg{background-color:black;}';
    css += 'div#entries, div#entries .entry, div#viewer-container, div.entry-container .entry-body{color:#999!important;}';
    //text color and size
    css += 'div.card-common,div#viewer-container{color:white;background-color: black;}';
    css += '.card{border-color:transparent!important; border-width:0px !important;-webkit-box-shadow:0px 0px black!important;box-shadow:10px 10px 20px black!important;}';
    css += 'a.entry-title-link{color:white !important;text-decoration: none;}';
    css += 'a,a:visited,.link{color: #AAA !important;}';
    css += '#chrome-header,#lhn-add-subscription-section{display:none;}';
    css += '#search,#gbh,#logo-container{display:none !important;}';
    css += 'div#main{top:0px;}';
    css += '#viewer-page-container{height:200px!important;}';
    css += '#entries, #viewer-page-container{overflow:hidden!important;}';
    css += '.scroll-tree li, .lhn-section{background-color:#AAA !important;}';
    css += '.scroll-tree li a:hover, a:hover .tree-item-action-container, .scroll-tree li a.menu-open, #lhn-selectors .selector:hover{background-color:#DDD !important;}';
    
	//arrows
	css += '#entries-up,#entries-down{display:none;}';
    //css += '#entries-up{left:0px;}#entries-down{right:0px;}';
    //css += '#entries-up,#entries-down{z-index:9999;color: #AAA;cursor: pointer;font-size: 200%;font-weight: bold;height: 64px;line-height: 58px;margin-top: -32px;position: fixed;text-align: center;top: 50%;width: 32px;}';
	
    //Can scroll long articles
    //css += '.entry-body{overflow:auto;}';
    css += '.entry{overflow:auto;}';
    
    //hide entry items
    css += '#gbar, #entries-status, .card-actions, .card-bottom{display:none;}';
    //hide nav
    css += '#chrome{margin-left:0px !important;}';//#chrome-lhn-toggle
    //TIMELINE
    css += '#viewer-footer{background-color: #222 !important;}';
    css += '#timeline{background-color: #222;margin-left:30px;}';
    var w = screen.width - 100;
    css += '#timeline{overflow:hidden;width:' + w + 'px;}';
    css += '#tl-items{padding:2px;}';
    css += '.tl-item{float:left;width:80px;height:80px;border:2px solid #acacac;margin:10px;opacity: 0.6;cursor: pointer;}';
    css += 'div.tl-item-sel{opacity:1;border:2px solid #dedede;}';
    css += '.tl-img{width: 80px; height: 80px; margin-top: 0px; margin-left: 0px;}';
    css += '.tl-ico{position: relative;bottom: 20px;left: 65px;}';
    css += '.tl-arrow{cursor:pointer;color: #DEDEDE;font-size: 300%;position: absolute;bottom:50px;z-index: 9999;}';
    css += '#tl-arrow-left{left:0px;}#tl-arrow-right{right:0px;}';
    css += '#viewer-footer{height:120px!important;padding-top:40px;}';
    
    //header timeline
    css += '.entry-date{position:fixed;right:0px;bottom:130px;font-size:23px!important;}';
    css += 'b.gb4{position:fixed;right:300px;bottom:130px;color:#aaa;z-index:99;font-size:23px!important;}';
    
    //Show unread counter
    //css += '#viewer-header{display:none;}';//let viewer-all-new-links be displayed
    css += '#viewer-comments-all-links, #mark-all-as-read-split-button, #viewer-header .goog-button, #viewer-toggles, #viewer-allcomments-return, #viewer-recommendations-return, #viewer-translated-by, #viewer-single-parent, #viewer-single-item-parent, #viewer-details-toggle {display:none;}';
    css += '#quick-add-success, #viewer-details {display:none;}div#viewer-top-controls{padding:0;}';
    css += '#viewer-all-new-links{position:fixed;left:10px;bottom:130px;color:#aaa;z-index:99;font-size:15px!important;}';
    
    GM_addStyle(css, 'rps_player');
    
    var csst = '#navdebug{cursor:pointer;position:fixed;right:10px;bottom:10px;color:#aaa;z-index:99;font-size:23px!important;}';
    GM_addStyle(csst, 'rps_playert');
    
    
    //nav hidden on load
    addClass(document.body, 'lhn-hidden');
    
/*    var body, gup = document.getElementById('entries-up'), gdown = document.getElementById('entries-down');
    if (gup) {
        body = getFirstElementByClassName(gup, 'goog-button-body');
        body.innerText = '◀';
    }
    if (gdown) {
        body = getFirstElementByClassName(gdown, 'goog-button-body');
        body.innerText = '▶';
    }
  */
   
    function createArrow(root, left){
        var el = document.createElement('div');
        el.id = (left) ? 'tl-arrow-left' : 'tl-arrow-right';
        el.className = 'tl-arrow';
        el.innerText = (left) ? '◀' : '▶';
        el.addEventListener('click', function(e){
			scrollpage(left, 1);
        });
        root.appendChild(el);
    }
    
    var vf = document.getElementById('viewer-footer');
    
    //Toggle skin
    var navdebug = document.createElement('div');
    navdebug.id = 'navdebug';
    var eltoggle = document.createElement('a');
    eltoggle.innerText = '#';
	eltoggle.title = 'Toggle skin';
    eltoggle.addEventListener('click', function(e){
        var el = get_id('rps_player');
        if (el) {
            el.parentNode.removeChild(el);
        } else {
            GM_addStyle(css, 'rps_player');
        }
        playerOn = !el;
    });
    navdebug.appendChild(eltoggle);
    vf.appendChild(navdebug);
	
    createArrow(vf, true);
    
    var timeline = document.createElement('div');
    timeline.id = 'timeline';
    var timelineItems = document.createElement('div');
    timelineItems.id = 'tl-items';
    timeline.appendChild(timelineItems);
	timeline.addEventListener('mousewheel', function(e){
		timeline.scrollLeft-=event.wheelDelta/2;
		if (((timeline.scrollLeft + timeline.clientWidth) / timeline.scrollWidth) > 0.5) {
			scrollNext();
		}
	});
	
    vf.appendChild(timeline);
    
    createArrow(vf, false);
    
    function checkCurrentEntry(){
        if (!playerOn) {
            return;
        }
		var current = getCurrentEntry();
        if (!current) {
            current = getFirstElementByClassName(document, 'entry');
        }
        if (current) {
            if (!lastEntry || lastEntry !== current) {
                selectEntry(current, true);
				/*if (lastEntry){
					removeClass(lastEntry, 'current');
				}
				addClass(current, 'current');
				console.log('Detect change current from '+((lastEntry)?lastEntry.className:'undef')+' to '+current.className);
				selectThumb(current);
                adaptSize(current);
                lastEntry = current;*/
            }
        }
    }
    
    function scrollNext(){
		entries.scrollTop = entries.scrollHeight;
		window.setTimeout(function(){
			entries.scrollTop = 0;
		}, 300);
    }
    
    function selectEntry(entry, selThumb){
        //if (entry && entry.id !== 'current-entry'){
		if (entry){
			if (lastEntry){
				removeClass(lastEntry, 'current');
			}
			//console.log('selectEntry:'+entry.className)
			/*var current = getCurrentEntry();
            if (current) {
                current.removeAttribute('id');
            }*/
			addClass(entry, 'current');
            //entry.id = 'current-entry';
            if (selThumb) {
                //console.log('selectEntry+selThumb');
				selectThumb(entry);
            }
            simulateClick(entry);//mark as read
            adaptSize(entry);
			lastEntry = entry;
        }
    }
	
	function getEntryIndex(entry){
		var index=false, m = /tl-entry-(\d+)/.exec(entry.className || '');
            if (m && m[1]) {
				index = parseInt(m[1], 10);
			}
			return index;
	}
	function getThumbIndex(entry){
		var index=false, m = /tl-item-(\d+)/.exec(entry.id || '');
            if (m && m[1]) {
				index = parseInt(m[1], 10);
			}
			return index;
	}	
	
	function getThumb(index){
		return get_id('tl-item-' + index);
	}
    
    function selectThumb(entry, elThumb){
		//console.log('selectThumb');
		if (lastThumb) {
            removeClass(lastThumb, 'tl-item-sel');
        }
        if (elThumb) {
            selectEntry(entry);
			var i = getThumbIndex(elThumb);
			scrollThumb(i);
        } else {
            //get thumb from entry id
            var index = getEntryIndex(entry);
			//console.log('index from entry:'+index)
            if (index) {
                elThumb=getThumb(index);
				console.log('elThumb from index:'+elThumb.className);
                //center on screen
                scrollThumb(index);
            }
        }
        if (elThumb) {
            addClass(elThumb, 'tl-item-sel');
            lastThumb = elThumb;
        }
    }
    
    
    function scrollpage(left, count){
        if (!left) {
			scrollNext();
		}
		
	    var current = getCurrentEntry();
		var index = getEntryIndex(current);
        index += ((left)?(-1):1)*count;

        var el = getThumb(index);
		if (el) {
			simulateClick(el);
		}
    }
    
    function scrollThumb(index){
        var vf = get_id('viewer-footer');
        //scroll(timeline, (index * 80) - (vf.clientWidth / 2));
		
		var el = get_id('tl-item-'+index);
		var value = (el)?el.offsetLeft:(index * 80);
		scroll(timeline, value - (vf.clientWidth / 2) + 40 );
    }
    function scroll(el, value, inc, time){
		//value=Math.min(Math.max(0,value),el.scrollWidth);
		//el.scrollLeft = value;
		var dir = (el.scrollLeft < value);
		scr(el, value, dir, inc || 2, time || 40);
	}
    function scr(el, value, dir, inc, time){
        //console.log('scroll from ' + el.scrollLeft + ' to ' + value);
        el.scrollLeft += ((dir)?1:-1)*inc ;
        //console.log('new value = '+ el.scrollLeft);
        if ((dir && el.scrollLeft < value) || (!dir && el.scrollLeft > value)) {
            window.setTimeout(function(){
                scr(el, value, inc, time);
            }, time);
        } else {
            el.scrollLeft = value;
        }
    }
    
    function forceSelectEntry(){
        var current = getCurrentEntry();
        if (!current) {
            var entry = getFirstElementByClassName(document, 'entry');
            selectEntry(entry, true);
        }
    }
    
    var heightEntries = getHeightEntries();
    
	function start(){
	 	//console.log('start monitor checkCurrentEntry');
		taskcce = window.setInterval(function(){
       	   checkCurrentEntry();
    	}, 500);
	}
	//start();
	function stop(){
		//console.log('stop monitor checkCurrentEntry');
		window.clearInterval(taskcce);
	}
	
    window.setInterval(function(){
        fillTimeline();
    }, 2000);

    
    function resetTop(entry){
		entry.parentNode.scrollTop = 0;//entries top=0
	}
	
    function adaptSize(entry){
        resetTop(entry);
        var eb = entry.firstChild;//card-common
        eb.style.fontSize = "200%";
        for (var c = 200; c > 80 && eb.offsetHeight > heightEntries; c -= 10) {
            eb.style.fontSize = c + "%";
        }
    }
    function findImage(images, width, minWidth){
        for (var i = 0, len = images.length; i < len; i++) {
            if (images[i].width >= width) {
                if (!minWidth || (minWidth && images[i].width >= minWidth)) {
                    return images[i].src;
                }
            }
        }
        return images[0].src;
    }
    
    function fillTimeline(){
        var entriesContainer = get_id('entries');
        var entry0 = entriesContainer.firstChild;
        if (!entry0) {
            fireResize();
        } else if (entry0 && !hasClass(entry0, 'tl-marked')) {
            //clear timeline if change folder
            timelineItems.innerHTML = '';
        }
        //getElements("id('entries')/div[contains(@class, 'entry')][not(contains(@class, 'tl-marked'))]")
        var entries = entriesContainer.getElementsByClassName('entry');
        timelineItems.style.width = (entries.length * 100 + 120) + 'px';
        foreach(entries, function(entry){
            if (hasClass(entry, 'tl-marked')) {
                return;
            }
            var link = getEntryLink(entry);
            var title = link.title || '';
            var eb = getFirstElementByClassName(entry, 'entry-body');
            var img = '', images;
			if (eb) {
				images = eb.getElementsByTagName('img');
				if (images && images[0]) {
					img = findImage(images, 80, 30);
				}
			}
            if (!img) {
                img = '/reader/ui/1327928375-explore-default-thumbnail.png';
            }
            var domain = getDomain(link.url);
            var el = document.createElement('div');
            el.className = 'tl-item';
            el.id = 'tl-item-' + itl;
            addClass(entry, 'tl-entry-' + itl);
            ++itl;
            var html = '<img class="tl-img" title="' + title + '" src="' + img + '" width="78" height="78"/><img src="http://s2.googleusercontent.com/s2/favicons?domain=' + domain + '" class="tl-ico" width="16" height="16"/>';
            el.innerHTML = html;
            el.addEventListener('click', function(e){
                scrollNext();
				selectThumb(entry, el);
            });
            timelineItems.appendChild(el);
            addClass(entry, 'tl-marked');
        }, this);
    }
    
    
};
//Calibri skin
//Author: dave kratter
//http://code.google.com/p/googlereaderplus/issues/detail?id=162
GRP.calibri = function() {
	var css = "*, html, body, span, div, td, br, input, font, button, select, option {font-family: Calibri !important; font-size: 10pt !important;} #viewer-top-controls, #chrome-header {padding: 2px 0 2px 5px !important;} #chrome {margin-left: 199px !important;} #entries .entry-body, #entries .entry-title {max-width: none !important;  padding-right: 1px !important;} .entry :hover {background: #FFFBF0 !important;} #entries .collapsed {padding: 2px !important; font-size: 12pt !important;} #nav-toggler {display: none !important;} #nav {font-size: 8pt !important; width: 199px !important;} #selectors-container {width: 199px !important;} #sub-tree {width: 199px !important;} #add-box {font-size: 8pt !important; margin: 1px !important;} #selectors-box, #sub-tree-box {margin: 1px !important;} #friends-settings-link {display: none !important;} #sub-tree .name {color: #0000cc !important;}";
	GM_addStyle(css, 'rps_calibri');
};//webbizgeek skin
//Author: jl kenney
//http://code.google.com/p/googlereaderplus/issues/detail?id=282
//http://www.webbizgeek.com/how-to-add-custom-css-to-google-reader-in-chrome/
GRP.webbizgeek = function() {
	var css = ".scroll-tree,.lhn-section{font-size:12px;line-height:25px}.folder-name-text{font-size:13px;line-height:28px}#entries.list .entry .collapsed{height:3ex;line-height:3ex}#entries.list .collapsed .entry-main .entry-source-title{font-size:90%;width:9em;left:10px!important}.entry-date{font-size:90%}#chrome-lhn-toggle,#viewer-header{background:#d6d6d6}.scroll-tree li a,#sub-tree-container,#sub-tree,.gecko{background:#F2F2F2}.folder-toggle + a.link{background:#d6d6d6;border-top:2px solid #F2F2F2}.lhn-section-primary,.lhn-subscriptions,#lhn-add-subscription-section,html{background:#F2F2F2!important;xborder-top:2px solid #fff}html,#logo-container,#guser,h1.logo{background:#F2F2F2!important}#entries.list .read .collapsed{background:#F0F0F0!important}#entries.list .expanded .collapsed{background:#d6d6d6!important}#sub-tree-container{border-top:2px solid #C2CFF1}.scroll-tree .icon,.entry .entry-icons .star{background:none}.scroll-tree .favicon{top:4px}.scroll-tree .folder-name{padding-left:0}.scroll-tree .toggle{top:6px}.section-button{top:7px}.entry-source-title,#current-entry.expanded .entry-secondary-snippet{display:none}#entries.list .collapsed .entry-secondary .entry-title{font-family:Georgia,serif;font-size:115%;font-weight:400}#entries.list .collapsed .entry-main .entry-source-title,#entries .read .collapsed .entry-title{color:#898989}#entries.list .entry .entry-actions{background:#E3E3E3;padding:7px 0 7px 18px}.samedir #entries.list .collapsed .entry-secondary{margin-left:11em}.samedir #entries.single-source .collapsed div.entry-secondary{margin-left:13px}.samedir #entries.single-source .collapsed .entry-secondary{margin-left:10px!important}#sub-tree ul ul li a{padding-left:32px}";
	GM_addStyle(css, 'rps_webbizgeek');
};//Sublime Reader skin
//Author: lai
//https://chrome.google.com/extensions/detail/jbhkdhkngalchoobjfiobbjobnbpfgmg#
GRP.sublimelight = function() {
	var css = "#sub-tree::-webkit-scrollbar {width: 10px;}*{font-weight:400!important}b,.label{font-weight:700!important}body{background-color:#ececec!important}#main{top:0!important}#sub-tree::-webkit-scrollbar,#entries::-webkit-scrollbar{width:9px!important}#sub-tree::-webkit-scrollbar-thumb,#entries::-webkit-scrollbar-thumb{background:#f6f6f6!important;border:1px solid #bbb!important;-webkit-border-radius:5px!important}#entries.list .entry{margin-right:1px!important;border-color:transparent!important}.goog-button-base-outer-box{border:none!important}.goog-button-base-top-shadow{border-bottom:none!important;background-color:transparent!important}.goog-button-base-inner-box{border:1px solid #dbdbdb!important;border-radius:3px!important;background-image:0 to(#f2f2f2))!important}.goog-button-body{font-size:11px!important;color:#888!important;line-height:18px!important;text-shadow:0 1px 0 #fff}#nav{width:200px!important}.lhn-section{border-top:none!important;background-color:transparent!important}#sub-tree{font-size:12px!important}.scroll-tree li .tree-link-selected span{font-weight:700!important;color:#3e3e3e!important}.scroll-tree li a{background-color:transparent!important;padding-left:10px!important}.scroll-tree li a:hover span{text-decoration:underline!important}#sub-tree ul ul li a{padding-left:26px!important}.scroll-tree .name{padding-left:2px!important}.lhn-section-footer{height:0!important}#chrome{margin-left:200px!important;border-left:none!important;padding-left:10px!important;padding-right:12px!important}#chrome-title{font-size:21px!important;color:#3e3e3e!important;text-shadow:0 1px 0 #fff}#viewer-header{background-color:transparent!important;border-bottom:1px solid #bbb!important;font-size:11px!important}#viewer-top-controls{border-bottom:1px solid #fff!important}#viewer-container{background-color:transparent!important;border-bottom:1px solid #bbb!important;padding:0 1px!important}#entries.list .entry .collapsed{background:#e2e2e2!important;border-color:#e2e2e2!important}#entries.list .read .collapsed{background:transparent!important;border-color:transparent!important}#entries.list .entry .collapsed:hover{background-color:transparent!important;border-color:transparent!important}#entries.list .collapsed .entry-secondary{color:#999!important}#entries.list .read .collapsed .entry-secondary{color:#b2b2b2!important}#entries .collapsed .entry-title{color:#505050!important}#entries .read .collapsed .entry-title{color:#909090!important}.entry-title a,.entry-container .entry-body{color:#333!important}#entries.list .entry .entry-actions{background:transparent!important;border:none!important}#viewer-footer{background-color:transparent!important;font-size:11px!important;border-color:#fff!important}#no-entries-msg{background:transparent!important;border:1px solid #fff!important;-webkit-box-shadow:0 0 0 1px #bbb;border-radius:10px!important}.entry-secondary .entry-title,.entry-container .entry-title a{font-family:Georgia,serif!important}#searchicon{position:absolute;top:8px;right:16px;color:#666!important;cursor:pointer;font-weight:700!important;font-size:11px}#search{left:auto!important;right:0!important;top:31px!important;background-color:#eee!important;-webkit-box-shadow:rgba(0,0,0,0.3) -4px 4px 10px 1px!important;padding:10px!important}#gbar,#guser,.gbh,#logo-container,.section-button,#lhn-add-subscription-section,#lhn-recommendations,.folder-toggle,.folder-icon,.sub-icon,.tree-item-action-container,#chrome-view-links,.chevron,#chrome-lhn-toggle,.entry-icons,.entry-original,#lhn-friends .icon{display:none!important}.lhn-section .link *,.entry-body a{color:#666!important}.scroll-tree li,.scroll-tree li .tree-link-selected,#chrome-header,#entries .entry{background-color:transparent!important}.entry-date,.entry-author{font-size:11px!important}#entries.list .entry .entry-container,.entry-likers{background:transparent!important}";
	GM_addStyle(css, 'rps_sublimelight');
	fireResizeDefer();
	sublime_update();
};
//Sublime Reader skin
//Author: lai
//https://chrome.google.com/extensions/detail/jbhkdhkngalchoobjfiobbjobnbpfgmg#
GRP.sublimedark = function() {
	var css = '#sub-tree::-webkit-scrollbar {width: 10px;}*{font-weight:400!important}#searchicon{position:absolute;top:8px;right:16px;color:#aaa!important;cursor:pointer;font-weight:700!important;font-size:11px}#entries.search .entry{border:none!important}.highlighted0,.highlighted1,.highlighted2,.highlighted3,.highlighted4,.highlighted5,.highlighted6{color:#fff!important;background-color:transparent!important}#search-restrict-button .goog-menu{width:180px!important;padding-right:1px!important}#search-restrict-button .goog-menu::-webkit-scrollbar-thumb{background:#555!important;-webkit-border-radius:4px!important}.goog-menu{background-color:#393939!important;-webkit-box-shadow:#1a1a1a 0 2px 10px!important}.goog-menuitem,.goog-menuitem-content,.goog-menuitem-content span{color:#999!important;font-size:11px!important;line-height:18px!important}.related-streams-menu .title{margin-left:0!important}.goog-menuseparator{border-top-color:#555!important}.goog-menuitem-highlight{background-color:#555!important}.goog-option-selected .goog-menuitem-checkbox{background-image:none!important}.goog-option-selected .goog-menuitem-checkbox:before{content:"✓"!important}.entry-actions{background-color:transparent!important;border:0!important;padding:3px 22px!important}.item-link-drop-down-arrow{border-left-color:transparent!important;border-right-color:transparent!important;border-top-color:#555!important}.entry-comments{background-color:#2b2b2b!important;color:#666!important}.entry-conversation{border-top:0!important}#current-entry .entry-conversation{padding-left:20px!important}.card-actions{background-color:transparent!important;padding:0 5px!important}.entry-actions .link,.entry-actions .email{background-image:none!important;padding-left:2px!important}.entry-actions .like-active:before{content:"☻";font-size:18px}.entry-actions .email:before{content:"✉";font-size:18px!important}.entry-actions .email-active,.email-active .link{color:#fff!important;text-shadow:0 0 3px #666;background-color:transparent!important;border-bottom:0!important}.entry-actions .read-state-not-kept-unread:before{content:"☐";font-size:18px!important;position:relative;top:1px}.entry-actions .read-state-kept-unread:before{content:"☑";font-size:18px!important;position:relative;top:1px}.number-of-likers{background-image:none!important;padding-left:0!important}.action-area{background-color:#2b2b2b!important;color:#999!important;border-color:#202020!important}#search{left:auto!important;right:0!important;top:31px!important;background-color:#3f3f3f!important;-webkit-box-shadow:#1a1a1a -8px 8px 20px!important;padding:10px!important}#search-restrict{border-color:#3f3f3f!important}#search-restrict-button .search-restrict-contents{padding-bottom:0!important}input,textarea{outline:none!important;background-color:#999!important;border:1px solid #2b2b2b!important;color:#202020!important;padding:1px!important}input:focus{-webkit-box-shadow:#202020 0 0 10px!important}#search-restrict-input:focus{-webkit-box-shadow:none!important}#search-input{margin:1px 4px!important}#search-restrict-input{border:none!important;background-color:transparent!important;color:#999!important}.goog-button-base-inner-box{border:1px solid #222!important;background-image:0!important;-webkit-border-radius:3px!important;-moz-border-radius:3px!important}.goog-button-body{line-height:18px!important}#logo-container,#gbar,#guser,#global-info,.gbh,#lhn-add-subscription-section,#chrome-view-links,#lhn-selectors,#your-items-tree-container,#lhn-recommendations,.section-minimize,.scroll-tree .icon,.goog-menuitem-content .icon,a:hover .tree-item-action-container,.menu-open .tree-item-action-container,#chrome-lhn-toggle,.entry .entry-title .entry-title-go-to,.entry-original,#chrome-title .chevron,.entry-icons,#loading-area,#message-area-outer{display:none!important}.goog-button-base-outer-box,.goog-button-base-top-shadow,.section-button,.folder-toggle,.lhn-section,.scroll-tree li,.scroll-tree li a:hover,.scroll-tree li .updated,.tree-link-selected,#chrome,#no-entries-msg,#tips,.entry-likers{background-image:none!important;background-color:transparent!important;border:0!important}.link,span.unselectable,#viewer-all-new-links,#entries-status,.entry-author,#entries .entry-date,.goog-button-body,.entry-comment-date{font-size:11px!important}#chrome-title a{font-size:19px!important;text-shadow:#000 1px 1px 1px!important}#nav span{font-size:12px!important}.entry-container .entry-title a{font-size:18px!important}.entry-secondary .entry-title,.entry-container .entry-title a{font-family:Georgia,serif!important}body,.viewer-page,#viewer-page-container,#lhn-subscriptions,#lhn-friends,#viewer-container,#entries .entry.read,#chrome-header,.read .card-common{background-color:#1a1a1a!important}#viewer-top-controls,.entry,.read .collapsed,#entries.list .entry-container,.friend-interruption,#viewer-footer{border-color:#202020!important}.read .collapsed,#no-entries-msg,#tips{background-color:#202020!important}#viewer-header,#viewer-footer,.collapsed,#entries .entry,.card-common,.friend-interruption{background-color:#2b2b2b!important}.collapsed,.entry .card{border-color:#2b2b2b!important}.read .snippet{color:#383838!important}.entry-actions span{color:#555!important}.read .entry-secondary .entry-title{color:#757575!important}a,a:visited,.link,.snippet,.entry-author,.entry-attribution,.generic-comments-header,#scroll-filler{color:#666!important}.entry-body{color:#aaa!important}#nav .tree-link-selected span,.scroll-tree li .updated,#chrome-title,#chrome-title a,.entry-secondary .entry-title,.entry-container .entry-title a{color:#fff!important}.goog-menu-button .goog-menu-button-dropdown{border-color:#999 #3f3f3f #3f3f3f!important}#main,#settings-frame,#settings{top:0!important;margin:0!important}#nav,#nav *{max-width:200px!important}#nav{width:200px!important}#sub-tree{margin-right:1px!important}#sub-tree::-webkit-scrollbar,#entries::-webkit-scrollbar,#viewer-page-container::-webkit-scrollbar,#search-restrict-button .goog-menu::-webkit-scrollbar{width:8px!important}#sub-tree::-webkit-scrollbar-thumb,#entries::-webkit-scrollbar-thumb,#viewer-page-container::-webkit-scrollbar-thumb{background:#393939!important;-webkit-border-radius:4px!important}.folder-toggle{left:5px!important;top:3px!important}.section-button,.folder-toggle{height:0!important;width:0!important;margin-top:5px!important;margin-right:3px!important;border-color:#999 #1a1a1a #1a1a1a!important;border-style:solid!important;border-width:4px 4px 0!important}.scroll-tree li a{padding-left:0!important}.scroll-tree li a:hover span{text-decoration:underline!important}.lhn-section-footer{height:0!important}#chrome{margin-left:200px!important}.lhn-hidden #chrome{margin-left:1px!important}#chrome-header,#viewer-top-controls,#viewer-footer{padding:5px 15px!important}#viewer-container{margin-right:4px!important}#entries{padding-right:1px!important}#entries.list #current-entry.expanded{border-bottom-width:2px!important}#entries .collapsed .entry-date{margin:0 2px 0 0 !important}.samedir #entries.single-source .collapsed .entry-secondary{margin-left:1em!important}.entry .entry-main{margin-left:26px!important}#entries.list .collapsed .entry-main .entry-source-title{left:1em!important}#entries-status{top:5px!important}#no-entries-msg,#tips,.entry .card{-webkit-border-radius:10px!important;-moz-border-radius:10px!important}.entry .card{-webkit-box-shadow:none!important;-moz-box-shadow:none!important;border-width:2px!important}#current-entry .card .card-content{padding:10px 1px 5px 5px !important}#current-entry .card .card-bottom{padding:0 5px!important}.tags-edit{background-color:#3f3f3f!important;border:none!important;-webkit-box-shadow:#1a1a1a 0 0 10px!important}#quick-add-bubble-holder{background-color:#3f3f3f!important;border:0!important;-webkit-box-shadow:#1a1a1a 0 0 10px!important}.modal-dialog-bg,.fr-modal-dialog-bg{background-color:#000!important}.fr-modal-dialog{border:0!important;background-color:rgba(63,63,63,0.9)!important;color:#fff!important;outline:none!important;-webkit-box-shadow:#000 0 0 15px!important;padding:6px!important}button{border:1px solid #222!important;background-image:0 to(#373737))!important;-webkit-border-radius:3px!important;color:#999!important;font-size:11px!important;min-width:55px!important}button:focus{outline:none!important;-webkit-box-shadow:red 0 0 10px!important}.text-tooltip{font-family:Arial, san serif!important;line-height:12px!important;background-color:rgba(26,26,26,0.7)!important;border:0!important;color:#fff!important;-webkit-border-radius:4px!important;font-size:11px!important;-webkit-box-shadow:#1a1a1a 0 0 5px!important;padding:4px!important}b,.label,.tree-link-selected span,.scroll-tree li .updated{font-weight:700!important}.search .entry-title-link,#nav span,#viewer-all-new-links,#viewer-top-controls .link-selected,#no-entries-msg,#tips,.goog-button-body,.info *,.search-result .entry-date,.entry-comment-content,#quick-add-instructions,#quick-add-helptext{color:#999!important}#entries .entry-container,.entry-actions .item-link-active,.email-this-area,.card-bottom,#entries.cards .entry,.fr-modal-dialog-content,.fr-modal-dialog-buttons{background-color:transparent!important}.entry-actions .item-star:before,.entry-actions .item-star-active:before{content:"★";font-size:18px!important;position:relative;top:1px}.entry-actions .item-star-active,.entry-actions .like-active,.entry-actions .broadcast-active,.entry-actions .read-state-kept-unread{color:#fff!important;text-shadow:0 0 3px #666}.entry-actions .like-inactive:before,.number-of-likers:before{content:"☺";font-size:18px}.entry-actions .broadcast-inactive:before,.entry-actions .broadcast-active:before{content:"❤";font-size:16px!important;position:relative;top:1px}.goog-button-base:hover .goog-button-base-inner-box,.goog-button-base:active .goog-button-base-inner-box,.goog-button-base-open .goog-button-base-inner-box{background-image:0!important}#lhn-friends,#lhn-subscriptions #sub-tree ul ul li a{padding-left:10px!important}';
	GM_addStyle(css, 'rps_sublimedark');
	fireResizeDefer();
	sublime_update();
};//GReader Redesigned (by Globex Designs), 1.1.1 Developer
//Author: Evgueni Naverniouk (evgueni@globexdesigns.com)
//http://www.globexdesigns.com/gr
//https://chrome.google.com/extensions/detail/ckginkiikecmgijnldmohmbiifhjeiej
//http://www.globexdesigns.com/products/gr/greader/greader.css
GRP.redesigned = function() {
	var css = 'input[type=checkbox],input[type=radio]{background:url(http://www.globexdesigns.com/products/gr/img/checkbox.gif) no-repeat;cursor:pointer;-moz-border-bottom-colors:#999 #FFF;-moz-border-left-colors:#999 #FFF;-moz-border-right-colors:#999 #FFF;-moz-border-top-colors:#999 #FFF}input[type=text],#search-restrict-input:focus,select{background:url(http://www.globexdesigns.com/products/gr/gmail/img/buttons/i.gif) repeat-x!important;border:2px solid!important;color:#505050!important;font-size:11px!important;-moz-border-bottom-colors:#363B42 #FFF;-moz-border-left-colors:#363B42 #FFF;-moz-border-right-colors:#363B42 #FFF;-moz-border-top-colors:#363B42 #FFF;-moz-border-radius:4px;margin:0!important;padding:2px 4px 3px!important}textarea{background:#F6F6F6 url(http://www.globexdesigns.com/products/gr/img/textarea.gif) repeat-x!important;border:2px solid!important;color:#000!important;-moz-border-bottom-colors:#363B42 #FFF;-moz-border-left-colors:#363B42 #FFF;-moz-border-right-colors:#363B42 #FFF;-moz-border-top-colors:#363B42 #FFF;-moz-border-radius:4px;margin:0!important}*{font-family:Tahoma, Verdana, Arial, Helvetica, sans-serif!important}:focus{outline:0!important}::-moz-selection{background:#40464F;color:#FFF}a::-moz-selection{color:#FB0}body{background:#566068!important}button,input,option,select,textarea{-moz-appearance:none!important}#gbar,#guser,.message-area-inner,#search-restrict,#search-restrict-button,.goog-button-base,.goog-button-base-outer-box,.goog-button-base-inner-box,.goog-button-base-content,.search-restrict-contents,.subscribe-button,.lhn-section,.scroll-tree li,.scroll-tree li a,.lhn-section-footer,.goog-button-body,#viewer-container,#chrome.page-view #viewer-page-container,#scour-menu-contents,#team-messages,.recent,#stream-prefs-menu,.tab-group,.tab-header,.fr-modal-dialog-content,.fr-modal-dialog-buttons,.fr-modal-dialog-title,#directory-box,#directory-box .tab-group,#bundle-meta-info,#friends-manager,#following-intro,#followers-intro,.card-content,.friends-tree-invite-info,.friends-tree-notification-info,#settings,#settings .c,#settings #header,#settings .settings-list .setting-body td,.associated-friends-names,.action-area .email-this-area,.entry-likers,.tree-item-action-container,.user-tags-list,.pc_fl,.talk,#tips-body .bookmarklet{background:transparent!important;border:0!important;margin:0!important;padding:0!important}.goog-button,button,.bookmarklet-link,#close-settings-link,.setting-group-title,input[type=button],#recommendations-tree-view-all{cursor:pointer!important;font-size:11px!important}.goog-button-base-outer-box,#friends-tree .friends-tree-item-action,button,.bookmarklet-link,#close-settings-link,.setting-group-title,.subs-unsubscribe,.labels-delete,#recommendations-tree-view-all{border:2px solid!important;-moz-border-bottom-colors:#363B42 #6E7680;-moz-border-left-colors:#363B42 #6E7680;-moz-border-right-colors:#363B42 #6E7680;-moz-border-top-colors:#363B42 #6E7680;-moz-border-radius:4px}.goog-button-base-outer-box:focus,.goog-button-base-outer-box:hover,button:focus,button:hover,#close-settings-link:hover,#close-settings-link:focus,.setting-group-title:hover,.setting-group-title:focus,#recommendations-tree-view-all:hover,#recommendations-tree-view-all:focus{-moz-border-bottom-colors:#363B42 #7D8692;-moz-border-left-colors:#363B42 #7D8692;-moz-border-right-colors:#363B42 #7D8692;-moz-border-top-colors:#363B42 #7D8692}.goog-button-base-content,#friends-tree .friends-tree-item-action,button,#close-settings-link,.setting-group-title,.subs-unsubscribe,.labels-delete,#recommendations-tree-view-all{background:url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/button.gif) repeat-x!important;color:#EEE!important;cursor:pointer;font-weight:400!important;height:22px;line-height:21px!important;text-align:center;text-decoration:none!important;text-shadow:#363B42 0 1px 1px;vertical-align:inherit!important;padding:0 9px!important}button,input[type=button],input[type=submit]{line-height:12px!important;padding-bottom:3px!important}#lhn-add-subscription-section .goog-button-body,.setting-group-title .link{color:#EEE!important;display:inline!important;padding:0!important}#search-restrict-button .goog-button-base-content,#search-submit .goog-button-base-content,.button-publish .goog-button-base-content,.bookmarklet-link,#discover-table .goog-button-base-content,#directory-search-button .goog-button-base-content,#service-quickadd-button .goog-button-base-content,#directory-saved-searches-button .goog-button-base-content,#recommendations-tab-contents .goog-button-base-content,#directory-search-results .goog-button-base-content,.entry-comments .goog-button-base-content,.friend-display-toggle .goog-button-base-content,#profile-search-button .goog-button-base-content,.subs-unsubscribe,.folder-chooser .goog-button-base-content,.labels-delete,.email-this-buttons .goog-button-base-content,.preview-interruption .goog-button-base-content{color:#303030!important}#search-restrict-button .goog-button-base-content,#search-submit .goog-button-base-content,.button-publish .goog-button-base-content,#discover-table .goog-button-base-content,#directory-search-button .goog-button-base-content,#service-quickadd-button .goog-button-base-content,#directory-saved-searches-button .goog-button-base-content,#recommendations-tab-contents .goog-button-base-content,#directory-search-results .goog-button-base-content,.entry-comments .goog-button-base-content,.friend-display-toggle .goog-button-base-content,#profile-search-button .goog-button-base-content,.subs-unsubscribe,.folder-chooser .goog-button-base-content,.labels-delete,.email-this-buttons .goog-button-base-content,.preview-interruption .goog-button-base-content{background:url(http://www.globexdesigns.com/products/gr/gmail/img/buttons/b.gif) repeat-x!important;color:#505050!important;height:18px;line-height:16px!important;text-shadow:#FFF 0 1px 1px}.folder-chooser .goog-button-body,.friend-display-toggle .goog-button-base-content{display:block!important;line-height:17px!important}#search-restrict-button:hover .goog-button-base-content,#search-submit:hover .goog-button-base-content,.button-publish .goog-button-base-content:hover,#discover-table .goog-button-base-content:hover,#directory-search-button .goog-button-base-content:hover,#service-quickadd-button .goog-button-base-content:hover,#directory-saved-searches-button .goog-button-base-content:hover,#recommendations-tab-contents .goog-button-base-content:hover,#directory-search-results .goog-button-base-content:hover,.entry-comments .goog-button-base-content:hover,.friend-display-toggle .goog-button-base-content:hover,#profile-search-button .goog-button-base-content:hover,.subs-unsubscribe:hover,.folder-chooser .goog-button-base-content:hover,.labels-delete:hover,.email-this-buttons .goog-button-base-content:hover,.preview-interruption .goog-button-base-content:hover{background-position:0 -18px!important;color:#202020!important}input[type=radio]{-moz-box-shadow:#DDD 0 0 2px}input[type=text]:hover,#search-restrict-input:hover,select:hover{-moz-border-bottom-colors:#555F67 #FFF;-moz-border-left-colors:#555F67 #FFF;-moz-border-right-colors:#555F67 #FFF;-moz-border-top-colors:#555F67 #FFF}select{padding:1px 3px 2px!important}option{background:#FFF!important;cursor:pointer}.progress-bar{background:#414850 url(http://www.globexdesigns.com/products/gr/gmail/img/messages/progressbar.gif) repeat-x;border:2px solid!important;height:12px!important;-moz-border-bottom-colors:#707273 #373D42;-moz-border-left-colors:#707273 #373D42;-moz-border-right-colors:#707273 #373D42;-moz-border-top-colors:#707273 #373D42;-moz-border-radius:6px;margin:0 auto!important;padding:0!important}.progress-bar-thumb{background:transparent url(http://www.globexdesigns.com/products/gr/gmail/img/messages/progressbar-on.gif) repeat!important;height:14px;-moz-border-radius:5px}textarea:focus{background-color:#F8EAC5!important;background-position:0 -18px!important;color:#202020!important}.goog-menu,.gbm,#quick-add-bubble-holder,.lhn-menu #nav,#scour-menu-container,#stream-prefs-menu-contents,.small-interruption,#overview,#rec-preview,#recent-activity,#tips,.fr-modal-dialog,#bundle-creation-area,.folder-chooser-contents,.friends-tree-following-info,.friends-feeds-invite-info,.profile-frame-border{background:url(http://www.globexdesigns.com/products/gr/gmail/img/logobar/popup.png) repeat-x!important;border:2px solid!important;-moz-border-bottom-colors:#6C6D70 #D2D2D2;-moz-border-left-colors:#6C6D70 #D2D2D2;-moz-border-right-colors:#6C6D70 #D2D2D2;-moz-border-top-colors:#6C6D70 #D2D2D2;-moz-border-radius:8px;-moz-box-shadow:#000 0 0 8px}.goog-menuitem,.reading-list-menu-item,.single-feed-menu-item,.chooser-item,.friend-stream-menu-item,.gbm .gb2{background:transparent!important;clear:both;color:#FFF!important;font-size:11px!important;-moz-border-radius:4px;padding-left:18px!important;padding-right:8px!important}.goog-menuitem-highlight,.reading-list-menu-item:hover,.single-feed-menu-item:hover,.chooser-item:hover,.friend-stream-menu-item:hover,.gbm .gb2:hover{background:#222!important;cursor:pointer!important}#stream-folder-chooser .chooser-item{padding-left:16px!important}.goog-option-selected .goog-menuitem-checkbox,.goog-menuitem-icon,.menu-item.selected,.chooser-item-selected,.chooser-item-selected:hover{background:url(http://www.globexdesigns.com/products/gr/greader/img/menu/check.png) no-repeat!important}.menu-item.selected{background-position:1px 1px!important;cursor:default!important}.chooser-item-selected,.chooser-item-selected:hover{background-position:0 4px!important}.divider{border-color:#999!important}#gbar{left:0;position:absolute;top:0;z-index:2;padding:0 0 0 12px !important}#gbar,#guser{font-size:11px!important;height:23px!important;line-height:21px}#gbar a,#guser a{color:#999!important}.gb3 u{text-decoration:none!important}.gb3 small{background:url(http://www.globexdesigns.com/products/gr/gmail/img/icons/arrows.gif) no-repeat -1px -3px;font-size:0;padding:4px 7px 0 0}.gb3:hover small{background-position:-12px -3px}#gbi{background:transparent!important;border:2px solid!important;min-width:100px;-moz-border-bottom-colors:#1B1D1F #51575C;-moz-border-left-colors:#1B1D1F #51575C;-moz-border-right-colors:#1B1D1F #51575C;-moz-border-top-colors:#1B1D1F #51575C;-moz-border-radius:6px;-moz-box-shadow:#000 0 0 5px;top:18px!important}#gbs{opacity:0}a.gb2{background:#181C1F;line-height:18px;opacity:0.9;padding:0 8px!important}a.gb2:focus,a.gb2:hover{background:#1F2124!important;color:#FFF!important;opacity:1.0}a.gb2:first-child{-moz-border-radius-topleft:3px;-moz-border-radius-topright:3px}a.gb2:last-child{-moz-border-radius-bottomleft:3px;-moz-border-radius-bottomright:3px}#guser{background:#1B1D20 url(http://www.globexdesigns.com/products/gr/gmail/img/gbar/gbar.gif) repeat-x!important;color:#FB0!important;left:0;text-align:right;position:absolute;right:0;top:0}#guser b{color:#DDD}#guser a{padding:0 4px!important}#guser .offline-status-icon{background-image:url(http://www.globexdesigns.com/products/gr/gmail/img/gbar/offline.png)!important;font-size:9px!important}#is-connected{background-position:0 -198px!important}#is-disconnected{background-position:0 -99px!important}#guser a:last-child{color:#DCDBDB!important;font-weight:700;margin-right:12px}#loading-area,.info-message #message-area-inner,.progress-message #message-area-inner{background:#B90000 url(http://www.globexdesigns.com/products/gr/gmail/img/messages/loading.gif) repeat-x!important;border:2px solid!important;display:block;-moz-border-bottom-colors:#B30000 #9B0000;-moz-border-left-colors:#B30000 #840000;-moz-border-right-colors:#B30000 #840000;-moz-border-top-colors:#B30000 #6D0000;-moz-border-radius:4px;-moz-box-shadow:#000 0 0 5px;padding:2px 20px!important}#logo-container{left:17px!important;top:31px!important}#logo{background:url(http://www.globexdesigns.com/products/gr/greader/img/logobar/logo.png) no-repeat!important;height:48px!important;width:134px!important;z-index:200}#logo:hover{opacity:0.8}#search{background:#FFF url(http://www.globexdesigns.com/products/gr/gmail/img/logobar/logobar.gif) repeat-x!important;height:58px;left:0!important;top:23px!important;width:100%;z-index:0!important}.scour #search,.settings #search{display:block!important}#search-input{width:217px!important;margin:18px 1px 0 167px !important}#search-restrict{margin:18px 0 0 3px !important}#search-restrict .goog-menu-button .goog-menu-button-dropdown{background:url(http://www.globexdesigns.com/products/gr/greader/img/logobar/arrow-blue.gif) no-repeat 0 1px!important;border:0!important;height:4px!important;right:6px!important;width:7px!important}#search-restrict-input{background:transparent;border:0!important;color:#505050!important;text-shadow:#FFF 0 1px 1px}#search-restrict-input:focus{width:116px!important;margin:-2px -11px 0!important}#search-submit{margin:18px 0 0 2px !important}.loaded #main{background:#566068 url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/background.gif) repeat-x;top:81px!important;z-index:-1;padding:6px 0 0}#nav{width:220px!important}#lhn-add-subscription-section{text-align:center;margin:0 0 4px!important}#lhn-add-subscription .goog-button-base-content{width:125px}.lhn-menu #lhn-add-subscription-section{width:125px;margin:4px auto!important}.lhn-menu #lhn-add-subscription .goog-button-base-content{width:auto!important}.lhn-menu #lhn-add-subscription .goog-button-body{margin-left:8px!important}#chrome-lhn-menu{margin-right:8px!important}#chrome-lhn-menu .goog-button-base-content{height:18px!important;line-height:16px!important;padding:0 7px 0 9px !important}#quick-add-close,.close-box,.fr-modal-dialog-title-close{background:transparent url(http://www.globexdesigns.com/products/gr/gmail/img/chat/button-close.gif) no-repeat!important;height:16px!important;opacity:0.4;width:16px!important;margin:0 1px!important}#quickadd{width:225px!important;margin:6px auto!important}#quick-add-btn{float:right!important;margin:6px 0 0!important}#quick-add-btn .goog-button-base-content{height:18px!important;line-height:16px!important}.lhn-button,.section-button{background:url(http://www.globexdesigns.com/products/gr/greader/img/menu/buttons.gif) no-repeat!important;border:2px solid;height:11px!important;-moz-border-bottom-colors:#363B42 #6E7680;-moz-border-left-colors:#363B42 #6E7680;-moz-border-right-colors:#363B42 #6E7680;-moz-border-top-colors:#363B42 #6E7680;-moz-border-radius:3px;width:11px!important;margin:1px 0 0!important}.section-minimize{background-position:-11px 0!important;margin-right:1px!important;right:28px!important}.section-minimize:hover{background-position:-11px -11px!important}.section-minimized .section-minimize{background-position:0 0!important}#lhn-friends-indicator{background:url(http://www.globexdesigns.com/products/gr/greader/img/menu/comment.png)!important;border:0;right:47px!important;margin:3px 0 0!important}.friend-tree-comments-name[class*=-unread]{font-weight:700!important}.section-menubutton{background-position:-22px 0!important;right:13px!important}.section-menubutton:hover{background-position:-22px -11px!important}.tree-item-action-container .tree-item-action{right:3px!important;top:1px!important}.lhn-menu .goog-menuitem{padding-left:18px!important}.goog-menuitem-content .goog-menuitem-checkbox,.goog-menuitem-content .goog-menuitem-icon{left:3px!important;top:4px}.goog-menu .goog-menuitem-content{position:relative}.goog-menu .goog-menuitem-content .goog-menuitem-checkbox{left:-14px!important}#lhn-selectors .selector,#lhn-selectors .scroll-tree-container,#lhn-friends .selector,#lhn-subscriptions .lhn-section-footer,#lhn-recommendations .selector{background:transparent!important;width:auto;margin:0 8px 0 9px !important;padding:0 0 2px!important}.lhn-section-primary,#lhn-selectors .lhn-section-secondary:last-child,#friends-tree-container .lhn-section-secondary,#friends-tree-container .lhn-section-footer{padding-left:4px!important}#lhn-selectors .link,#lhn-friends .link,#lhn-recommendations a[class*=link]{background:url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/mainmenu.gif) repeat-x!important;border:2px solid!important;cursor:pointer!important;display:block;font-size:11px!important;height:20px;line-height:19px;-moz-border-bottom-colors:#363B42 #6E7680;-moz-border-left-colors:#363B42 #6E7680;-moz-border-right-colors:#363B42 #6E7680;-moz-border-top-colors:#363B42 #6E7680;-moz-border-radius:4px;position:relative;text-indent:20px;text-shadow:#363B42 0 1px 1px}.lhn-section .text,.lhn-section span,.lhn-section .link{color:#EEE!important;font-size:11px!important;text-decoration:none!important}#lhn-selectors .link:hover,#lhn-friends .link:hover,#lhn-recommendations a[class*=link]:hover{background-position:left center!important;color:#FFF!important;-moz-border-bottom-colors:#363B42 #7D8692;-moz-border-left-colors:#363B42 #7D8692;-moz-border-right-colors:#363B42 #7D8692;-moz-border-top-colors:#363B42 #7D8692}#lhn-selectors .selected .link,#lhn-selectors .tree-link-selected,#lhn-friends .selected .link,#lhn-friends .tree-link-selected,#lhn-recommendations a[class*=link][class*=tree-link-selected]{background-position:left bottom!important}.lhn-section .selected a,.lhn-section .selected a .text,.lhn-section .selected .link,.tree-link-selected span{color:#FFF!important;font-weight:700!important}.selector-icon,#your-items-tree .icon,.friend-tree-comments-icon{background:url(http://www.globexdesigns.com/products/gr/greader/img/menu/icons.png) no-repeat!important}#star-selector .selector-icon{background-position:0 -2px!important}#your-items-tree .broadcast-icon{background-position:-3px -21px!important}#your-items-tree .created-icon{background-position:-4px -46px!important}#trends-selector .selector-icon{background-position:-2px -70px!important}.friend-tree-comments-icon{background-position:0 -94px!important;margin-left:-5px}.friend-icon{border:1px solid #363B42;height:14px!important;width:14px!important;margin:0 0 0 -4px}.friend-icon img{height:14px!important;width:14px!important;margin:0 0 0 -20px}.scroll-tree .unselectable a{margin:0 0 2px!important}#lhn-selectors .folder-toggle,#lhn-recommendations .folder-toggle{left:8px!important;top:8px!important;z-index:100}#friends-tree .suffix-node{color:#FB0!important;font-size:9px!important;font-weight:400!important;padding-left:3px!important}#friends-tree .friends-tree-item-action{height:auto!important;font-size:9px!important;font-weight:400!important;line-height:normal!important;-moz-border-radius:3px;right:2px!important;text-indent:0!important;padding:2px 5px!important}#friends-tree .friends-tree-invite-info,#friends-tree .friends-tree-notification-info{text-align:center;margin:-4px 0 2px!important}#friends-tree .friends-tree-invite-info .link,#friends-tree .friends-tree-notification-info .link,.friends-tree-following-info .link{padding:2px 8px!important}#friends-tree .friends-tree-invite-info span,#friends-tree .friends-tree-notification-info span{display:inline!important}#lhn-friends .friends-feeds-invite-info .link{background:transparent!important;border:0!important;color:#FB0!important;font-weight:700}#lhn-recommendations .lhn-section-footer{text-align:center;margin:-2px 0 3px!important}#recommendations-tree-view-all{padding:1px 6px 2px!important}#lhn-subscriptions{background:#40464F url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/block.gif) repeat-x 0 23px!important;border:2px solid!important;-moz-border-bottom-colors:#363B42 #6E7680;-moz-border-left-colors:#363B42 #6E7680;-moz-border-right-colors:#363B42 #6E7680;-moz-border-top-colors:#363B42 #6E7680;-moz-border-radius:8px;margin:0 8px!important}#lhn-subscriptions .lhn-section-primary{background:url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/button.gif) repeat-x!important;border-bottom:1px solid #6E7680;height:19px;line-height:18px;-moz-border-radius-topleft:6px;-moz-border-radius-topright:6px;margin:0!important;padding:0!important}#sub-tree-header{color:#FFF;display:block;font-weight:400!important;text-align:center;padding:0!important}#lhn-subscriptions .section-button{top:1px!important}#lhn-subscriptions .lhn-minimize{right:17px!important}#lhn-subscriptions .lhn-menubutton{right:2px!important}#lhn-subscriptions.lhn-section-minimized .lhn-section-primary{border:0;-moz-border-radius:6px}#sub-tree .link{background:#202328 url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/block-row.gif) repeat-x!important;border:0!important;border-top:1px solid #202328!important;height:18px;line-height:17px;-moz-border-radius:0;text-indent:20px;width:100%;margin:0!important}#sub-tree .link:hover,#sub-tree .link.cursor{background-color:#3B4149!important;background-position:0 -36px!important;border-top:1px solid #3B4149!important}#sub-tree .link:hover *{color:#E7E7E7!important}#sub-tree .tree-link-selected,#sub-tree .tree-link-selected:hover,#sub-tree .tree-link-selected.cursor{background:#0B0F0F url(http://www.globexdesigns.com/products/gr/greader/img/menu/subsel.gif) repeat-x!important;border-top:1px solid #202328!important;color:#FFF!important}.scroll-tree .toggle{left:4px!important;top:5px!important}.expanded .toggle,.collapsed .toggle,.bundle-container .bundle-show-details-link div{background:url(http://www.globexdesigns.com/products/gr/greader/img/menu/exp.gif) no-repeat!important;height:9px!important;width:9px!important}.collapsed .toggle,.bundle-container .goog-zippy-collapsed div{background-position:0 -9px!important}.bundle-container .bundle-show-details-toggle{margin:3px!important}.expanded .toggle:hover,.bundle-container .goog-zippy-expanded div:hover{background-position:-9px 0!important}.collapsed .toggle:hover,.bundle-container .goog-zippy-collapsed div:hover{background-position:-9px -9px!important}#lhn-subscriptions .scroll-tree span[class="icon sub-icon icon-d-2"],#lhn-subscriptions .scroll-tree span[class="icon folder-icon icon-d-1"],.bundle-feed-icon,#recommendations-tree .icon{background:url(http://www.globexdesigns.com/products/gr/greader/img/menu/folder-icons.png) no-repeat!important;height:0!important;left:16px!important;top:0!important;width:0!important;padding:18px 18px 0 0 !important}#lhn-subscriptions .scroll-tree .tag-icon{background-position:0 -1px!important}#lhn-subscriptions .scroll-tree .tree-selected .tag-icon{background-position:0 -19px!important}#lhn-subscriptions .scroll-tree .expanded .folder-icon,#recommendations-tree .expanded .folder-icon{background-position:-18px -1px!important}#lhn-subscriptions .scroll-tree .collapsed .folder-icon,#recommendations-tree .collapsed .folder-icon{background-position:-18px -19px!important}#lhn-subscriptions .scroll-tree span[class="icon sub-icon icon-d-2"],#recommendations-tree .sub-icon{background-position:-36px -1px!important}#lhn-subscriptions .scroll-tree .tree-link-selected span[class="icon sub-icon icon-d-2"]{background-position:-36px -19px!important}#sub-tree ul ul li a{text-indent:26px!important}#sub-tree-container .scroll-tree ul ul li .icon{left:20px!important}.tree-flying-item{background:red!important;color:#FFF!important;font-size:10px;-moz-border-radius:3px;text-decoration:none!important;padding:1px 6px 2px!important}#sub-tree .tree-drop-target-above{border-top:2px solid #202328!important}#sub-tree .tree-drop-target-below{border-bottom:2px solid #202328!important}#lhn-subscriptions .lhn-section-footer{background:#414750 url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/block-footer.gif) repeat-x!important;border-top:1px solid #3B4149!important;-moz-border-radius-bottomleft:8px;-moz-border-radius-bottomright:8px;height:23px;margin:0!important;padding:0!important}#lhn-subscriptions .lhn-section-footer a{color:#E9E9E9!important;display:block;text-align:center;text-shadow:#363B42 0 1px 1px}#chrome{border:0!important;margin-left:220px!important}#chrome-header{background:url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/button.gif) repeat-x!important;border:2px solid;color:#D7D7D7!important;margin-left:-1px!important;-moz-border-bottom-colors:#363B42 #6E7680;-moz-border-left-colors:#363B42 #6E7680;-moz-border-right-colors:#363B42 #6E7680;-moz-border-top-colors:#363B42 #6E7680;-moz-border-radius:3px;text-shadow:#363B42 0 1px 1px;padding:0 12px!important}#chrome-title a{color:#D7D7D7!important}#chrome-lhn-toggle{background:#363B42 url(http://www.globexdesigns.com/products/gr/greader/img/body/lhn-toggle.gif) repeat-y!important;border-left:1px solid #77808A!important;border-right:1px solid #77808A!important}#chrome-lhn-toggle-icon{background:url(http://www.globexdesigns.com/products/gr/greader/img/body/lhn-toggle-arrow.gif) no-repeat -3px 0;border:0!important;margin-left:3px!important;padding:5px 3px 0 0}#chrome-lhn-toggle:hover #chrome-lhn-toggle-icon{background-position:-9px 0}.lhn-hidden #chrome{margin-left:0!important}.lhn-hidden #chrome-lhn-toggle-icon{background-position:0 0}.lhn-hidden #chrome-lhn-toggle:hover #chrome-lhn-toggle-icon{background-position:-6px 0}.section-header,#recent-activity h4{border-bottom:1px solid #6E7680;color:#FB0;font-size:16px!important;font-weight:700!important;padding:0 0 10px!important}#overview{color:#FFF;font-size:11px;padding:6px 12px!important}#featured-bundles-promo{background:#353B42!important;border:1px solid #656B72!important;-moz-border-radius:4px}.overview-metadata,#team-messages-snippet,.recent-item{border-left:3px solid #6E7680;font-size:11px!important;padding-left:6px!important;margin:8px 0!important}.overview-metadata:hover{background:#6E7680;border:0;cursor:pointer;padding-left:9px!important;-moz-border-radius:6px}.overview-segment img{border:3px solid #6E7680;-moz-border-radius:4px;margin:0 10px 4px 0;padding:0!important}.item-title{color:#FFF!important;display:block;font-weight:700}.item-snippet,#team-messages-snippet{color:#BBB!important;line-height:150%}.info{color:#999;font-size:11px;margin:-3px 0 0!important}#overview .label{background:#363B42;color:#999!important;font-size:10px!important;-moz-border-radius:3px;padding:0 4px 1px}#rec-preview{padding:12px!important}#all-recs-link{color:#FFF!important;font-size:10px!important}#rec-preview .rec-preview-feed-title{color:#FFF!important;font-size:12px!important}#rec-preview .recommendation-preview-feed-summary{color:#BBB!important;font-size:11px;margin:-4px 0 0!important}#recent-activity h4{background:transparent!important;margin:0!important}.recent-item{color:#AAA}.recent-item .link{color:#FFF!important;display:block;font-size:12px;font-weight:700}.recent-stream-title{color:#FB0;font-style:normal!important}#overview-footer{margin:0 auto!important}#footer{color:#DDD;font-size:11px;border-color:#6E7680!important}#chrome-view-links{background:transparent!important;font-size:0;margin:-10px 0 0!important}#chrome-view-links span.link,#chrome-view-links span.link-selected{background-image:url(http://www.globexdesigns.com/products/gr/greader/img/body/mode.gif)!important;background-repeat:repeat-x!important}#chrome-view-links span.link{background-color:#373C41!important;background-position:0 -25px!important;border:2px solid!important;color:#A8A8A8!important;font-size:11px;-moz-border-bottom-colors:#31353B #666C75;-moz-border-left-colors:#31353B #666C75;-moz-border-right-colors:#31353B #666C75;-moz-border-top-colors:#31353B #666C75;-moz-border-radius:4px;margin:0 0 0 4px !important;padding:1px 6px 3px!important}#chrome-view-links span.link:hover,#chrome-view-links span.link-selected{color:#FFF!important;-moz-border-bottom-colors:#373C43 #A6AEB9;-moz-border-left-colors:#373C43 #A6AEB9;-moz-border-right-colors:#373C43 #A6AEB9;-moz-border-top-colors:#373C43 #A6AEB9}#chrome-view-links span.link-selected{background-color:#434A53!important;background-position:0 0!important}#viewer-top-controls,#viewer-footer{background:transparent url(http://www.globexdesigns.com/products/gr/gmail/img/inbox/sel.gif) repeat-x!important;border:0!important;color:#D7D7D7;font-size:11px;font-weight:700;padding:1px 8px!important}#viewer-all-new-links,#viewer-comments-all-links,#viewer-allcomments-return{text-shadow:#363B42 0 1px 1px;margin:-3px 8px 0 0 !important}#viewer-top-controls .link{border:0!important;color:#A6AEB9!important;font-weight:400;text-shadow:#363B42 0 1px 1px}#viewer-top-controls .link-selected:hover{color:#A6AEB9!important}#viewer-details-toggle,#viewer-allcomments-toggle{line-height:normal!important;padding-top:1px}#viewer-translated-by{margin-top:-3px!important}#entries-status{color:#D7D7D7!important;top:-1px!important}#viewer-header .goog-button-base-content,#viewer-footer .goog-button-base-content{background:url(http://www.globexdesigns.com/products/gr/gmail/img/inbox/sel-b.gif) repeat-x!important;border:1px solid #69727B!important;color:#9DA5AD!important;font-size:11px;font-weight:400;height:auto;line-height:normal!important;-moz-border-radius:4px;margin:-1px 1px 0 0 !important;padding:1px 6px 2px!important}#viewer-header .goog-button-base-content:hover,#viewer-footer .goog-button-base-content:hover{background-position:bottom!important;color:#FFF!important;border-color:#C0C2C6!important}#viewer-footer .goog-button-base-content{margin:0 1px 1px 0 !important}#viewer-header .goog-button-base-inner-box,#viewer-header .goog-button-base-outer-box,#viewer-footer .goog-button-base-inner-box,#viewer-footer .goog-button-base-outer-box{border:0!important}#mark-all-as-read .goog-button-base-content{border-right:0!important;-moz-border-radius:4px 0 0 4px}#mark-all-as-read-options .goog-button-base-content{-moz-border-radius:0 4px 4px 0;border-left:1px solid #39424B!important;margin-left:-1px!important}#mark-all-as-read-options .goog-button-base-content:hover{border-left:1px solid #39424B!important}#mark-all-as-read-options .goog-menu-button-dropdown{background:url(http://www.globexdesigns.com/products/gr/gmail/img/icons/arrows.gif) no-repeat -2px -3px!important;border:0!important;display:block!important;height:3px!important;top:7px!important;width:6px!important}.entry .card{border:0!important;-moz-border-radius:0!important;-moz-box-shadow:none!important}#entries.list .entry{border-bottom:0!important;border-top:1px solid #6A767E!important;font-size:11px}#entries.list .entry .collapsed{background-image:url(http://www.globexdesigns.com/products/gr/gmail/img/inbox/rows.gif)!important;background-repeat:repeat-x!important;border:0!important;background-color:#CBDAF1!important;background-position:left -42px!important;padding:4px 0!important}#entries.list .read .collapsed{background-color:#F4F7FB!important;background-position:top left!important;opacity:1.0!important}#entries.list .entry .collapsed:hover{background-color:#ECEC63!important;background-position:left -84px!important}#entries.list #current-entry .collapsed{background-color:#B3D2B7!important;background-position:left -126px!important}#entries.list #current-entry .entry-container{border-top:1px solid #6A767E!important}#entries.list .collapsed .entry-icons{top:2px!important;padding:0 2px!important}.star{background:url(http://www.globexdesigns.com/products/gr/gmail/img/inbox/stars.png) no-repeat 0 -1px!important;border-bottom:0!important;height:17px!important;width:17px!important}.entry-profile-image-container{margin-top:-4px!important}.item-star-active{background-position:0 -23px!important}.search-result .entry-original,#entries .collapsed .entry-original,.entry .entry-title .entry-title-go-to{background:url(http://www.globexdesigns.com/products/gr/greader/img/body/link.png) no-repeat!important;height:17px!important;width:17px!important}.search-result .entry-original:hover,#entries .collapsed .entry-original:hover,.entry .entry-title .entry-title-go-to:hover{background-position:top right!important}#entries.list .entry-main > img{left:22px!important}#entries.list .entry-secondary{bottom:2px;line-height:normal!important;padding:0!important}#entries.list .entry-title{line-height:16px}#entries.list .collapsed .entry-main .entry-source-title{border:0!important;color:#414750!important;font-weight:700!important;padding-left:6px!important;top:4px!important}#entries.list .collapsed .entry-secondary-snippet{color:#748296!important;font-size:10px;line-height:14px}#viewer-details{background:#FFF url(http://www.globexdesigns.com/products/gr/gmail/img/email/bg.gif) repeat-x 0 -4px!important;border:0!important;padding:6px!important}.viewer-details-url{font-weight:700}.viewer-details-url a{color:#24B!important;font-weight:400}.viewer-details-url a:hover{color:#000!important}#entries.list #current-entry.expanded{border:0!important;border-top:1px solid #6A767E!important}#entries.cards #current-entry .entry-container{margin-top:-1px!important}#entries.cards #current-entry .card-actions{padding-left:1px!important}.entry-actions{background:#E9E9E9 url(http://www.globexdesigns.com/products/gr/gmail/img/email/header.gif) repeat-x 0 -33px!important;border:0!important;border-top:1px solid #6A767E!important;font-size:11px!important;height:20px;padding:0!important}.entry-actions > span{display:block;float:left;height:20px;line-height:20px;margin:0 0 0 4px;padding:0 0 0 22px !important}#entries .entry-actions span:hover{color:#111!important}.entry-actions .star{font-size:0;margin-top:1px!important;padding:0!important}.entry .entry-actions .email{padding-left:23px!important;padding-right:11px!important}.entry .entry-actions .email-active{background-color:#DDD!important;border-left:1px solid #6A767E;border-right:1px solid #6A767E;padding-left:22px!important;padding-right:10px!important}#entries.list #current-entry.action-area-visible .action-area{background:#FFF url(http://www.globexdesigns.com/products/gr/gmail/img/email/bg.gif) repeat-x 0 -4px!important;border-bottom:2px solid #6A767E!important;border-top:1px solid #6A767E!important}.email-this-buttons .goog-button{margin-right:2px!important}#entries .user-tags-list a{background:#444;color:#FFF!important;font-size:10px;-moz-border-radius:3px;padding:2px 4px}#entries .user-tags-list a:hover{background:#222}#no-entries-msg,.entry-container,.interruption,.friend-interruption .iframe-container,.style-chooser,#trends,#discover-container,.bundle-container,#search-tab-contents,#recommendations-tab-contents,.bundle-creator-page,#directory-search-results,.comment-entry,#followers-tab-contents,#following-tab-contents,#friends-manager,.setting-body,#full-bundles-container,#chrome.search-stream #entries.search .entry,#friends-tab-contents{background:#FFF url(http://www.globexdesigns.com/products/gr/gmail/img/email/bg.gif) repeat-x 0 -4px!important;border:0!important;padding:15px 25px!important}.interruption,.setting-body{-moz-border-radius:8px}.card-content .entry-container,#chrome.search-stream #entries.search .entry{-moz-border-radius:6px 6px 0 0!important}#entries.cards #current-entry .card{border:2px solid #FB0!important;-moz-border-radius:8px!important;margin:-1px 8px!important}.user-tags-list{float:right;list-style:none}#chrome.search-stream #entries.search .entry{margin:8px!important}#chrome.search-stream #entries.search .star{margin-top:8px!important}#interrupt-friend .title-container,.title-container .text{margin:0 0 4px!important}#interrupt-friend .tag-instructions{color:#666!important;display:block;font-size:11px!important;margin:-1px 0 0}.friend-interruption .iframe-container,.style-chooser{border:2px solid!important;-moz-border-bottom-colors:#ACACAC #FFF;-moz-border-left-colors:#ACACAC #FFF;-moz-border-right-colors:#ACACAC #FFF;-moz-border-top-colors:#ACACAC #FFF;-moz-border-radius:8px;padding:8px!important}#no-entries-msg h2{color:#414750;font-size:16px}.created-no-title .entry-body,.created-no-title .entry-snippet{background-position:8px 7px!important;border:1px solid #DDD!important;-moz-border-radius:8px;padding-left:30px!important}#full-bundles-container{overflow:auto}.tab-header{background:url(http://www.globexdesigns.com/products/gr/gmail/img/sidebar/button.gif) repeat-x!important;border:1px solid #111;border-bottom:0;color:#DDD!important;font-size:11px;-moz-border-radius-topleft:4px;-moz-border-radius-topright:4px;text-decoration:none!important;margin:0 1px 0 0 !important;padding:3px 10px!important}.tab-header:hover{opacity:0.7}#trends h2{color:#333;font-size:16px;margin:8px 0!important}#trends .explanation{color:#666!important;font-size:11px!important}.tab-group-contents{background:transparent!important;border:1px solid #424851;-moz-border-radius:0 4px 4px;padding:0!important}.tab-group-contents .label{color:#333!important;font-size:11px!important}.color-box{-moz-border-radius:3px}.sorting th{font-size:12px}#directory-box{width:auto!important;padding:8px!important}#import-prompt{color:#FFF;font-size:11px!important;padding:0!important}#discover-container,#search-tab-contents,#recommendations-tab-contents{-moz-border-radius:0 4px 4px}#discover-container h3{color:#333!important;border:0!important}.bundle-container{border:1px solid #6E7680!important;display:block;height:auto!important;-moz-border-radius:6px;padding:4px!important}.subscribe .goog-button{float:right}#bundle-desc{width:250px!important;margin:4px 0 0!important}#bundle-creator-delete-target{color:#DDD!important;font-size:11px!important}.bundle-creator-add-shared-area{color:#FFF!important;font-size:11px}.bundle-creator-button-area .goog-button{margin:2px 2px 0 0 !important}.bundle-feed-icon{background-position:-36px -1px!important;margin:0 0 0 -12px}#service-quickadd-form .discover-search-box,#directory-saved-searches-form .discover-search-box{margin:5px 4px 0 0 !important}#service-quickadd-button,#directory-saved-searches-button{margin:5px 0 0!important}.entry-comments .goog-button{margin:0 2px 0 0 !important}#followers-tab-contents,#following-tab-contents{padding:6px!important}#friends-manager .intro-text{width:100%!important}#settings-frame{top:82px!important}#settings{padding:0 6px!important}#settings #header,#settings-navigation{float:left;width:auto!important}#settings-navigation{border:2px solid!important;-moz-border-bottom-colors:#363B42 #6E7680;-moz-border-left-colors:#363B42 #6E7680;-moz-border-right-colors:#363B42 #6E7680;-moz-border-top-colors:#363B42 #6E7680;-moz-border-radius:4px;margin:6px 0 0 6px !important}#close-settings-link,.setting-group-title{background:url(http://www.globexdesigns.com/products/gr/gmail/img/inbox/button.gif) repeat-x!important}.setting-group-title{border:0!important;border-left:1px solid #6E7680!important;border-right:1px solid #363B42!important;-moz-border-radius:0;-moz-border-left-colors:#6E7680;margin:0!important}#settings-navigation .setting-group-title:last-child{border-right:0!important}.setting-group-title:hover{-moz-border-left-colors:#6E7680}.setting-group-title.selected{background-position:bottom!important}.settings-list{font-size:10px;margin:38px 0 0!important}#locale{padding:1px 4px 0!important}#setting-extras .extra,#settings #subscriptions .feed-row td,.setting-import{border-bottom:1px solid #566068!important}.folder-chooser-contents .chooser-item{text-indent:10px!important}.folder-chooser-contents .chooser-item-selected{background-position:3px 4px!important;cursor:default!important}#subscriptions .folder-chooser{margin-top:3px!important}#subscriptions .labels{margin-bottom:3px!important}#subscriptions .title{font-size:14px}#sidebar{background:#363B42;-moz-border-radius:8px}.item{color:#FFF;font-size:90%}.vcard{padding-bottom:3px!important}.ll_profilephoto{border:2px solid #DDD!important;-moz-border-radius:3px}a,.link,.public-link,.profile-link,.result-title,a{color:#2A5DB0!important;text-decoration:none!important}a:hover,.link:hover,.public-link:hover,.profile-link:hover,.result-title:hover,a:focus,.link:focus,.public-link:focus,.profile-link:focus,.result-title:focus,.entry-date,.entry-title,#entries .entry-actions span,a:hover,.link:hover{color:#414750!important}#home .link,#home a,#footer a,.fr-modal-dialog .link,.instruction a,.pc_fl a,.pc_card a{color:#FB0!important;text-decoration:none!important}.goog-button:hover .goog-button-base-content,#friends-tree .friends-tree-item-action:hover,button:hover,#close-settings-link:hover,.setting-group-title:hover,#recommendations-tree-view-all:hover,.goog-button:focus .goog-button-base-content,button:focus,#close-settings-link:focus,.setting-group-title:focus,#recommendations-tree-view-all:focus{background-position:bottom!important;color:#FFF!important}#search-restrict-button .goog-button-base-outer-box,#search-submit .goog-button-base-outer-box,.button-publish .goog-button-base-outer-box,.bookmarklet-link,#discover-table .goog-button-base-outer-box,#directory-search-button .goog-button-base-outer-box,#service-quickadd-button .goog-button-base-outer-box,#directory-saved-searches-button .goog-button-base-outer-box,#recommendations-tab-contents .goog-button-base-outer-box,#directory-search-results .goog-button-base-outer-box,.entry-comments .goog-button-base-outer-box,.friend-display-toggle .goog-button-base-outer-box,#profile-search-button .goog-button-base-outer-box,.subs-unsubscribe,.folder-chooser .goog-button-base-outer-box,.labels-delete,.email-this-buttons .goog-button-base-outer-box,.preview-interruption .goog-button-base-outer-box,#search-input{-moz-border-bottom-colors:#ACACAC #FFF!important;-moz-border-left-colors:#ACACAC #FFF!important;-moz-border-right-colors:#ACACAC #FFF!important;-moz-border-top-colors:#ACACAC #FFF!important}#search-restrict-button .goog-button-base-outer-box:focus,#search-restrict-button .goog-button-base-outer-box:hover,#search-submit .goog-button-base-outer-box:focus,#search-submit .goog-button-base-outer-box:hover,.button-publish .goog-button-base-outer-box:hover,.button-publish .goog-button-base-outer-box:focus,.bookmarklet-link:hover,.bookmarklet-link:focus,#discover-table .goog-button-base-outer-box:hover,#discover-table .goog-button-base-outer-box:focus,#directory-search-button .goog-button-base-outer-box:hover,#directory-search-button .goog-button-base-outer-box:focus,#service-quickadd-button .goog-button-base-outer-box:hover,#service-quickadd-button .goog-button-base-outer-box:focus,#directory-saved-searches-button .goog-button-base-outer-box:hover,#directory-saved-searches-button .goog-button-base-outer-box:focus,#recommendations-tab-contents .goog-button-base-outer-box:hover,#recommendations-tab-contents .goog-button-base-outer-box:focus,#directory-search-results .goog-button-base-outer-box:hover,#directory-search-results .goog-button-base-outer-box:focus,.entry-comments .goog-button-base-outer-box:hover,.entry-comments .goog-button-base-outer-box:focus,.friend-display-toggle .goog-button-base-outer-box:hover,.friend-display-toggle .goog-button-base-outer-box:focus,#profile-search-button .goog-button-base-outer-box:hover,#profile-search-button .goog-button-base-outer-box:focus,.subs-unsubscribe:hover,.subs-unsubscribe:focus,.folder-chooser .goog-button-base-outer-box:hover,.folder-chooser .goog-button-base-outer-box:focus,.labels-delete:hover,.labels-delete:focus,.email-this-buttons .goog-button-base-outer-box:hover,.email-this-buttons .goog-button-base-outer-box:focus,.preview-interruption .goog-button-base-outer-box:hover,.preview-interruption .goog-button-base-outer-box:focus,#search-input:hover{-moz-border-bottom-colors:#8C8C8C #FFF!important;-moz-border-left-colors:#8C8C8C #FFF!important;-moz-border-right-colors:#8C8C8C #FFF!important;-moz-border-top-colors:#8C8C8C #FFF!important}.button-publish .goog-button-base-content,#profile-search-button .goog-button-base-content,#directory-saved-searches-button .goog-button-base-content{line-height:18px!important}#search-restrict-button:focus .goog-button-base-content,#search-submit:focus .goog-button-base-content,.button-publish .goog-button-base-content:focus,#discover-table .goog-button-base-content:focus,#directory-search-button .goog-button-base-content:focus,#service-quickadd-button .goog-button-base-content:focus,#directory-saved-searches-button .goog-button-base-content:focus,#recommendations-tab-contents .goog-button-base-content:focus,#directory-search-results .goog-button-base-content:focus,.entry-comments .goog-button-base-content:focus,.friend-display-toggle .goog-button-base-content:focus,#profile-search-button .goog-button-base-content:focus,.subs-unsubscribe:focus,.folder-chooser .goog-button-base-content:focus,.labels-delete:focus,.email-this-buttons .goog-button-base-content:focus,.preview-interruption .goog-button-base-content:focus,input[type=text]:focus,#search-restrict-input:focus,select:focus{background-position:bottom!important;color:#202020!important}#chrome-title,#trends-item-count-header{font-size:12px!important}#overview .title,#name .large{font-size:14px!important}#overview .label-link,#entries.list .read .collapsed .entry-main .entry-source-title{font-weight:400!important}#recent-activity,#tips,#bundle-meta-info{padding:10px!important}#tips,#interrupt-friend .posting-form-layout label,#interrupt-friend .posting-form-layout .link,.posting-form-layout label,.posting-form-layout .link,.sorting td{font-size:11px}.entry-container,#settings-navigation .setting-group-title:first-child{border-left:0!important}.entry-title-go-to,#directory-search-button{margin:0 0 0 4px !important}.gbh,div.gb2,.message-area-bottom-1,.message-area-bottom-2,.message-area-bottom-3,.goog-button-base-top-shadow,#sub-tree-refreshing,#scour-menu-container-shadow,#scour-menu-container .s,#settings .s,#settings #header h2,#viewer-top-controls .goog-menu-button-dropdown,.subscribed .goog-menu-button-dropdown,.folder-chooser .goog-menu-button-dropdown,#chrome-lhn-menu .goog-menu-button-dropdown,.scour #search *,.settings #search *{display:none!important}#scour-menu-contents,.fr-modal-dialog-content,.fr-modal-dialog-title,.friends-feeds-invite-info,.pc_fl,.label span b,#single-item-bottom-links,.bundle-item{color:#FFF}.progress-bar-header,.progress-bar-label,.friends-feeds-invite-info,.text,#talk_status{font-size:11px!important}#scour-menu-contents,.fr-modal-dialog-content,.fr-modal-dialog-title,#viewer-details .tab-group,#friends-manager{padding:8px!important}#stream-folder-chooser:hover,#entries .entry,.card-common,.tab-contents,.bundle-container th{background:transparent!important}.goog-menuitem-disabled,#entries.cards .entry.read .entry-title-link{opacity:0.6}#quick-add-instructions,#quick-add-helptext,.single-feed-menu-item .goog-button-body,.friends-dialog-title .instruction,.friend-name .email,#overview .title a:hover,#recent-activity h4 a:hover,#all-recs-link:hover,#rec-preview .rec-preview-feed-title:hover,.recent-item .link:hover{color:#DDD!important}#gbar a:hover,#gbar a:focus,#guser a:hover,#guser a:focus,.lhn-section .link:hover *,.lhn-section .selected a:hover *,.scroll-tree li .tree-link-selected:hover *,#friends-settings-link.selected:hover *,#lhn-friends .friends-feeds-invite-info .link:hover,#sub-tree .tree-link-selected:hover *,#home .link:hover,#home a:hover,#home .link:focus,#home a:focus,.pc_fl a:hover,.pc_fl a:focus,.fr-modal-dialog .link:hover,.fr-modal-dialog .link:focus,#footer a:hover,#entries #scroll-filler-see-recommendations:hover,#single-item-bottom-links p a:hover,#single-item-bottom-links p .link:hover,#footer a:focus,#entries #scroll-filler-see-recommendations:focus,#single-item-bottom-links p a:focus,#single-item-bottom-links p .link:focus,.instruction a:hover,.instruction a:focus,#lhn-subscriptions .lhn-section-footer a:hover,#chrome-title a:hover,#chrome-title .chevron:hover,#overview .title a,#recent-activity h4 a,#tips p,#overview .label-link:hover,#overview a:hover,.recent-stream-title:hover,#footer a:hover,#viewer-top-controls .link:hover,.tab-header-selected,.pc_card a:hover,.pc_card div{color:#FFF!important}b.gb1,.lhn-section .unread-count,.lhn-section a:hover .unread-count,#sub-tree li a .unread-count,#sub-tree .folder .link:hover .unread-count,#sub-tree .folder .tree-link-selected:hover .unread-count,#chrome-title .chevron{color:#FB0!important}#is-syncing,.section-minimized .section-minimize:hover{background-position:0 -11px!important}.gbm .gb2,.entry-main{margin:0!important}#loading-area-text,.info-message #message-area-inner,.progress-message #message-area-inner,.friends-tree-following-info{color:#FFF;font-size:11px}.message-area-text-container,.ll_photobox{overflow:visible!important}#quick-add-close:hover,.close-box:hover,.fr-modal-dialog-title-close:hover,.tab-header-selected:hover{opacity:1.0}#lhn-selectors #your-items-tree-container,.lhn-section-minimized .lhn-section-primary{padding:0!important}';
	GM_addStyle(css, 'rps_redesigned');
};//Glass BlackGold
//Author: Ghis1964
//http://userstyles.org/styles/26569
GRP.glassblackgold = function() {
	//a lot of changes to work under chrome
	//-moz ->webkit + strecteched image using css3 background-size:100%
	//still needs a lot of clean up
	var css = 'body{background:url(http://i40.tinypic.com/161ksk.jpg)no-repeat fixed top center!important;background-size:100%!important;color:#aaa!important;border:0!important}#gbar a,#gbar a:visited,#guser a,#guser a:visited{color:#AAA!important}#logo{display:none}[id=gbar],[id=guser],.text,.gbh,#explore-promo,#tips,#overview-footer,[class=viewer-page],#lhn-selectors .selector:hover,[id=quick-add-success],.friend-interruption,#directory-box .tab-group,#directory-box .tab-contents,#directory-contents .tab-header,.tab-group-contents,#featured-bundles-container,#discover-table td,.bundle-container th,#friends-tree .friends-tree-following-info,#directory-welcome-conversion,.date-tooltip td,.date-tooltip,.text-tooltip,.text-tooltip td,[target=_blank]{color:#aaa!important;border:0!important}#current-entry.read .entry-container .entry-body,.read .entry-container .entry-body,#overview .item-snippet,#team-messages .body,#overview .label,p,dl,multicol,.overview-item-link,address,blockquote,body,caption,center,col,colgroup,dd,dir,div,dl,dt,fieldset,form,h1,h2,h3,h4,h5,h6,hr,html,isindex,li,listing,map,marquee,menu,noframes,ol,p,plaintext,pre,table,tbody,td,tfoot,th,thead,tr,ul,xmp{color:#aaa!important}#recent-activity #recent-activity-kept-unread h4,#recent-activity #recent-activity-read h4,#explore-promo-new,#recent-activity .recent-stream-title{color:#dfdfdf!important}a,.link,.lhn-section,.scroll-tree li,#chrome-header,#viewer-header,#viewer-footer,[id=chrome],.card-common,span.name-text,.name{background:transparent!important;color:#aaa!important;border:0!important}.card-common,[id=chrome-view-links]{-webkit-border-radius:3px 3px 3px 3px!important;-webkit-box-shadow:1px 1px 2em 2px #000!important;border-width:0!important}.card-content{-webkit-border-radius:3px 3px 3px 3px!important;-webkit-box-shadow:0 0 2em 2px #000!important}.scroll-tree{-webkit-border-radius:7px 7px 7px 7px!important;-webkit-box-shadow:inset 1px 1px 2em 2px #000!important}tr{-webkit-border-radius:7px 7px 7px 7px!important;-webkit-box-shadow:inset 0 0 3em 3px #999!important}.posting-form .textarea{-webkit-border-radius:7px 7px 7px 7px!important;-webkit-box-shadow:inset 0 0 1em 1px #000!important;border-width:0!important;margin:3px!important}#entries .entry,#entries.list .entry-container,[id=current-entry],#no-entries-msg,.interruption{-webkit-border-radius:3px 3px 3px 3px!important;-webkit-box-shadow:inset 0 0 2em 4px #999!important}[id=viewer-top-controls],.email-entry-table,.field-name,.email-this-area,#current-entry .card .action-area,.action-area .email-this-area,#quick-add-bubble-holder,#setting-extras .extra,#settings #settings-navigation .selected,#settings .settings-list .setting-body,#settings .settings-list .setting-body td,.setting-import,#footer,.hover-form,[class=" fr-modal-dialog fr-dialog-with-close"],[class=" fr-modal-dialog-buttons"],[id=:a0],[id=:a1],[class=f],[class="fr-clips-dialog fr-modal-dialog fr-dialog-with-close"],[id=main-clip-creator],.fr-modal-dialog-buttons,h3,[id=publisher-preview-container],[id=publisher-preview],[id=readerpublishermodule0],[class=i],[id=publisher-blogger-widget],[id=publisher-snippet],.fr-modal-dialog-title,[class=" fr-modal-dialog-title  fr-modal-dialog-title-draggable"],[style="margin: 0.5em; padding: 0pt; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 1px solid rgb(188, 204, 235); text-align: left; text-indent: 0pt; text-decoration: none; font-weight: normal; font-family: arial,sans-serif; font-size: 10pt;"],#header,#main,#main2,[class="fr-confirm-dialog fr-modal-dialog"],#no-entries-msg,.friend-interruption,.interruption,#featured-bundles-container,#discover-table td,.bundle-container,.bundle-container th,.bundles-list,p,#trends .sorting td,#trends .trends-columns td,[class=top-links],[class=sorting-empty],#chrome.page-view,#viewer-page-container,#friends-manager h2,#friends-manager .style-chooser,*|:-webkit-any-link img,img[usemap],object[usemap],.preview-interruption-related-streams,[class="goog-button-base-outer-box goog-inline-block"],[class="goog-button-base-inner-box goog-inline-block"],.goog-button-body,.fr-modal-dialog{border-width:0!important}#search-input,#search-restrict-input{-webkit-border-radius:3px 3px 3px 3px!important}#stream-prefs-menu-menu,.webkit .goog-menu,.gecko191 .goog-menu,.hover-form{-webkit-border-radius:3px 3px 3px 3px!important;-webkit-box-shadow:0 0 2em 6px #999!important}.entry .entry-actions{direction:ltr;font-size:100%!important;height:14px!important;-webkit-border-radius:3px 3px 3px 3px!important;-webkit-box-shadow:inset 0 0 .4em 1px #000!important;margin:-2px!important;padding:4px 7px .5em!important}#trends .tab-header{-webkit-border-radius:3px 3px 3px 3px!important;-webkit-box-shadow:inset 0 0 1em 2px #999!important}.entry,.card-content,#entries .entry{-webkit-box-shadow:0 0 1em 1px #000!important}#search-restrict-input{width:110px!important;height:20px!important}a:hover,span.name-text:hover,span.link:hover,span.item-star:hover,#sub-tree-header:hover,#viewer-all-new-links .link:hover,.name-unread{color:#cfcfcf!important}.bookmarklet,.bookmarklet-container .bookmarklet-callout-inner{-webkit-border-radius:8px 8px 8px 8px;background-color:rgba(20,20,20,.4)!important;padding:5px}[id=blue],[class=blue],[color=blue],[value=blue]{color:#aaa!important;border-width:0!important}#bundle-creation-area .drag-over{border-color:#aaa!important;border-style:solid;border-width:0!important}#entries.list .read .collapsed{margin:-2px!important}.subscribe-button{-webkit-border-radius:2px 2px 2px 2px!important;-webkit-box-shadow:0 0 .4em 1px #000!important}#search-input{-webkit-border-radius:7px 7px 7px 7px!important;-webkit-box-shadow:0 0 .4em 4px #999!important}[class=" fr-modal-dialog fr-dialog-with-close"],[id=:a1],[id=quick-add-success],[class="fr-clips-dialog fr-modal-dialog-title fr-clips-dialog fr-modal-dialog-title-draggable"],[class="fr-clips-dialog fr-modal-dialog fr-dialog-with-close"],[class="fr-confirm-dialog fr-modal-dialog"]{color:#aaa!important;-webkit-border-radius:4px 4px 4px 4px!important;-webkit-box-shadow:0 0 .2em 6px #999!important;margin:-3px!important}select > option{-webkit-padding-end:5px;-webkit-padding-start:3px;padding-bottom:0;padding-top:0}option{-webkit-user-select:none;display:block;float:none!important;line-height:normal!important;min-height:1em;position:static!important;text-indent:0;white-space:nowrap!important;word-wrap:normal!important}.read .entry-container .entry-title a,.read .entry-container a.entry-source-title,.read .entry-container .entry-body a,.read .entry-container a.entry-post-author-name{color:#b1b1b1!important}.read .entry-container .entry-title a:hover,.read .entry-container a.entry-source-title:hover,.read .entry-container .entry-body a:hover,.read .entry-container a.entry-post-author-name:hover,:-webkit-any-link:hover{color:#CFCFCF!important}.goog-menu-button:hover .goog-menu-button-dropdown,.goog-menu-button.goog-button-base:focus .goog-menu-button-dropdown,#entries.list .read .collapsed,#setting-extras .extra,.no-chrome,#settings #settings-navigation .selected,#entries,#settings .settings-list .setting-body,#settings .round-box td,[id=message-area-inner],[class=message-area-text],[id=message-area-outer],[class="message-area-inner message-area-text-container"],[class=message-area],h3,[class=f],[class="message-area hidden"],[id=loading-area],.message-area-text-container,[class=offscreen],.hover-form,[class=i],[style="-webkit-user-select: none; visibility: visible; left: 675px; top: 1075.27px;"],[class=" fr-modal-dialog-content"],[id=:a0],[style="margin-left: -27px; width: 64px;"],[class=" fr-modal-dialog fr-dialog-with-close"],[class=" fr-modal-dialog-buttons"],[class="fr-clips-dialog fr-modal-dialog-content"],[class="fr-clips-dialog fr-modal-dialog fr-dialog-with-close"],[id=:a1],[id=main-clip-creator],.fr-modal-dialog-buttons,[id=publisher-preview-container],[id=publisher-preview],[id=readerpublishermodule0],[id=publisher-title],[class="fr-clips-dialog fr-modal-dialog-title fr-clips-dialog fr-modal-dialog-title-draggable"],[style="margin: 0.5em; padding: 0pt; background: none repeat scroll 0% 0% rgb(255, 255, 255); border: 1px solid rgb(188, 204, 235); text-align: left; text-indent: 0pt; text-decoration: none; font-weight: normal; font-family: arial,sans-serif; font-size: 10pt;"],[class="message-area-inner message-area-bottom"],[class="message-area-inner message-area-bottom-1"],[class="message-area-inner message-area-bottom-2"],[class="message-area-inner message-area-bottom-3"],[class="message-area-inner message-area-bottom-4"],[class="message-area-inner message-area-bottom-5"],[class="message-area-inner message-area-bottom-6"],[class="message-area-inner message-area-bottom-7"],[class="message-area-inner message-area-bottom-8"],[class="message-area-inner message-area-bottom-9"],[class="message-area-inner message-area-bottom-10"],[class="message-area-inner message-area-bottom-11"],.message-area-inner message-area,[type=text/javascript],[class=" fr-modal-dialog-title  fr-modal-dialog-title-draggable"],#header,#main,#main2,[class="fr-confirm-dialog fr-modal-dialog"],[class="fr-confirm-dialog fr-modal-dialog-content"],[class=secondary],[class=link],[class="selector selected"],[id=reading-list-selector],[href=#overview-page],#trends .tab-header,.small-interruption,.preview-interruption,.preview-interruption-related-streams,.fr-modal-dialog-content,.fr-modal-dialog-bg,[id=:3k],option,option:checked,select > option,[id=subs-label-selector]{background-color:transparent!important;color:#aaa!important}#viewer-container,.entry,.card-actions,.collapsed,.entry-container,.entry-actions,.scroll-tree li a.menu-open:hover,a:hover .tree-item-action-container,.section-button,.section-menubutton,[id=message-area-inner],[class=message-area-text],[id=message-area-outer],[class="message-area hidden"] [class="message-area-inner message-area-text-container"],[id=loading-area],#loading,#no-entries-msg,.message-area-text-container,[class=offscreen],[style="margin-left: -27px; width: 64px;"],.hover-form{background-color:transparent!important}';
	css +='#chrome-view-links,#lhn-selectors .selected,#lhn-selectors .selected:hover{background-color: transparent !important;}'; 
 	GM_addStyle(css, 'rps_glassblackgold');
};//nativecompact
GRP.nativecompact = function() {
	var css = "#search{top:0px;left:500px;}#logo-container{display:none;}#main{top:24px;}#chrome-header,#viewer-top-controls{padding:0px;}#lhn-add-subscription-section{position: absolute;left: 330px;top: -26px;z-index: 9;}";
	var el = getFirstElementByClassName(get_id('lhn-add-subscription-section'), 'subscribe-button');
	if (el){
		el.innerText='';
	}
	GM_addStyle(css, 'rps_nativecompact');
	fireResize();
};/**
 * Google Reader - Colorful List View
 * @version  1.6
 * @date 2010-02-27 
 *
 * Colorizes the item headers in Google Reader list view and the entries in expanded view.
 *
 * Original author :
 * kepp
 * http://userscripts.org/scripts/show/8782
 */
GRP.colorful = function(prefs, langs, ID, SL, lang){    
    const BASE_CSS = "#entries.list .entry-likers,#entries.list .collapsed .entry-source-title,#entries.list .collapsed .entry-secondary,#entries.list .collapsed .entry-title{background-color:transparent!important}.gm-color-lv .collapsed /* list view headers */{border-color:transparent!important}#entries.list.gm-color-lv #current-entry .collapsed{border:2px solid #8181DC!important}#entries.list.gm-color-lv #current-entry.expanded .collapsed{border-bottom-color:transparent!important;border-width:2px 0!important}#entries .entry{padding:5px 0}#entries.list .collapsed{line-height:2.4ex!important}";
	
    // controls and applies colors
    var theme = 
    {
        colors: {}, 
        prefs: "", 
        bgColor: null, 
        textColor: null,
        styles: null, 
        init: function(chrome, settings){
            //this.styles = GM_addStyle("", 'colorful');
            this.prefs = settings; //settings.getColorPrefs();
            
            var setup = this.setup, thm = this;
            var set = function(){
                setup.call(thm);
                chrome.removeEventListener("DOMNodeInserted", set, false);
            };
            chrome.addEventListener("DOMNodeInserted", set, false);
        },
        
        setup: function(){ 
            this.initConfig(); 
            var entries = get_id("entries");
			
            if (entries) {
                addClass(entries, this.prefs);
                entries.addEventListener("DOMNodeInserted", bind(this.processEntries, this), false);
				this.processEntries();
            }
			
			if (prefs.colorful_tree){
				var root = get_id("sub-tree");
				addClass(root, this.prefs);
				initCatchSidebars(bind(this.processNodes, this), 'sidebar-colorful');
			}
        },
        
        // determine what color theme to use by looking at the header colors
        initConfig: function(){
            var bg, color;
			var header = get_id("chrome-header");
			if (prefs.colorful_usebasecolor) {
				bg = (prefs.colorful_background||'').toLowerCase();
			} else {
				bg = getComputedStyle(header, null).getPropertyValue("background-color");
			}
            
            bg = this.rgbToHsl(bg);
            
            // a min saturation & lightness is needed to distinguish colors
            // note: value is further subtracted from this for read items
            this.bgColor = 
            {
                hue: bg[0],
                sat: Math.max(bg[1], 35),
                lt: Math.max(bg[2], 32)
            };
            
			if (prefs.colorful_usebasecolor) {
				color = (prefs.colorful_color||'').toLowerCase();
			} else {
				color = getComputedStyle(header, null).getPropertyValue("color");
			}
            
            color = this.rgbToHsl(color);
            this.textColor = 
            {
                hue: color[0],
                sat: color[1],
                lt: color[2]
            };
            this.setTextColor();
        },
        
        rgbToHsl: function(color){ // calculate hsl from rgb css color string
            var hue = 0, sat = 0, lt;
            
            var rgb = this.getRgb(color);
            var max = Math.max.apply(Math, rgb);
            var min = Math.min.apply(Math, rgb);
            var chroma = max - min;
            
            var index = rgb.indexOf(max);
            rgb.splice(index, 1);
            
            lt = (max + min) / 2;
            if (chroma) {
                sat = (lt > 0.5) ? (max - min) / (2 - (max + min)) : (max - min) / (max + min);
                hue = 60 * ((rgb[0] - rgb[1]) / (max - min) + index * 2);
            }
            
            return [hue, sat * 100, lt * 100];
        },
        
        getRgb: function(color){
            var rgb;
            
            if ((rgb = /(\d+), (\d+), (\d+)/.exec(color))) {
                rgb = rgb.slice(1);
                return [rgb[0] / 255, rgb[1] / 255, rgb[2] / 255];
            }
            
            // Opera return a hex value, so convert hex to decimal
            if ((rgb = /#(......)/.exec(color))) {
                rgb = parseInt(rgb[1], 16);
                var red = rgb >> 16;
                var grn = (rgb - (red << 16)) >> 8;
                var blu = rgb - (red << 16) - (grn << 8);
                return [red / 255, grn / 255, blu / 255];
            }
            
            return [1, 0, 0];
        },
        
        setTextColor: function(){
            var hue = this.textColor.hue;
            var sat = this.textColor.sat;
            var lt = this.textColor.lt;
            
            // default color lightnesses:
            // bg lt: 85.3
            // color lt: 0
            
            // text lightnesses are set to values in the range between title text and
            // background color lightnesses
            var range = this.bgColor.lt - lt;
            
            var css = "  color: hsl(" + hue + "," + sat + "%, ";
            css += ("" +
            "#entries .collapsed .entry-title {" +
            css +
            lt +
            "% ) !important;" + // 000000 <- default color
            "}" +
            "#entries.list .collapsed .entry-main .entry-source-title {" +
            css +
            (lt + range * 0.42) +
            "% ) !important;" + // 555555
            "}" +
            ".entry .entry-author," +
            ".entry-comments .comment-time, .entry .entry-date {" +
            css +
            (lt + range * 0.50) +
            "% ) !important;" + // 666666
            "}" +
            "#entries.list .collapsed .entry-secondary {" +
            css +
            (lt + range * 0.59) +
            "% ) !important;" + // 777777
            "}" +
            // "a, a:visited, .link {" + // shouldn't need to mess with link color
            // css + lt + "% ) !important;" + // 2244BB
            // "}" + 
            "#entries .item-body {" +
            css +
            lt +
            "% ) !important;" + // 000000
            "}");
			
			//this.styles.innerText+=css;
			GM_addStyle(css, 'colorful');
        },
        
        // inject color css into the page
        processEntries: function(){
			this.process(this.bgColor, this.styles, 
				"id('entries')/div[contains(@class,'entry')][not(@colored)]", 
				".//*[ contains(concat( ' ', normalize-space( @class ), ' '),' entry-source-title ' ) ]",
				this);
		},
		processNodes: function(e){
			this.process(this.bgColor, this.styles, 
				"id('sub-tree')//li[contains(@class, 'sub')][contains(@class, 'unread')][not(@colored)]",
				".//span[contains(@class,'name')]/@title",
				 this);
	        
        },
		process: function(bgColor, styles, xpath, xpathText, thm){
            // pick up all uncolored entries, including ones missed previously
            var nocolor = getElements(xpath);
			if (!nocolor.length) {
                return;
            }
            nocolor.forEach(function(nc){
				thm.setColor(styles, bgColor, xpathText, nc);
            });
		},
			
        setColor: function(styles, bgColor, xpathText, nc){
            // source in header is: "<a>" for expanded/comment view
            //                      "<span>" for list view
            // if "Shared by [xxx]" is there this will grab that
            // search for a node that has 'entry-source-title' class name
            var src = getElementValue(xpathText, nc);
            src = src.textContent.replace(/\s+\(\d+\)$/, "").replace(/\W/g, "-");
			
			//console.log(src);
			
            nc.setAttribute("colored", src);
            if (typeof this.colors[src] == "undefined") {
				//console.log('CSS for '+src);
				//styles.innerText += this.getColorCss(src, bgColor);
				GM_addStyle(this.getColorCss(src, bgColor), 'color_'+src)
            }
        },
        
        getColorCss: function(title, bgColor){ // generate css to color items
            var hue = this.getHue(title);
            var sat = bgColor.sat;
            var lt = bgColor.lt;
            
            // set direction entry lightness is modified on read/hover
            var dir = (lt > 50) ? 1 : -1;
            
            var hsl = 
            {
                norm: "background-color: hsl(" +
                hue +
                "," +
                (sat + 7) +
                "%," +
                (lt - dir * 5) +
                "% ) !important;",
                hover: "background-color: hsl(" +
                hue +
                "," +
                (sat + 27) +
                "%, " +
                lt +
                "% ) !important;",
                read: "background-color: hsl(" +
                hue +
                "," +
                (sat - 13) +
                "%," +
                (lt + dir * 5) +
                "% ) !important;",
                readhvr: "background-color: hsl(" +
                hue +
                "," +
                (sat + 7) +
                "%," +
                (lt + dir * 10) +
                "% ) !important;"
            };
        
	        var css = this.getLvCss(title, hsl) + this.getEvCss(title, hsl) + this.getEfCss(title, hsl) + this.getCvCss(title, hsl);
	        if (prefs.colorful_tree) {
	            css += this.getTreeCss(title, hsl);
	        }
	        return css;
        },
        
        getLvCss: function(ttl, hsl){ // css for coloring items in list view
            // this selector should be take priority over any other selector
            var us = "#entries.gm-color-lv.gm-color-ui div[ colored='" + ttl + "' ]";
            var rs = "#entries.gm-color-lv.gm-color-ri div[ colored='" + ttl + "' ]";
            
            return "" +
            us +
            " .collapsed {" +
            hsl.norm +
            "}" +
            us +
            ":hover .collapsed {" +
            hsl.hover +
            "}" +
            us +
            ".read .collapsed," +
            us +
            ".read:hover .collapsed {background-color: white !important; }" +
            rs +
            ".read .collapsed {" +
            hsl.read +
            "}" +
            rs +
            ".read:hover .collapsed { " +
            hsl.readhvr +
            "}";
        },
        
        // css for coloring expanded view item bodies
        getEvCss: function(ttl, hsl){
            var us = "#entries.gm-color-ev.gm-color-ui div[ colored='" + ttl + "' ]";
            var rs = "#entries.gm-color-ev.gm-color-ri div[ colored='" + ttl + "' ]";
            
            return "" +
            us +
            " .card," +
            /* .ccard, .t2, .t3 used for Opera expanded view 
            us +
            " .ccard," +
            us +
            " .t2," +
            us +
            " .t3 {" +
            hsl.norm +
            "}" +
            */
            us +
            ":hover .card," +
            us +
            ":hover .ccard," +
            us +
            ":hover .t2," +
            us +
            ":hover .t3 {" +
            hsl.hover +
            "}" +
            
            us +
            ".read .card," +
            us +
            ".read .ccard," +
            us +
            ".read .t2," +
            us +
            ".read .t3," +
            us +
            ".read:hover .card," +
            us +
            ".read:hover .ccard," +
            us +
            ".read:hover .t2," +
            us +
            ".read:hover .t3 { background-color: white !important; }" +
            rs +
            ".read .card," +
            rs +
            ".read .ccard," +
            rs +
            ".read .t2," +
            rs +
            ".read .t3 { " +
            hsl.read +
            "}" +
            rs +
            ".read:hover .card," +
            rs +
            ".read:hover .ccard," +
            rs +
            ".read:hover .t2," +
            rs +
            ".read:hover .t3 {" +
            hsl.readhvr +
            "}";
        },
        
        // css for coloring expanded view item frames
        getEfCss: function(ttl, hsl){
            var us = "#entries.gm-color-ef.gm-color-ui div[ colored='" + ttl + "' ]";
            var rs = "#entries.gm-color-ef.gm-color-ri div[ colored='" + ttl + "' ]";
            
            return "" +
            us +
            " {" +
            hsl.norm +
            "}" +
            us +
            ":hover {" +
            hsl.hover +
            "}" +
            us +
            ".read," +
            us +
            ".read:hover { " +
            "background-color: #F3F5FC !important; }" +
            rs +
            ".read {  " +
            hsl.read +
            "}" +
            rs +
            ".read:hover { " +
            hsl.readhvr +
            "}";
        },
        
        getCvCss: function(ttl, hsl){
            var us = "#entries.gm-color-cv.gm-color-ui div[ colored='" + ttl + "' ]";
            var rs = "#entries.gm-color-cv.gm-color-ri div[ colored='" + ttl + "' ]";
            
            // comment view doesn't have read/unread
            return "" +
            us +
            " .comment-entry {" +
            hsl.norm +
            "}" +
            us +
            ":hover .comment-entry {" +
            hsl.hover +
            "}" +
            us +
            ".read .comment-entry," +
            us +
            ".read:hover .comment-entry {" +
            "background-color: white !important; }" +
            rs +
            ".read .comment-entry {" +
            hsl.read +
            "}" +
            rs +
            ".read:hover .comment-entry {" +
            hsl.readhvr +
            "}";
        },

		getTreeCss: function(ttl, hsl){
            var us = "#sub-tree li[ colored='" + ttl + "' ]";
	        return us + " {" + hsl.norm +"}" +
	        us + ":hover{" + hsl.hover + "}";
	    },
        
        getHue: function(title){ // calculate item hue
            var hue = 0;
            
            for (var i = 0, ch; (ch = title[i]); i++) {
                hue += ch.charCodeAt(0);
            }
            hue %= 360;
            
            this.colors[title] = hue;
            return hue;
        }
    };
    
	GM_getValue("colorful_settings", {}, function(o){
			var a = [];
            a.push(o['gm-color-lv']||"gm-color-lv");
            a.push(o['gm-color-ev']||"gm-color-ev");
            a.push(o['gm-color-ef']||"");
            a.push(o['gm-color-cv']||"");
            a.push(o['gm-color-ui']||"gm-color-ui");
            a.push(o['gm-color-ri']||"gm-color-ri");
			var settings=a.join(" ");
			
	    var chrome = get_id("chrome");
	    theme.init(chrome, settings);	
	});

    GM_addStyle(BASE_CSS);
};
/**
 * Reader Plus
 *
 * Adds favicons to feeds and entries
 *
 * Author : LudoO
 *
 * ChangeLog: cf about.html
 */
(function(){
    var ReaderPlus = {
        init: function(){
            console.log("Starts ReaderPlus");
            window.GRP = window.GRP || {};
            GRP.language = function(){
                //dummy
            };
            GRP.fns = [];
			GRP.IMAGES_PATH = LOCALPATH + '/images';
            this.prefs = {};
            var me = this;
            mycore.extension.sendRequest({
                message: "getprefs"
            }, function(a){
                me.prefs = a.prefs;
                me.initprefs.call(me);
            });
			
			mycore.page.listen(function(a){
				if (a.message === 'export') {
					mycore.extension.sendRequest({
						message: 'exported',
						entries: me.getExportedEntries(),
						dir: getSelectedDir()
					});
				}
			});
        },
        initprefs: function(){
            this.lang = this.prefs.language_lang || 'en';
            loadLangs(this.lang, function(){
                console.log("ReaderPlus in " + this.lang);
                this.runExtra();
                this.fixMenu();
            }, this);
        },
		getExportedEntries: function(){
			var root = get_id('entries');
			var entries = root.getElementsByClassName('entry-main');
			var r= [];
			foreach(entries, function(entry){
				r.push(entry.innerHTML);
			});	
			return r;
		},
        runExtra: function(){
            var count = 0;
            if (GRP.scripts) {
                var langs = GRP.langs[this.lang].texts;
                iterate(GRP.scripts, function(id, script){
                    if (script && this.prefs[id]) {
                        ++count;
                        this.run(id, langs);
                    }
                }, this, true);
                console.log("ReaderPlus is running with " + count + "/" + getCount(GRP.scripts) + " features");
                //Start entries monitoring 
                monitorEntries();
                if (GRP.fns && GRP.fns.length > 0) {
                    function priorityfns(a, b){
                        return (a.priority - b.priority);
                    }
                    GRP.fns.sort(priorityfns);
                    foreach(GRP.fns, function(o){
                        if (o.fn) {
                            console.log('Run priority ' + o.id + ' - ' + o.priority);
                            if (o.delay) {
								window.setTimeout(o.fn, o.delay);
							} else {
								o.fn();
							}
                        }
                    });
                }
            } else {
                console.error("ReaderPlus failed to load any features!!");
            }
        },
        run: function(o, langs){
            if (o && o !== "false") {
                if (o == 'theme') {
                    //skin
                    console.log("**** run " + o);
                    GRP.theme(this.prefs, langs, this);
					track('theme', o);
                } else {
                    if (window.GRP[o]) {
                        console.log("**** run " + o);
                        try {
                            //console.log("myport(run) "+this.myport.portId_);
                            window.GRP[o].call(window, this.prefs, langs, o, langs[o]||{}, this.lang);
							track('feature', o);
                        } catch (e) {
                            console.error(e);
                        }
                    } else {
                        console.log("ERROR: can't run " + o);
                    }
                }
            }
        },
        fixMenu: function(langs){
			//dh('gbg', 'br', {cls: 'brmenu'});
			addReaderMenuItem(getText(this.lang, 'ig', 'menu_prefs', 'en', 'Reader+ preferences'), 
                function(){
                    GM_openInTab(mycore.getUrl('/preferences.html'));
                }
            );
            addReaderMenuItem(getText(this.lang, 'ig', 'menu_theme', 'en', 'Theme configuration'), 
                function(){
                    GM_openInTab(mycore.getUrl('/preferences.html#theme'));
                }
            );
			addReaderMenuItem(getText(this.lang, 'menu', 'showallfolders', 'en', 'Show all folders'), 
                showallfolders, true
            );
			addReaderMenuItem(getText(this.lang, 'general', 'menu_clearcache', 'en', 'Clear cache'), 
                function(){
                    clearcache(this.lang);
                }
            );
			addReaderMenuItem(getText(this.lang, 'general', 'menu_removeread', 'en', 'Remove read items'), 
                 function(){
                    removeReadItems();
                }
            );
        }
    };
    ReaderPlus.init();
})();

function track(name, value){
	mycore.extension.sendRequest({
                message: "track",
				name:name, 
				value: value
    });
}
